<?php
/**
 * Quiet Truths — Search results
 *
 * Two modes, both powered by the background ontology:
 *
 *  - Text search (?s=…): stories + pages + journals, expanded through
 *    concepts, threads, domains and semantic signals (hybrid search;
 *    lexical → concept → semantic, per Bible XXXIV / Correction 17).
 *  - Concept search (?qt_concept=hope): every story that is ABOUT hope,
 *    found through the invisible layer — not by matching the word.
 *    Concepts are background ontology; they power discovery but are
 *    not a public taxonomy of landing pages (Bible §XXI).
 *
 * The eight legacy "Doors" (?qt_theme=family etc.) were retired as a
 * public surface in v1.7.1. Core\Themes intercepts them earlier in
 * template_redirect and 301s them to the search page, so no old
 * bookmark dies. No door markup or door wording is rendered here.
 *
 * Rooms are never shown as search results — they are placeholders of
 * belonging, not answers.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

$qt_concept_slug = sanitize_key(get_query_var('qt_concept'));
$qt_is_concept   = '' !== $qt_concept_slug;

if ($qt_is_concept) {
    $qt_result = \QuietTruths\Core\Search::runConcept($qt_concept_slug);
    $qt_raw    = '';
    $qt_hasHit = $qt_result['total'] > 0 || null !== $qt_result['page'];
} else {
    $qt_raw    = get_search_query(false);
    $qt_result = \QuietTruths\Core\Search::run($qt_raw);
    $qt_hasHit = $qt_result['total'] > 0 || null !== $qt_result['page'];
}
?>

<main id="qt-main">

    <header class="room-header">
        <?php echo qt_room_symbol('letters'); ?>
        <h1 class="room-header__name">
            <?php
            if ($qt_is_concept) {
                /* translators: %s: the concept name (e.g. "Hope") */
                printf(esc_html__('Stories about %s', 'quiet-truths'), esc_html($qt_result['query']));
            } elseif ('' !== $qt_raw) {
                /* translators: %s: the search query */
                printf(esc_html__('Searching for "%s"', 'quiet-truths'), esc_html($qt_raw));
            } else {
                echo esc_html__('Search the house', 'quiet-truths');
            }
            ?>
        </h1>

        <?php if (($qt_is_concept || '' !== $qt_raw)) : ?>
            <p class="room-header__description">
                <?php
                if ($qt_is_concept) {
                    echo esc_html(sprintf(
                        /* translators: %1$d number of held pieces, %2$s concept name */
                        _n('%1$d held here about %2$s', '%1$d held here about %2$s', $qt_result['total'], 'quiet-truths'),
                        $qt_result['total'],
                        $qt_result['query']
                    ));
                } else {
                    echo esc_html(sprintf(
                        /* translators: %d number of results */
                        _n('%d result found', '%d results found', $qt_result['total'], 'quiet-truths'),
                        $qt_result['total']
                    ));
                }
                ?>
            </p>
        <?php endif; ?>
    </header>

    <div class="reading-container reading-container--narrow">
        <?php qt_search_bar($qt_is_concept ? '' : $qt_raw); ?>
    </div>

    <div class="story-feed" style="padding-top:0">

        <?php if ('' === $qt_raw && !$qt_is_concept) : ?>

            <?php qt_gentle_notice('reflection', __('Search the shelves — or begin with one of the words below.', 'quiet-truths')); ?>
            <div class="search-invitation__examples u-mt-lg">
                <?php qt_concept_chips(['hope', 'joy', 'peace', 'courage', 'forgiveness', 'home']); ?>
            </div>

        <?php elseif (!$qt_hasHit) : ?>

            <?php
            if ($qt_is_concept) {
                qt_gentle_notice('reflection', sprintf(
                    /* translators: %s: the concept name */
                    __('Nothing about %s has been left yet — the house grows slowly. Perhaps one of these instead:', 'quiet-truths'),
                    $qt_result['query']
                ));
            } else {
                qt_gentle_notice('reflection', __('Nothing was found for that — but the rooms are still open. Try another word, or one of these close to it:', 'quiet-truths'));
            }
            ?>

            <?php if (!empty($qt_result['suggestions'])) : ?>
                <div class="search-invitation__examples u-mt-lg">
                    <?php if ($qt_is_concept) : ?>
                        <?php qt_concept_chips(array_slice($qt_result['suggestions'], 0, 6)); ?>
                    <?php else : ?>
                        <?php foreach ($qt_result['suggestions'] as $qt_suggestion) : ?>
                            <a class="search-invitation__example" href="<?php echo esc_url(home_url('/?s=' . rawurlencode($qt_suggestion))); ?>"><?php echo esc_html($qt_suggestion); ?></a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="u-text-center u-mt-xl">
                <?php qt_button(home_url('/stories/'), __('Wander the house', 'quiet-truths'), 'quiet'); ?>
            </div>

        <?php else : ?>

            <?php if (null !== $qt_result['page']) : ?>
                <?php $qt_page = $qt_result['page']; ?>
                <article class="story-panel">
                    <div class="story-panel__room">
                        <span class="story-panel__room-symbol" aria-hidden="true"></span>
                        <?php echo esc_html__('Page', 'quiet-truths'); ?>
                    </div>
                    <h3 class="story-panel__title">
                        <a href="<?php echo esc_url(get_permalink($qt_page)); ?>"><?php echo esc_html($qt_page->post_title); ?></a>
                    </h3>
                    <p class="story-panel__excerpt"><?php echo esc_html(wp_trim_words(wp_strip_all_tags((string) $qt_page->post_content), 30, '…')); ?></p>
                </article>
            <?php endif; ?>

            <?php
            // Journals are gathered apart — they are the deeper reading.
            $qt_result_journals = array_values(array_filter(
                $qt_result['results'],
                static fn ($qt_p) => 'qt_journal' === ($qt_p->post_type ?? '')
            ));
            ?>

            <?php foreach ($qt_result['results'] as $qt_post) : ?>
                <?php if ('qt_story' === $qt_post->post_type) : ?>
                    <?php qt_story_panel($qt_post, false); ?>
                <?php elseif ('qt_journal' === $qt_post->post_type) : ?>
                    <?php continue; ?>
                <?php else : ?>
                    <article class="story-panel">
                        <h3 class="story-panel__title"><a href="<?php echo esc_url(get_permalink($qt_post)); ?>"><?php echo esc_html($qt_post->post_title); ?></a></h3>
                        <p class="story-panel__excerpt"><?php echo esc_html(wp_trim_words(wp_strip_all_tags((string) $qt_post->post_content), 30, '…')); ?></p>
                        <div class="story-panel__time"><?php echo esc_html(get_the_date('j M Y', $qt_post)); ?></div>
                    </article>
                <?php endif; ?>
            <?php endforeach; ?>

            <?php if (!empty($qt_result_journals)) : ?>
                <section class="search-journals">
                    <p class="rooms-section__label"><?php echo esc_html__('In depth — from the Journals', 'quiet-truths'); ?></p>
                    <p class="search-journals__note">
                        <?php echo esc_html__('The Journals hold longer reflections, written by named voices. If one of these continues what you are looking for, it may carry you further.', 'quiet-truths'); ?>
                    </p>
                    <?php foreach ($qt_result_journals as $qt_jpost) : ?>
                        <?php qt_journal_card($qt_jpost); ?>
                    <?php endforeach; ?>
                </section>
            <?php endif; ?>

            <?php if ($qt_result['max_pages'] > 1) : ?>
                <div class="u-text-center u-mt-2xl">
                    <?php
                    echo paginate_links([
                        'total'     => $qt_result['max_pages'],
                        'current'   => $qt_result['paged'],
                        'prev_text' => '←',
                        'next_text' => '→',
                        'type'      => 'list',
                        'add_args'  => $qt_is_concept ? ['qt_concept' => $qt_concept_slug] : [],
                    ]);
                    ?>
                </div>
            <?php endif; ?>

        <?php endif; ?>

    </div>

    <section class="starting-point">
        <p class="starting-point__label"><?php echo esc_html__('Still looking?', 'quiet-truths'); ?></p>
        <p class="starting-point__guide">
            <?php echo esc_html__('Sometimes the story you are looking for has not been left yet. The house receives them slowly, so that each one is held properly.', 'quiet-truths'); ?>
        </p>
        <?php qt_button(home_url('/leave-a-story/'), __('Leave a story', 'quiet-truths'), 'quiet'); ?>
    </section>

</main>

<?php get_footer(); ?>
