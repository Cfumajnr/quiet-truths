<?php
/**
 * Quiet Truths — Story archive (post type: qt_story)
 *
 * The collection. Four quiet layers: arrival, one search, ways of
 * wandering, and the shelf. No statistics, no images, no cards.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

$qt_sort = sanitize_key(wp_unslash((string) ($_GET['qt_sort'] ?? '')));
?>

<main id="qt-main">

    <!-- 1 · Arrival -->
    <header class="library-header">
        <h1 class="library-header__title"><?php echo esc_html__('The Collection', 'quiet-truths'); ?></h1>
        <p class="library-header__line"><?php echo esc_html__('You are now in the collection.', 'quiet-truths'); ?></p>
    </header>

    <!-- 2 · One search — it assists, it does not invite -->
    <div class="library-search">
        <p class="library-search__line">
            <?php echo esc_html__('Not sure what to read? Type anything — a feeling, a word, a question — and begin there.', 'quiet-truths'); ?>
        </p>
        <?php qt_search_bar(''); ?>
        <div class="qt-live-suggest" id="qt-live-suggest-library" hidden></div>
    </div>

    <!-- 3 · Ways of wandering -->
    <section class="library-wander" aria-label="<?php echo esc_attr__('Ways of wandering', 'quiet-truths'); ?>">
        <p class="library-wander__label"><?php echo esc_html__('Ways of wandering', 'quiet-truths'); ?></p>
        <div class="library-wander__chips">
            <a class="library-wander__chip<?php echo 'recent' === $qt_sort ? ' is-active' : ''; ?>" href="<?php echo esc_url(add_query_arg('qt_sort', 'recent', get_post_type_archive_link('qt_story'))); ?>">
                <?php echo esc_html__('Recently shared', 'quiet-truths'); ?>
            </a>
            <a class="library-wander__chip<?php echo 'responded' === $qt_sort ? ' is-active' : ''; ?>" href="<?php echo esc_url(add_query_arg('qt_sort', 'responded', get_post_type_archive_link('qt_story'))); ?>">
                <?php echo esc_html__('Most responded to', 'quiet-truths'); ?>
            </a>
            <a class="library-wander__chip<?php echo 'short' === $qt_sort ? ' is-active' : ''; ?>" href="<?php echo esc_url(add_query_arg('qt_sort', 'short', get_post_type_archive_link('qt_story'))); ?>">
                <?php echo esc_html__('Short reads', 'quiet-truths'); ?>
            </a>
            <a class="library-wander__chip<?php echo 'long' === $qt_sort ? ' is-active' : ''; ?>" href="<?php echo esc_url(add_query_arg('qt_sort', 'long', get_post_type_archive_link('qt_story'))); ?>">
                <?php echo esc_html__('Long reads', 'quiet-truths'); ?>
            </a>
        </div>
    </section>

    <!-- 3b · The seven rooms of the house -->
    <?php if (function_exists('qt_get_rooms')) : ?>
        <?php $qt_rooms = qt_get_rooms(); ?>
        <?php if (!empty($qt_rooms)) : ?>
            <section class="library-rooms" aria-label="<?php echo esc_attr__('The rooms of the house', 'quiet-truths'); ?>">
                <p class="library-rooms__label"><?php echo esc_html__('Or enter a room', 'quiet-truths'); ?></p>
                <div class="library-rooms__chips">
                    <?php foreach ($qt_rooms as $qt_room) : ?>
                        <a class="library-rooms__chip" href="<?php echo esc_url($qt_room['href'] ?? qt_room_url($qt_room['slug'])); ?>">
                            <?php echo esc_html($qt_room['name']); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>
    <?php endif; ?>

    <!-- 4 · The shelf -->
    <section class="library-shelf" aria-label="<?php echo esc_attr__('The stories', 'quiet-truths'); ?>">
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <?php qt_story_row(get_the_ID()); ?>
            <?php endwhile; ?>
        <?php else : ?>
            <?php qt_gentle_notice('reflection', __('The shelves are still being filled. When a story is left here, it will be held with care — and read slowly.', 'quiet-truths')); ?>
        <?php endif; ?>
    </section>

    <?php if ($wp_query->max_num_pages > 1) : ?>
        <?php qt_pagination(); ?>
    <?php endif; ?>

</main>

<?php get_footer(); ?>
