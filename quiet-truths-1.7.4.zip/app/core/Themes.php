<?php
/**
 * Quiet Truths — Legacy "Themes / Doors" compatibility shim.
 *
 * ⚠️  COMPATIBILITY-ONLY.  ⚠️
 *
 * v1.6–v1.7.0 exposed eight reader-facing "Doors" (family, work,
 * tradition, faith, love, loss, growth, healing) as a second public
 * discovery surface at ?qt_theme=<slug>. v1.7.1 retired those pages
 * and this class now exists solely to:
 *
 *   1. Register `qt_theme` as a recognised query var so we can
 *      intercept legacy bookmarks.
 *   2. 301-redirect every ?qt_theme=<slug> hit to a normal search
 *      for that theme's human name — no landing page renders, no
 *      Door component is ever served (Corrections 1, 3, 12, 14).
 *
 * Do not add new routes here. Do not add discovery logic here.
 * Future discovery runs through Core\Search + the background
 * ontology (Concepts / Threads / Domains / Context / Signals /
 * Relationships).
 *
 * Removal plan: once access logs show ?qt_theme= URLs receive no
 * meaningful traffic for one full release cycle (~3 months), this
 * file, the `qt_theme` query var, and app/config/themes.php may be
 * deleted together.
 *
 * @package QuietTruths
 * @subpackage Core
 * @deprecated 1.7.3 Compatibility-only. Do not build new features here.
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Themes
{
    private static ?array $data = null;

    public static function init(): void
    {
        // Register qt_theme only so we can intercept it and 301.
        add_filter('query_vars', static function (array $vars): array {
            $vars[] = 'qt_theme';
            return $vars;
        });

        // Any direct hit on ?qt_theme=<slug> becomes a normal search
        // for that theme's human name. Legacy bookmarks keep working;
        // no door page is ever rendered.
        add_action('template_redirect', [self::class, 'redirectLegacyTheme'], 1);
    }

    /**
     * Load the legacy config file (migration-only). Returns [] if the
     * file is absent.
     */
    public static function data(): array
    {
        if (null === self::$data) {
            $path = dirname(__DIR__) . '/config/themes.php';
            self::$data = is_file($path) ? (array) require $path : [];
        }
        return self::$data;
    }

    /**
     * Look up a single legacy theme entry by slug. Used only to resolve
     * the human name for the 301 redirect.
     */
    public static function theme(string $slug): ?array
    {
        return self::data()[$slug] ?? null;
    }

    /**
     * 301 any incoming ?qt_theme= request to the canonical search page.
     *
     * /?qt_theme=family   → /?s=Family
     * /?qt_theme=healing  → /?s=Healing
     * unknown slugs       → home page
     */
    public static function redirectLegacyTheme(): void
    {
        if (is_admin() || wp_doing_ajax() || wp_doing_cron()) {
            return;
        }

        $slug = get_query_var('qt_theme');
        if ('' === (string) $slug) {
            return;
        }

        $slug  = sanitize_key((string) $slug);
        $theme = self::theme($slug);
        $target = ($theme && !empty($theme['name']))
            ? home_url('/?s=' . rawurlencode((string) $theme['name']))
            : home_url('/');

        wp_safe_redirect($target, 301);
        exit;
    }
}
