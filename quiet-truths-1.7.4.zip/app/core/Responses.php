<?php
/**
 * Quiet Truths — Anonymous Responses
 *
 * A fully custom response system for stories. No names, no emails, no
 * accounts — just words, held before they appear.
 *
 *  - post type qt_response; replies are child posts (post_parent).
 *  - every response starts "pending" and is approved by the house.
 *  - a random edit token (cookie + post meta) lets the writer correct
 *    their own words later.
 *  - rate limiting stops floods; a profanity filter (bad-words.php)
 *    refuses abusive words and phrases outright.
 *  - any reader can report a response; enough reports hold it quietly
 *    for review.
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Responses
{
    private const NONCE_CREATE = 'qt_new_response';
    private const NONCE_REPORT = 'qt_report_response_';
    private const COOKIE       = 'qt_edit_tokens';

    /** @var list<string> */
    private static array $errors = [];

    /** @var array<string,string> */
    private static array $old = [];

    public static function init(): void
    {
        add_action('init', [self::class, 'registerPostType']);
        add_action('template_redirect', [self::class, 'maybeHandleCreate']);
        add_action('template_redirect', [self::class, 'maybeHandleEdit']);
        add_action('template_redirect', [self::class, 'maybeHandleReport']);
        add_action('save_post_qt_response', [self::class, 'ensureTitle'], 10, 2);
        add_action('admin_post_qt_approve_response', [self::class, 'handleApprove']);
        add_action('admin_notices', [self::class, 'adminNotice']);
        add_filter('post_row_actions', [self::class, 'rowActions'], 10, 2);
        add_filter('manage_qt_response_posts_columns', [self::class, 'adminColumns']);
        add_action('manage_qt_response_posts_custom_column', [self::class, 'adminColumnValue'], 10, 2);
    }

    /* ─────────────── registration ─────────────── */

    public static function registerPostType(): void
    {
        register_post_type('qt_response', [
            'labels' => [
                'name'          => __('Responses', 'quiet-truths'),
                'singular_name' => __('Response', 'quiet-truths'),
                'add_new'       => __('Add Response', 'quiet-truths'),
                'add_new_item'  => __('Add a Response', 'quiet-truths'),
                'edit_item'     => __('Edit Response', 'quiet-truths'),
                'new_item'      => __('New Response', 'quiet-truths'),
                'view_item'     => __('View Response', 'quiet-truths'),
                'search_items'  => __('Search Responses', 'quiet-truths'),
                'not_found'     => __('No responses yet.', 'quiet-truths'),
                'menu_name'     => __('Responses', 'quiet-truths'),
            ],
            'public'             => false,
            'publicly_queryable' => false,
            'exclude_from_search'=> true,
            'show_ui'            => true,
            'show_in_menu'       => 'edit.php?post_type=qt_story',
            'show_in_rest'       => false,
            'menu_position'      => 25,
            'rewrite'            => false,
            'supports'           => ['editor'],
            'capability_type'    => 'post',
            'map_meta_cap'       => true,
        ]);
    }

    /**
     * Responses need a title for the admin list; derive one from the words.
     */
    public static function ensureTitle(int $postId, $post): void
    {
        if ('' !== trim((string) $post->post_title)) {
            return;
        }

        $text = trim(wp_strip_all_tags((string) $post->post_content));
        $text = preg_replace('/\s+/u', ' ', $text) ?: '';
        $title = function_exists('mb_substr') ? mb_substr($text, 0, 48) : substr($text, 0, 48);

        if ('' !== $title) {
            wp_update_post(['ID' => $postId, 'post_title' => $title]);
        }
    }

    /* ─────────────── view state ─────────────── */

    /** @return list<string> */
    public static function errors(): array
    {
        return self::$errors;
    }

    /** @return array<string,string> */
    public static function old(): array
    {
        return self::$old;
    }

    /* ─────────────── creation ─────────────── */

    public static function maybeHandleCreate(): void
    {
        if (!is_singular('qt_story')) {
            return;
        }
        if (empty($_POST['qt_resp_action']) || 'create' !== $_POST['qt_resp_action']) {
            return;
        }

        $storyId = get_queried_object_id();
        $back    = get_permalink($storyId) . '#qt-responses';

        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce(sanitize_key(wp_unslash((string) $_POST['_wpnonce'])), self::NONCE_CREATE)) {
            self::fail('session', $back);
        }

        // Honeypot: pretend it was held, tell no one.
        if (!empty($_POST['qt_website'])) {
            wp_safe_redirect(add_query_arg('qt_resp', '1', $back));
            exit;
        }

        if ('publish' !== get_post_status($storyId)) {
            self::fail('invalid', $back);
        }

        $parentId = absint($_POST['qt_parent'] ?? 0);

        if ($parentId > 0) {
            $parent = get_post($parentId);
            if (!$parent || 'qt_response' !== $parent->post_type || 'publish' !== $parent->post_status
                || (int) get_post_meta($parentId, '_qt_story_id', true) !== $storyId) {
                self::fail('invalid', $back);
            }
        }

        if (!self::passesRateLimit('create')) {
            self::fail('rate', $back);
        }

        $text = isset($_POST['qt_response']) ? sanitize_textarea_field(wp_unslash((string) $_POST['qt_response'])) : '';
        self::$old = ['response' => $text];

        $maxLen = (int) apply_filters('quiet_truths_response_max_length', 1000);
        $minLen = (int) apply_filters('quiet_truths_response_min_length', 2);
        $len    = function_exists('mb_strlen') ? mb_strlen($text) : strlen($text);

        if ($len < $minLen) {
            self::fail('short', $back);
        }
        if ($len > $maxLen) {
            self::fail('long', $back);
        }
        if (self::containsForbidden($text)) {
            self::fail('profanity', $back);
        }

        // Consent confirmations are required for top-level responses;
        // replies inherit the conversation context but still use the
        // same editorial/moderation safeguards.
        if (0 === $parentId) {
            if (empty($_POST['qt_consent_age_rules'])) {
                self::fail('consent_age', $back);
            }
            if (empty($_POST['qt_consent_publish'])) {
                self::fail('consent_publish', $back);
            }
        }

        $token = wp_generate_password(24, false);

        $responseId = wp_insert_post([
            'post_type'    => 'qt_response',
            'post_status'  => 'pending',
            'post_title'   => '',
            'post_content' => $text,
            'post_author'  => 0, // anonymous
            'post_parent'  => $parentId,
        ], true);

        if (is_wp_error($responseId)) {
            error_log('Quiet Truths: could not store a response — ' . $responseId->get_error_message());
            self::fail('store', $back);
        }

        update_post_meta($responseId, '_qt_story_id', $storyId);
        update_post_meta($responseId, '_qt_edit_token', $token);
        if (0 === $parentId) {
            update_post_meta($responseId, '_qt_consent_at', current_time('mysql', true));
            update_post_meta($responseId, '_qt_consent_version', defined('QT_THEME_VERSION') ? QT_THEME_VERSION : '1.0');
            update_post_meta($responseId, '_qt_consent_age_rules', '1');
            update_post_meta($responseId, '_qt_consent_publish', '1');
        }
        self::rememberToken($responseId, $token);

        wp_safe_redirect(add_query_arg('qt_resp', '1', $back));
        exit;
    }

    /* ─────────────── editing ─────────────── */

    public static function maybeHandleEdit(): void
    {
        if (!is_singular('qt_story')) {
            return;
        }
        if (empty($_POST['qt_resp_action']) || 'edit' !== $_POST['qt_resp_action']) {
            return;
        }

        $responseId = absint($_POST['qt_response_id'] ?? 0);
        $back       = get_permalink(get_queried_object_id()) . '#response-' . $responseId;

        if (!$responseId || !isset($_POST['_wpnonce'])
            || !wp_verify_nonce(sanitize_key(wp_unslash((string) $_POST['_wpnonce'])), 'qt_edit_response_' . $responseId)) {
            self::fail('session', $back);
        }

        $response = get_post($responseId);
        if (!$response || 'qt_response' !== $response->post_type) {
            self::fail('invalid', $back);
        }

        // Only the writer (the holder of the edit token) may correct it.
        if (self::tokenFor($responseId) !== (self::tokenCookie()[$responseId] ?? '')) {
            self::fail('invalid', $back);
        }

        $text = isset($_POST['qt_response']) ? sanitize_textarea_field(wp_unslash((string) $_POST['qt_response'])) : '';

        $maxLen = (int) apply_filters('quiet_truths_response_max_length', 1000);
        $minLen = (int) apply_filters('quiet_truths_response_min_length', 2);
        $len    = function_exists('mb_strlen') ? mb_strlen($text) : strlen($text);

        if ($len < $minLen) {
            self::fail('short', $back);
        }
        if ($len > $maxLen) {
            self::fail('long', $back);
        }
        if (self::containsForbidden($text)) {
            self::fail('profanity', $back);
        }

        wp_update_post([
            'ID'           => $responseId,
            'post_content' => $text,
        ]);
        update_post_meta($responseId, '_qt_edited_at', current_time('mysql', true));

        wp_safe_redirect(add_query_arg('qt_edited', '1', $back));
        exit;
    }

    /* ─────────────── reporting ─────────────── */

    public static function maybeHandleReport(): void
    {
        if (!is_singular('qt_story')) {
            return;
        }
        if (empty($_POST['qt_resp_action']) || 'report' !== $_POST['qt_resp_action']) {
            return;
        }

        $responseId = absint($_POST['qt_response_id'] ?? 0);
        $back       = get_permalink(get_queried_object_id()) . '#response-' . $responseId;

        if (!$responseId || !isset($_POST['_wpnonce'])
            || !wp_verify_nonce(sanitize_key(wp_unslash((string) $_POST['_wpnonce'])), self::NONCE_REPORT . $responseId)) {
            self::fail('session', $back);
        }

        $response = get_post($responseId);
        if (!$response || 'qt_response' !== $response->post_type) {
            self::fail('invalid', $back);
        }

        if (!self::passesRateLimit('report')) {
            self::fail('rate', $back);
        }

        $allowedReasons = ['abuse', 'harassment', 'spam', 'personal', 'other'];
        $reason         = isset($_POST['qt_report_reason']) ? sanitize_key(wp_unslash((string) $_POST['qt_report_reason'])) : 'other';
        if (!in_array($reason, $allowedReasons, true)) {
            $reason = 'other';
        }

        $reports = get_post_meta($responseId, '_qt_reports', true);
        $reports = is_array($reports) ? $reports : [];
        $reports[] = ['t' => time(), 'r' => $reason];
        update_post_meta($responseId, '_qt_reports', $reports);

        // Two reports hold the response quietly for the house to review.
        $holdAt = (int) apply_filters('quiet_truths_response_auto_hold_reports', 2);

        if (count($reports) >= $holdAt && 'publish' === $response->post_status) {
            wp_update_post(['ID' => $responseId, 'post_status' => 'pending']);
            update_post_meta($responseId, '_qt_reported', '1');
            error_log('Quiet Truths: response ' . $responseId . ' held after ' . count($reports) . ' reports.');
        }

        wp_safe_redirect(add_query_arg('qt_reported', '1', $back));
        exit;
    }

    /* ─────────────── moderation ─────────────── */

    public static function handleApprove(): void
    {
        $postId = absint($_GET['post_id'] ?? 0);

        if (!$postId) {
            wp_die(__('No response was specified.', 'quiet-truths'));
        }

        check_admin_referer('qt_approve_response_' . $postId);

        $post = get_post($postId);
        if (!$post || 'qt_response' !== $post->post_type) {
            wp_die(__('That is not a response.', 'quiet-truths'));
        }
        if (!current_user_can('edit_post', $postId)) {
            wp_die(__('You are not allowed to do that.', 'quiet-truths'));
        }

        wp_update_post(['ID' => $postId, 'post_status' => 'publish']);
        delete_post_meta($postId, '_qt_reported');

        // Keep the shelf's "Most responded to" honest.
        $storyId = (int) get_post_meta($postId, '_qt_story_id', true);
        if ($storyId > 0) {
            self::touchCount($storyId);
        }

        wp_safe_redirect(admin_url('edit.php?post_type=qt_response&post_status=pending'));
        exit;
    }

    /**
     * Recompute and store how many published responses a story holds,
     * so the Stories shelf can order by it.
     */
    public static function touchCount(int $storyId): void
    {
        global $wpdb;

        $count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*)
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} m ON p.ID = m.post_id
             WHERE p.post_type = %s
               AND p.post_status = %s
               AND m.meta_key = %s
               AND m.meta_value = %d",
            'qt_response',
            'publish',
            '_qt_story_id',
            $storyId
        ));

        update_post_meta($storyId, '_qt_response_count', $count);
    }

    /**
     * @param array<string,string> $actions
     * @return array<string,string>
     */
    public static function rowActions(array $actions, $post): array
    {
        if ('qt_response' !== $post->post_type || 'pending' !== $post->post_status) {
            return $actions;
        }
        if (!current_user_can('edit_post', $post->ID)) {
            return $actions;
        }

        $url = wp_nonce_url(
            admin_url('admin-post.php?action=qt_approve_response&post_id=' . $post->ID),
            'qt_approve_response_' . $post->ID
        );

        $actions['qt_approve'] = sprintf(
            '<a href="%s" aria-label="%s">%s</a>',
            esc_url($url),
            esc_attr__('Approve this response', 'quiet-truths'),
            esc_html__('Approve', 'quiet-truths')
        );

        return $actions;
    }

    public static function adminNotice(): void
    {
        if (!current_user_can('edit_posts')) {
            return;
        }

        $counts  = wp_count_posts('qt_response');
        $pending = (int) ($counts->pending ?? 0);

        if ($pending < 1) {
            return;
        }

        $url = admin_url('edit.php?post_type=qt_response&post_status=pending');

        echo '<div class="notice notice-info"><p>' . wp_kses_post(sprintf(
            /* translators: %1$d count, %2$s "response"/"responses", %3$s URL */
            __('%1$d %2$s waiting to be read, and — if they are kind — held. <a href="%3$s">Open the responses queue</a>.', 'quiet-truths'),
            $pending,
            _n('response', 'responses', $pending, 'quiet-truths'),
            esc_url($url)
        )) . '</p></div>';
    }

    /**
     * @param array<string,string> $columns
     * @return array<string,string>
     */
    public static function adminColumns(array $columns): array
    {
        $new = [];

        foreach ($columns as $key => $label) {
            $new[$key] = $label;
            if ('title' === $key) {
                $new['qt_story'] = __('Story', 'quiet-truths');
            }
        }

        $new['qt_reports'] = __('Reports', 'quiet-truths');

        return $new;
    }

    public static function adminColumnValue(string $column, int $postId): void
    {
        if ('qt_story' === $column) {
            $storyId = (int) get_post_meta($postId, '_qt_story_id', true);
            $story   = $storyId ? get_post($storyId) : null;

            if ($story) {
                echo '<a href="' . esc_url(get_edit_post_link($story->ID)) . '">' . esc_html($story->post_title) . '</a>';
            } else {
                echo '<span class="qt-muted">—</span>';
            }
        }

        if ('qt_reports' === $column) {
            $reports = get_post_meta($postId, '_qt_reports', true);
            $count   = is_array($reports) ? count($reports) : 0;

            if ($count > 0) {
                printf('<span style="color:#b32d2e;font-weight:600">%d</span>', $count);
            } else {
                echo '<span class="qt-muted">0</span>';
            }
        }
    }

    /* ─────────────── helpers ─────────────── */

    private static function fail(string $code, string $back): void
    {
        self::$errors[] = $code;
        set_transient('qt_resp_state', [
            'errors' => self::$errors,
            'old'    => self::$old,
        ], 60);

        wp_safe_redirect($back);
        exit;
    }

    private static function passesRateLimit(string $kind): bool
    {
        $key = 'qt_resp_rate_' . $kind . '_' . md5((string) ($_SERVER['REMOTE_ADDR'] ?? ''));

        $limit = 'report' === $kind
            ? (int) apply_filters('quiet_truths_report_rate_limit', 5)
            : (int) apply_filters('quiet_truths_response_rate_limit', 8);

        $window = 'report' === $kind ? HOUR_IN_SECONDS : 10 * MINUTE_IN_SECONDS;

        $count = (int) get_transient($key);

        if ($count >= $limit) {
            return false;
        }

        set_transient($key, $count + 1, $window);
        return true;
    }

    /**
     * The full blocked list, for the live writing assistant.
     *
     * @return array{words:list<string>,phrases:list<string>}
     */
    public static function badWordsList(): array
    {
        $path = dirname(__DIR__) . '/config/bad-words.php';

        if (!is_file($path)) {
            return ['words' => [], 'phrases' => []];
        }

        $list = require $path;

        if (!is_array($list)) {
            return ['words' => [], 'phrases' => []];
        }

        return [
            'words'   => array_values((array) ($list['words'] ?? [])),
            'phrases' => array_values((array) ($list['phrases'] ?? [])),
        ];
    }

    /**
     * The profanity check. Normalises the text (lowercase, leetspeak,
     * repeated letters, separators) and refuses on any hit.
     */
    public static function containsForbidden(string $text): bool
    {
        $path = dirname(__DIR__) . '/config/bad-words.php';

        if (!is_file($path)) {
            return false;
        }

        $list = require $path;
        if (!is_array($list)) {
            return false;
        }

        $normal = self::normalise($text);
        $tight  = preg_replace('/[^a-z0-9]+/u', '', $normal) ?: '';

        foreach ((array) ($list['words'] ?? []) as $word) {
            $word = mb_strtolower((string) $word, 'UTF-8');

            if (preg_match('/\b' . preg_quote($word, '/') . '\b/u', $normal)) {
                return true;
            }
            if ('' !== $word && str_contains($tight, $word)) {
                return true;
            }
        }

        foreach ((array) ($list['phrases'] ?? []) as $phrase) {
            $phrase = mb_strtolower((string) $phrase, 'UTF-8');

            if ('' !== $phrase && (str_contains($normal, $phrase) || str_contains($tight, preg_replace('/\s+/u', '', $phrase)))) {
                return true;
            }
        }

        return false;
    }

    public static function normalise(string $text): string
    {
        $text = mb_strtolower($text, 'UTF-8');

        $leet = [
            '0' => 'o', '1' => 'i', '3' => 'e', '4' => 'a', '5' => 's',
            '7' => 't', '8' => 'b', '@' => 'a', '$' => 's', '!' => 'i', '+' => 't',
        ];
        $text = strtr($text, $leet);

        // "fuuuck" → "fuck"
        $text = preg_replace('/(.)\1{2,}/u', '$1$1', $text) ?: $text;

        return $text;
    }

    private static function tokenFor(int $responseId): string
    {
        return (string) get_post_meta($responseId, '_qt_edit_token', true);
    }

    /** @return array<int,string> */
    private static function tokenCookie(): array
    {
        if (empty($_COOKIE[self::COOKIE])) {
            return [];
        }

        $data = json_decode(stripslashes((string) $_COOKIE[self::COOKIE]), true);

        return is_array($data) ? $data : [];
    }

    private static function rememberToken(int $responseId, string $token): void
    {
        $tokens = self::tokenCookie();
        $tokens[$responseId] = $token;
        $tokens = array_slice($tokens, -30, 30, true);

        if (PHP_VERSION_ID >= 70300) {
            setcookie(self::COOKIE, wp_json_encode($tokens), [
                'expires'  => time() + 30 * DAY_IN_SECONDS,
                'path'     => (string) COOKIEPATH,
                'domain'   => (string) (COOKIE_DOMAIN ?: ''),
                'secure'   => is_ssl(),
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        } else {
            setcookie(
                self::COOKIE,
                wp_json_encode($tokens),
                time() + 30 * DAY_IN_SECONDS,
                COOKIEPATH . '; SameSite=Lax',
                (string) (COOKIE_DOMAIN ?: ''),
                is_ssl(),
                true
            );
        }
    }

    /**
     * Whether the current visitor holds the edit token for a response.
     */
    public static function canEdit(int $responseId): bool
    {
        $token = self::tokenFor($responseId);

        return '' !== $token && (self::tokenCookie()[$responseId] ?? '') === $token;
    }

    /**
     * Total approved responses for a story (top-level + all replies).
     */
    public static function descendantCount(int $storyId): int
    {
        global $wpdb;

        $count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*)
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} m ON p.ID = m.post_id
             WHERE p.post_type = %s
               AND p.post_status = %s
               AND m.meta_key = %s
               AND m.meta_value = %d",
            'qt_response',
            'publish',
            '_qt_story_id',
            $storyId
        ));

        return $count;
    }

    /**
     * Approved top-level responses for a story, oldest first (flow).
     *
     * @return list<\WP_Post>
     */
    public static function forStory(int $storyId, int $parentId = 0): array
    {
        $query = new \WP_Query([
            'post_type'      => 'qt_response',
            'post_status'    => 'publish',
            'post_parent'    => $parentId,
            'posts_per_page' => 100,
            'orderby'        => 'date',
            'order'          => 'ASC',
            'no_found_rows'  => true,
            'meta_query'     => $parentId ? [] : [
                ['key' => '_qt_story_id', 'value' => $storyId, 'compare' => '='],
            ],
        ]);

        return array_values(array_filter($query->posts, static fn ($p) => $p instanceof \WP_Post));
    }
}
