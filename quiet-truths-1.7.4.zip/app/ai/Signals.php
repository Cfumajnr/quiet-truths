<?php
/**
 * Quiet Truths — Signals
 *
 * The human-texture layer of the AI profile. Signals describe what is
 * happening emotionally, contextually, relationally, and temporally in
 * a story — distinct from both "what room is it in" and "what concepts
 * does it contain." Signals are interpretations, not categories, and
 * multiple can be true at once.
 *
 * Four signal groups:
 *   - emotional     — the feeling texture (grief, longing, joy, shame, fear, hope, …)
 *   - relationship  — who is in the story with the writer (mother, stranger, ex, child, …)
 *   - time          — where in time the story lives (childhood, recently, long ago, now, …)
 *   - context       — life-context markers (parenting, poverty, migration, school, …)
 *   - communication — how the story addresses its subject (unsent_letter, apology,
 *                     confession, gratitude, address_to_absent, address_to_younger_self)
 *
 * Signals are always scored 0..1. They never appear as categories to
 * readers; they are used by the librarian for related-story finding,
 * why-chains, and search ranking.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

use QuietTruths\Core\AiKernel;

final class Signals
{
    /**
     * Score all signal groups for a piece of text.
     *
     * @return array{
     *   emotional:array<string,float>,
     *   relationship:array<string,float>,
     *   time:array<string,float>,
     *   context:array<string,float>,
     *   communication:array<string,float>,
     * }
     */
    public static function forText(string $text): array
    {
        $t = AiKernel::normalise($text);

        return [
            'emotional'     => self::emotional($t, $text),
            'relationship'  => self::relationship($t),
            'time'          => self::time($t),
            'context'       => self::context($t),
            'communication' => self::communication($t),
        ];
    }

    /**
     * Emotional signals — the feeling-terrain of the story.
     *
     * @return array<string,float>
     */
    private static function emotional(string $t, string $raw): array
    {
        $signals = [];

        $map = [
            'grief'        => ['grief','grieve','mourn','died','death','funeral','burial','passed away','lost him','lost her','kifo','amefariki','mazishi','huzuni','maombolezo','kufiwa'],
            'longing'      => ['wish i could','i miss','miss him','miss her','longing','yearn','ache for','still have his number','still have her number','saved number','kumiss','kumbukumbu','kutamani'],
            'loss'         => ['lost','losing','gone','never came back','taken from','kupoteza','kufa','ameondoka'],
            'shame'        => ['ashamed','embarrassed','humiliated','disgrace','stigma','aibu','fedheha','kudharauliwa','kukosa heshima'],
            'fear'         => ['afraid','scared','frightened','terror','dread','panic','anxious','worry','worried','hofu','woga','kuogopa','wasiwasi'],
            'anger'        => ['angry','rage','fury','furious','resent','bitter','outrage','frustrated','hasira','kukasirika','chuki','uchungu wa moyo'],
            'betrayal'     => ['betrayed','cheated','lied to','stabbed in the back','double-crossed','broke my trust','usaliti','kusalitiwa','kudanganywa','aliniambia uongo'],
            'joy'          => ['happy','laughed','smiled','laughed','delighted','grinned','joy','celebrated','furaha','kufurahi','kicheko','shangwe','sherehe'],
            'gratitude'    => ['grateful','thankful','thank you','gratitude','appreciated','asante','nashukuru','shukrani','kung\'oa','kushukuru'],
            'hope'         => ['hope','hopeful','believe that','tomorrow','future','dream','one day','things will get better','mwanga','tumaini','matumaini','kuna tumaini','haitakuwa hivi siku zote'],
            'peace'        => ['peace','calm','quiet','still','at peace','serene','amani','utulivu','kimya','kutulia','amepumzika'],
            'love'         => ['love','loved','loving','cherish','tender','warmth','affection','mapenzi','kupendwa','mpenzi','kupendana'],
            'vulnerability'=> ['vulnerable','raw','opened up','let him in','let her in','cry','cried','tears','machozi','kulia','alilia','kufunguka','kuwa wazi'],
            'relief'       => ['relief','relieved','finally','at last','breathed again','could breathe','sighed','nafuu','kumekucha','amepumzika'],
            'shock'        => ['could not believe','shocked','stunned','frozen','could not speak','stared','numb','sikuamini','nilishangaa'],
            'guilt'        => ['guilty','my fault','blame myself','i should have','i should not have','could have','if only','lawama','kujilaumi'],
            'pride'        => ['proud','accomplished','did it','made it','success','hongera','kufanikiwa','mafanikio','kushinda'],
            'loneliness'   => ['alone','lonely','no one','nobody','empty','isolated','upweke','peke yangu','kuwa peke yako','hakuna mtu'],
            'forgiveness'  => ['forgive','forgiven','forgiveness','pardoned','made peace','let go','reconciled','kusamehe','msamaha','kuacha','kuachilia'],
        ];

        foreach ($map as $sig => $words) {
            $hits = 0;
            foreach ($words as $w) {
                if (str_contains($t, $w)) {
                    $hits++;
                }
            }
            if ($hits > 0) {
                // Stronger if multiple cues; cap at 0.95 so no signal is absolute.
                $signals[$sig] = min(0.95, 0.40 + 0.15 * ($hits - 1));
            }
        }

        // Valence/arousal are kept as summary dimensions alongside the labels.
        $pos = ['joy','gratitude','hope','peace','love','relief','pride','forgiveness'];
        $neg = ['grief','longing','loss','shame','fear','anger','betrayal','shock','guilt','loneliness'];
        $posScore = 0.0; $negScore = 0.0;
        foreach ($pos as $k) $posScore = max($posScore, $signals[$k] ?? 0.0);
        foreach ($neg as $k) $negScore = max($negScore, $signals[$k] ?? 0.0);
        $denom = $posScore + $negScore;
        $signals['_valence'] = round($denom > 0 ? ($posScore - $negScore) / $denom : 0.0, 2);

        return $signals;
    }

    /**
     * Relationship signals — who the story is about (relation to writer).
     *
     * @return array<string,float>
     */
    private static function relationship(string $t): array
    {
        $signals = [];

        $map = [
            'mother'          => ['my mother','my mum','my mom','mama yangu','mamangu','mama','mum','mom'],
            'father'          => ['my father','my dad','baba yangu','babangu','baba','dad'],
            'child'           => ['my son','my daughter','mtoto wangu','mwana wangu','binti yangu','my child','my kid','my baby'],
            'sibling'         => ['my brother','my sister','kaka yangu','dada yangu','kaka','dada'],
            'spouse_partner'  => ['my husband','my wife','my partner','mume wangu','mke wangu','mchumba wangu','my fiancé','my fiancée','my boyfriend','my girlfriend'],
            'ex'              => ['my ex','ex-husband','ex-wife','ex-boyfriend','ex-girlfriend','tuliachana','after we broke up','baada ya kuachana'],
            'grandparent'     => ['my grandmother','my grandfather','grandma','grandpa','babu','bibi','nyanya','shangazi','mjomba'],
            'friend'          => ['my friend','best friend','rafiki yangu','marafiki zangu','my best friend','my neighbour','jirani yangu'],
            'stranger'        => ['a stranger','someone i did not know','a woman i had never met','a man i did not know','sikumjua'],
            'colleague'       => ['my boss','my colleague','coworker','my manager','wenzangu','bosi wangu','at work'],
            'in_laws'         => ['my mother-in-law','my father-in-law','mkwe wangu','shemeji','wifi'],
            'teacher'         => ['my teacher','mwalimu wangu','mwalimu','my lecturer','my professor'],
            'clergy'          => ['pastor','priest','imam','father','padre','mchungaji','sheikh'],
            'police_authority'=> ['police','officer','askari','polisi'],
            'younger_self'    => ['to my younger self','younger me','the girl i was','the boy i was','when i was younger','nilipokuwa mdogo','nafsi yangu mdogo'],
            'deceased'        => ['who died','who passed','who is gone','my late','marehemu','aliyefariki','before he died','before she died','after she died','after he died'],
            'absent'          => ['who left','who never came back','did not come back','never knew my father','never met my mother','absent father','absent mother'],
            'community'       => ['our village','our community','the neighbourhood','neighbours','majirani','mtaani','kijijini','sisi wote','church members','mosque'],
        ];

        foreach ($map as $sig => $phrases) {
            $hits = 0;
            foreach ($phrases as $p) {
                if (str_contains($t, $p)) {
                    $hits++;
                }
            }
            if ($hits > 0) {
                $signals[$sig] = min(0.95, 0.45 + 0.15 * ($hits - 1));
            }
        }

        return $signals;
    }

    /**
     * Time signals — where in the writer's life the story lives.
     *
     * @return array<string,float>
     */
    private static function time(string $t): array
    {
        $signals = [];

        $map = [
            'childhood'       => ['when i was a child','when i was young','as a child','growing up','childhood','utotoni','nilipokuwa mdogo','primary school','shule ya msingi'],
            'adolescence'     => ['high school','secondary school','form 1','form 2','form 3','form 4','teenage','as a teenager','shule ya upili'],
            'young_adult'     => ['university','campus','chuo','after campus','in my twenties','my first job','biashara yangu ya kwanza','first job'],
            'new_parent'      => ['when my baby was born','after giving birth','new mother','new father','baada ya kujifungua','mtoto mchanga','first child'],
            'marriage_early'  => ['first year of marriage','early in our marriage','newly wed','baada ya harusi','tulipooana','first few months of marriage'],
            'recent_past'     => ['last week','last month','recently','a few days ago','yesterday','last night','jana','juzi','wiki iliyopita','mwezi uliopita','hivi karibuni'],
            'long_past'       => ['years ago','many years ago','when i was young','a long time ago','miaka mingi iliyopita','zamani sana','siku za nyuma'],
            'now_present'     => ['now','these days','right now','currently','at the moment','siku hizi','sasa','hivi sasa','kwa sasa'],
            'looking_back'    => ['looking back','i remember','i still remember','nakumbuka','ninakumbuka','kumbukumbu'],
            'looking_forward' => ['someday','one day','i hope','i pray','in the future','future','kesho','baadaye','mbeleni','ntaweza','nitaweza'],
            'anniversary'     => ['it has been','years since','miaka tangu','three years later','ten years later','baada ya miaka'],
        ];

        foreach ($map as $sig => $phrases) {
            $hits = 0;
            foreach ($phrases as $p) {
                if (str_contains($t, $p)) {
                    $hits++;
                }
            }
            if ($hits > 0) {
                $signals[$sig] = min(0.95, 0.40 + 0.15 * ($hits - 1));
            }
        }

        return $signals;
    }

    /**
     * Life-context signals — structural/contextual facts about the situation.
     *
     * @return array<string,float>
     */
    private static function context(string $t): array
    {
        $signals = [];

        $map = [
            'poverty_hardship'  => ['no money','no food','hungry','kulala njaa','maskini','umasikini','could not afford','couldn\'t afford','no fare','no rent','kukosa kodi','deni','mkopo','kubana mkono'],
            'school_fees'       => ['school fees','fees','karo','kukosa karo','sent home for fees','kutimuliwa shule kwa karo'],
            'work_hustle'       => ['my job','at work','my boss','my business','biashara','mchana kucha','kuchapa kazi','kazi','hustle','side hustle','mjengo','mgeni'],
            'illness'           => ['sick','hospital','daktari','hospitali','ugonjwa','cancer','kansa','hiv','sukari','depression','anxiety','mfadhaiko','kuugua','kuumwa'],
            'pregnancy_birth'   => ['pregnant','pregnancy','mimba','kuzaa','kujifungua','mtoto mchanga','nursing','kunyonyesha','miscarriage','kuharibika kwa mimba'],
            'migration_diaspora'=> ['abroad','overseas','diaspora','nilihamia','travelled abroad','kusafiri nje','moved to','uk','usa','saudi','qatar','dubai','gulf'],
            'inherited_faith'   => ['grew up in church','raised muslim','raised christian','family church','kukaa kanisani','kukaa msikitini','dad taught me to pray','mum taught me to pray'],
            'domestic_violence' => ['hit me','beat me','beaten','kupigwa','alinitupa','choked me','alimpiga','battered','domestic violence','unyanyasaji wa nyumbani'],
            'infidelity'        => ['cheated on me','another woman','another man','mpango wa kando','mwingine','ana mwingine','affair'],
            'addiction'         => ['alcohol','pombe','drugs','madawa','bhangi','binge','gambled','kamari','rehab','ulevi'],
            'unemployment'      => ['no job','out of work','fired','sacked','kufukuzwa kazi','kukosa kazi','kutimuliwa','no work'],
            'success_escape'    => ['i made it','nimetoka','i got out','escaped','niliweza','kufanikiwa','made it out','got through it'],
            'waiting'           => ['waiting','i waited','subiri','kungoja','kusubiri','still waiting','bado nasubiri'],
        ];

        foreach ($map as $sig => $phrases) {
            $hits = 0;
            foreach ($phrases as $p) {
                if (str_contains($t, $p)) {
                    $hits++;
                }
            }
            if ($hits > 0) {
                $signals[$sig] = min(0.95, 0.40 + 0.15 * ($hits - 1));
            }
        }

        return $signals;
    }

    /**
     * Communication-mode signals — how the story addresses its subject.
     *
     * The Letters room is triggered not by topic but by form/intention:
     * direct address, second person, addressee who is absent/dead/estranged,
     * apologies, confessions, gratitude, letters to younger self.
     *
     * @return array<string,float>
     */
    private static function communication(string $t): array
    {
        $signals = [];

        // Direct address: "Dear X", "Dadi,", "Mama,", "To X", letter openings.
        $dearOpenings = 0;
        if (preg_match('/\b(?:dear|to)\s+(?:my\s+)?(?:mom|mum|mother|dad|father|sister|brother|son|daughter|friend|husband|wife|child|children|self|younger\s+self|person|stranger)\b/iu', $t)) {
            $dearOpenings++;
        }
        if (preg_match('/\b(?:mama|baba|rafiki|mume|mke|mpenzi)\s*,/u', $t)) {
            $dearOpenings++;
        }
        // Second-person address to absent/dead: "you never came", "i hope you"
        $youMentions = substr_count($t, ' you ');
        $secondPersonAbsent = 0;
        $absentCues = ['never came back','who died','who passed','never met','left me','i hope you','you always','you never','i wish you could','if you were here','i still talk to you','i miss you','i forgave you','i loved you','thank you for','goodbye'];
        foreach ($absentCues as $c) {
            if (str_contains($t, $c)) {
                $secondPersonAbsent++;
            }
        }

        // Unsent letter: strong "dear" / "to you" opening + second person.
        if ($dearOpenings > 0 || ($youMentions >= 2 && $secondPersonAbsent >= 1)) {
            $signals['unsent_letter'] = min(0.95, 0.55 + 0.20 * $dearOpenings + 0.10 * $secondPersonAbsent);
        }

        // Apology
        $apology = 0;
        foreach (['i am sorry','i\'m sorry','forgive me','i forgive you','pole','msamaha','samahani','i apologise','i apologize'] as $p) {
            if (str_contains($t, $p)) {
                $apology++;
            }
        }
        if ($apology > 0) {
            $signals['apology'] = min(0.95, 0.50 + 0.15 * ($apology - 1));
        }

        // Confession
        $confess = 0;
        foreach (['i have never told anyone','i never told','never told anyone','a secret i','must confess','i need to tell','siri yangu','sijawahi mwambia','i have to say','what i did'] as $p) {
            if (str_contains($t, $p)) {
                $confess++;
            }
        }
        if ($confess > 0) {
            $signals['confession'] = min(0.95, 0.55 + 0.15 * ($confess - 1));
        }

        // Gratitude letter
        if (str_contains($t, 'thank you') || str_contains($t, 'asante') || str_contains($t, 'nashukuru') || str_contains($t, 'i am grateful to') || str_contains($t, 'shukrani')) {
            $signals['gratitude_letter'] = 0.70;
        }

        // Address to younger self
        if (str_contains($t, 'younger self') || str_contains($t, 'to the girl i was') || str_contains($t, 'to the boy i was') || str_contains($t, 'if i could go back')) {
            $signals['address_to_younger_self'] = 0.85;
        }

        // Address to deceased/absent
        if ($secondPersonAbsent >= 1 && (str_contains($t, ' died') || str_contains($t, ' gone') || str_contains($t, 'never came') || str_contains($t, 'kufa') || str_contains($t, 'fariki'))) {
            $signals['address_to_deceased'] = min(0.95, 0.55 + 0.15 * ($secondPersonAbsent - 1));
        }

        // Direct address (generic second-person story, not necessarily a letter)
        if ($youMentions >= 3) {
            $signals['direct_address'] = min(0.85, 0.40 + 0.10 * ($youMentions - 3));
        }

        return $signals;
    }
}
