<?php
/**
 * Quiet Truths — Embeddings
 *
 * Owns all vector I/O. Hard rule: once a story has a dense model vector
 * (e.g. bge-m3), we NEVER overwrite it with token vectors because the
 * embedding service is temporarily down. A service outage may prevent
 * *new* embeddings from being created; it must never destroy existing
 * high-quality ones.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

final class Embeddings
{
    public const META_KEY         = '_qt_embedding';
    public const MODEL_KEY        = '_qt_embedding_model';
    public const DIM_KEY          = '_qt_embedding_dim';
    public const AI_VERSION_KEY   = '_qt_ai_version';
    public const PROFILE_VERSION_KEY = '_qt_ai_profile_version';

    public const PROFILE_VERSION = 3;

    public const STATUS_PENDING    = 'pending';
    public const STATUS_DENSE      = 'dense_ready';
    public const STATUS_LEXICAL    = 'lexical_fallback';
    public const STATUS_FAILED     = 'failed';

    public const STATUS_KEY = '_qt_embedding_status';

    /** @var array<int,array<float>|array<string,float>|null> */
    private static array $postVecCache = [];

    /** Per-request cache of transient token vectors (never persisted). */
    private static array $transientVecCache = [];

    /** Service metadata cached per request. */
    private static ?array $serviceMeta = null;

    public static function init(): void
    {
        add_action('transition_post_status', [self::class, 'onStatusChange'], 20, 3);
        add_action('save_post_qt_story', [self::class, 'onSave'], 20, 2);
        add_action('save_post_qt_journal', [self::class, 'onSave'], 20, 2);
    }

    /* ──────────────────── service metadata ──────────────────── */

    /**
     * @return array{ok:bool,model:string,dim:int}
     */
    public static function serviceMeta(): array
    {
        if (null !== self::$serviceMeta) {
            return self::$serviceMeta;
        }
        $url = AiKernel::serviceUrl();
        if ('' === $url) {
            return self::$serviceMeta = ['ok' => false, 'model' => '', 'dim' => 0];
        }
        $resp = wp_remote_get($url . '/health', [
            'timeout' => 0.4,
            'blocking' => true,
            'sslverify' => false,
        ]);
        if (is_wp_error($resp) || 200 !== (int) wp_remote_retrieve_response_code($resp)) {
            return self::$serviceMeta = ['ok' => false, 'model' => '', 'dim' => 0];
        }
        $body = json_decode((string) wp_remote_retrieve_body($resp), true);
        if (!is_array($body) || empty($body['ok'])) {
            return self::$serviceMeta = ['ok' => false, 'model' => '', 'dim' => 0];
        }
        return self::$serviceMeta = [
            'ok'    => true,
            'model' => (string) ($body['model'] ?? ''),
            'dim'   => (int) ($body['dim'] ?? 0),
        ];
    }

    /**
     * The model available right now for NEW embeddings. 'tokens-v1' if
     * service is down. This is NOT used to invalidate existing dense
     * vectors — see activeModelForStored().
     */
    public static function activeModel(): string
    {
        $meta = self::serviceMeta();
        return $meta['ok'] && '' !== $meta['model'] ? $meta['model'] : 'tokens-v1';
    }

    public static function activeDim(): int
    {
        $meta = self::serviceMeta();
        return $meta['ok'] ? (int) $meta['dim'] : 0;
    }

    /**
     * Can we currently write dense embeddings? If the service is down,
     * existing dense vectors remain readable but new posts get token
     * vectors until the service returns.
     */
    public static function canWriteDense(): bool
    {
        return self::serviceMeta()['ok'];
    }

    /**
     * Is a model string a dense-embedding model (vs the PHP token fallback)?
     */
    public static function isDenseModel(string $model): bool
    {
        return '' !== $model && 'tokens-v1' !== $model;
    }

    /* ──────────────────── fetching embeddings ──────────────────── */

    /**
     * Embed a batch of texts with the DENSE model only. Returns null on
     * any failure (service down, HTTP error, wrong vector count, wrong
     * dimension, non-numeric entries). Does NOT fall back to token
     * vectors. Use this when the caller MUST know whether a dense
     * vector was really produced (prototype caching, semantic-mode
     * detection).
     *
     * @param  list<string> $texts
     * @param  int          $expectDim  If >0, every returned vector must
     *                                  have exactly this many entries.
     * @return list<array<float>>|null   Dense vectors in input order, or null on failure.
     */
    public static function embedDense(array $texts, int $expectDim = 0): ?array
    {
        $texts = array_values(array_filter($texts, fn($t) => '' !== trim((string) $t)));
        if (empty($texts)) {
            return [];
        }

        $meta = self::serviceMeta();
        if (!$meta['ok'] || $meta['dim'] < 1) {
            return null;
        }
        $dim = $expectDim > 0 ? $expectDim : (int) $meta['dim'];

        $resp = AiKernel::postJson('/embed', ['texts' => $texts]);
        if (null === $resp || !isset($resp['vectors']) || !is_array($resp['vectors'])) {
            return null;
        }
        if (count($resp['vectors']) !== count($texts)) {
            // Wrong number of vectors returned — malformed response.
            return null;
        }

        $out = [];
        foreach ($resp['vectors'] as $v) {
            if (!is_array($v)) {
                return null;
            }
            // Must be a sequential dense array of exactly $dim floats.
            if (array_keys($v) !== range(0, count($v) - 1)) {
                return null;
            }
            if (count($v) !== $dim) {
                return null;
            }
            $clean = [];
            foreach ($v as $x) {
                if (!is_numeric($x)) {
                    return null;
                }
                $clean[] = (float) $x;
            }
            $out[] = $clean;
        }
        return $out;
    }

    /**
     * Embed a batch of texts RIGHT NOW. Uses the service if available,
     * else token vectors. Call this only from background/CLI contexts;
     * do not call it from a reader-facing page load.
     *
     * @param  list<string> $texts
     * @return list<array<float>|array<string,float>>
     */
    public static function embed(array $texts): array
    {
        $texts = array_values(array_filter($texts, fn($t) => '' !== trim((string) $t)));
        if (empty($texts)) {
            return [];
        }

        $meta = self::serviceMeta();
        if ($meta['ok']) {
            $resp = AiKernel::postJson('/embed', ['texts' => array_values($texts)]);
            if (null !== $resp && isset($resp['vectors']) && is_array($resp['vectors'])) {
                $out = [];
                foreach ($resp['vectors'] as $v) {
                    $out[] = is_array($v) ? array_map('floatval', $v) : [];
                }
                return $out;
            }
        }
        return array_map([__CLASS__, 'tokenVector'], $texts);
    }

    /**
     * Cosine similarity between two vectors (dense or sparse).
     *
     * @param array<float>|array<string,float> $a
     * @param array<float>|array<string,float> $b
     */
    public static function vectorSimilarity(array $a, array $b): float
    {
        if (empty($a) || empty($b)) {
            return 0.0;
        }
        $aDense = self::isDense($a);
        $bDense = self::isDense($b);
        if ($aDense && $bDense) {
            return self::denseCosine($a, $b);
        }
        if (!$aDense && !$bDense) {
            return self::sparseCosine($a, $b);
        }
        return 0.0;
    }

    public static function textSimilarity(string $a, string $b): float
    {
        $a = trim($a); $b = trim($b);
        if ('' === $a || '' === $b) {
            return 0.0;
        }
        $meta = self::serviceMeta();
        if ($meta['ok']) {
            $resp = AiKernel::postJson('/similarity', ['a' => $a, 'b' => $b]);
            if (null !== $resp && isset($resp['score'])) {
                return max(0.0, min(1.0, (float) $resp['score']));
            }
        }
        return self::sparseCosine(self::tokenVector($a), self::tokenVector($b));
    }

    /**
     * @param  list<string> $candidates
     * @return list<float>
     */
    public static function textSimilarities(string $anchor, array $candidates): array
    {
        $anchor = trim($anchor);
        $candidates = array_values(array_filter($candidates, fn($t) => '' !== trim((string) $t)));
        if ('' === $anchor || empty($candidates)) {
            return array_fill(0, count($candidates), 0.0);
        }
        $meta = self::serviceMeta();
        if ($meta['ok']) {
            $resp = AiKernel::postJson('/similarities', [
                'anchor' => $anchor,
                'candidates' => $candidates,
            ]);
            if (null !== $resp && isset($resp['scores']) && is_array($resp['scores'])
                && count($resp['scores']) === count($candidates)) {
                return array_map(fn($s) => max(0.0, min(1.0, (float) $s)), $resp['scores']);
            }
        }
        $av = self::tokenVector($anchor);
        return array_map(fn($t) => self::sparseCosine($av, self::tokenVector((string) $t)), $candidates);
    }

    /**
     * @param  array<string,list<string>> $anchors
     * @return array<string,float>
     */
    public static function classifyAgainstAnchors(string $text, array $anchors): array
    {
        if ('' === trim($text) || empty($anchors)) {
            return [];
        }
        $meta = self::serviceMeta();
        if (!$meta['ok']) {
            return [];
        }
        $resp = AiKernel::postJson('/classify', [
            'text' => $text,
            'anchors' => $anchors,
        ]);
        if (null === $resp || !isset($resp['scores']) || !is_array($resp['scores'])) {
            return [];
        }
        $out = [];
        foreach ($resp['scores'] as $k => $v) {
            $out[(string) $k] = max(0.0, min(1.0, (float) $v));
        }
        return $out;
    }

    /* ──────────────────── post vectors ──────────────────── */

    /**
     * READ-ONLY access to a post's stored vector. NEVER computes a new
     * vector, never hits the service, never overwrites metadata.
     * Returns [] if nothing is stored.
     *
     * @return array<float>|array<string,float>
     */
    public static function forPostReadOnly(int $postId): array
    {
        if (array_key_exists($postId, self::$postVecCache)) {
            return self::$postVecCache[$postId] ?? [];
        }
        $cached = get_post_meta($postId, self::META_KEY, true);
        $v = is_array($cached) && !empty($cached) ? $cached : [];
        self::$postVecCache[$postId] = $v;
        return $v;
    }

    /**
     * Return a post's usable vector (read-only). If a vector is stored
     * (dense or tokens-v1 lexical-fallback) return it. Otherwise build a
     * transient in-memory token-vector floor, never persisted.
     *
     * Safe for reader-facing pages. Never hits the service.
     *
     * @return array<float>|array<string,float>
     */
    public static function forPostRead(int $postId): array
    {
        $v = self::forPostReadOnly($postId);
        if (!empty($v)) {
            return $v;
        }
        // Per-request transient (never persisted).
        if (array_key_exists($postId, self::$transientVecCache)) {
            return self::$transientVecCache[$postId] ?? [];
        }
        $post = get_post($postId);
        if (!$post) {
            self::$transientVecCache[$postId] = [];
            return [];
        }
        $tv = self::tokenVector((string) $post->post_title . ' ' . (string) $post->post_content);
        self::$transientVecCache[$postId] = $tv;
        return $tv;
    }

    public static function embeddingStatus(int $postId): string
    {
        $s = (string) get_post_meta($postId, self::STATUS_KEY, true);
        if (in_array($s, [self::STATUS_PENDING, self::STATUS_DENSE, self::STATUS_LEXICAL, self::STATUS_FAILED], true)) {
            return $s;
        }
        // Unknown: we don't yet have a status recorded.
        return '';
    }

    /**
     * Does this post still need a dense embedding to be produced by the
     * background worker? Returns false for already-dense posts and for
     * posts that were deliberately written as lexical_fallback (i.e.
     * the operator chose not to run the embedding service).
     */
    public static function needsDense(int $postId): bool
    {
        $status = self::embeddingStatus($postId);
        if ($status === self::STATUS_DENSE || $status === self::STATUS_LEXICAL) {
            return false;
        }
        // pending / failed / unknown: re-queue when service is up.
        return true;
    }

    /**
     * Compute and persist a fresh vector for a post. This is the WRITE
     * path — it MUST be called from background/CLI only (never from a
     * reader request or the moderation panel render).
     *
     * Rules:
     *   - If the service is available, write a dense vector tagged
     *     with the live model name/dim.
     *   - If the service is unavailable AND the post already has a
     *     dense vector from a previous model, PRESERVE it unchanged.
     *     (A temporary outage must never downgrade a dense vector to
     *     tokens-v1.)
     *   - If the service is unavailable AND there is no existing dense
     *     vector, write tokens-v1.
     *
     * @return array<float>|array<string,float>
     */
    public static function forPostWrite(int $postId): array
    {
        $post = get_post($postId);
        if (!$post) return [];
        if (!in_array($post->post_type, ['qt_story','qt_journal','post','page'], true)) return [];

        $text = self::postText($post);

        $existing      = get_post_meta($postId, self::META_KEY, true);
        $existingModel = (string) get_post_meta($postId, self::MODEL_KEY, true);
        $hasDense      = is_array($existing) && !empty($existing) && self::isDenseModel($existingModel);

        if (self::canWriteDense()) {
            // Use embedDense so we only persist a vector if it is a
            // validated dense vector of the expected dimension. On any
            // failure (timeout, malformed response, wrong count/dim)
            // we fall through to the preserve/token-vector path
            // instead of persisting a sparse token vector as if it
            // were BGE-M3.
            $vecs = self::embedDense([$text]);
            if (null !== $vecs && isset($vecs[0]) && !empty($vecs[0])) {
                $vec  = $vecs[0];
                $meta = self::serviceMeta();
                update_post_meta($postId, self::META_KEY, $vec);
                update_post_meta($postId, self::MODEL_KEY, $meta['model']);
                update_post_meta($postId, self::DIM_KEY, (int) $meta['dim']);
                update_post_meta($postId, self::AI_VERSION_KEY, QT_THEME_VERSION);
                update_post_meta($postId, self::PROFILE_VERSION_KEY, self::PROFILE_VERSION);
                update_post_meta($postId, self::STATUS_KEY, self::STATUS_DENSE);
                self::$postVecCache[$postId] = $vec;
                return $vec;
            }
            // embedDense failed. If the post already has a good dense
            // vector, leave its status as DENSE — the stored vector is
            // still valid; this was only a failed refresh attempt. The
            // background worker will retry. If there is no dense vector
            // yet, mark FAILED so the post is re-queued.
            if (!$hasDense) {
                update_post_meta($postId, self::STATUS_KEY, self::STATUS_FAILED);
            }
        }

        if ($hasDense) {
            // Preserve dense vector through outage or failed refresh.
            // Status stays at whatever it was (DENSE); readers keep
            // serving the good vector; BackgroundWorker re-schedules.
            self::$postVecCache[$postId] = is_array($existing) ? $existing : [];
            return self::$postVecCache[$postId];
        }

        // Service down, no dense vector yet. Mark PENDING (do NOT persist
        // tokens-v1 as the permanent answer); return transient token vec
        // for this run so profile scoring still works.
        if (self::embeddingStatus($postId) !== self::STATUS_PENDING
            && self::embeddingStatus($postId) !== self::STATUS_FAILED) {
            update_post_meta($postId, self::STATUS_KEY, self::STATUS_PENDING);
        }
        $vec = self::tokenVector($text);
        self::$postVecCache[$postId] = $vec;
        return $vec;
    }

    /**
     * Mark that a post's profile is stale (after edit/approve) without
     * deleting the last good profile or dense vector. Consumers will
     * keep serving the previous profile until the background worker
     * replaces it.
     */
    public static function invalidate(int $postId): void
    {
        unset(self::$postVecCache[$postId], self::$transientVecCache[$postId]);
        if (self::needsDense($postId)) {
            update_post_meta($postId, self::STATUS_KEY, self::STATUS_PENDING);
        }
    }

    /**
     * Wipe a post's vector completely (for testing or forget()).
     */
    public static function purge(int $postId): void
    {
        unset(self::$postVecCache[$postId]);
        delete_post_meta($postId, self::META_KEY);
        delete_post_meta($postId, self::MODEL_KEY);
        delete_post_meta($postId, self::DIM_KEY);
        delete_post_meta($postId, self::AI_VERSION_KEY);
        delete_post_meta($postId, self::PROFILE_VERSION_KEY);
    }

    /* ──────────────────── post events ──────────────────── */

    public static function onStatusChange(string $new, string $old, \WP_Post $post): void
    {
        if (!in_array($post->post_type, ['qt_story', 'qt_journal'], true)) {
            return;
        }
        if ('publish' === $new) {
            self::invalidate($post->ID);
            // Delegate to Profile::queueWarm which sets rebuild_pending
            // (the existing FRESH profile is NOT demoted to stale on
            // publish; new posts have no profile yet so they'll get a
            // lexical fallback first, upgraded to dense on retry).
            Profile::queueWarm($post->ID);
        }
    }

    public static function onSave(int $postId, \WP_Post $post): void
    {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (wp_is_post_revision($postId) || wp_is_post_autosave($postId)) {
            return;
        }
        if ('publish' !== $post->post_status) {
            return;
        }
        self::invalidate($postId);
        // Edit to a published story: request a background rebuild
        // WITHOUT demoting the existing good profile to stale.
        // Readers keep the FRESH profile until an atomic replacement
        // lands; the background worker retries on outage.
        Profile::queueWarm($postId);
    }

    /* ──────────────────── token vector fallback ──────────────────── */

    /**
     * @return array<string,float>
     */
    public static function tokenVector(string $text): array
    {
        $text   = AiKernel::normalise($text);
        $tokens = preg_split('/[^\p{L}\p{N}\']+/u', $text) ?: [];
        $tokens = array_values(array_filter($tokens, fn($t) => mb_strlen($t) >= 3));
        if (count($tokens) < 4) {
            return [];
        }
        $freq = [];
        $prev = null;
        foreach ($tokens as $t) {
            $freq[$t] = ($freq[$t] ?? 0.0) + 1.0;
            if (null !== $prev) {
                $freq[$prev . ' ' . $t] = ($freq[$prev . ' ' . $t] ?? 0.0) + 0.5;
            }
            $prev = $t;
        }
        $sum = 0.0;
        foreach ($freq as $w) { $sum += $w * $w; }
        $mag = sqrt($sum);
        if ($mag < 1e-9) { return []; }
        foreach ($freq as &$w) { $w /= $mag; }
        unset($w);
        return $freq;
    }

    private static function denseCosine(array $a, array $b): float
    {
        $a = array_values($a); $b = array_values($b);
        $n = min(count($a), count($b));
        if ($n < 1) return 0.0;
        $dot = 0.0; $na = 0.0; $nb = 0.0;
        for ($i = 0; $i < $n; $i++) {
            $av = (float) $a[$i]; $bv = (float) $b[$i];
            $dot += $av * $bv;
            $na += $av * $av;
            $nb += $bv * $bv;
        }
        if ($na < 1e-12 || $nb < 1e-12) return 0.0;
        return max(0.0, min(1.0, $dot / (sqrt($na) * sqrt($nb))));
    }

    private static function sparseCosine(array $a, array $b): float
    {
        if (count($a) > count($b)) { [$a, $b] = [$b, $a]; }
        $dot = 0.0;
        foreach ($a as $k => $va) {
            if (isset($b[$k])) { $dot += (float) $va * (float) $b[$k]; }
        }
        return max(0.0, min(1.0, $dot));
    }

    private static function isDense(array $v): bool
    {
        if (empty($v)) return false;
        return array_keys($v) === range(0, count($v) - 1);
    }

    /**
     * Compose the canonical text representation sent to the embedding
     * model (token fallback or BGE-M3 dense).
     *
     * v1.7.4 (Correction 10): semantic representation is built from
     *   title + body + room label + CANONICAL concepts + threads +
     *   domains + signals + context (when available in the stored
     *   profile). Legacy _qt_themes / _qt_doors are ONLY consulted
     *   when an older story has NO current representation — they must
     *   never become a permanent semantic signal, nor teach the
     *   embedding layer that Doors are part of the current ontology.
     *
     * Thread/domain/context/signal enrichment will expand in v1.8.0;
     * postText() here carries the structural terms safe to read
     * without triggering a full profile rebuild.
     */
    private static function postText(\WP_Post $post): string
    {
        $title = apply_filters('the_title', $post->post_title, $post->ID);
        $body  = apply_filters('the_content', $post->post_content);
        $terms = [];

        // Layer 2 (room): public orientation — always included.
        $rooms = get_the_terms($post->ID, 'qt_room');
        if (is_array($rooms)) {
            foreach ($rooms as $r) {
                $terms[] = $r->name;
            }
        }

        // Layer 3 (concepts): canonical _qt_concepts is the primary
        // background tag (v8+ profiles).
        $hasCanonicalConcepts = false;
        $conceptsCanonical = get_post_meta($post->ID, '_qt_concepts', true);
        if (is_array($conceptsCanonical) && !empty($conceptsCanonical)) {
            $hasCanonicalConcepts = true;
            foreach ($conceptsCanonical as $row) {
                if (is_string($row)) {
                    $terms[] = str_replace('-', ' ', $row);
                } elseif (is_array($row) && isset($row['slug'])) {
                    $terms[] = str_replace('-', ' ', (string) $row['slug']);
                }
            }
        }

        // LEGACY FALLBACK (READ-ONLY): only when canonical concepts are
        // absent. _qt_themes and _qt_doors are NEVER written by current
        // AI and NEVER consulted when a canonical representation exists
        // (Correction 10 — legacy data must not become a permanent
        // semantic signal).
        if (!$hasCanonicalConcepts) {
            $conceptsLegacy = get_post_meta($post->ID, '_qt_themes', true);
            if (is_array($conceptsLegacy)) {
                foreach ($conceptsLegacy as $c) {
                    $terms[] = str_replace('-', ' ', (string) $c);
                }
            }
            $doors = get_post_meta($post->ID, '_qt_doors', true);
            if (is_array($doors)) {
                foreach ($doors as $d) {
                    $terms[] = str_replace('-', ' ', (string) $d);
                }
            }
        }

        // Thread/domain/signal/context enrichment is slated for v1.8.0
        // (search intent, cross-room discovery, relational
        // intelligence). At this layer the embedding sees title + body
        // + room label + canonical concepts; legacy keys only when no
        // canonical representation exists.

        $extra = $terms ? (' ' . implode('. ', $terms) . '.') : '';
        return trim(wp_strip_all_tags($title . '. ' . $body . $extra));
    }
}
