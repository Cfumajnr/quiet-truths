<?php
/**
 * Quiet Truths — Background AI Worker
 *
 * Wraps WP-Cron single events so AI work (embedding generation,
 * profiling) runs in a separate request instead of tying up the
 * PHP/FPM worker that approved the story.
 *
 * This is not a true task queue (there's no dedicated worker process);
 * WP-Cron fires on a later request (WP's own traffic or a server cron
 * that pings wp-cron.php). It is the correct trade-off: zero extra
 * dependencies, no blocking the approval response, and a clear upgrade
 * path to ActionScheduler or a CLI queue when the site grows.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

final class BackgroundWorker
{
    private const HOOK_PROFILE = 'qt_ai_profile_warm';

    public static function init(): void
    {
        add_action(self::HOOK_PROFILE, [self::class, 'runProfile'], 10, 1);
    }

    /**
     * Enqueue a post for profiling + embedding in a later request.
     * Safe to call multiple times — WP-Cron will not double-schedule the
     * same post when an identical task is already pending.
     *
     * Lifecycle (v1.5.6+): Profile::queueWarm() sets _rebuild_pending=true
     * without touching the stored profile's _status. A FRESH profile stays
     * FRESH while the new build runs; runProfile() atomically replaces it
     * when a dense build completes, and leaves it untouched (rescheduling)
     * on failure.
     */
    public static function enqueueProfiling(int $postId): void
    {
        if ($postId < 1) {
            return;
        }
        // We do NOT delete or demote the existing profile here. The
        // profile's _status describes the STORED content (fresh/stale),
        // and _rebuild_pending is the separate flag that says work is
        // wanted. Readers keep the last good profile until an atomic
        // replacement lands.

        // wp_schedule_single_event deduplicates on (hook, args) within
        // 10 minutes; we add a small jitter so bulk publishes don't collide.
        $when = time() + wp_rand(2, 15);
        $existing = wp_next_scheduled(self::HOOK_PROFILE, [$postId]);
        if (false === $existing) {
            wp_schedule_single_event($when, self::HOOK_PROFILE, [$postId], true);
        }
    }

    /**
     * WP-Cron callback. Runs embedding generation + profile build for one post.
     *
     * Retry behaviour (v1.5.6): when warm() reports a retryable outcome
     * (preserved_existing_dense, persisted_lexical_fallback, failed) we
     * re-schedule a later attempt with exponential back-off up to a
     * ~15-minute ceiling. A transient outage must not strand a story
     * in lexical mode forever, and must not demote a FRESH dense profile.
     * On successful dense build, the retry counter is cleared.
     */
    public static function runProfile(int $postId): void
    {
        $post = get_post($postId);
        if (!$post) return;
        if (!in_array($post->post_type, ['qt_story','qt_journal'], true)) return;
        if ('publish' !== $post->post_status && 'pending' !== $post->post_status) return;

        $result = Profile::warm($postId);

        $retryable = in_array($result, ['preserved_existing_dense', 'persisted_lexical_fallback', 'failed'], true);
        if ($retryable) {
            // Exponential back-off: 30s, 60s, 120s, 240s, 480s, 900s cap.
            // We do NOT touch the stored profile's _status during retry.
            $attempts = (int) get_post_meta($postId, '_qt_ai_retry_attempts', true);
            $attempts = min($attempts + 1, 6);
            update_post_meta($postId, '_qt_ai_retry_attempts', $attempts);
            $delay = min(15 * 60, 30 * (2 ** max(0, $attempts - 1)));
            wp_schedule_single_event(time() + $delay, self::HOOK_PROFILE, [$postId], true);
        } else {
            // Successful dense build: clear retry counter.
            delete_post_meta($postId, '_qt_ai_retry_attempts');
        }
    }
}
