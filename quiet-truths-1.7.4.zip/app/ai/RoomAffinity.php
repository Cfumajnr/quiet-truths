<?php
/**
 * Quiet Truths — Room Affinity
 *
 * Scores how strongly a story resonates with each of the seven rooms.
 * Unlike a categorizer that forces a single bucket, affinity produces
 * a 0..1 score for EVERY room. The highest-scoring room is the
 * "primary" placement; rooms above the secondary threshold are
 * offered as secondary resonances. Editorial assignment (the room
 * chosen by mwenye nyumba) is a separate, human decision and always
 * wins for placement — but affinity is available to the librarian
 * for search, related-story links, and why-chains.
 *
 * Scoring combines (in order of weight):
 *   1. semantic prototype similarity   — BGE-M3 embedding distance to
 *      hand-curated "room prototype" phrases when the embeddings
 *      service is live (0 when off). Prototypes are vectorised ONCE
 *      via PrototypeCache (persisted to wp_options) and reused across
 *      every story, so cost is one story embed per build, not N per
 *      room.
 *   2. concept evidence               — matches against the existing
 *      multilingual concept knowledge base.
 *   3. signal evidence                — overlaps with the Signals
 *      layer (emotional, relationship, time, context, communication).
 *   4. lexical cues                   — direct phrase hits for the
 *      strongest room-specific phrases.
 *   5. tiny editorial semantic gravity for Heavy Hearts (0.02),
 *      reflecting the genuinely wider emotional range the room holds
 *      — NOT its popularity.
 *
 * When the embeddings service is off, affinity is a multi-signal
 * lexical score (clearly noted as such in $raw['mode']); when it is
 * on, it is genuinely semantic. The scorer never blocks on the
 * service: if embeddings are unavailable it falls back gracefully.
 *
 * HIERARCHY OF EVIDENCE (by weight, strongest first):
 *     semantic prototype (0.35)
 *        -> concepts (0.18)
 *        -> signals (0.10)
 *        -> lexical cues (0.05)
 *        -> Heavy-Hearts semantic gravity (0.02)
 *
 * Lexical cues are supporting evidence only. Do NOT expand lexical
 * lists to cover missed stories — that path rebuilds a keyword
 * classifier inside a much larger file. Add/better prototypes and
 * let BGE-M3 generalise; reserve lexical for unmistakable room
 * markers ("Dear Dad", "we buried", "first day") that should fire
 * regardless of embedding drift.
 *
 * The 0..1 mapping of cosine (best - 0.25) / 0.40 is a PROVISIONAL
 * calibration constant, not a universal truth about BGE-M3. Raw
 * best-cosine per room is returned in $raw['proto_best'] so future
 * calibration can tune thresholds against real stories without
 * changing the scoring pipeline.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

use QuietTruths\Core\Concepts;
use QuietTruths\Core\Config;
use QuietTruths\Core\AiKernel;

final class RoomAffinity
{
    /**
     * Minimum score to treat as a meaningful secondary resonance.
     */
    public const SECONDARY_THRESHOLD = 0.45;

    /**
     * Cosine-to-affinity mapping constants (provisional — kept named so
     * calibration can tune them against real stories).
     */
    public const PROTO_FLOOR = 0.25;  // cosine below this contributes 0
    public const PROTO_RANGE = 0.40;  // cosine range that maps to 0..1

    /**
     * @return array<string,array{name:string,description:string,concepts:list<string>,lexical:list<string>,signals:list<string>,bias:float,prototypes:list<string>}>
     */
    public static function rooms(): array
    {
        // Canonical source of truth: app/config/rooms.php, loaded by
        // Config at boot. RoomAffinity is a SCORING ENGINE, not a second
        // ontology — it never redefines what a room means.
        //
        // Shape of each spec: { name, description, purpose, concepts[],
        // signals[], lexical[], bias:float, prototypes[] }.
        $specs = Config::instance()->roomSpecs();

        // Defensive fallback: if Config has not booted (should never
        // happen in normal theme load but guards against CLI/test
        // environments), require the file directly.
        if (empty($specs)) {
            $f = dirname(__DIR__) . '/config/rooms.php';
            if (is_file($f)) {
                $specs = (array) require $f;
            }
        }

        // Make sure every spec carries the keys score() expects (in case
        // a room entry is added with a partial definition).
        foreach ($specs as $slug => $spec) {
            if (!is_array($spec)) { unset($specs[$slug]); continue; }
            $specs[$slug] = array_merge([
                'name'        => ucfirst((string) $slug),
                'description' => '',
                'purpose'     => '',
                'concepts'    => [],
                'signals'     => [],
                'lexical'     => [],
                'bias'        => 0.0,
                'prototypes'  => [],
            ], $spec);
        }

        return $specs;
    }

    /**
     * Flatten all room prototypes into one ordered list (for batched
     * embedding in Profile::build()).
     *
     * @return list<string>
     */
    public static function allPrototypes(): array
    {
        $out = [];
        foreach (self::rooms() as $spec) {
            foreach ((array) ($spec['prototypes'] ?? []) as $p) {
                $out[] = $p;
            }
        }
        return array_values(array_unique($out));
    }

    /**
     * Score room affinity for a piece of text.
     *
     * @param string              $text         Full story text (title + content).
     * @param array<string,float> $concepts     Concept slugs → scores.
     * @param array<string,mixed> $signals      Signals from Signals::forText().
     * @param array<float>|array<string,float>|null $storyVec  Precomputed vector for $text (or null to compute/fallback).
     * @param array<string,array<float>|array<string,float>>|null $protoVecs Precomputed phrase→vector cache for all room prototypes (from PrototypeCache).
     *
     * @return array{affinity:array<string,float>,raw:array<string,mixed>}
     *               affinity: slug→0..1; raw: per-room diagnostics including best raw cosine for calibration.
     */
    public static function score(
        string $text,
        array $concepts = [],
        array $signals = [],
        $storyVec = null,
        ?array $protoVecs = null
    ): array {
        $t       = AiKernel::normalise($text);
        $rooms   = self::rooms();
        $affinity = [];
        $raw     = ['proto_best' => [], 'mode' => 'lexical'];

        // Populate signals if caller did not pass them.
        if (empty($signals)) {
            $signals = Signals::forText($text);
        }

        $comm = (array) ($signals['communication'] ?? []);
        $emo  = (array) ($signals['emotional'] ?? []);
        $rel  = (array) ($signals['relationship'] ?? []);
        $tim  = (array) ($signals['time'] ?? []);
        $ctx  = (array) ($signals['context'] ?? []);

        // If precomputed vectors were NOT supplied, we fall back to the
        // legacy "do it ourselves" path via PrototypeCache so cache-
        // warming still happens even if called standalone (e.g. from CLI
        // classify or a future test harness). This path makes AT MOST one
        // extra story-embed call + uses cached protos.
        if (null === $storyVec || null === $protoVecs) {
            $cached = PrototypeCache::vectors('rooms', self::allPrototypes());
            $storyVecs = Embeddings::embed([$t]);
            $storyVec  = $storyVecs[0] ?? [];
            $protoVecs = $cached;
            $raw['mode'] = Embeddings::canWriteDense() && !empty($storyVec) && Embeddings::isDenseModel(Embeddings::activeModel()) ? 'dense' : 'lexical';
        } else {
            $raw['mode'] = (!empty($storyVec) && is_array($storyVec) && isset($storyVec[0])) ? 'dense' : 'lexical';
        }

        foreach ($rooms as $slug => $spec) {
            $score = (float) ($spec['bias'] ?? 0.0);
            $bestCos = 0.0;

            // 1) Semantic prototype similarity (strongest when embeddings are on).
            if (!empty($storyVec) && !empty($protoVecs)) {
                foreach ((array) ($spec['prototypes'] ?? []) as $p) {
                    $pv = $protoVecs[$p] ?? [];
                    if (empty($pv)) continue;
                    $sim = Embeddings::vectorSimilarity($storyVec, $pv);
                    if ($sim > $bestCos) $bestCos = $sim;
                }
            }
            $protoMapped = max(0.0, min(1.0,
                ($bestCos - self::PROTO_FLOOR) / max(0.01, self::PROTO_RANGE)
            ));
            $score += 0.35 * $protoMapped;

            // 2) Concept matches.
            foreach ((array) $spec['concepts'] as $c) {
                if (isset($concepts[$c])) {
                    $score += 0.18 * (float) $concepts[$c];
                }
            }

            // 3) Signal matches.
            foreach ((array) $spec['signals'] as $sigRef) {
                [$group, $name] = explode(':', $sigRef . ':');
                $groupArr = (array) ($signals[$group] ?? []);
                if (isset($groupArr[$name])) {
                    $score += 0.10 * (float) $groupArr[$name];
                }
            }

            // 4) Lexical cues.
            foreach ((array) $spec['lexical'] as $phrase) {
                if (str_contains($t, $phrase)) {
                    $score += 0.05;
                }
            }

            $affinity[$slug] = min(0.99, round($score, 2));
            $raw['proto_best'][$slug] = round($bestCos, 3);
        }

        // Letters gets a heavy bonus when the communication detector fires.
        if (!empty($comm['unsent_letter'])) {
            $affinity['letters'] = min(0.99, max((float) $affinity['letters'], 0.55 + 0.35 * (float) $comm['unsent_letter']));
        }
        if (!empty($comm['address_to_younger_self'])) {
            $affinity['letters'] = min(0.99, max((float) $affinity['letters'], 0.80));
        }
        if (!empty($comm['address_to_deceased']) && ($comm['unsent_letter'] ?? 0) > 0) {
            $affinity['letters'] = min(0.99, max((float) $affinity['letters'], 0.85));
        }
        if (!empty($comm['gratitude_letter']) && ($comm['unsent_letter'] ?? 0) > 0) {
            $affinity['letters'] = min(0.99, max((float) $affinity['letters'], 0.80));
            $affinity['small-mercies'] = min(0.99, max((float) $affinity['small-mercies'], 0.65));
        }

        arsort($affinity);
        return ['affinity' => $affinity, 'raw' => $raw];
    }

    /**
     * Legacy scalar entry point — returns just the affinity array (matches
     * the previous signature so consumers that call RoomAffinity::score()
     * without capturing raw still work).
     *
     * @return array<string,float>
     */
    public static function scoreLegacy(string $text, array $concepts = [], array $signals = []): array
    {
        $res = self::score($text, $concepts, $signals);
        return $res['affinity'];
    }

    /**
     * Pick primary and secondary rooms from an affinity array.
     *
     * @param array<string,float> $affinity
     * @return array{primary:?string, score:float, secondary:list<array{slug:string,score:float}>}
     */
    public static function primarySecondary(array $affinity): array
    {
        if (empty($affinity)) {
            return ['primary' => null, 'score' => 0.0, 'secondary' => []];
        }

        arsort($affinity);
        $slugs = array_keys($affinity);
        $primary = (string) $slugs[0];
        $primaryScore = (float) $affinity[$primary];

        $secondary = [];
        foreach ($affinity as $slug => $score) {
            if ($slug === $primary) continue;
            if ($score >= self::SECONDARY_THRESHOLD) {
                $secondary[] = ['slug' => $slug, 'score' => round($score, 2)];
            }
        }

        return [
            'primary'   => $primary,
            'score'     => round($primaryScore, 2),
            'secondary' => array_slice($secondary, 0, 2),
        ];
    }
}
