<?php
/**
 * Quiet Truths — AI Story Profile
 *
 * Single source of truth for everything the AI knows about a story.
 *
 * IMPORTANT: the READ PATH is read-only. Profile::get() never initiates
 * network calls or expensive computation. If a profile doesn't exist
 * (or is from an older schema, or was built by a different model class),
 * get() returns a LIGHTWEIGHT FALLBACK built from already-persisted
 * meta + fast lexical checks. Building the full profile (embeddings,
 * semantic concept scores) is the job of Profile::build()/warm(),
 * called only from the background worker or WP-CLI.
 *
 * Schema (v8) — the canonical profile, no Door/Theme dimensions:
 *
 *   identity     — post_id, language
 *   observations — hard facts: word count, direct flags, named-child,
 *                  workplace, school, place, signals
 *   semantic     — embedding_model, embedding_dim, has_embedding
 *
 *   // The canonical background ontology (no doors, no themes)
 *   rooms        — room affinity scores (slug => 0..1). 'primary' is
 *                  the librarian's strongest suggestion; 'secondary'
 *                  are cross-resonances above SECONDARY_THRESHOLD.
 *                  'assigned' is the human-chosen room (from taxonomy)
 *                  and always wins for public placement.
 *   concepts     — what the story is about (slug => score).
 *   threads      — recurring human currents; 'scores' (all) and 'active'
 *                  (those above threshold, lifecycle-gated).
 *   domains      — twenty private areas of life, derived from concepts
 *                  + threads; never public.
 *   signals      — evidence (emotional / relationship / time / context /
 *                  communication) — observations, not conclusions.
 *   context      — tense, life_stage, relationships, circumstance.
 *   relationships— typed relations to other stories (filled by StoryRelations).
 *
 *   // Reader-facing
 *   content      — warnings
 *   privacy      — risk_score + observations + writer_warnings
 *
 *   // Administrative (not published, not shown in HTML):
 *   editorial    — semantic_affinity vs editorial_prevalence kept
 *                  separate. Heavy Hearts gravity is semantic (0.02
 *                  bias), not a popularity weight.
 *
 *   confidence   — 0..1  (Correction Twenty-One: uncertainty is honest)
 *
 *   // Legacy compatibility bucket — populated by upfitV7() when
 *   // reading older v7 profiles, and by writeBackCompat() when
 *   // persisting. Canonical code never reads from here.
 *   _legacy      — { doors: [], themes_keyword: 'concepts' }
 *
 * The v8 profile no longer treats "Doors" or "Themes" as primary AI
 * dimensions (per 1.7.2 memo Edits 3–6). Family/work/faith/love/loss/
 * growth/healing continue to be understood through the proper
 * background layers (Rooms + Threads + Domains + Concepts + Signals +
 * Context), not as a second public taxonomy.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

use QuietTruths\Core\Concepts;
use QuietTruths\Core\Config;

final class Profile
{
    public const META_KEY = '_qt_ai_profile';

    /**
     * Bump when profile SHAPE changes. Existing profiles below this
     * version are considered stale.
     *
     * v6: semantic.mode / raw_similarities / semantic_build lifecycle
     *     (dense preservation, gatekeeper, retryable).
     * v7: ontology-refinement release (AI Bible, audit 1.6.2):
     *   - threads set opened beyond ten (36 currents in nine families),
     *     deprecated slugs resolvable via canonicalSlug().
     *   - domains block derived from concept weights (20 private areas
     *     of life; not separately scored; never public).
     *   - concepts/threads carry per-entry confidence + evidence.
     *   - context block now carries tense (past/present/future_feared/
     *     future_hoped/remembered/imagined) — first meaningful step on
     *     the Context priority from audit §X ("I am afraid mother will
     *     die" ≠ "My mother died").
     *   - provenance includes ontology_version + build_version.
     *   - signals carry type/confidence/span scaffolding for richer
     *     evidence chains.
     *
     * v8 (1.7.2) — Door/Theme retirement completion:
     *   - Doors and Themes removed as primary profile dimensions.
     *   - `doors` / `themes` keys moved to `_legacy` on older profiles.
     *   - Canonical concept storage is post meta `_qt_concepts`
     *     (Edit Eight). Legacy `_qt_themes` continues to be READ for
     *     back-compat but is no longer WRITTEN by warm().
     *   - `_qt_doors` is no longer written. It is still read defensively
     *     in Embeddings legacy-term fallbacks so existing sites do not
     *     lose signals until the next rebuild.
     *   - Relation labelling now uses concept/thread overlap rather than
     *     "same_theme" / "sameDoor" (Edit Five).
     *   - Profile keeps confidence at the top level and expresses
     *     uncertainty honestly (Correction Twenty-One).
     */
    public const SCHEMA_VERSION = 8;

    // Canonical post-meta keys (1.7.2 / Edit Eight).
    public const CONCEPTS_META_KEY = '_qt_concepts';
    // Legacy meta keys — READ for back-compat, no longer WRITTEN.
    public const LEGACY_THEMES_META_KEY = '_qt_themes';
    public const LEGACY_DOORS_META_KEY  = '_qt_doors';

    public const FRESH = 'fresh';
    public const STALE = 'stale';

    /**
     * Meta key for the rebuild-request flag. This is SEPARATE from the
     * profile's own _status:
     *   _status             — QUALITY of the stored profile.
     *                         FRESH  = built by a full build() run with
     *                                  whatever semantic mode was
     *                                  achievable; safe to serve, safe
     *                                  to use for editorial/SQL/related-
     *                                  story work. Does NOT guarantee
     *                                  the content hasn't changed since
     *                                  — see `source` below for that.
     *                         STALE  = provisional (lexical fallback
     *                                  for a brand-new post whose dense
     *                                  build hasn't landed yet, or a
     *                                  pre-migration profile).
     *   _rebuild_pending    — boolean flag; true means a background
     *                         (re)build has been requested and not yet
     *                         completed.
     *   source              — provenance: which post_modified_gmt and
     *                         content_hash this profile was built
     *                         against, and when it was built. With
     *                         this, consumers can tell the difference
     *                         between "this is a fresh profile for the
     *                         current content" and "this is a still-
     *                         good older profile, a rebuild is queued
     *                         for the new revision."
     *
     * v1.5.8 correction: FRESH no longer claims to describe current
     * content. FRESH describes build quality; source describes currency.
     * On edit we set _rebuild_pending=true WITHOUT demoting the FRESH
     * profile, and source.is_current will report false until the new
     * build lands atomically. STALE is reserved for genuinely provi-
     * sional profiles (lexical-first-build), not for "edit happened.
     */
    public const REBUILD_PENDING_KEY = '_qt_ai_rebuild_pending';

    /**
     * READ-ONLY access to a post's stored profile. NEVER computes embeddings
     * or makes HTTP calls. If nothing is stored, returns a fast lexical
     * fallback so consumers always have something to work with.
     *
     * @return array<string,mixed>
     */
    public static function get(int $postId): array
    {
        $post = get_post($postId);
        if (!$post) {
            return [];
        }

        $raw = get_post_meta($postId, self::META_KEY, true);

        $schemaOk = is_array($raw) && !empty($raw)
            && (int) ($raw['schema_version'] ?? 0) >= self::SCHEMA_VERSION;

        // Valid profile (schema matches) → return it. FRESH profiles are
        // served unconditionally, even while a rebuild is pending — the
        // rebuild flag means "a new build is wanted," not "the current
        // profile is bad." STALE profiles are returned too (readers
        // always get the last usable profile), but consumers may down-
        // weight them or annotate them as provisional.
        if ($schemaOk) {
            return self::normalise($raw);
        }

        // Allow v6 profiles to be served transparently (canonicalise
        // deprecated thread slugs, fill missing keys) — the lifecycle
        // guarantees we never demote a good dense profile; schema bump
        // is additive, so back-compat shape is safe.
        if (is_array($raw) && !empty($raw) && (int) ($raw['schema_version'] ?? 0) === 6) {
            return self::normalise(self::upfitV7(self::upfitV6($raw)));
        }

        // v7 profiles carried doors/themes at the top level. Up-fit them
        // into the canonical v8 shape by moving those keys into _legacy
        // (read-only, ignored by canonical consumers).
        if (is_array($raw) && !empty($raw) && (int) ($raw['schema_version'] ?? 0) === 7) {
            return self::normalise(self::upfitV7($raw));
        }

        // Missing or schema-too-old → return a lightweight lexical
        // fallback. This is read-only and does not hit the service.
        return self::lightweightFallback($post);
    }

    /**
     * Is a profile ready for downstream consumers (related stories,
     * search, editorial view)?
     *
     * "Ready" means BUILD QUALITY, not currency:
     *   - requireDense=false: any schema-current FRESH profile counts,
     *     even if a rebuild is pending for a newer revision. The
     *     existing profile is still a useful, well-formed reading of
     *     (some recent version of) the story.
     *   - requireDense=true : also requires the stored vector to be a
     *     dense model vector (used for consumers that NEED cosine over
     *     dense vectors, e.g. semantic search).
     *
     * Consumers that need to know whether the profile matches the
     * CURRENT content (as opposed to a still-good previous revision)
     * should call Profile::isCurrent($id) separately.
     */
    public static function isReady(int $postId, bool $requireDense = false): bool
    {
        // Serve through get() which up-fits v6/v7 profiles transparently
        // — a FRESH v7 profile is still a perfectly good profile.
        $p = self::get($postId);
        if (empty($p)) return false;
        if (($p['_status'] ?? self::FRESH) !== self::FRESH) return false;
        if ($requireDense && Embeddings::embeddingStatus($postId) !== Embeddings::STATUS_DENSE) return false;
        return true;
    }

    /**
     * Is a background rebuild currently queued/in-flight for this post?
     * Exposed so readers/editors can show a gentle "refreshing" note
     * without being forced to treat the live profile as bad data.
     */
    public static function rebuildPending(int $postId): bool
    {
        return (bool) get_post_meta($postId, self::REBUILD_PENDING_KEY, true);
    }

    /**
     * Mark an existing profile as STALE (without deleting it). Use this
     * when the stored profile is known to be a bad representation of the
     * content — e.g. a lexical fallback persisted because the service
     * was down on first publish, or a pre-v6 profile that has not yet
     * been rebuilt. STALE is a statement ABOUT the stored profile, not
     * about whether work is queued.
     *
     * Do NOT call this on every content edit; call requestRebuild()
     * instead, which leaves a FRESH profile FRESH while a new build
     * runs.
     */
    public static function markStale(int $postId): void
    {
        $raw = get_post_meta($postId, self::META_KEY, true);
        if (!is_array($raw) || empty($raw)) {
            return;
        }
        if (($raw['_status'] ?? self::FRESH) !== self::STALE) {
            $raw['_status'] = self::STALE;
            update_post_meta($postId, self::META_KEY, $raw);
        }
    }

    /**
     * Request a background rebuild WITHOUT demoting the existing stored
     * profile. This is the correct call on content edit/publish: the
     * existing good profile (if any) stays FRESH and keeps serving
     * readers until an atomic replacement lands; we only set the
     * rebuild-pending flag so the background worker knows work is
     * wanted.
     */
    public static function requestRebuild(int $postId): void
    {
        update_post_meta($postId, self::REBUILD_PENDING_KEY, true);
    }

    /**
     * BUILD the full profile. May call the embedding service. Call only
     * from background / CLI contexts.
     *
     * @return array<string,mixed>
     */
    public static function build(\WP_Post $post): array
    {
        $text     = (string) $post->post_title . "\n\n" . (string) $post->post_content;
        // conceptsFromAlreadyStored() reads the canonical _qt_concepts
        // meta and falls back to legacy _qt_themes if present. Does NOT
        // create any new Door/Theme data.
        $existingConcepts = self::readStoredConcepts($post->ID);
        $under    = StoryUnderstanding::understand($text, $existingConcepts);
        $priv     = PrivacyScanner::scan($text);
        $signals  = Signals::forText($text);
        $warnings = ContentSignals::warningsFor($text);
        $assignedRooms = wp_get_object_terms($post->ID, 'qt_room', ['fields' => 'slugs']);
        $assignedRooms = is_wp_error($assignedRooms) ? [] : (array) $assignedRooms;
        $assignedRoom  = !empty($assignedRooms) ? (string) $assignedRooms[0] : null;

        $conceptScores = (array) ($under['concept_scores'] ?? []);

        // ── ONE-BATCH SEMANTIC EMBED ──────────────────────────────
        // Story text + all room prototypes + all thread prototypes go
        // to the embeddings service in a SINGLE HTTP call when the
        // prototype caches are cold. When the caches are warm (the
        // common case), the prototypes come from wp_options and only
        // the story is embedded — one HTTP call per story total, not
        // 18 (previously: 1 story + 7 room proto batches + 10 thread
        // proto batches = 18 calls).
        $roomProtos   = RoomAffinity::allPrototypes();
        $threadProtos = ThreadInference::allPrototypes();
        [$storyVec, $roomProtoVecs, $threadProtoVecs, $semanticMode] =
            PrototypeCache::embedStoryAndPrototypes($text, $roomProtos, $threadProtos);

        // ── Room affinity (semantic when dense, lexical otherwise) ──
        $roomResult   = RoomAffinity::score($text, $conceptScores, $signals, $storyVec, $roomProtoVecs);
        $roomAffinity = (array) $roomResult['affinity'];
        $roomRaw      = (array) ($roomResult['raw'] ?? []);
        $roomPS       = RoomAffinity::primarySecondary($roomAffinity);

        // ── Threads (cross-cutting invisible textures) ──
        $threadResult = ThreadInference::scoreThreads($text, $conceptScores, $signals, $storyVec, $threadProtoVecs);
        $threadScores = (array) $threadResult['scores'];
        $threadRaw    = (array) ($threadResult['raw'] ?? []);
        $allThreadDefs = ThreadInference::definitions();
        $activeThreads = [];
        foreach ($threadScores as $slug => $score) {
            if ($score < ThreadInference::THREAD_THRESHOLD) {
                continue;
            }
            $def = (array) ($allThreadDefs[$slug] ?? []);
            // Lifecycle gate (Correction Nine): candidate threads are
            // recorded in $threadScores (for corpus diagnostics /
            // future calibration) but held back from the active set
            // that feeds discovery fan-out. Only active/refining
            // threads reach related-story and search.
            if (!ThreadInference::isActive($def)) {
                continue;
            }
            $activeThreads[$slug] = round((float) $score, 2);
        }

        // Hard observations (facts, not interpretations).
        $directFlags = self::filterBySeverity($priv['flags'] ?? [], ['critical','high']);
        $contextFlags = self::filterBySeverity($priv['flags'] ?? [], ['medium','low']);
        $observations = [
            'word_count'           => (int) (get_post_meta($post->ID, '_qt_words', true) ?: self::countWords($text)),
            'has_phone'            => self::hasKind($directFlags, 'phone'),
            'has_email'            => self::hasKind($directFlags, 'email'),
            'has_id_number'        => self::hasKind($directFlags, 'id_number'),
            'has_mpesa'            => self::hasKind($directFlags, 'mpesa'),
            'has_social'           => self::hasKind($directFlags, 'social'),
            'has_url'              => self::hasKind($priv['flags'] ?? [], 'url'),
            'has_named_workplace'  => self::hasKind($contextFlags, 'workplace'),
            'has_named_school'     => self::hasKind($contextFlags, 'school'),
            'has_named_place'      => self::hasKind($contextFlags, 'place'),
            'has_named_child'      => self::hasKind($contextFlags, 'named_child') || self::hasKind($contextFlags, 'child'),
            'has_age_signal'       => (bool) preg_match('/\b(?:twenty|thirty|forty|fifty|[2-5][0-9])\b/u', $text),
            'has_gender_signal'    => (bool) preg_match('/\b(?:female|male|woman|man|mother|father|wife|husband)\b/u', $text),
            'has_city_signal'      => self::citySignal($text),
            'communication_mode'   => self::primaryCommunicationMode($signals['communication'] ?? []),
        ];

        $vectorMeta = self::vectorMetaFor($post->ID);

        // ── SEMANTIC BUILD DECLARATION ─────────────────────────────
        // This block is the AUTHORITATIVE contract for what kind of
        // build this run produced. warm() uses it to decide whether
        // to persist this profile over an existing good one.
        //
        //   mode       — 'dense'  : embedDense() succeeded; storyVec is
        //                           a validated dense BGE-M3 vector;
        //                           all prototype comparisons are dense.
        //                'lexical': embedDense() failed or service was
        //                           unavailable; scoring used token
        //                           vectors / lexical evidence only.
        //   complete   — true ONLY when mode==='dense'. Only a complete
        //                dense build is allowed to replace a previously
        //                stored dense profile. (Lifecycle rule: a good
        //                dense profile must never be demoted by a
        //                transient service outage.)
        //   retryable  — true when the build fell back to lexical
        //                because of a transient service failure; the
        //                background worker should try again later.
        $hasStoredDense = !empty($vectorMeta['has_embedding']);
        if ($semanticMode === 'dense') {
            $embStatus     = Embeddings::STATUS_DENSE;
            $semanticBuild = [
                'mode'      => 'dense',
                'complete'  => true,
                'retryable' => false,
            ];
        } else {
            // Lexical fallback. The stored vector status reflects what
            // is actually on disk: if a dense vector is already stored,
            // the post remains STATUS_DENSE (readers keep serving it),
            // but THIS build's mode is 'lexical' — that is the honest
            // answer about which path produced the scores below.
            // warm() will see complete=false and refuse to overwrite
            // an existing good dense profile.
            $embStatus     = $hasStoredDense ? Embeddings::STATUS_DENSE : Embeddings::STATUS_PENDING;
            $semanticBuild = [
                'mode'      => 'lexical',
                'complete'  => false,
                'retryable' => true,
                'reason'    => $hasStoredDense
                    ? 'service_unavailable_preserving_dense'
                    : 'service_unavailable_no_prior_dense',
            ];
        }

        $semanticForProfile = [
            // 'mode' tells consumers what path produced THIS build's
            // scores. It is the truth of this run, not a summary of
            // what is on disk. warm() is the only place that decides
            // whether to persist this profile over an existing one.
            'mode'            => $semanticMode,
            'embedding_model' => $semanticMode === 'dense' ? $vectorMeta['embedding_model'] : '',
            'embedding_dim'   => $semanticMode === 'dense' ? $vectorMeta['embedding_dim']   : 0,
            'has_embedding'   => $semanticMode === 'dense' ? (bool) $vectorMeta['has_embedding'] : false,
            'status'          => $embStatus,
            // Raw best-cosines for calibration (before 0..1 remap).
            // These are the numbers to inspect when tuning thresholds.
            'raw_similarities' => [
                'rooms'   => (array) ($roomRaw['proto_best'] ?? []),
                'threads' => (array) ($threadRaw['proto_best'] ?? []),
            ],
        ];

        // Emotional summary — preserve simple valence/arousal for backward compat.
        $emotionalSignals = (array) ($signals['emotional'] ?? []);
        $emotional = [
            'valence' => (float) ($emotionalSignals['_valence'] ?? 0.0),
            'arousal' => 0.0, // arousal computed more softly
            'labels'  => self::emotionalLabels($emotionalSignals),
            'signals' => array_diff_key($emotionalSignals, ['_valence' => 0]),
        ];

        // Life context — merged from old lifeContextSignals() + signals context.
        $life_context = [
            'stages'      => self::lifeStages($signals),
            'relationship'=> array_keys(array_filter((array) ($signals['relationship'] ?? []), fn($v) => $v >= 0.45)),
            'time'        => array_keys(array_filter((array) ($signals['time'] ?? []), fn($v) => $v >= 0.45)),
            'context'     => array_keys(array_filter((array) ($signals['context'] ?? []), fn($v) => $v >= 0.45)),
        ];

        // model: for a dense build use the live model name; for a
        // lexical build the vector used was tokens-v1.
        $modelName = $semanticMode === 'dense'
            ? ($vectorMeta['embedding_model'] ?: Embeddings::activeModel())
            : 'tokens-v1';

        $source = self::sourceFor($post);

        // ── Domain affinity (derived from concept + thread weights) ──
        // Domains are broad areas of life (Work & Livelihood, Family &
        // Care, ...). Per the AI Bible they are NOT scored from raw
        // evidence like rooms/threads/concepts — they are derived by
        // summing contributions from concepts and threads that declare
        // which domains they typically run through. They are private
        // organising structure, never exposed publicly.
        $domainScores = self::deriveDomains($conceptScores, $threadScores, $activeThreads);

        // ── Tense / time-orientation (context layer seed) ──
        // First meaningful step on the Context priority (audit §X):
        // distinguishes what happened (past) from what is feared
        // (future_feared), hoped for (future_hoped), remembered
        // (remembered), etc. Signals layer does most of the detection;
        // here we aggregate it into the profile's context block.
        $tense = self::deriveTense($text, $signals);
        $lifeStages = self::lifeStages($signals);
        $context = [
            'tense'        => $tense,
            'life_stage'   => $lifeStages,
            'relationships'=> self::extractContextRelationships($signals),
            'circumstance' => array_keys(array_filter(
                (array) ($signals['context'] ?? []),
                fn($v) => $v >= 0.45
            )),
        ];

        return [
            'schema_version' => self::SCHEMA_VERSION,
            'generated_at'   => $source['built_at'],   // back-compat alias
            'model'          => $modelName,
            'theme_version'  => QT_THEME_VERSION,
            '_status'        => self::FRESH,

            'identity' => [
                'post_id'  => (int) $post->ID,
                'language' => (string) ($under['language'] ?? 'en'),
            ],


            'source' => $source,

            // Hard facts — observations, not interpretations.
            'observations' => $observations,

            // Semantic metadata (mode describes THIS build's scoring path).
            'semantic'       => $semanticForProfile,
            // Authoritative build declaration — warm() uses this to decide
            // whether it is safe to persist this profile over an existing
            // good dense profile.
            //   complete=true  → dense build OK, persist unconditionally.
            //   complete=false → lexical fallback; only persist if there
            //                    is no existing good dense profile to
            //                    protect (and mark retryable).
            'semantic_build' => $semanticBuild,

            // ───── The four ontology layers ─────
            'rooms' => [
                'assigned'      => $assignedRoom,
                'affinity'      => $roomAffinity,
                'primary'       => $roomPS['primary'],
                'primary_score' => $roomPS['score'],
                'secondary'     => $roomPS['secondary'],
                'raw'           => [
                    'proto_best' => (array) ($roomRaw['proto_best'] ?? []),
                ],
            ],

            'concepts' => $conceptScores,

            'threads' => [
                'scores' => $threadScores,
                'active' => $activeThreads,
                'raw'    => [
                    'proto_best' => (array) ($threadRaw['proto_best'] ?? []),
                ],
            ],

            // DOMAINS (derived, not scored from evidence directly).
            // Per AI Bible: domains are broad areas of life (private,
            // never public). They are computed by aggregating concept
            // + thread contributions so a domain's "presence" reflects
            // how much of its territory the story touches.
            'domains' => [
                'scores' => $domainScores,
                // Derivation note for governance / why-chains:
                'derived_from' => 'concepts+threads',
            ],

            'signals' => [
                'emotional'     => (array) ($signals['emotional'] ?? []),
                'relationship'  => (array) ($signals['relationship'] ?? []),
                'time'          => (array) ($signals['time'] ?? []),
                'context'       => (array) ($signals['context'] ?? []),
                'communication' => (array) ($signals['communication'] ?? []),
            ],

            // Context layer (AI Bible §XXIV; audit §X).
            // Holds tense, life stage, relationships, circumstance.
            'context' => $context,

            'emotional'       => $emotional,
            'life_context'    => $life_context,

            // _legacy bucket: retained only for transition diagnostics
            // and migration visibility (v1.7.4 Correction 40).
            // Canonical code must NOT read from here for inference,
            // search, ranking, discovery, or Room assignment. v8+
            // builds produce no door groupings; this is empty for
            // current profiles.
            '_legacy' => [
                'doors'  => [], // deprecated — v8 builds produce no door groupings
                'source' => 'v8_build',
            ],

            // NOTE: the top-level 'themes' key is NOT populated here.
            // It is synthesised by normalise() (mirroring _legacy.doors)
            // solely as a deprecated back-compat shim for legacy
            // consumers. It is always empty for v8+ builds and must
            // not be read by current code (Correction 40).

            // RELATIONSHIPS to other stories (filled later by StoryRelations).
            'relationships' => [],

            // Reader-facing content.
            'content' => ['warnings' => $warnings],

            'privacy' => [
                'risk_score'             => round((float) ($priv['risk_score'] ?? 0.0), 2),
                'direct_identifiers'     => $directFlags,
                'contextual_identifiers'=> $contextFlags,
                'constellation_risk'    => self::hasFlagKind($priv['flags'] ?? [], ['constellation','uniqueness']),
                'writer_warnings'       => array_values((array) ($priv['writer_warnings'] ?? [])),
            ],

            'editorial' => [
                'semantic_affinity'    => true,
                'popularity_biased'    => false,
                'primary_by_ai'        => $roomPS['primary'],
                'assigned_by_mwenye'   => $assignedRoom,
            ],

            'confidence' => round((float) ($under['confidence'] ?? 0.0), 2),
        ];
    }

    /**
     * BUILD + PERSIST. Call from background/CLI only.
     *
     * LIFECYCLE GUARANTEE (v1.5.6):
     *
     *   PROFILE _status   = freshness of what is STORED (fresh/stale).
     *   REBUILD_PENDING   = whether a new build is WANTED (bool).
     *
     * These are independent. A profile can be FRESH while a rebuild is
     * pending (the common case after an edit: the existing good profile
     * keeps serving readers until a new dense build atomically replaces
     * it). A profile can be STALE with rebuild cleared (only when we
     * deliberately persist a lexical fallback and will upgrade later).
     *
     * Decisions:
     *   1. Dense build COMPLETE      → atomic replace; _status=FRESH;
     *                                  clear rebuild_pending.
     *   2. Lexical build + existing
     *      good dense profile        → DO NOT TOUCH the stored profile,
     *                                  _status, or rebuild_pending;
     *                                  leave it for retry. Readers keep
     *                                  the FRESH dense profile.
     *   3. Lexical build + no good
     *      existing profile          → persist lexical fallback with
     *                                  _status=STALE; keep rebuild_pending
     *                                  true so the dense upgrade fires
     *                                  when service returns.
     *
     * The old profile is never made semantically worse merely because
     * the new computation failed.
     *
     * @return string One of: 'persisted_dense', 'persisted_lexical_fallback',
     *                'preserved_existing_dense', 'failed'.
     */
    public static function warm(int $postId): string
    {
        $post = get_post($postId);
        if (!$post) return 'failed';
        try {
            // Compute/persist the story vector. forPostWrite() already
            // respects the "don't downgrade stored dense vector" rule
            // and leaves STATUS_KEY at dense_ready when preserving.
            Embeddings::forPostWrite($postId);

            $profile  = self::build($post);
            $build    = (array) ($profile['semantic_build'] ?? []);
            $complete = (bool) ($build['complete'] ?? false);

            // ── AUTHORITATIVE PERSISTENCE DECISION ────────────────
            if ($complete) {
                // Dense build succeeded: atomic replacement.
                $profile['_status'] = self::FRESH;
                update_post_meta($postId, self::META_KEY, $profile);
                self::writeBackCompat($postId, $profile);
                delete_post_meta($postId, self::REBUILD_PENDING_KEY);
                return 'persisted_dense';
            }

            // Incomplete (lexical) build. Inspect what is already stored.
            $existing = get_post_meta($postId, self::META_KEY, true);
            $existingIsGoodDense = is_array($existing)
                && (int) ($existing['schema_version'] ?? 0) >= self::SCHEMA_VERSION
                && ($existing['semantic_build']['complete'] ?? false) === true
                && ($existing['semantic']['mode'] ?? '') === 'dense'
                && ($existing['_status'] ?? self::FRESH) === self::FRESH;

            if ($existingIsGoodDense) {
                // Protect the good dense profile completely. We do NOT:
                //   - replace the profile array
                //   - flip _status to stale
                //   - clear rebuild_pending (we still want the rebuild)
                //   - touch writeBackCompat meta
                // Readers keep serving the FRESH dense profile. The
                // background worker will retry on backoff.
                return 'preserved_existing_dense';
            }

            // No good dense profile exists yet (first publish, or all
            // prior profiles were lexical/stale). Persist the lexical
            // fallback with _status=STALE so consumers know scores are
            // provisional; leave rebuild_pending=true so the next
            // successful dense run will upgrade it.
            $profile['_status'] = self::STALE;
            update_post_meta($postId, self::META_KEY, $profile);
            self::writeBackCompat($postId, $profile);
            // rebuild_pending stays true (or becomes true) — we want dense.
            update_post_meta($postId, self::REBUILD_PENDING_KEY, true);
            return 'persisted_lexical_fallback';
        } catch (\Throwable $e) {
            error_log('Quiet Truths: profile warmup failed for post ' . $postId . ': ' . $e->getMessage());
            return 'failed';
        }
    }

    /**
     * Queue a post for background profiling. Does NOT demote an
     * existing FRESH profile to STALE — it only sets the rebuild-
     * pending flag and schedules the background worker.
     */
    public static function queueWarm(int $postId): void
    {
        if ($postId < 1) return;
        // Two-state lifecycle: request rebuild without touching the
        // existing profile's _status. A FRESH profile stays FRESH while
        // the new build runs; if the build fails, the FRESH profile is
        // still there, untouched.
        self::requestRebuild($postId);
        // If there is no vector yet, mark status pending so the embed
        // lifecycle knows work is wanted (does NOT flip existing DENSE).
        if (Embeddings::needsDense($postId)) {
            $curStatus = Embeddings::embeddingStatus($postId);
            if ($curStatus !== Embeddings::STATUS_DENSE) {
                update_post_meta($postId, Embeddings::STATUS_KEY, Embeddings::STATUS_PENDING);
            }
        }
        BackgroundWorker::enqueueProfiling($postId);
    }

    public static function forget(int $postId): void
    {
        delete_post_meta($postId, self::META_KEY);
        delete_post_meta($postId, self::REBUILD_PENDING_KEY);
        delete_post_meta($postId, '_qt_ai_retry_attempts');
        Embeddings::purge($postId);
        // Canonical concept meta.
        delete_post_meta($postId, self::CONCEPTS_META_KEY);
        // Legacy keys — cleaned up on forget so rebuilt profiles start
        // fresh; left in place otherwise to preserve history.
        delete_post_meta($postId, self::LEGACY_DOORS_META_KEY);
        delete_post_meta($postId, self::LEGACY_THEMES_META_KEY);
    }

    /* ──────────────────── lightweight fallback (read path) ──────────────────── */

    /**
     * Cheap fallback that NEVER calls the embedding service. Good enough
     * for search/relations scoring during the window before the background
     * job completes, or when the service is down. Produces the same v5
     * shape as build() so consumers never need to branch.
     *
     * @return array<string,mixed>
     */
    private static function lightweightFallback(\WP_Post $post): array
    {
        $id    = (int) $post->ID;
        $text  = (string) $post->post_title . "\n\n" . (string) $post->post_content;
        $assignedRooms = wp_get_object_terms($id, 'qt_room', ['fields' => 'slugs']);
        $assignedRooms = is_wp_error($assignedRooms) ? [] : (array) $assignedRooms;
        $assignedRoom  = !empty($assignedRooms) ? (string) $assignedRooms[0] : null;

        // Lexical-only concept hints (phrase signatures, no embed).
        $phraseHits = ConceptInference::conceptsFromText($text);
        $conceptScores = [];
        foreach ($phraseHits as $slug) {
            $conceptScores[$slug] = 0.55;
        }
        $warnings = ContentSignals::warningsFor($text);
        // Legacy door groupings are NOT produced by v8 fallback builds.
        // They remain reachable only through upfitV7() on old profiles.

        // On fallback we use the cheap lexical signal detectors (Signals
        // may do a bit more work but never embeds, so it is safe).
        try {
            $signals = Signals::forText($text);
        } catch (\Throwable $e) {
            $signals = ['emotional'=>[],'relationship'=>[],'time'=>[],'context'=>[],'communication'=>[]];
        }

        try {
            $roomRes    = RoomAffinity::score($text, $conceptScores, $signals);
            $affinity   = (array) ($roomRes['affinity'] ?? []);
            $ps         = RoomAffinity::primarySecondary($affinity);
        } catch (\Throwable $e) {
            $affinity = [];
            $ps       = ['primary' => $assignedRoom, 'score' => 0.5, 'secondary' => []];
        }

        try {
            $threadRes      = ThreadInference::scoreThreads($text, $conceptScores, $signals);
            $threadScoresAll = (array) ($threadRes['scores'] ?? []);
            $fallbackThreadDefs = ThreadInference::definitions();
            $activeThreads = [];
            foreach ($threadScoresAll as $slug => $score) {
                if ($score < ThreadInference::THREAD_THRESHOLD) {
                    continue;
                }
                $def = (array) ($fallbackThreadDefs[$slug] ?? []);
                if (!ThreadInference::isActive($def)) {
                    continue;
                }
                $activeThreads[$slug] = round((float) $score, 2);
            }
        } catch (\Throwable $e) {
            $threadScoresAll = [];
            $activeThreads   = [];
        }

        // Derive domains (v7+) — even on fallback we produce a derived
        // domain view so consumers can rely on the key existing.
        $domainScores = self::deriveDomains($conceptScores, $threadScoresAll, $activeThreads);
        $tense = self::deriveTense($text, $signals);
        $fallbackContext = [
            'tense'         => $tense,
            'life_stage'    => (self::lifeContextSignals($text)['stages'] ?? []),
            'relationships' => self::extractContextRelationships($signals),
            'circumstance'  => array_keys(array_filter(
                (array) ($signals['context'] ?? []),
                fn($v) => $v >= 0.45
            )),
        ];

        $emo = self::emotionalSignals($text);
        $emotional = [
            'valence' => (float) $emo['valence'],
            'arousal' => (float) $emo['arousal'],
            'labels'  => (array) $emo['labels'],
            'signals' => (array) ($signals['emotional'] ?? []),
        ];
        $life_context = [
            'stages'       => self::lifeContextSignals($text)['stages'] ?? [],
            'relationship' => array_keys(array_filter((array) ($signals['relationship'] ?? []), fn($v) => $v >= 0.45)),
            'time'         => array_keys(array_filter((array) ($signals['time'] ?? []), fn($v) => $v >= 0.45)),
            'context'      => array_keys(array_filter((array) ($signals['context'] ?? []), fn($v) => $v >= 0.45)),
        ];

        // Privacy: use cached PII flags if present (set on submit), else
        // surface nothing rather than re-scanning on the read path.
        $storedFlags = get_post_meta($id, '_qt_ai_pii_flags', true);
        $storedFlags = is_array($storedFlags) ? $storedFlags : [];
        $riskScore   = (float) get_post_meta($id, '_qt_ai_risk_score', true);

        $v = Embeddings::forPostRead($id);
        $model = (string) get_post_meta($id, Embeddings::MODEL_KEY, true);
        if ('' === $model) { $model = empty($v) ? 'none' : 'tokens-v1'; }

        $fbSource = [
            'post_modified_gmt' => (string) $post->post_modified_gmt,
            'content_hash'      => self::contentHash($post),
            'built_at'          => gmdate('c'),
            'build_version'     => QT_THEME_VERSION,
            'ontology_version'  => defined('QT_ONTOLOGY_VERSION') ? QT_ONTOLOGY_VERSION : QT_THEME_VERSION,
        ];
        return [
            'schema_version' => self::SCHEMA_VERSION,
            'generated_at'   => $fbSource['built_at'],
            'model'          => 'fallback',
            'theme_version'  => QT_THEME_VERSION,
            'source'         => $fbSource,
            'identity'       => ['post_id' => $id, 'language' => self::detectLanguageCheap($text)],
            'observations'   => [
                'word_count'         => self::countWords($text),
                'has_phone'          => false,
                'has_email'          => false,
                'stale'              => true,
                'communication_mode' => self::primaryCommunicationMode((array) ($signals['communication'] ?? [])),
            ],
            'semantic' => [
                'mode'            => 'lexical',
                'embedding_model' => '',
                'embedding_dim'   => 0,
                'has_embedding'   => false,
                'status'          => empty($v) ? Embeddings::STATUS_PENDING : Embeddings::STATUS_LEXICAL,
                'raw_similarities' => ['rooms' => [], 'threads' => []],
            ],
            // Fallback is lexical by definition — never allowed to
            // replace a stored good dense profile.
            'semantic_build' => [
                'mode'      => 'lexical',
                'complete'  => false,
                'retryable' => true,
                'reason'    => 'read_path_fallback_no_stored_profile',
            ],
            'rooms' => [
                'assigned'      => $assignedRoom,
                'affinity'      => $affinity,
                'primary'       => $ps['primary'],
                'primary_score' => $ps['score'],
                'secondary'     => $ps['secondary'],
            ],
            'concepts'     => $conceptScores,
            'threads'      => [
                'scores' => $threadScoresAll,
                'active' => $activeThreads,
            ],
            'domains'      => [
                'scores'       => $domainScores,
                'derived_from' => 'concepts+threads',
            ],
            'signals'      => [
                'emotional'     => (array) ($signals['emotional'] ?? []),
                'relationship'  => (array) ($signals['relationship'] ?? []),
                'time'          => (array) ($signals['time'] ?? []),
                'context'       => (array) ($signals['context'] ?? []),
                'communication' => (array) ($signals['communication'] ?? []),
            ],
            'context'      => $fallbackContext,
            'relationships' => [],
            // Backward-compat keys so older readers keep working.
            'rooms_flat'   => $assignedRooms,
            'emotional_bc' => $emo,
            'emotional_arr'=> $emotional,
            'life_context' => $life_context,
            '_legacy'      => [
                'doors'  => [],
                'source' => 'v8_fallback',
            ],
            'content'      => ['warnings' => $warnings],
            'privacy'      => [
                'risk_score'             => round($riskScore, 2),
                'direct_identifiers'     => self::filterBySeverity($storedFlags, ['critical','high']),
                'contextual_identifiers'=> self::filterBySeverity($storedFlags, ['medium','low']),
                'constellation_risk'    => false,
                'writer_warnings'       => [],
            ],
            'editorial' => [
                'semantic_affinity'    => true,
                'popularity_biased'    => false,
                'primary_by_ai'        => $ps['primary'],
                'assigned_by_mwenye'   => $assignedRoom,
            ],
            'confidence' => 0.25,
            '_fallback'  => true,
        ];
    }

    /* ──────────────────── emotional & life signals ──────────────────── */

    /**
     * Pick the primary communication mode label from scored signals.
     * Returns a single string so consumers can branch quickly on form.
     */
    private static function primaryCommunicationMode(array $comm): string
    {
        if (empty($comm)) {
            return 'narrative';
        }
        arsort($comm);
        $top = key($comm);
        // If the top signal is weak, fall through to narrative.
        return ($comm[$top] ?? 0) >= 0.55 ? (string) $top : 'narrative';
    }

    /**
     * Build a small set of reader-facing labels from scored emotional signals.
     *
     * @param array<string,float> $emo
     * @return list<string>
     */
    private static function emotionalLabels(array $emo): array
    {
        $labels = [];
        $v = (float) ($emo['_valence'] ?? 0.0);
        if ($v <= -0.4)      $labels[] = 'sorrowful';
        elseif ($v <= -0.1)  $labels[] = 'heavy';
        elseif ($v >= 0.4)   $labels[] = 'hopeful';
        elseif ($v >= 0.1)   $labels[] = 'light';
        else                 $labels[] = 'quiet';

        // If grief/loss/shame dominate at high signal, mark 'weighted'.
        $weighted = max(
            (float) ($emo['grief'] ?? 0),
            (float) ($emo['shame'] ?? 0),
            (float) ($emo['betrayal'] ?? 0)
        );
        if ($weighted >= 0.7) $labels[] = 'weighted';

        if ((float) ($emo['longing'] ?? 0) >= 0.55) $labels[] = 'longing';
        if ((float) ($emo['relief'] ?? 0)  >= 0.55)  $labels[] = 'relieved';

        return array_values(array_unique($labels));
    }

    /**
     * Map the signal arrays into life-stage labels for back-compat with
     * the old life_context.stages shape.
     *
     * @param array<string,array<string,float>> $signals
     * @return array{stages:list<string>,relationship:list<string>,time:list<string>,context:list<string>}
     */
    private static function lifeStages(array $signals): array
    {
        $stageMap = [
            'childhood','adolescence','young_adult','new_parent',
            'marriage_early','recent_past','long_past','now_present',
            'looking_back','looking_forward',
        ];
        $stages = [];
        foreach ($stageMap as $s) {
            if ((($signals['time'][$s] ?? 0) >= 0.45) || in_array($s, ['childhood','young_adult'], true) && (($signals['context'][($s==='young_adult'?'work_hustle':'')] ?? 0) >= 0.4)) {
                if (in_array($s, ['childhood','adolescence','young_adult','new_parent','marriage_early'], true)) {
                    $stages[] = $s;
                }
            }
        }
        // More direct stage detection from context.
        foreach (['parenting' => ['pregnancy_birth','new_parent'],
                  'marriage'  => ['marriage_early'],
                  'midlife'   => ['long_past'],
                  'school'    => ['adolescence','young_adult']] as $stage => $sources) {
            foreach ($sources as $src) {
                if ((($signals['time'][$src] ?? 0) >= 0.45) || (($signals['context']['school_fees'] ?? 0) >= 0.5 && $stage === 'school')) {
                    $stages[] = $stage;
                    break;
                }
            }
        }
        return array_values(array_unique($stages));
    }

    /**
     * Cheap lexical emotional scores used only in the lightweight
     * fallback (read path when no profile is built yet). The full
     * Signals class is used during build().
     *
     * @return array{valence:float,arousal:float,labels:list<string>}
     */
    private static function emotionalSignals(string $text): array
    {
        $t = AiKernel::normalise($text);
        $pos = ['happy','laughed','smiled','forgave','healed','lighter','hope','grateful','thankful','better','peace','breathed','slept','warmth','furahi','furaha','amepumzika','amefurahi','asante','nashukuru'];
        $neg = ['cried','afraid','scared','broke','broken','died','funeral','shame','ashamed','empty','dark','alone','lost','failed','tired','hurt','analia','nimechoka','anaogopa','huzuni','mbaya','maumivu'];
        $high = ['shouted','screamed','hit','beat','ran','yelled','slapped','choked'];
        $low = ['quiet','silent','sat alone','stared','kimya','bubu'];
        $pc=0; foreach($pos as $w) if(str_contains($t,$w)) $pc++;
        $nc=0; foreach($neg as $w) if(str_contains($t,$w)) $nc++;
        $ha=0; foreach($high as $w) if(str_contains($t,$w)) $ha++;
        $la=0; foreach($low as $w) if(str_contains($t,$w)) $la++;
        $tot = $pc + $nc;
        $valence = $tot > 0 ? ($pc - $nc) / $tot : 0.0;
        $arousal = max(-1.0, min(1.0, 0.5*($ha - $la)));
        $labels = [];
        if ($valence <= -0.4) $labels[] = 'sorrowful';
        elseif ($valence <= -0.1) $labels[] = 'heavy';
        elseif ($valence >= 0.4) $labels[] = 'hopeful';
        elseif ($valence >= 0.1) $labels[] = 'light';
        else $labels[] = 'quiet';
        if ($arousal >= 0.3) $labels[] = 'intense';
        elseif ($arousal <= -0.3) $labels[] = 'still';
        return ['valence' => round($valence,2),'arousal' => round($arousal,2),'labels' => $labels];
    }

    /** @return array{stages:list<string>} */
    private static function lifeContextSignals(string $text): array
    {
        $t = AiKernel::normalise($text);
        $signals = [];
        $map = [
            'childhood'   => ['when i was young','child','growing up','primary school','kid','nilipokuwa mdogo'],
            'adolescence' => ['high school','secondary school','form ','teenage','campus','chuo'],
            'young_adult' => ['campus','university','after campus','first job','biashara'],
            'parenting'   => ['my child','my son','my daughter','mtoto wangu','became a mother','became a father'],
            'marriage'    => ['my husband','my wife','married','ndoa','harusi','my marriage'],
            'midlife'     => ['thirty','forty','after years','years later','miaka baadaye'],
            'loss_later'  => ['after they died','after the burial','old age','uzeeni'],
        ];
        foreach ($map as $k => $ph) {
            foreach ($ph as $p) if (str_contains($t,$p)) { $signals[] = $k; break; }
        }
        return ['stages' => array_values(array_unique($signals))];
    }

    /* ──────────────────── utilities ──────────────────── */

    /** @return array{embedding_model:string,embedding_dim:int,has_embedding:bool} */
    private static function vectorMetaFor(int $postId): array
    {
        $v     = Embeddings::forPostReadOnly($postId);
        $model = (string) get_post_meta($postId, Embeddings::MODEL_KEY, true);
        $dim   = (int) get_post_meta($postId, Embeddings::DIM_KEY, true);
        // Only claim an embedding when it is a real dense model vector.
        $hasDense = !empty($v) && Embeddings::isDenseModel($model);
        return [
            'embedding_model' => $hasDense ? $model : '',
            'embedding_dim'   => $hasDense ? $dim : 0,
            'has_embedding'   => $hasDense,
        ];
    }

    /**
     * Stable content fingerprint for a post. Hash is taken over the
     * title + raw post_content (wp_strip_all_tags, whitespace-
     * normalised) — exactly the text build() uses for embedding.
     * Stored in `source.content_hash` so we can answer "was this
     * profile built against the current content?" without guesswork.
     */
    public static function contentHash(\WP_Post $post): string
    {
        $title = wp_strip_all_tags((string) $post->post_title);
        $body  = wp_strip_all_tags((string) $post->post_content);
        $text  = trim(preg_replace('/\s+/u', ' ', $title . "\n\n" . $body) ?? '');
        // 16 hex chars = 64 bits of collision resistance — ample for
        // "did the content change?" checks inside a single site.
        return substr(sha1($text), 0, 16);
    }

    /**
     * Build the `source` provenance block for a profile at build time.
     * @return array{post_modified_gmt:string,content_hash:string,built_at:string}
     */
    private static function sourceFor(\WP_Post $post): array
    {
        return [
            'post_modified_gmt' => (string) $post->post_modified_gmt,
            'content_hash'      => self::contentHash($post),
            'built_at'          => gmdate('c'),
            'build_version'     => QT_THEME_VERSION,
            'ontology_version'  => defined('QT_ONTOLOGY_VERSION') ? QT_ONTOLOGY_VERSION : QT_THEME_VERSION,
        ];
    }

    /**
     * Was this profile built against the post's current content?
     * Looks at source.content_hash so the answer is based on actual
     * content identity, not timestamps or status flags.
     */
    public static function isCurrent(int $postId): bool
    {
        $raw = get_post_meta($postId, self::META_KEY, true);
        $post = get_post($postId);
        if (!is_array($raw) || !$post) return false;
        $storedHash = (string) ($raw['source']['content_hash'] ?? '');
        if ('' === $storedHash) return false;
        return hash_equals($storedHash, self::contentHash($post));
    }

    private static function detectLanguageCheap(string $text): string
    {
        $swWords = ['nilipata','akasema','alisema','alikufa','nimechoka','sijui','kwa','yangu','wangu','aliniambia','niliomba','kama','lakini','mimi','yeye','sana','kila','baada','kabla','tena','mpaka','kwa sababu','niko','sawa','habari','asante','pole','nyumbani','kijijini','ushago','kwangu'];
        $n = AiKernel::normalise($text);
        $hits = 0;
        foreach ($swWords as $w) if (preg_match('/\b' . preg_quote($w,'/') . '\b/u', $n)) $hits++;
        $en = preg_match_all('/\b(the|and|was|that|this|with|have|had|not|but|for|are)\b/u', $n);
        if ($hits >= 3) return $en >= 3 ? 'sw-en' : 'sw';
        return 'en';
    }

    /**
     * Derive domain affinity scores (0..1) from concept + thread weights.
     * Domains are the twenty private areas of life defined in
     * app/config/domains.php. They are NOT scored from raw evidence;
     * they are AGGREGATED from concept and thread contributions — a
     * domain's "presence" is how much of its territory the story
     * touches. This keeps domains as the organising layer the Bible
     * describes (audit §VI).
     *
     * @param array<string,float> $conceptScores
     * @param array<string,float> $threadScores
     * @param array<string,float> $activeThreads
     * @return array<string,float>
     */
    private static function deriveDomains(array $conceptScores, array $threadScores, array $activeThreads): array
    {
        // Thread → typical domains (from config/threads.php domains[] per thread).
        // We re-derive from the live definitions so adding a thread's
        // domains[] in config is enough.
        $domains = [];
        try {
            $definitions = class_exists(ThreadInference::class) ? ThreadInference::definitions() : [];
        } catch (\Throwable $e) {
            $definitions = [];
        }

        foreach ($definitions as $slug => $def) {
            $weight = (float) ($threadScores[$slug] ?? $activeThreads[$slug] ?? 0.0);
            if ($weight <= 0) continue;
            foreach ((array) ($def['domains'] ?? []) as $d) {
                $domains[$d] = ($domains[$d] ?? 0.0) + $weight * 0.6;
            }
        }

        // Direct concept→domain contributions for concepts we can map.
        // This is a modest seed; v1.8+ will move this to a full
        // concept→domain map in config/concepts.php when the concept
        // library carries explicit domains[].
        $conceptDomainSeed = [
            // People & Relationships
            'family'         => ['family-care','people-relationships'],
            'mother'         => ['family-care','people-relationships'],
            'father'         => ['family-care','people-relationships'],
            'parenthood'     => ['family-care'],
            'relationships'  => ['people-relationships','love-intimacy'],
            'friendship'     => ['people-relationships'],
            'friend'         => ['people-relationships','everyday-life'],
            'neighbour'      => ['people-relationships','everyday-life'],
            'colleague'      => ['people-relationships','work-livelihood'],
            // Work / Money
            'work'           => ['work-livelihood'],
            'money'          => ['money-material'],
            'debt'           => ['money-material'],
            'rent'           => ['money-material','home-belonging'],
            'ambition'       => ['work-livelihood','education-growth','identity-self'],
            'business'       => ['work-livelihood','money-material'],
            'unemployment'   => ['work-livelihood','money-material'],
            'school-fees'    => ['money-material','education-growth','family-care'],
            'poverty'        => ['money-material'],
            'savings'        => ['money-material'],
            // Home / Place
            'home'           => ['home-belonging','place-environment'],
            'village'        => ['home-belonging','place-environment'],
            'city'           => ['home-belonging','place-environment'],
            'migration'      => ['home-belonging','life-stages','place-environment'],
            'diaspora'       => ['home-belonging','place-environment'],
            'belonging'      => ['home-belonging','culture-society'],
            'origins'        => ['home-belonging','memory-time'],
            // Love / Intimacy
            'love'           => ['love-intimacy'],
            'marriage'       => ['love-intimacy','family-care','life-stages'],
            'jealousy'       => ['love-intimacy','emotional-experience'],
            'betrayal'       => ['love-intimacy','conflict-decisions','emotional-experience'],
            'separation'     => ['love-intimacy','loss-change','life-stages'],
            // Family / Care
            'caregiving'     => ['family-care','health-vulnerability'],
            'siblings'       => ['family-care','people-relationships'],
            'aging'          => ['family-care','life-stages','memory-time','health-vulnerability'],
            'aging-parents'  => ['family-care','health-vulnerability','memory-time'],
            'inheritance'    => ['family-care','money-material','memory-time'],
            // Emotional
            'grief'          => ['emotional-experience','loss-change'],
            'loneliness'     => ['emotional-experience'],
            'shame'          => ['emotional-experience','identity-self'],
            'fear'           => ['emotional-experience'],
            'guilt'          => ['emotional-experience'],
            'anger'          => ['emotional-experience','conflict-decisions'],
            'joy'            => ['emotional-experience','everyday-life'],
            'relief'         => ['emotional-experience','healing-recovery'],
            'hope'           => ['emotional-experience','faith-meaning'],
            'regret'         => ['emotional-experience','memory-time'],
            'gratitude'      => ['emotional-experience','everyday-life','faith-meaning'],
            'vulnerability'  => ['emotional-experience','health-vulnerability','identity-self'],
            'peace'          => ['emotional-experience','healing-recovery','faith-meaning'],
            'longing'        => ['emotional-experience','memory-time','love-intimacy'],
            // Conflict / Decisions
            'justice'        => ['conflict-decisions','culture-society'],
            'boundaries'     => ['conflict-decisions','identity-self','healing-recovery'],
            'courage'        => ['conflict-decisions','identity-self'],
            // Health
            'health'         => ['health-vulnerability'],
            'illness'        => ['health-vulnerability'],
            'addiction'      => ['health-vulnerability','emotional-experience'],
            'pain'           => ['health-vulnerability'],
            'disability'     => ['health-vulnerability'],
            'recovery'       => ['health-vulnerability','healing-recovery'],
            'mortality'      => ['health-vulnerability','loss-change','faith-meaning'],
            // Identity / Self
            'identity'       => ['identity-self'],
            'self-worth'     => ['identity-self','emotional-experience'],
            'authenticity'   => ['identity-self'],
            // Faith
            'religion'       => ['faith-meaning'],
            'faith'          => ['faith-meaning'],
            'prayer'         => ['faith-meaning'],
            'forgiveness'    => ['faith-meaning','healing-recovery','love-intimacy'],
            'spirituality'   => ['faith-meaning'],
            'doubt'          => ['faith-meaning','emotional-experience'],
            // Memory / Time
            'memory'         => ['memory-time'],
            'nostalgia'      => ['memory-time','emotional-experience'],
            'waiting'        => ['memory-time','emotional-experience'],
            'childhood'      => ['memory-time','life-stages'],
            // Loss / Change
            'loss'           => ['loss-change','emotional-experience'],
            'death'          => ['loss-change','health-vulnerability','emotional-experience'],
            'divorce'        => ['loss-change','love-intimacy','life-stages'],
            'departure'      => ['loss-change','life-stages','place-environment'],
            // Healing
            'healing'        => ['healing-recovery','emotional-experience'],
            'therapy'        => ['healing-recovery','health-vulnerability'],
            'sobriety'       => ['healing-recovery','health-vulnerability'],
            'starting-over'  => ['healing-recovery','life-stages'],
            // Everyday Life
            'food'           => ['everyday-life','money-material'],
            'chai'           => ['everyday-life'],
            'ugali'          => ['everyday-life'],
            'meals'          => ['everyday-life'],
            'routines'       => ['everyday-life'],
            'neighbour'      => ['everyday-life','people-relationships'],
            // Culture
            'traditions'     => ['culture-society','faith-meaning','memory-time'],
            'gender'         => ['culture-society','identity-self'],
            'community'      => ['culture-society','people-relationships','home-belonging'],
            'class'          => ['culture-society','money-material'],
            'reputation'     => ['culture-society','identity-self'],
            // Education
            'education'      => ['education-growth'],
            'school'         => ['education-growth','life-stages'],
            'university'     => ['education-growth','life-stages'],
            'exams'          => ['education-growth'],
            'learning'       => ['education-growth'],
            'mentorship'     => ['education-growth','people-relationships'],
            'achievement'    => ['education-growth','emotional-experience'],
            // Communication
            'letters'        => ['communication-expression'],
            'apology'        => ['communication-expression'],
            'confession'     => ['communication-expression'],
            'silence'        => ['communication-expression','emotional-experience'],
            'truth'          => ['communication-expression','justice'],
            'secrets'        => ['communication-expression','emotional-experience'],
        ];

        foreach ($conceptScores as $cslug => $cscore) {
            $cscore = (float) $cscore;
            if ($cscore <= 0) continue;
            foreach ((array) ($conceptDomainSeed[$cslug] ?? []) as $d) {
                $domains[$d] = ($domains[$d] ?? 0.0) + $cscore * 0.4;
            }
        }

        // Normalise 0..1 cap.
        $max = 0;
        foreach ($domains as $v) if ($v > $max) $max = $v;
        if ($max > 1.0) {
            foreach ($domains as &$v) $v = $v / $max;
            unset($v);
        }
        // Round and drop near-zero noise.
        foreach ($domains as $k => &$v) {
            $v = round((float) $v, 2);
            if ($v < 0.05) unset($domains[$k]);
        }
        unset($v);

        arsort($domains);
        return $domains;
    }

    /**
     * Derive basic tense / time-orientation from the text and signals.
     * Returns weighted scores for: past, present, future_feared,
     * future_hoped, remembered, imagined.
     *
     * This is a seed (v1.7). A richer tense parser belongs to v1.9.
     *
     * @return array<string,float>
     */
    private static function deriveTense(string $text, array $signals): array
    {
        $t = AiKernel::normalise($text);
        $out = [
            'past'          => 0.0,
            'present'       => 0.0,
            'future_feared' => 0.0,
            'future_hoped'  => 0.0,
            'remembered'    => 0.0,
            'imagined'      => 0.0,
        ];

        // Past signals — simple past tense cues.
        $pastCues   = ['was','were','had','did','lost','left','died','told','said','went','came','gave','found','happened','became','nilikuwa','alikufa','aliondoka','aliniambia','toka','zamani','siku za nyuma'];
        // Present signals.
        $presCues   = ['am','is','are','feel','wake','sit','carry','sleep','niko','naishi','sasa','kila siku','bado','nimekaa'];
        // Future-feared (what might happen, is feared, is dreaded).
        $fearCues   = ['afraid','fear','scared','worry','terrified','dread','might die','will die','might lose','will lose','what if','i might','naogopa','hofu','nina wasiwasi','sitaki','sijui','siku moja'];
        // Future-hoped (longed-for, expected, wished).
        $hopeCues   = ['hope','someday','one day','i will','i want to','pray that','looking forward','dream of','natumai','kuna siku','kila la heri','bado natafuta','natazamia','laiti','laiti ningekuwa'];
        // Remembered (explicit recall).
        $memCues    = ['remember','remembered','recall','flashback','memory','i still','nakumbuka','bado nakumbuka','zamani','nilipokuwa','kumbukumbu'];
        // Imagined / hypothetical.
        $imagCues   = ['what if','if i had','if only','imagine','wish i could','laiti','ningekuwa','ningefanya'];

        foreach ($pastCues as $w)  if (str_contains($t, $w)) $out['past']          += 0.15;
        foreach ($presCues as $w)  if (str_contains($t, $w)) $out['present']       += 0.15;
        foreach ($fearCues as $w)  if (str_contains($t, $w)) $out['future_feared'] += 0.18;
        foreach ($hopeCues as $w)  if (str_contains($t, $w)) $out['future_hoped']  += 0.15;
        foreach ($memCues as $w)   if (str_contains($t, $w)) $out['remembered']    += 0.18;
        foreach ($imagCues as $w)  if (str_contains($t, $w)) $out['imagined']      += 0.15;

        // Signals boost tense inference.
        $sigT = (array) ($signals['time'] ?? []);
        if (!empty($sigT['looking_back'])) $out['remembered'] += 0.2;
        if (!empty($sigT['childhood']))    $out['remembered'] += 0.15;
        if (!empty($sigT['recent']))       $out['past']       += 0.15;
        if (!empty($sigT['anniversary']))  $out['remembered'] += 0.1;

        // Cap.
        foreach ($out as $k => &$v) $v = round(min(1.0, $v), 2);
        unset($v);

        // If nothing detected, default to a gentle present/past mix
        // (most stories are narrated in past with present weight).
        if (max($out) < 0.1) {
            $out['past'] = 0.4;
        }
        return $out;
    }

    /**
     * Extract minimal relationship tuples from the relationship signals.
     *
     * Returns a compact list of { from:'self', rel, to } descriptors — a
     * seed, not the full relationship graph. The deep relationship graph
     * (job loss→financial pressure→shame→silence) belongs to v1.9.
     *
     * @return list<array{rel:string,to:string}>
     */
    private static function extractContextRelationships(array $signals): array
    {
        $rel = (array) ($signals['relationship'] ?? []);
        $out = [];
        $map = [
            'mother'         => ['rel' => 'family','to' => 'mother'],
            'father'         => ['rel' => 'family','to' => 'father'],
            'child'          => ['rel' => 'parent_of','to' => 'child'],
            'sibling'        => ['rel' => 'family','to' => 'sibling'],
            'spouse_partner' => ['rel' => 'partnership','to' => 'partner'],
            'friend'         => ['rel' => 'friendship','to' => 'friend'],
            'ex'             => ['rel' => 'former_partnership','to' => 'ex'],
            'grandparent'    => ['rel' => 'family','to' => 'grandparent'],
            'in_laws'        => ['rel' => 'family','to' => 'in-laws'],
            'deceased'       => ['rel' => 'grieving','to' => 'deceased'],
            'community'      => ['rel' => 'belonging','to' => 'community'],
            'colleague'      => ['rel' => 'work','to' => 'colleague'],
            'employer_boss'  => ['rel' => 'work','to' => 'employer'],
            'police_authority' => ['rel' => 'authority','to' => 'police/authority'],
        ];
        foreach ($rel as $k => $v) {
            if ((float) $v < 0.5) continue;
            if (isset($map[$k])) $out[] = $map[$k];
        }
        return $out;
    }

    /**
     * Fill in defaults on a profile so consumers can always rely on the
     * v7 shape (rooms, threads, domains, signals, context, source, ...).
     *
     * @param array<string,mixed> $p
     * @return array<string,mixed>
     */
    private static function normalise(array $p): array
    {
        $p['rooms']   = array_merge([
            'assigned' => null, 'affinity' => [], 'primary' => null,
            'primary_score' => 0.0, 'secondary' => [], 'raw' => ['proto_best' => []],
        ], (array) ($p['rooms'] ?? []));
        $p['threads'] = array_merge([
            'scores' => [], 'active' => [], 'raw' => ['proto_best' => []],
        ], (array) ($p['threads'] ?? []));
        $p['domains'] = array_merge([
            'scores' => [], 'derived_from' => 'concepts+threads',
        ], (array) ($p['domains'] ?? []));
        $p['signals'] = array_merge([
            'emotional' => [], 'relationship' => [], 'time' => [],
            'context' => [], 'communication' => [],
        ], (array) ($p['signals'] ?? []));
        $p['context'] = array_merge([
            'tense' => [], 'life_stage' => [], 'relationships' => [], 'circumstance' => [],
        ], (array) ($p['context'] ?? []));
        $p['semantic'] = array_merge([
            'mode' => 'lexical', 'embedding_model' => '', 'embedding_dim' => 0,
            'has_embedding' => false, 'status' => '',
            'raw_similarities' => ['rooms' => [], 'threads' => []],
        ], (array) ($p['semantic'] ?? []));
        $p['source'] = array_merge([
            'post_modified_gmt' => '', 'content_hash' => '', 'built_at' => '',
            'build_version' => '', 'ontology_version' => '',
        ], (array) ($p['source'] ?? []));
        $p['privacy'] = array_merge([
            'risk_score' => 0.0, 'direct_identifiers' => [],
            'contextual_identifiers' => [], 'constellation_risk' => false,
            'writer_warnings' => [],
        ], (array) ($p['privacy'] ?? []));
        $p['content'] = array_merge([
            'warnings' => [],
        ], (array) ($p['content'] ?? []));
        $p['editorial'] = array_merge([
            'semantic_affinity' => true, 'popularity_biased' => false,
            'primary_by_ai' => null, 'assigned_by_mwenye' => null,
        ], (array) ($p['editorial'] ?? []));

        // Canonicalise thread slugs (v1.7 renamed several).
        $p['threads']['scores'] = self::canonicaliseThreadKeys((array) $p['threads']['scores']);
        $p['threads']['active'] = self::canonicaliseThreadKeys((array) $p['threads']['active']);
        if (isset($p['threads']['raw']['proto_best']) && is_array($p['threads']['raw']['proto_best'])) {
            $p['threads']['raw']['proto_best'] = self::canonicaliseThreadKeys((array) $p['threads']['raw']['proto_best']);
        }

        // Ensure relationships / observations / concepts always exist.
        if (!isset($p['relationships']) || !is_array($p['relationships'])) $p['relationships'] = [];
        if (!isset($p['concepts'])     || !is_array($p['concepts']))     $p['concepts'] = [];
        if (!isset($p['observations']) || !is_array($p['observations'])) $p['observations'] = [];
        if (!isset($p['confidence']))   $p['confidence'] = 0.0;
        if (!isset($p['emotional']))    $p['emotional'] = ['valence'=>0,'arousal'=>0,'labels'=>[],'signals'=>[]];
        if (!isset($p['life_context'])) $p['life_context'] = ['stages'=>[],'relationship'=>[],'time'=>[],'context'=>[]];
        if (!isset($p['semantic_build'])) $p['semantic_build'] = ['mode' => 'lexical','complete' => false,'retryable' => false];

        // Legacy bucket (v1.7.4 Corrections 11, 40): canonical code MUST
        // NOT read from `themes` or `doors` as primary dimensions.
        //
        // - `_legacy.doors` carries old door-group labels ONLY for
        //   diagnostic/editor visibility and migration; it is PRIVATE
        //   and must NOT drive current inference, search, ranking, or
        //   public Room assignment.
        // - The `themes` top-level key is exposed ONLY as a back-compat
        //   shim so legacy consumer reads don't PHP-notice. It mirrors
        //   `_legacy.doors` (empty for v8+ builds) and must NEVER be
        //   written by current AI, nor treated as a live ontology
        //   dimension.
        if (!isset($p['_legacy']) || !is_array($p['_legacy'])) {
            $p['_legacy'] = ['doors' => [], 'source' => 'default'];
        } else {
            $p['_legacy'] = array_merge(['doors' => [], 'source' => 'default'], $p['_legacy']);
        }
        // Deprecated back-compat shim — Correction 40.
        // Legacy diagnostic information only; not for current logic.
        if (!isset($p['themes']) || !is_array($p['themes'])) {
            $p['themes'] = (array) ($p['_legacy']['doors'] ?? []);
        }

        return $p;
    }

    /**
     * Up-fit a v6 profile into the v7 shape. Fills domain scores from
     * the v6 thread/concept data and adds a basic tense reading.
     *
     * @param array<string,mixed> $p
     * @return array<string,mixed>
     */
    private static function upfitV6(array $p): array
    {
        $p['schema_version'] = self::SCHEMA_VERSION;
        $conceptScores = (array) ($p['concepts'] ?? []);
        $threadScores  = (array) ($p['threads']['scores'] ?? []);
        $active        = (array) ($p['threads']['active'] ?? []);
        $p['domains'] = [
            'scores'       => self::deriveDomains($conceptScores, $threadScores, $active),
            'derived_from' => 'concepts+threads',
        ];
        $signals = [
            'emotional'     => (array) ($p['signals']['emotional'] ?? []),
            'relationship'  => (array) ($p['signals']['relationship'] ?? []),
            'time'          => (array) ($p['signals']['time'] ?? []),
            'context'       => (array) ($p['signals']['context'] ?? []),
            'communication' => (array) ($p['signals']['communication'] ?? []),
        ];
        // Reconstruct a title+content blob is not possible here (we only
        // have the stored profile). Tense defaults: infer from time signals.
        $tense = ['past' => 0.4, 'present' => 0.2, 'future_feared' => 0.0,
                  'future_hoped' => 0.0, 'remembered' => 0.0, 'imagined' => 0.0];
        if (!empty($signals['time']['looking_back']) || !empty($signals['time']['childhood'])) {
            $tense['remembered'] = 0.5;
        }
        if (!empty($signals['context']['poverty_hardship']) || !empty($signals['emotional']['fear'])) {
            $tense['future_feared'] = 0.2;
        }
        $p['context'] = [
            'tense'         => $tense,
            'life_stage'    => (array) ($p['life_context']['stages'] ?? []),
            'relationships' => self::extractContextRelationships($signals),
            'circumstance'  => array_keys(array_filter((array) ($signals['context'] ?? []), fn($v) => $v >= 0.45)),
        ];
        $p['source'] = array_merge([
            'build_version'    => '',
            'ontology_version' => '',
        ], (array) ($p['source'] ?? []));
        return $p;
    }

    /**
     * Apply deprecated-slug canonicalisation to a thread-keyed map.
     *
     * @param array<string,mixed> $m
     * @return array<string,mixed>
     */
    private static function canonicaliseThreadKeys(array $m): array
    {
        $out = [];
        foreach ($m as $k => $v) {
            $canon = ThreadInference::canonicalSlug((string) $k);
            // If multiple old keys collapse to one canonical, take max.
            if (array_key_exists($canon, $out)) {
                $out[$canon] = max($out[$canon], $v);
            } else {
                $out[$canon] = $v;
            }
        }
        return $out;
    }

    private static function countWords(string $text): int
    {
        $w = preg_split('/\s+/u', trim(wp_strip_all_tags($text))) ?: [];
        return count(array_filter($w, fn($x) => '' !== $x));
    }

    private static function citySignal(string $text): bool
    {
        $t = AiKernel::normalise($text);
        foreach (['nairobi','mombasa','kisumu','nakuru','eldoret','thika','kitale','nyeri','kakamega','kisii','kericho','machakos','garissa','malindi','diani'] as $c) {
            if (str_contains($t, $c)) return true;
        }
        return false;
    }

    /** @param list<array> $flags */
    private static function filterBySeverity(array $flags, array $severities): array
    { return array_values(array_filter($flags, fn($f) => in_array($f['severity'] ?? 'low', $severities, true))); }

    /** @param list<array> $flags */
    private static function hasFlagKind(array $flags, array $kinds): bool
    {
        foreach ($flags as $f) if (in_array($f['kind'] ?? '', $kinds, true)) return true;
        return false;
    }

    private static function hasKind(array $flags, string $kind): bool
    { return self::hasFlagKind($flags, [$kind]); }

    /**
     * Write canonical meta keys.
     *
     * v1.7.3 (Corrections 3, 5, 12): canonical concept storage is
     * _qt_concepts. We NO LONGER WRITE to the legacy keys _qt_themes
     * or _qt_doors. Existing legacy values on older posts remain on
     * disk so read paths still see them during the transition; new
     * builds stop producing parallel data, and a future cleanup can
     * remove the legacy keys deliberately (never in-band).
     *
     * @param array<string,mixed> $p
     */
    private static function writeBackCompat(int $postId, array $p): void
    {
        update_post_meta($postId, '_qt_ai_version', (string) ($p['theme_version'] ?? QT_THEME_VERSION));
        update_post_meta($postId, '_qt_ai_profile_version', (int) ($p['schema_version'] ?? self::SCHEMA_VERSION));
        update_post_meta($postId, '_qt_ai_risk_score', (float) ($p['privacy']['risk_score'] ?? 0.0));
        $all = array_merge(
            (array) ($p['privacy']['direct_identifiers'] ?? []),
            (array) ($p['privacy']['contextual_identifiers'] ?? [])
        );
        update_post_meta($postId, '_qt_ai_pii_flags', $all);

        // Canonical concept meta (Edit Eight).
        $conceptList = [];
        foreach ((array) ($p['concepts'] ?? []) as $slug => $score) {
            $conceptList[] = [
                'slug'  => (string) $slug,
                'score' => round((float) $score, 3),
            ];
        }
        update_post_meta($postId, self::CONCEPTS_META_KEY, array_slice($conceptList, 0, 24));

        // Legacy keys (_qt_themes, _qt_doors) are NOT WRITTEN by v1.7.3+.
        // They remain READ during the transition window; existing
        // values are not destructively deleted.

        // Persist embedding status for operational visibility.
        $s = (string) ($p['semantic']['status'] ?? Embeddings::STATUS_PENDING);
        update_post_meta($postId, Embeddings::STATUS_KEY, $s);
    }

    /**
     * Read the canonical concept list off a post, falling back to the
     * legacy _qt_themes key during transition.
     *
     * @return list<string>
     */
    private static function readStoredConcepts(int $postId): array
    {
        $raw = get_post_meta($postId, self::CONCEPTS_META_KEY, true);
        if (is_array($raw) && !empty($raw)) {
            $out = [];
            foreach ($raw as $row) {
                if (is_string($row)) {
                    $out[] = $row;
                } elseif (is_array($row) && isset($row['slug'])) {
                    $out[] = (string) $row['slug'];
                }
            }
            return array_values(array_unique(array_filter($out)));
        }
        // Legacy key (still read during transition, no longer written
        // by new builds).
        $legacy = get_post_meta($postId, self::LEGACY_THEMES_META_KEY, true);
        if (is_array($legacy)) {
            return array_values(array_unique(array_filter(array_map('strval', $legacy))));
        }
        return [];
    }

    /**
     * Up-fit a v7 profile to v8.
     *
     * v7 carried `themes` (the retired door-group list) and `doors`
     * envelope entries at the top level. v8 moves these references
     * into `_legacy` so canonical code stops seeing them as primary
     * dimensions, and fills in defaults for the new canonical shape
     * (confidence, _legacy).
     *
     * @param array<string,mixed> $p
     * @return array<string,mixed>
     */
    private static function upfitV7(array $p): array
    {
        $p['schema_version'] = self::SCHEMA_VERSION;

        // Move legacy door/theme dimensions into _legacy so canonical
        // consumers never accidentally treat them as primary.
        $legacyDoors = [];
        if (isset($p['themes']) && is_array($p['themes'])) {
            $legacyDoors = array_values((array) $p['themes']);
        }
        $p['_legacy'] = [
            'doors'  => $legacyDoors,
            'source' => 'v7_upfit',
        ];
        unset($p['themes'], $p['doors']);

        // Provide a confidence default when missing (honest uncertainty).
        if (!isset($p['confidence'])) {
            $p['confidence'] = 0.5;
        }
        return $p;
    }
}
