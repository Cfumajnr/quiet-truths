<?php
/**
 * Quiet Truths — Responses (view layer)
 *
 * Loaded by loader.php. Renders the anonymous, threaded response
 * section for a story: flowing (never numbered), with reply/edit/
 * report forms. All logic lives in QuietTruths\Core\Responses.
 *
 * @package QuietTruths
 * @subpackage Presentation
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('qt_responses_section')) {
    /**
     * The whole responses section for a story page.
     */
    function qt_responses_section(int $storyId): void
    {
        if (!class_exists(\QuietTruths\Core\Responses::class)) {
            return;
        }

        $state = get_transient('qt_resp_state');
        if (is_array($state)) {
            delete_transient('qt_resp_state');
        }
        $errors = is_array($state) && !empty($state['errors']) ? $state['errors'] : [];
        $old    = is_array($state) && !empty($state['old']) ? $state['old'] : [];

        $message = '';
        if (isset($_GET['qt_resp'])) {
            $message = __('Your response is being held. It will appear once it has been read.', 'quiet-truths');
        } elseif (isset($_GET['qt_edited'])) {
            $message = __('Your response has been corrected.', 'quiet-truths');
        } elseif (isset($_GET['qt_reported'])) {
            $message = __('Thank you — the house has been told.', 'quiet-truths');
        }

        $threads = \QuietTruths\Core\Responses::forStory($storyId);
        $count   = count($threads);
        $total   = $count + (int) \QuietTruths\Core\Responses::descendantCount($storyId);

        echo '<section class="qt-responses" id="qt-responses" aria-label="' . esc_attr__('Responses', 'quiet-truths') . '">';
        echo '<hr class="quiet-divider">';

        echo '<p class="qt-responses__count">' . esc_html(sprintf(
            /* translators: %d number of responses */
            _n('%d response', '%d responses', $total, 'quiet-truths'),
            $total
        )) . '</p>';

        echo '<p class="qt-responses__invite">'
            . esc_html__('Responses are anonymous and held before they appear. Be kind — the writer may never see your words, but they are held just the same.', 'quiet-truths')
            . '</p>';

        if ('' !== $message) {
            echo '<p class="qt-responses__message" role="status">' . esc_html($message) . '</p>';
        }

        if (!empty($errors)) {
            echo '<ul class="qt-form__error" role="alert">';
            foreach ($errors as $code) {
                echo '<li>' . esc_html(qt_response_error_message($code)) . '</li>';
            }
            echo '</ul>';
        }

        if (empty($threads)) {
            echo '<p class="qt-responses__empty">' . esc_html__('No responses yet — your words would be the first.', 'quiet-truths') . '</p>';
        } else {
            echo '<div class="qt-responses__flow">';
            foreach ($threads as $thread) {
                qt_response_thread($thread);
            }
            echo '</div>';
        }

        qt_response_form($storyId, 0, 'top', $old);
        echo '</section>';
    }
}

if (!function_exists('qt_response_thread')) {
    /**
     * One response and, nested beneath it, its replies — flowing,
     * never numbered.
     */
    function qt_response_thread(\WP_Post $response, int $depth = 0): void
    {
        $depthClass = min($depth, 3);
        $canEdit    = \QuietTruths\Core\Responses::canEdit($response->ID);
        $replies    = \QuietTruths\Core\Responses::forStory(0, $response->ID);

        echo '<div class="qt-response" id="response-' . (int) $response->ID . '" data-depth="' . (int) $depthClass . '">';
        echo '<div class="qt-response__body">' . wp_kses_post(wpautop(esc_html((string) $response->post_content))) . '</div>';

        echo '<div class="qt-response__meta">';
        echo '<span>' . esc_html__('Anonymous', 'quiet-truths') . '</span>';
        echo '<span aria-hidden="true">·</span>';
        echo '<span>' . esc_html(qt_relative_time(get_post_time('U', true, $response))) . '</span>';
        if (get_post_meta($response->ID, '_qt_edited_at', true)) {
            echo '<span aria-hidden="true">·</span>';
            echo '<span>' . esc_html__('corrected', 'quiet-truths') . '</span>';
        }
        echo '</div>';

        echo '<div class="qt-response__actions">';
        echo '<button type="button" class="qt-response__action" data-qt-toggle="qt-reply-' . (int) $response->ID . '">'
            . esc_html__('Reply', 'quiet-truths') . '</button>';
        if ($canEdit) {
            echo '<button type="button" class="qt-response__action" data-qt-toggle="qt-edit-' . (int) $response->ID . '">'
                . esc_html__('Edit', 'quiet-truths') . '</button>';
        }
        echo '<button type="button" class="qt-response__action" data-qt-toggle="qt-report-' . (int) $response->ID . '">'
            . esc_html__('Report', 'quiet-truths') . '</button>';
        echo '</div>';

        /* Reply form */
        qt_response_form((int) get_post_meta($response->ID, '_qt_story_id', true), $response->ID, 'reply-' . $response->ID);

        /* Edit form — only for the writer */
        if ($canEdit) {
            echo '<form class="qt-response__form" id="qt-edit-' . (int) $response->ID . '" method="post">';
            echo '<textarea name="qt_response" rows="4" maxlength="1000" required>'
                . esc_textarea((string) $response->post_content) . '</textarea>';
            echo '<div class="qt-response__form-row">';
            echo '<span class="qt-response__hint">' . esc_html__('Correct it, and it will be held again.', 'quiet-truths') . '</span>';
            echo '<button class="qt-button qt-button--quiet" type="submit">' . esc_html__('Save correction', 'quiet-truths') . '</button>';
            echo '</div>';
            echo '<input type="hidden" name="qt_resp_action" value="edit">';
            echo '<input type="hidden" name="qt_response_id" value="' . (int) $response->ID . '">';
            wp_nonce_field('qt_edit_response_' . $response->ID);
            echo '</form>';
        }

        /* Report form */
        echo '<form class="qt-response__form" id="qt-report-' . (int) $response->ID . '" method="post">';
        echo '<label class="qt-form__label" for="qt_report_reason_' . (int) $response->ID . '">' . esc_html__('Why is this response not appropriate?', 'quiet-truths') . '</label>';
        echo '<select id="qt_report_reason_' . (int) $response->ID . '" name="qt_report_reason">';
        echo '<option value="abuse">' . esc_html__('Abusive or hateful', 'quiet-truths') . '</option>';
        echo '<option value="harassment">' . esc_html__('Harassment', 'quiet-truths') . '</option>';
        echo '<option value="spam">' . esc_html__('Spam or advertisement', 'quiet-truths') . '</option>';
        echo '<option value="personal">' . esc_html__('Contains personal information', 'quiet-truths') . '</option>';
        echo '<option value="other">' . esc_html__('Something else', 'quiet-truths') . '</option>';
        echo '</select>';
        echo '<div class="qt-response__form-row">';
        echo '<span class="qt-response__hint">' . esc_html__('Reports are read by the house.', 'quiet-truths') . '</span>';
        echo '<button class="qt-button qt-button--quiet" type="submit">' . esc_html__('Report', 'quiet-truths') . '</button>';
        echo '</div>';
        echo '<input type="hidden" name="qt_resp_action" value="report">';
        echo '<input type="hidden" name="qt_response_id" value="' . (int) $response->ID . '">';
        wp_nonce_field('qt_report_response_' . $response->ID);
        echo '</form>';

        /* Nested replies — under the comment, never beside it */
        if (!empty($replies)) {
            echo '<div class="qt-response__replies">';
            foreach ($replies as $reply) {
                qt_response_thread($reply, $depth + 1);
            }
            echo '</div>';
        }

        echo '</div>';
    }
}

if (!function_exists('qt_response_form')) {
    /**
     * The anonymous response form (top-level or a reply).
     *
     * @param array<string,string> $old
     */
    function qt_response_form(int $storyId, int $parentId, string $context, array $old = []): void
    {
        $label = $parentId > 0
            ? __('Reply to this response', 'quiet-truths')
            : __('Add your response', 'quiet-truths');

        echo '<form class="qt-response__form' . (0 === $parentId ? ' is-open' : '') . '"'
            . (0 === $parentId ? '' : ' id="qt-reply-' . $parentId . '"') . ' method="post">';

        echo '<label class="qt-form__label" for="qt_response_' . esc_attr($context) . '">' . esc_html($label) . '</label>';
        echo '<textarea id="qt_response_' . esc_attr($context) . '" name="qt_response" rows="4" maxlength="1000" placeholder="' . esc_attr__('Write gently — it will be read slowly.', 'quiet-truths') . '" required>'
            . esc_textarea($old['response'] ?? '') . '</textarea>';

        echo '<div class="qt-response__form-row">';
        echo '<span class="qt-response__hint">' . esc_html__('Anonymous · held before it appears', 'quiet-truths') . '</span>';
        echo '<button class="qt-button qt-button--quiet" type="submit">'
            . esc_html($parentId > 0 ? __('Send reply', 'quiet-truths') : __('Send response', 'quiet-truths')) . '</button>';
        echo '</div>';

        echo '<input type="hidden" name="qt_resp_action" value="create">';
        echo '<input type="hidden" name="qt_parent" value="' . (int) $parentId . '">';
        echo '<input type="text" name="qt_website" class="qt-hp" tabindex="-1" autocomplete="off" aria-hidden="true">';
        wp_nonce_field('qt_new_response');
        echo '</form>';
    }
}

if (!function_exists('qt_response_error_message')) {
    function qt_response_error_message(string $code): string
    {
        $messages = [
            'session'   => __('Your session expired — please try again.', 'quiet-truths'),
            'rate'      => __('The house receives responses slowly, so that each one is held properly. Please try again in a few minutes.', 'quiet-truths'),
            'short'     => __('A response needs at least a few words.', 'quiet-truths'),
            'long'      => __('Please keep responses under 1,000 characters.', 'quiet-truths'),
            'profanity' => __('That word cannot be held in this house. Please try again with kindness.', 'quiet-truths'),
            'invalid'   => __('Something is not right with that request. Please try again.', 'quiet-truths'),
            'store'     => __('Something went wrong while your response was being kept. Please try again.', 'quiet-truths'),
        ];

        return $messages[$code] ?? __('Something went wrong. Please try again.', 'quiet-truths');
    }
}
