<?php
/**
 * Quiet Truths — House Themes
 *
 * The middle layer of the house. Rooms are where a story is placed;
 * concepts are what it is about; themes are what the house is known
 * for — the doors you walk in by. Each theme collects the concepts
 * that belong to it, so a theme card is a promise: "come here for the
 * stories about family / work / faith / love / loss…"
 *
 * The cards on the homepage carry no counts and no hurry — just a name
 * and a quiet line. Walk through a door and the invisible layer finds
 * every story that belongs to it, whatever room those stories live in.
 *
 * @package QuietTruths
 */

return [
    'family'    => ['name' => 'Family',    'tagline' => 'the people we come from',              'concepts' => ['family', 'parenthood', 'origins', 'home', 'aging', 'memory']],
    'work'      => ['name' => 'Work',      'tagline' => 'what we do, and what it costs',        'concepts' => ['work', 'money', 'education', 'ambition', 'justice']],
    'tradition' => ['name' => 'Tradition', 'tagline' => 'what was handed down to us',           'concepts' => ['religion', 'origins', 'family', 'memory']],
    'faith'     => ['name' => 'Faith',     'tagline' => 'what we believe when no one is watching', 'concepts' => ['religion', 'hope', 'healing', 'silence', 'peace']],
    'love'      => ['name' => 'Love',      'tagline' => 'the ways we hold one another',         'concepts' => ['relationships', 'friendship', 'joy', 'love', 'jealousy', 'boundaries']],
    'loss'      => ['name' => 'Loss',      'tagline' => 'what stays when someone goes',         'concepts' => ['grief', 'separation', 'loneliness', 'memory', 'aging', 'silence']],
    'growth'    => ['name' => 'Growth',    'tagline' => 'becoming, slowly',                     'concepts' => ['growth', 'identity', 'courage', 'education', 'ambition', 'vulnerability']],
    'healing'   => ['name' => 'Healing',   'tagline' => 'the mending that takes time',          'concepts' => ['healing', 'forgiveness', 'hope', 'peace', 'boundaries', 'silence']],
];
