<?php
/**
 * Quiet Truths — Words the house cannot hold
 *
 * The response system never allows these words or phrases. The check
 * normalises the text first (lowercase, leetspeak mapping, repeated
 * letters collapsed, separators stripped), so "f*ck", "f.u.c.k",
 * "fuuuck" and "F U C K" are all caught.
 *
 * Add your own: words are matched as whole words; phrases as substrings.
 *
 * @package QuietTruths
 */

return [
    'words' => [
        'fuck', 'fucking', 'fucker', 'motherfucker', 'fuckface', 'fuckhead',
        'shit', 'bullshit', 'shitty', 'bitch', 'bastard', 'asshole', 'arsehole',
        'cunt', 'dick', 'prick', 'cock', 'twat', 'wanker', 'whore', 'slut',
        'pussy', 'douchebag', 'jackass', 'dumbass', 'idiot', 'moron', 'imbecile',
        'retard', 'retarded', 'nigger', 'nigga', 'faggot', 'spic', 'chink',
        'kike', 'tranny', 'rape', 'rapist', 'pedophile', 'paedophile', 'paedo',
    ],
    'phrases' => [
        'kill yourself', 'go kill yourself', 'kys', 'kill urself',
        'i hope you die', 'hope you die', 'go die', 'drop dead', 'you should die',
        'shut the fuck up', 'shut up bitch', 'fuck you', 'fuck off', 'fuck this',
        'go to hell', 'burn in hell', 'you are worthless', 'worthless piece of shit',
        'piece of shit', 'screw you', 'suck my dick', 'blow me', 'kiss my ass',
        'eat shit', 'piss off', 'no one cares about you', 'nobody loves you',
    ],
];
