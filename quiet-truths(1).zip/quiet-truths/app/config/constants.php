<?php
/**
 * Quiet Truths — Configuration Constants
 *
 * Loaded by app/core/Config.php. Idempotent: safe to require more than once.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

if (defined('QT_THEME_VERSION')) {
    return;
}

/* ── Identity ── */
define('QT_THEME_VERSION', '1.0.0');
define('QT_TEXT_DOMAIN', 'quiet-truths');

/* ── Paths ── */
define('QT_THEME_DIR', get_stylesheet_directory());
define('QT_THEME_URI', get_stylesheet_directory_uri());
define('QT_APP_DIR', QT_THEME_DIR . '/app');
define('QT_APP_URI', QT_THEME_URI . '/app');
define('QT_DESIGN_SYSTEM_DIR', QT_APP_DIR . '/design-system');
define('QT_DESIGN_SYSTEM_URI', QT_APP_URI . '/design-system');
define('QT_ASSETS_URI', QT_THEME_URI . '/assets');

/* ── Content model ── */
define('QT_STORY_POST_TYPE', 'qt_story');
define('QT_ROOM_TAXONOMY', 'qt_room');

/* ── The house, directly ── */
define('QT_CONTACT_EMAIL', 'admin@quiettruths.co.ke');

/* Social links — fill these when the house is ready; leave '' to hide. */
define('QT_SOCIAL_FACEBOOK', '');
define('QT_SOCIAL_WHATSAPP', '');
define('QT_SOCIAL_X', '');

/* ── The rooms ──
 * Each room is a category of human experience. The slug doubles as the
 * modifier for the room-symbol component (see components.css).
 */
if (!defined('QT_ROOMS')) {
    define('QT_ROOMS', [
        'beginnings' => [
            'slug'        => 'beginnings',
            'name'        => 'Beginnings',
            'description' => 'New paths, first lines, the courage to start.',
        ],
        'becoming' => [
            'slug'        => 'becoming',
            'name'        => 'Becoming',
            'description' => 'The long, quiet work of growing into yourself.',
        ],
        'heavy-hearts' => [
            'slug'        => 'heavy-hearts',
            'name'        => 'Heavy Hearts',
            'description' => 'Grief and loss — the weight we carry quietly.',
        ],
        'crossroads' => [
            'slug'        => 'crossroads',
            'name'        => 'Crossroads',
            'description' => 'Decisions that change everything, and the ones that change nothing.',
        ],
        'homecoming' => [
            'slug'        => 'homecoming',
            'name'        => 'Homecoming',
            'description' => 'Returning — to people, places, and the self you left behind.',
        ],
        'quiet-victories' => [
            'slug'        => 'quiet-victories',
            'name'        => 'Quiet Victories',
            'description' => 'Wins no one saw, kept anyway.',
        ],
        'unfinished' => [
            'slug'        => 'unfinished',
            'name'        => 'Unfinished',
            'description' => 'The drafts, the goodbyes unsaid, the work still in progress.',
        ],
        'after-storm' => [
            'slug'        => 'after-storm',
            'name'        => 'After the Storm',
            'description' => 'What the calm looks like when it finally comes.',
        ],
        'letters' => [
            'slug'        => 'letters',
            'name'        => 'Letters',
            'description' => 'Words written but never sent; words that needed saying.',
        ],
        'everyday-grace' => [
            'slug'        => 'everyday-grace',
            'name'        => 'Everyday Grace',
            'description' => 'Small mercies, ordinary kindnesses, quiet goodness.',
        ],
    ]);
}
