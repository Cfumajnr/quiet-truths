<?php
/**
 * Quiet Truths — Semantic Search
 *
 * Search that thinks, not just matches:
 *
 *  - Scope: stories (qt_story) and posts (post) only. Pages are excluded
 *    unless the query explicitly names a page (exact title or slug).
 *  - Expansion: the query is expanded through the search lexicon, so
 *    "marriage" also finds stories about weddings, vows and divorce.
 *  - Ranking: exact phrase > title > excerpt > content > synonym hits,
 *    with room-name matches boosted. Newest first within ties.
 *
 * The template search.php renders the results; this class does the work.
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Search
{
    public const PER_PAGE = 10;

    public static function init(): void
    {
        add_action('pre_get_posts', [self::class, 'scopeMainSearch']);
        add_filter('query_vars', static function (array $vars): array {
            $vars[] = 'qt_concept';

            return $vars;
        });
    }

    /**
     * Keep the main search query scoped to stories + posts so the
     * canonical s= query behaves like our custom one even before the
     * template takes over. Concept searches (?qt_concept=…) are made
     * to look like searches so the search template renders them.
     */
    public static function scopeMainSearch($query): void
    {
        if (is_admin() || !$query->is_main_query()) {
            return;
        }

        $concept = $query->get('qt_concept');

        if ('' !== (string) $concept && '' === (string) $query->get('s')) {
            $query->set('s', (string) $concept);
        }

        if (!$query->is_search()) {
            return;
        }

        $query->set('post_type', ['qt_story', 'post', 'qt_journal', 'page']);
    }

    /**
     * Concept search: all stories that are ABOUT a concept (hope, grief,
     * healing…), found through the invisible layer's tags — not by
     * matching the word in the story. Rooms are never shown.
     *
     * @return array{
     *   query:string, expanded:list<string>, total:int,
     *   results:list<\WP_Post>, page:?\WP_Post, suggestions:list<string>,
     *   paged:int, max_pages:int, concept:?array{slug:string,name:string}
     * }
     */
    public static function runConcept(string $slug): array
    {
        $slug   = sanitize_key($slug);
        $concept = Concepts::concepts()[$slug] ?? null;

        // Unknown concept: fall back to ordinary semantic search.
        if (!$concept) {
            return self::run($slug);
        }

        $name  = (string) ($concept['name'] ?? $slug);
        $words = array_values((array) ($concept['words'] ?? []));
        $terms = array_slice($words, 0, 16);
        $paged = max(1, (int) get_query_var('paged'));

        $candidates = new \WP_Query([
            'post_type'      => ['qt_story', 'post', 'qt_journal', 'page'],
            'post_status'    => 'publish',
            'posts_per_page' => 500,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ]);

        $scored = [];

        foreach ($candidates->posts as $id) {
            $id   = (int) $id;
            $post = get_post($id);

            if (!$post) {
                continue;
            }

            $score = 0;

            // The invisible layer: tagged as about this concept.
            if (in_array($slug, Concepts::themesOf($id), true)) {
                $score += 10;
            }

            $title   = mb_strtolower((string) $post->post_title, 'UTF-8');
            $content = mb_strtolower(wp_strip_all_tags((string) $post->post_content), 'UTF-8');

            foreach ($terms as $term) {
                if ('' === $term) {
                    continue;
                }
                if (str_contains($title, $term)) {
                    $score += 4;
                } elseif (str_contains($content, $term)) {
                    $score += 2;
                }
            }

            if ($score > 0) {
                $scored[$id] = $score;
            }
        }

        arsort($scored);

        $total    = count($scored);
        $maxPages = max(1, (int) ceil($total / self::PER_PAGE));
        $paged    = min($paged, $maxPages);
        $slice    = array_slice(array_keys($scored), ($paged - 1) * self::PER_PAGE, self::PER_PAGE, true);

        $results = [];
        foreach ($slice as $id) {
            $post = get_post($id);
            if ($post) {
                $results[] = $post;
            }
        }

        // Other concepts worth offering when this one is empty.
        $suggestions = [];
        foreach (Concepts::concepts() as $otherSlug => $other) {
            if ($otherSlug === $slug) {
                continue;
            }
            $suggestions[] = (string) $otherSlug;
            if (count($suggestions) >= 6) {
                break;
            }
        }

        return [
            'query'       => $name,
            'expanded'    => $terms,
            'total'       => $total,
            'results'     => $results,
            'page'        => null,
            'suggestions' => $suggestions,
            'paged'       => $paged,
            'max_pages'   => $maxPages,
            'concept'     => ['slug' => $slug, 'name' => $name],
        ];
    }

    /**
     * Run the expanded search.
     *
     * @return array{
     *   query:string, expanded:list<string>, total:int,
     *   results:list<\WP_Post>, page:?\WP_Post, suggestions:list<string>,
     *   paged:int, max_pages:int
     * }
     */
    public static function run(string $rawQuery): array
    {
        $rawQuery = trim($rawQuery);
        $paged    = max(1, (int) get_query_var('paged'));

        if ('' === $rawQuery) {
            return self::emptyResult($paged);
        }

        $terms       = self::expandTerms($rawQuery);
        $suggestions = self::suggestionsFor($terms);
        $explicitPage = self::explicitPageMatch($rawQuery);

        // Candidate pool: published stories, posts, and pages —
        // search for everything and anything.
        $candidates = new \WP_Query([
            'post_type'      => ['qt_story', 'post', 'qt_journal', 'page'],
            'post_status'    => 'publish',
            'posts_per_page' => 500,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ]);

        $scored = [];

        foreach ($candidates->posts as $id) {
            $score = self::scorePost((int) $id, $rawQuery, $terms);

            if ($score > 0) {
                $scored[$id] = $score;
            }
        }

        // The invisible layer: stories tagged with a concept the query
        // touches are included even if the exact word never appears.
        self::addConceptMatches($terms, $scored);

        // Newest first within equal scores.
        arsort($scored);

        $total     = count($scored);
        $maxPages  = max(1, (int) ceil($total / self::PER_PAGE));
        $paged     = min($paged, $maxPages);
        $slice     = array_slice(array_keys($scored), ($paged - 1) * self::PER_PAGE, self::PER_PAGE, true);

        $results = [];
        foreach ($slice as $id) {
            $post = get_post($id);
            if ($post) {
                $results[] = $post;
            }
        }

        return [
            'query'       => $rawQuery,
            'expanded'    => $terms,
            'total'       => $total,
            'results'     => $results,
            'page'        => $explicitPage,
            'suggestions' => $suggestions,
            'paged'       => $paged,
            'max_pages'   => $maxPages,
            'concept'     => null,
        ];
    }

    /* ─────────────── term expansion ─────────────── */

    /**
     * @return list<string> Lowercased search terms, original words plus
     *                     concept expansions, capped for performance.
     */
    private static function expandTerms(string $rawQuery): array
    {
        $words = preg_split('/[\s,.;:!?"\'()]+/u', mb_strtolower($rawQuery, 'UTF-8')) ?: [];
        $words = array_values(array_filter(array_map('trim', $words), static fn (string $w) => '' !== $w));

        $terms   = [];
        $wordMap = Concepts::wordMap();

        foreach ($words as $word) {
            $terms[$word] = true;

            // Every concept that knows this word contributes its whole
            // family, so "muslim" brings in religion's other words.
            foreach ($wordMap[$word] ?? [] as $slug) {
                $concept = Concepts::concepts()[$slug] ?? null;

                if (!$concept) {
                    continue;
                }

                foreach ((array) ($concept['words'] ?? []) as $synonym) {
                    if (count($terms) >= 16) {
                        break 2;
                    }
                    $terms[$synonym] = true;
                }
            }

            if (count($terms) >= 16) {
                break;
            }
        }

        return array_keys($terms);
    }

    /**
     * @param list<string> $terms
     * @return list<string> Related words worth offering after an empty search.
     */
    private static function suggestionsFor(array $terms): array
    {
        $suggested = [];
        $wordMap   = Concepts::wordMap();

        foreach ($terms as $term) {
            foreach ($wordMap[$term] ?? [] as $slug) {
                $concept = Concepts::concepts()[$slug] ?? null;

                if (!$concept) {
                    continue;
                }

                $name = mb_strtolower((string) ($concept['name'] ?? ''), 'UTF-8');

                if ('' !== $name && !in_array($name, $terms, true) && !in_array($name, $suggested, true)) {
                    $suggested[] = $name;
                }

                foreach (array_slice((array) ($concept['words'] ?? []), 0, 4) as $word) {
                    if (!in_array($word, $terms, true) && !in_array($word, $suggested, true) && count($suggested) < 8) {
                        $suggested[] = $word;
                    }
                }
            }
        }

        return array_slice($suggested, 0, 8);
    }

    /* ─────────────── scoring ─────────────── */

    /**
     * @param list<string> $terms
     */
    private static function scorePost(int $postId, string $rawQuery, array $terms): int
    {
        $post = get_post($postId);

        if (!$post || 'publish' !== $post->post_status) {
            return 0;
        }

        $title   = mb_strtolower((string) $post->post_title, 'UTF-8');
        $content = mb_strtolower(wp_strip_all_tags((string) $post->post_content), 'UTF-8');
        $excerpt = mb_strtolower(wp_strip_all_tags((string) $post->post_excerpt), 'UTF-8');
        $raw     = mb_strtolower($rawQuery, 'UTF-8');

        $score = 0;

        // Exact phrase in the title is the strongest signal.
        if ('' !== $raw && str_contains($title, $raw)) {
            $score += 14;
        }
        if ('' !== $raw && str_contains($content, $raw)) {
            $score += 8;
        }

        foreach ($terms as $term) {
            if ('' === $term) {
                continue;
            }
            if (str_contains($title, $term)) {
                $score += 6;
            }
            if (str_contains($excerpt, $term)) {
                $score += 4;
            }
            if (str_contains($content, $term)) {
                $score += 3;
            }
        }

        // A story that lives in a room whose name or description echoes the
        // query deserves a nudge toward the top of its room.
        if ('qt_story' === $post->post_type) {
            $roomText = self::roomText($postId);

            if ('' !== $roomText) {
                foreach ($terms as $term) {
                    if ('' !== $term && str_contains($roomText, $term)) {
                        $score += 5;
                        break;
                    }
                }
            }
        }

        return $score;
    }

    private static function roomText(int $postId): string
    {
        $terms = get_the_terms($postId, 'qt_room');

        if (is_wp_error($terms) || empty($terms)) {
            return '';
        }

        $room   = $terms[0];
        $pieces = [mb_strtolower($room->name, 'UTF-8'), mb_strtolower((string) $room->description, 'UTF-8')];

        $meta = defined('QT_ROOMS') ? QT_ROOMS : [];
        if (isset($meta[$room->slug])) {
            $pieces[] = mb_strtolower($meta[$room->slug]['name'], 'UTF-8');
            $pieces[] = mb_strtolower($meta[$room->slug]['description'], 'UTF-8');
        }

        return implode(' ', array_filter($pieces));
    }

    /* ─────────────── concept matching ─────────────── */

    /**
     * For every term, find the concepts that know it, then add stories
     * tagged with those concepts — with a healthy score. This is how
     * searching "muslim" finds a story about mosque and faith that
     * never says the word.
     *
     * @param list<string>     $terms
     * @param array<int,int>   $scored
     */
    private static function addConceptMatches(array $terms, array &$scored): void
    {
        $wordMap = Concepts::wordMap();
        $slugs   = [];

        foreach ($terms as $term) {
            foreach ($wordMap[$term] ?? [] as $slug) {
                $slugs[$slug] = true;
            }
        }

        if (empty($slugs)) {
            return;
        }

        foreach (array_keys($slugs) as $slug) {
            $tagged = get_posts([
                'post_type'      => ['qt_story', 'qt_journal'],
                'post_status'    => 'publish',
                'posts_per_page' => 300,
                'fields'         => 'ids',
                'no_found_rows'  => true,
                'meta_query'     => [
                    [
                        'key'     => '_qt_themes',
                        'value'   => '"' . $slug . '"',
                        'compare' => 'LIKE',
                    ],
                ],
            ]);

            foreach ($tagged as $id) {
                $scored[(int) $id] = max($scored[(int) $id] ?? 0, 7);
            }
        }
    }

    /* ─────────────── explicit page ─────────────── */

    /**
     * A page only surfaces when the visitor is clearly asking for it:
     * the query equals the page title, or the page slug.
     */
    private static function explicitPageMatch(string $rawQuery): ?\WP_Post
    {
        $raw   = mb_strtolower(trim($rawQuery), 'UTF-8');
        $slug  = sanitize_title($rawQuery);
        $pages = get_posts([
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'posts_per_page' => 100,
        ]);

        foreach ($pages as $page) {
            $title = mb_strtolower((string) $page->post_title, 'UTF-8');
            $pageSlug = (string) $page->post_name;

            if ($raw === $title || $raw === $pageSlug || $slug === $pageSlug) {
                return $page;
            }
        }

        return null;
    }

    private static function emptyResult(int $paged): array
    {
        return [
            'query'       => '',
            'expanded'    => [],
            'total'       => 0,
            'results'     => [],
            'page'        => null,
            'suggestions' => [],
            'paged'       => $paged,
            'max_pages'   => 1,
            'concept'     => null,
        ];
    }
}
