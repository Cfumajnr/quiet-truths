<?php
/**
 * Quiet Truths — SEO
 *
 * A quiet, complete SEO layer:
 *  - meta descriptions (story excerpt → content, room description, home)
 *  - Open Graph + Twitter cards (so stories share beautifully)
 *  - Schema.org JSON-LD: WebSite + SearchAction, Article, BreadcrumbList
 *  - noindex on search results and 404s (never duplicate content)
 *  - a friendly robots.txt with the sitemap
 *  - resource hints (preconnect) for the Google Fonts
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Seo
{
    public static function init(): void
    {
        add_action('wp_head', [self::class, 'maybeNoindex'], 1);
        add_action('wp_head', [self::class, 'metaAndSocial'], 5);
        add_action('wp_head', [self::class, 'schemaJsonLd'], 10);
        add_action('wp_head', [self::class, 'favicons'], 2);
        add_filter('robots_txt', [self::class, 'robotsTxt'], 99, 2);
        add_filter('wp_resource_hints', [self::class, 'resourceHints'], 10, 2);
        add_filter('wp_robots', [self::class, 'robotsMeta']);
    }

    /* ─────────────── noindex ─────────────── */

    public static function maybeNoindex(): void
    {
        // Kept for backward compatibility; the real work is in robotsMeta.
    }

    /**
     * The modern robots meta filter (WP 5.7+). No deprecated calls.
     *
     * @param array<string,bool|string> $robots
     * @return array<string,bool|string>
     */
    public static function robotsMeta(array $robots): array
    {
        // Search results and 404s must never compete with real pages.
        if (is_search() || is_404()) {
            $robots['noindex'] = true;
        }

        // The post-submission confirmation ("your story is being held")
        // is a state, not a page — never index it.
        if (isset($_GET['qt_held'])) {
            $robots['noindex'] = true;
        }

        // Room-filtered views (?qt_room=…) are thin duplicates of the
        // real /room/… pages — never index them.
        if (isset($_GET['qt_room'])) {
            $robots['noindex'] = true;
        }

        return $robots;
    }

    /* ─────────────── favicon ─────────────── */

    /**
     * The house's mark — the gold ring, not WordPress's.
     */
    public static function favicons(): void
    {
        $uri = get_stylesheet_directory_uri() . '/assets/';

        echo "\n<!-- Quiet Truths favicon -->\n";
        echo '<link rel="icon" type="image/png" sizes="32x32" href="' . esc_url($uri . 'favicon-32.png') . "\">\n";
        echo '<link rel="icon" type="image/png" sizes="16x16" href="' . esc_url($uri . 'favicon-16.png') . "\">\n";
        echo '<link rel="apple-touch-icon" sizes="180x180" href="' . esc_url($uri . 'apple-touch-icon.png') . "\">\n";
        echo "<!-- /Quiet Truths favicon -->\n";
    }

    /* ─────────────── meta + social ─────────────── */

    public static function metaAndSocial(): void
    {
        if (is_admin()) {
            return;
        }

        $description = self::description();
        $title       = wp_get_document_title();
        $url         = self::canonicalUrl();
        $image       = self::imageUrl();
        $type        = (is_singular(['qt_story', 'post', 'page'])) ? 'article' : 'website';
        $locale      = str_replace('_', '-', (string) get_locale());

        echo "\n<!-- Quiet Truths SEO -->\n";

        if ('' !== $description) {
            echo '<meta name="description" content="' . esc_attr($description) . "\">\n";
        }

        // Open Graph
        echo '<meta property="og:type" content="' . esc_attr($type) . "\">\n";
        echo '<meta property="og:site_name" content="' . esc_attr(get_bloginfo('name')) . "\">\n";
        echo '<meta property="og:title" content="' . esc_attr($title) . "\">\n";
        if ('' !== $description) {
            echo '<meta property="og:description" content="' . esc_attr($description) . "\">\n";
        }
        echo '<meta property="og:url" content="' . esc_url($url) . "\">\n";
        if ('' !== $image) {
            echo '<meta property="og:image" content="' . esc_url($image) . "\">\n";
            echo '<meta property="og:image:width" content="1200">' . "\n";
            echo '<meta property="og:image:height" content="630">' . "\n";
        }
        echo '<meta property="og:locale" content="' . esc_attr($locale) . "\">\n";

        // Twitter
        echo '<meta name="twitter:card" content="' . ('' !== $image ? 'summary_large_image' : 'summary') . "\">\n";
        echo '<meta name="twitter:title" content="' . esc_attr($title) . "\">\n";
        if ('' !== $description) {
            echo '<meta name="twitter:description" content="' . esc_attr($description) . "\">\n";
        }
        if ('' !== $image) {
            echo '<meta name="twitter:image" content="' . esc_url($image) . "\">\n";
        }

        echo "<!-- /Quiet Truths SEO -->\n";
    }

    /* ─────────────── description ─────────────── */

    private static function description(): string
    {
        // Home: the house's promise.
        if (is_front_page()) {
            return (string) apply_filters(
                'quiet_truths_meta_description_home',
                'The website whispers, so that stories could be heard. Anonymous human experiences, preserved with dignity.'
            );
        }

        // A story, a post, or a page.
        if (is_singular()) {
            $post = get_queried_object();

            if ($post instanceof \WP_Post) {
                $text = (string) $post->post_excerpt;

                if ('' === trim($text)) {
                    $text = wp_strip_all_tags((string) $post->post_content);
                }

                return self::trimTo($text, 160);
            }
        }

        // A room.
        if (is_tax('qt_room')) {
            $term = get_queried_object();

            if ($term instanceof \WP_Term) {
                $text = (string) $term->description;

                return self::trimTo($text, 160);
            }
        }

        return '';
    }

    private static function canonicalUrl(): string
    {
        $url = home_url('/');

        if (is_singular() || is_tax() || is_post_type_archive()) {
            $url = get_permalink() ?: $url;
        } elseif (is_front_page()) {
            $url = home_url('/');
        } elseif (is_home()) {
            $url = get_permalink(get_option('page_for_posts')) ?: $url;
        }

        return $url;
    }

    /**
     * The share image: the story's featured image if it has one, else
     * the house's default (assets/og-default.png).
     */
    private static function imageUrl(): string
    {
        if (is_singular()) {
            $post = get_queried_object();

            if ($post instanceof \WP_Post && has_post_thumbnail($post)) {
                $image = wp_get_attachment_image_url(get_post_thumbnail_id($post), 'large');

                if ($image) {
                    return $image;
                }
            }
        }

        $default = get_stylesheet_directory_uri() . '/assets/og-default.png';

        return (string) apply_filters('quiet_truths_og_image', $default);
    }

    private static function trimTo(string $text, int $length): string
    {
        $text = trim((string) preg_replace('/\s+/u', ' ', $text));

        if (function_exists('mb_substr')) {
            if (mb_strlen($text) <= $length) {
                return $text;
            }

            return rtrim(mb_substr($text, 0, $length - 1)) . '…';
        }

        if (strlen($text) <= $length) {
            return $text;
        }

        return rtrim(substr($text, 0, $length - 1)) . '…';
    }

    /* ─────────────── schema.org ─────────────── */

    public static function schemaJsonLd(): void
    {
        if (is_admin()) {
            return;
        }

        $schemas = [];

        // WebSite + SearchAction (home).
        if (is_front_page()) {
            $schemas[] = [
                '@context'    => 'https://schema.org',
                '@type'       => 'WebSite',
                'name'        => get_bloginfo('name'),
                'url'         => home_url('/'),
                'description' => (string) apply_filters('quiet_truths_meta_description_home', 'The website whispers, so that stories could be heard.'),
                'potentialAction' => [
                    '@type'       => 'SearchAction',
                    'target'      => [
                        '@type'       => 'EntryPoint',
                        'urlTemplate' => home_url('/?s={search_term_string}'),
                    ],
                    'query-input' => 'required name=search_term_string',
                ],
            ];
        }

        // Article (stories, posts, journals).
        if (is_singular(['qt_story', 'post', 'qt_journal'])) {
            $post = get_queried_object();

            if ($post instanceof \WP_Post) {
                // Journals are signed; stories are anonymous — the house
                // is the author of anonymous ones.
                $authorType = 'Organization';
                $authorName = get_bloginfo('name');

                if ('qt_journal' === $post->post_type && function_exists('qt_journal_byline')) {
                    $byline = qt_journal_byline($post);

                    if ('' !== $byline['name']) {
                        $authorType = 'Person';
                        $authorName = $byline['name'];
                    }
                }

                $article = [
                    '@context'      => 'https://schema.org',
                    '@type'         => 'Article',
                    'headline'      => (string) $post->post_title,
                    'datePublished' => get_the_date('c', $post),
                    'dateModified'  => get_the_modified_date('c', $post),
                    'mainEntityOfPage' => get_permalink($post),
                    'author'        => [
                        '@type' => $authorType,
                        'name'  => $authorName,
                        'url'   => home_url('/'),
                    ],
                    'publisher'     => [
                        '@type' => 'Organization',
                        'name'  => get_bloginfo('name'),
                        'url'   => home_url('/'),
                    ],
                ];

                $excerpt = wp_strip_all_tags((string) $post->post_excerpt);
                if ('' === trim($excerpt)) {
                    $excerpt = self::trimTo(wp_strip_all_tags((string) $post->post_content), 200);
                }
                if ('' !== $excerpt) {
                    $article['description'] = $excerpt;
                }

                $image = self::imageUrl();
                if ('' !== $image) {
                    $article['image'] = $image;
                }

                $schemas[] = $article;

                // Breadcrumbs: Home > Room (if any) > Story.
                $crumbs = [
                    ['name' => 'Home', 'url' => home_url('/')],
                ];

                $room = (function () use ($post) {
                    $terms = get_the_terms($post->ID, 'qt_room');
                    return (!is_wp_error($terms) && !empty($terms)) ? $terms[0] : null;
                })();

                if ($room instanceof \WP_Term) {
                    $link = get_term_link($room);
                    if (!is_wp_error($link)) {
                        $crumbs[] = ['name' => $room->name, 'url' => $link];
                    }
                }

                $crumbs[] = ['name' => (string) $post->post_title, 'url' => get_permalink($post)];
                $schemas[] = self::breadcrumbs($crumbs);
            }
        }

        // Room archive breadcrumbs.
        if (is_tax('qt_room')) {
            $term = get_queried_object();

            if ($term instanceof \WP_Term) {
                $link = get_term_link($term);

                $schemas[] = self::breadcrumbs([
                    ['name' => 'Home', 'url' => home_url('/')],
                    ['name' => $term->name, 'url' => is_wp_error($link) ? home_url('/') : $link],
                ]);
            }
        }

        if (empty($schemas)) {
            return;
        }

        echo "\n<!-- Quiet Truths Schema -->\n";

        foreach ($schemas as $schema) {
            echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "</script>\n";
        }

        echo "<!-- /Quiet Truths Schema -->\n";
    }

    /**
     * @param list<array{name:string,url:string}> $items
     * @return array<string,mixed>
     */
    private static function breadcrumbs(array $items): array
    {
        $list = [];

        foreach ($items as $i => $item) {
            $list[] = [
                '@type'    => 'ListItem',
                'position' => $i + 1,
                'name'     => $item['name'],
                'item'     => $item['url'],
            ];
        }

        return [
            '@context'        => 'https://schema.org',
            '@type'           => 'BreadcrumbList',
            'itemListElement' => $list,
        ];
    }

    /* ─────────────── robots.txt ─────────────── */

    public static function robotsTxt(string $output, bool $public): string
    {
        if (!$public) {
            return $output;
        }

        $lines = [
            '# Quiet Truths',
            'User-agent: *',
            'Allow: /',
            'Disallow: /wp-admin/',
            'Disallow: /wp-includes/',
            'Disallow: /wp-login.php',
            'Disallow: /xmlrpc.php',
            '',
            'Sitemap: ' . home_url('/wp-sitemap.xml'),
        ];

        return implode("\n", $lines) . "\n";
    }

    /* ─────────────── resource hints ─────────────── */

    /**
     * @param list<string> $urls
     * @param string       $relation
     * @return list<string>
     */
    public static function resourceHints(array $urls, string $relation): array
    {
        if ('preconnect' === $relation) {
            $urls[] = 'https://fonts.googleapis.com';
            $urls[] = 'https://fonts.gstatic.com';
        }

        return $urls;
    }
}
