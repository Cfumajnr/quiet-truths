<?php
/**
 * Quiet Truths — Security
 *
 * The house's own security layer — no plugin needed:
 *
 *  - security headers (nosniff, framing, referrer, permissions, CSP)
 *  - HSTS (only over HTTPS)
 *  - hides the WordPress version (html + feeds)
 *  - disables XML-RPC
 *  - generic login errors (no username enumeration)
 *  - login rate limiting per IP (brute-force guard)
 *  - blocks author-archive enumeration
 *
 * Everything can be disabled by defining a constant:
 *   define('QT_SECURITY_HEADERS', false);   // no headers
 *   define('QT_SECURITY_LOGIN', false);     // no login hardening
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Security
{
    private const LOCKOUT_ATTEMPTS = 5;
    private const LOCKOUT_SECONDS  = 15 * MINUTE_IN_SECONDS;

    public static function init(): void
    {
        if (!defined('QT_SECURITY_HEADERS') || QT_SECURITY_HEADERS) {
            add_action('send_headers', [self::class, 'headers']);
        }

        if (!defined('QT_SECURITY_LOGIN') || QT_SECURITY_LOGIN) {
            self::loginHardening();
        }

        remove_action('wp_head', 'wp_generator');
        add_filter('the_generator', '__return_empty_string');
    }

    /* ─────────────── headers ─────────────── */

    public static function headers(): void
    {
        if (headers_sent()) {
            return;
        }

        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=(), interest-cohort=()');

        // HSTS only makes sense over HTTPS.
        if (is_ssl()) {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        }

        header("Content-Security-Policy: default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; script-src 'self' 'unsafe-inline'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'self'; form-action 'self'");
    }

    /* ─────────────── XML-RPC ─────────────── */

    public static function xmlRpc(bool $enabled): bool
    {
        return false;
    }

    /* ─────────────── login hardening ─────────────── */

    private static function loginHardening(): void
    {
        add_filter('xmlrpc_enabled', [self::class, 'xmlRpc']);
        add_filter('login_errors', [self::class, 'genericError']);
        add_filter('authenticate', [self::class, 'checkLock'], 30, 3);
        add_action('wp_login_failed', [self::class, 'recordFailure']);
        add_action('template_redirect', [self::class, 'blockAuthorEnumeration']);
    }

    public static function genericError(): string
    {
        return __('Incorrect details.', 'quiet-truths');
    }

    /**
     * @return \WP_Error|\WP_User|null
     */
    public static function checkLock($user, string $username, string $password)
    {
        if ($user instanceof \WP_User || is_wp_error($user)) {
            return $user;
        }

        if (self::isLocked()) {
            return new \WP_Error(
                'qt_locked',
                __('Too many attempts. The house is resting — please try again in a few minutes.', 'quiet-truths')
            );
        }

        return $user;
    }

    public static function recordFailure(string $username): void
    {
        $ip  = self::ip();
        $key = 'qt_login_' . md5($ip);

        $count = (int) get_transient($key);
        $count++;

        if ($count >= self::LOCKOUT_ATTEMPTS) {
            set_transient($key, $count, self::LOCKOUT_SECONDS);
            return;
        }

        set_transient($key, $count, self::LOCKOUT_SECONDS);
    }

    private static function isLocked(): bool
    {
        $key   = 'qt_login_' . md5(self::ip());
        $count = (int) get_transient($key);

        return $count >= self::LOCKOUT_ATTEMPTS;
    }

    /**
     * The visitor's address, as seen by the server. Used only for the
     * short-lived login lockout — never stored with any content.
     */
    private static function ip(): string
    {
        if (!empty($_SERVER['REMOTE_ADDR'])) {
            return sanitize_text_field(wp_unslash((string) $_SERVER['REMOTE_ADDR']));
        }

        return '';
    }

    /* ─────────────── author enumeration ─────────────── */

    public static function blockAuthorEnumeration(): void
    {
        if (is_admin()) {
            return;
        }

        // /author/name/ and ?author=1 both land here.
        if (is_author()) {
            wp_safe_redirect(home_url('/'));
            exit;
        }
    }
}
