<?php
/**
 * Quiet Truths — Application
 *
 * The boot point called by functions.php:
 *
 *     \QuietTruths\Core\Application::boot();
 *
 * Wires configuration, assets, theme supports, menus and the
 * content model (stories + rooms).
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

/* ── Deterministic class loading ──
 * Explicit requires keep the boot chain airtight; the autoloader is a
 * safety net for any future QuietTruths\* classes. (Linux filesystems
 * are case-sensitive, so the autoloader also tries a lowercase path.)
 */
require_once __DIR__ . '/Config.php';
require_once __DIR__ . '/AssetRegistry.php';
require_once __DIR__ . '/Submission.php';
require_once __DIR__ . '/Search.php';
require_once __DIR__ . '/Responses.php';
require_once __DIR__ . '/Concepts.php';
require_once __DIR__ . '/Themes.php';
require_once __DIR__ . '/Seo.php';
require_once __DIR__ . '/Contact.php';
require_once __DIR__ . '/Rooms.php';
require_once __DIR__ . '/Security.php';

spl_autoload_register(static function (string $class): void {
    $prefix = 'QuietTruths\\';

    if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
        return;
    }

    $base       = dirname(__DIR__);
    $relative   = str_replace('\\', '/', substr($class, strlen($prefix)));
    $candidates = [$relative, strtolower($relative)];

    foreach ($candidates as $candidate) {
        $path = $base . '/' . $candidate . '.php';

        if (is_file($path)) {
            require_once $path;
            return;
        }
    }
});

final class Application
{
    private static bool $booted = false;

    public static function boot(): void
    {
        if (self::$booted) {
            return;
        }
        self::$booted = true;

        Config::init();
        AssetRegistry::init();
        Submission::init();
        Search::init();
        Responses::init();
        Concepts::init();
        Themes::init();
        Seo::init();
        Contact::init();
        Security::init();

        add_action('template_redirect', [self::class, 'redirectOldStoryLinks']);
        add_filter('wp_get_nav_menu_items', [self::class, 'cleanMenuItems'], 10, 2);
        add_action('pre_get_posts', [self::class, 'storyArchiveSort']);
        add_action('init', [self::class, 'ensureStoryMeta'], 30);

        self::registerThemeSupports();
        self::registerMenus();
        self::registerStoryPostType();
        self::registerJournalPostType();
        self::registerRoomTaxonomy();
        self::ensureRoomTerms();
        self::registerRoomPicker();
        self::registerJournalByline();

        add_action('after_switch_theme', [self::class, 'flushRewriteRules']);
    }

    /**
     * Menus: the house's navigation carries only the everyday paths.
     * The Journals are reached through their door on the entrance —
     * never through the navigation. That is a design rule, not an
     * oversight: the door is the only way in.
     *
     * Also drops items that point at anchors that no longer exist on
     * the homepage.
     *
     * @param list<\WP_Post> $items
     * @return list<\WP_Post>
     */
    public static function cleanMenuItems(array $items, $menu): array
    {
        $filtered = [];

        foreach ($items as $item) {
            $url = (string) ($item->url ?? '');

            // Journals stay behind their door — never in a menu.
            if (str_contains($url, '/journals') || str_contains($url, '/journal/')) {
                continue;
            }

            // Dead anchors from the old homepage.
            if (str_contains($url, '#rooms') || str_contains($url, '#qt-home-doors')) {
                continue;
            }

            $filtered[] = $item;
        }

        return array_values($filtered);
    }

    /**
     * Stories migrated from Posts keep their old /slug/ URLs working:
     * a 404 on a bare slug that matches a published story is redirected
     * (301) to its new /story/slug/ home.
     */
    public static function redirectOldStoryLinks(): void
    {
        if (!is_404()) {
            return;
        }

        $uri  = sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'] ?? ''));
        $path = trim((string) parse_url($uri, PHP_URL_PATH), '/');

        if ('' === $path) {
            return;
        }

        $segments = explode('/', $path);
        $slug     = sanitize_title((string) end($segments));

        if ('' === $slug || 'story' === $slug) {
            return;
        }

        $story = get_posts([
            'name'           => $slug,
            'post_type'      => 'qt_story',
            'post_status'    => 'publish',
            'posts_per_page' => 1,
            'no_found_rows'  => true,
        ]);

        if (!empty($story)) {
            wp_safe_redirect(get_permalink($story[0]), 301);
            exit;
        }
    }

    public static function flushRewriteRules(): void
    {
        flush_rewrite_rules();
    }

    /**
     * The shelf's ways of wandering — how to read, not what taxonomy.
     */
    public static function storyArchiveSort($query): void
    {
        if (is_admin() || !$query->is_main_query() || !is_post_type_archive('qt_story')) {
            return;
        }

        $sort = sanitize_key(wp_unslash((string) ($_GET['qt_sort'] ?? '')));

        $query->set('posts_per_page', 20);

        // 'recent' is the default sort — its chip only highlights when
        // explicitly chosen, so the page arrives with no chip filled.
        if ('responded' === $sort) {
            $query->set('meta_key', '_qt_response_count');
            $query->set('orderby', 'meta_value_num');
            $query->set('order', 'DESC');
        } elseif ('short' === $sort) {
            $query->set('meta_key', '_qt_words');
            $query->set('orderby', 'meta_value_num');
            $query->set('order', 'ASC');
        } elseif ('long' === $sort) {
            $query->set('meta_key', '_qt_words');
            $query->set('orderby', 'meta_value_num');
            $query->set('order', 'DESC');
        }
    }

    /**
     * One-time backfill so the shelf's sorts have their numbers:
     * word counts for every story, and published-response counts.
     */
    public static function ensureStoryMeta(): void
    {
        if (!get_option('qt_story_meta_words_done')) {
            $ids = get_posts([
                'post_type'      => 'qt_story',
                'post_status'    => ['publish', 'pending'],
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'no_found_rows'  => true,
            ]);

            foreach ($ids as $id) {
                if ('' === get_post_meta($id, '_qt_words', true)) {
                    $post = get_post($id);
                    if ($post) {
                        update_post_meta($id, '_qt_words', \QuietTruths\Core\Submission::countWords((string) $post->post_content));
                    }
                }
            }

            update_option('qt_story_meta_words_done', '1');
        }

        if (!get_option('qt_story_meta_responses_done')) {
            $ids = get_posts([
                'post_type'      => 'qt_story',
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'no_found_rows'  => true,
            ]);

            foreach ($ids as $id) {
                \QuietTruths\Core\Responses::touchCount((int) $id);
            }

            update_option('qt_story_meta_responses_done', '1');
        }
    }

    /* ─────────────────────────── theme ─────────────────────────── */

    private static function registerThemeSupports(): void
    {
        add_theme_support('title-tag');
        add_theme_support('post-thumbnails');
        add_theme_support('automatic-feed-links');
        add_theme_support('align-wide');
        add_theme_support('responsive-embeds');
        add_theme_support('html5', [
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        ]);
        add_theme_support('custom-logo', [
            'height'      => 48,
            'width'       => 240,
            'flex-height' => true,
            'flex-width'  => true,
        ]);
        add_theme_support('customize-selective-refresh-widgets');
    }

    private static function registerMenus(): void
    {
        register_nav_menus([
            'primary' => __('Primary Navigation', 'quiet-truths'),
            'footer'  => __('Footer Navigation', 'quiet-truths'),
        ]);
    }

    /**
     * A story belongs to ONE room — it is placed there. The invisible
     * concept layer holds everything else it is about. Replace the
     * default checkbox box with a single-choice radio picker.
     */
    private static function registerRoomPicker(): void
    {
        add_action('add_meta_boxes', function (): void {
            remove_meta_box('qt_roomdiv', 'qt_story', 'side');

            add_meta_box('qt_room_picker', __('Room', 'quiet-truths'), function ($post): void {
                wp_nonce_field('qt_room_picker', 'qt_room_picker_nonce');

                $current = wp_get_object_terms($post->ID, 'qt_room', ['fields' => 'slugs']);
                $current = (!is_wp_error($current) && !empty($current)) ? (string) $current[0] : '';

                $rooms = defined('QT_ROOMS') ? QT_ROOMS : [];

                echo '<p style="margin:0 0 8px;color:#757575;font-size:12px">'
                    . esc_html__('Choose the room where this story is placed.', 'quiet-truths') . '</p>';

                foreach ($rooms as $slug => $room) {
                    printf(
                        '<label style="display:block;margin:4px 0"><input type="radio" name="qt_room_single" value="%s"%s> %s</label>',
                        esc_attr((string) $slug),
                        checked($current, (string) $slug, false),
                        esc_html((string) ($room['name'] ?? $slug))
                    );
                }
            }, 'qt_story', 'side', 'high');
        });

        add_action('save_post_qt_story', function (int $postId): void {
            if (!is_admin() || !isset($_POST['qt_room_picker_nonce'])
                || !wp_verify_nonce(sanitize_key(wp_unslash((string) $_POST['qt_room_picker_nonce'])), 'qt_room_picker')) {
                return;
            }
            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
                return;
            }
            if (wp_is_post_revision($postId) || wp_is_post_autosave($postId)) {
                return;
            }
            if (!current_user_can('edit_post', $postId) || empty($_POST['qt_room_single'])) {
                return;
            }

            wp_set_object_terms($postId, [sanitize_key(wp_unslash((string) $_POST['qt_room_single']))], 'qt_room');
        }, 12);
    }

    /* ─────────────────────── content model ─────────────────────── */

    /**
     * Journals — long-form writing from named voices: professionals,
     * journalists, writers who sign their work. The second wing of the
     * house, beside the anonymous Stories.
     */
    private static function registerJournalPostType(): void
    {
        register_post_type('qt_journal', [
            'labels' => [
                'name'          => __('Journals', 'quiet-truths'),
                'singular_name' => __('Journal', 'quiet-truths'),
                'add_new'       => __('Add Journal', 'quiet-truths'),
                'add_new_item'  => __('Add a Journal', 'quiet-truths'),
                'edit_item'     => __('Edit Journal', 'quiet-truths'),
                'new_item'      => __('New Journal', 'quiet-truths'),
                'view_item'     => __('Read Journal', 'quiet-truths'),
                'search_items'  => __('Search Journals', 'quiet-truths'),
                'not_found'     => __('No journals have been published yet.', 'quiet-truths'),
                'menu_name'     => __('Journals', 'quiet-truths'),
            ],
            'public'       => true,
            'has_archive'  => 'journals',
            'menu_icon'    => 'dashicons-welcome-write-blog',
            'menu_position'=> 22,
            'rewrite'      => ['slug' => 'journal', 'with_front' => false],
            'supports'     => ['title', 'editor', 'excerpt', 'thumbnail', 'author', 'revisions'],
            'show_in_rest' => true,
        ]);

        // One-time flush so /journal/… and /journals/ work.
        add_action('init', static function (): void {
            if (!get_option('qt_journal_rewrite_flushed')) {
                flush_rewrite_rules();
                update_option('qt_journal_rewrite_flushed', '1');
            }
        }, 20);
    }

    /**
     * The byline — the writer's details, accompanied by choice.
     * Name (defaults to the WordPress author), role/title, and a
     * short bio shown at the end of the article.
     */
    private static function registerJournalByline(): void
    {
        add_action('add_meta_boxes', function (): void {
            add_meta_box('qt_journal_byline', __('Byline — the writer\'s details', 'quiet-truths'), function ($post): void {
                wp_nonce_field('qt_journal_byline', 'qt_journal_byline_nonce');

                $name = get_post_meta($post->ID, '_qt_byline_name', true);
                $role = get_post_meta($post->ID, '_qt_byline_role', true);
                $bio  = get_post_meta($post->ID, '_qt_byline_bio', true);

                echo '<p style="margin:0 0 10px;color:#757575;font-size:12px">'
                    . esc_html__('Leave blank to use the WordPress author\'s name. The role and bio are optional — shown with the article.', 'quiet-truths') . '</p>';

                echo '<p><label style="display:block;margin-bottom:4px;font-weight:600">'
                    . esc_html__('Name', 'quiet-truths') . '</label>';
                echo '<input type="text" name="qt_byline_name" style="width:100%" value="' . esc_attr((string) $name) . '"></p>';

                echo '<p><label style="display:block;margin-bottom:4px;font-weight:600">'
                    . esc_html__('Role / title', 'quiet-truths') . '</label>';
                echo '<input type="text" name="qt_byline_role" style="width:100%" value="' . esc_attr((string) $role) . '"></p>';

                echo '<p><label style="display:block;margin-bottom:4px;font-weight:600">'
                    . esc_html__('Short bio', 'quiet-truths') . '</label>';
                echo '<textarea name="qt_byline_bio" rows="3" style="width:100%">' . esc_textarea((string) $bio) . '</textarea></p>';
            }, 'qt_journal', 'side', 'high');
        });

        add_action('save_post_qt_journal', function (int $postId): void {
            if (!is_admin() || !isset($_POST['qt_journal_byline_nonce'])
                || !wp_verify_nonce(sanitize_key(wp_unslash((string) $_POST['qt_journal_byline_nonce'])), 'qt_journal_byline')) {
                return;
            }
            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
                return;
            }
            if (wp_is_post_revision($postId) || wp_is_post_autosave($postId)) {
                return;
            }
            if (!current_user_can('edit_post', $postId)) {
                return;
            }

            update_post_meta($postId, '_qt_byline_name', sanitize_text_field(wp_unslash((string) ($_POST['qt_byline_name'] ?? ''))));
            update_post_meta($postId, '_qt_byline_role', sanitize_text_field(wp_unslash((string) ($_POST['qt_byline_role'] ?? ''))));
            update_post_meta($postId, '_qt_byline_bio', sanitize_textarea_field(wp_unslash((string) ($_POST['qt_byline_bio'] ?? ''))));
        }, 12);
    }

    /**
     * Make sure every room in QT_ROOMS exists as a real taxonomy term.
     *
     * Without this, /room/{slug}/ archives 404 until a story happens to
     * create the term. Runs once per rooms-set (tracked by an option);
     * flushes rewrite rules once so the /room/ and /story/ URL rules
     * register even if the theme was replaced while still active.
     */
    private static function ensureRoomTerms(): void
    {
        $rooms = defined('QT_ROOMS') ? QT_ROOMS : [];

        if (empty($rooms)) {
            return;
        }

        $signature = QT_THEME_VERSION . '|' . count($rooms) . '|' . implode(',', array_keys($rooms));

        if ((string) get_option('qt_room_terms_seeded') === $signature) {
            return;
        }

        $changed = false;

        foreach ($rooms as $slug => $room) {
            if (get_term_by('slug', $slug, 'qt_room')) {
                continue;
            }

            $insert = wp_insert_term($room['name'], 'qt_room', [
                'slug'        => $slug,
                'description' => $room['description'],
            ]);

            if (!is_wp_error($insert)) {
                $changed = true;
            }
        }

        update_option('qt_room_terms_seeded', $signature);

        if ($changed) {
            flush_rewrite_rules();
        }
    }

    private static function registerStoryPostType(): void
    {
        register_post_type('qt_story', [
            'labels' => [
                'name'          => __('Stories', 'quiet-truths'),
                'singular_name' => __('Story', 'quiet-truths'),
                'add_new'       => __('Add Story', 'quiet-truths'),
                'add_new_item'  => __('Add a Story', 'quiet-truths'),
                'edit_item'     => __('Edit Story', 'quiet-truths'),
                'new_item'      => __('New Story', 'quiet-truths'),
                'view_item'     => __('Read Story', 'quiet-truths'),
                'search_items'  => __('Search Stories', 'quiet-truths'),
                'not_found'     => __('No stories have been left here yet.', 'quiet-truths'),
                'menu_name'     => __('Quiet Stories', 'quiet-truths'),
            ],
            'public'       => true,
            'has_archive'  => 'stories',
            'menu_icon'    => 'dashicons-book-alt',
            'menu_position'=> 21,
            'rewrite'      => ['slug' => 'story', 'with_front' => false],
            'supports'     => ['title', 'editor', 'excerpt', 'thumbnail', 'author', 'revisions'],
            'show_in_rest' => true,
        ]);
    }

    private static function registerRoomTaxonomy(): void
    {
        register_taxonomy('qt_room', ['qt_story'], [
            'labels' => [
                'name'          => __('Rooms', 'quiet-truths'),
                'singular_name' => __('Room', 'quiet-truths'),
                'search_items'  => __('Search Rooms', 'quiet-truths'),
                'all_items'     => __('All Rooms', 'quiet-truths'),
                'edit_item'     => __('Edit Room', 'quiet-truths'),
                'update_item'   => __('Update Room', 'quiet-truths'),
                'add_new_item'  => __('Add Room', 'quiet-truths'),
                'new_item_name' => __('New Room Name', 'quiet-truths'),
                'menu_name'     => __('Rooms', 'quiet-truths'),
            ],
            'hierarchical'       => true,
            'public'             => true,
            'show_admin_column'  => true,
            'show_in_rest'       => true,
            'show_in_quick_edit' => true,
            'rewrite'            => ['slug' => 'room', 'with_front' => false],
        ]);
    }
}
