<?php
/**
 * Quiet Truths — House Themes
 *
 * The middle layer of the house. Themes are the doors you walk in by:
 * each collects concepts, so a theme's stories are found through the
 * invisible layer, not by matching words.
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Themes
{
    private static ?array $data = null;

    public static function init(): void
    {
        // Theme cards route through the search template.
        add_filter('query_vars', static function (array $vars): array {
            $vars[] = 'qt_theme';

            return $vars;
        });
    }

    public static function data(): array
    {
        if (null === self::$data) {
            $path = dirname(__DIR__) . '/config/themes.php';

            if (is_file($path)) {
                $loaded = require $path;
                self::$data = is_array($loaded) ? $loaded : [];
            } else {
                self::$data = [];
            }
        }

        return self::$data;
    }

    /** @return array<string,array{name:string,concepts:list<string>}> */
    public static function themes(): array
    {
        return self::data();
    }

    public static function theme(string $slug): ?array
    {
        return self::data()[$slug] ?? null;
    }

    /**
     * Stories that belong to a theme — collected through its concepts.
     *
     * @return list<\WP_Post>
     */
    public static function storiesFor(string $slug, int $limit = 20): array
    {
        $theme = self::theme($slug);

        if (!$theme) {
            return [];
        }

        $concepts = (array) ($theme['concepts'] ?? []);

        $pool = new \WP_Query([
            'post_type'      => 'qt_story',
            'post_status'    => 'publish',
            'posts_per_page' => 300,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ]);

        $scored = [];

        foreach ($pool->posts as $id) {
            $id    = (int) $id;
            $themes = Concepts::themesOf($id);

            $shared = array_intersect($concepts, $themes);

            if (!empty($shared)) {
                $scored[$id] = count($shared);
            }
        }

        arsort($scored);

        $stories = [];
        foreach (array_slice(array_keys($scored), 0, $limit, true) as $id) {
            $post = get_post($id);
            if ($post) {
                $stories[] = $post;
            }
        }

        return $stories;
    }

    /**
     * How many published stories a theme currently holds.
     */
    public static function countFor(string $slug): int
    {
        return count(self::storiesFor($slug, 300));
    }
}
