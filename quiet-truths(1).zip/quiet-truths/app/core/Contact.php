<?php
/**
 * Quiet Truths — Contact
 *
 * A quiet, theme-native contact form. No plugin. The visitor may write
 * without giving an email; if they do leave one, it is used once — to
 * reply — and never stored, never added to any list.
 *
 * Guards match the house: honeypot, rate limit, profanity filter.
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Contact
{
    private const NONCE = 'qt_contact';

    /** @var string[] */
    private static array $errors = [];

    /** @var array<string,string> */
    private static array $old = [];

    public static function init(): void
    {
        add_action('template_redirect', [self::class, 'maybeHandle']);
    }

    /* ─────────────── view state ─────────────── */

    /** @return string[] */
    public static function errors(): array
    {
        return self::$errors;
    }

    public static function old(string $key, string $default = ''): string
    {
        return self::$old[$key] ?? $default;
    }

    public static function sent(): bool
    {
        return isset($_GET['qt_contact_sent']);
    }

    /* ─────────────── handling ─────────────── */

    public static function maybeHandle(): void
    {
        if (is_admin() || (defined('REST_REQUEST') && REST_REQUEST)) {
            return;
        }
        if (empty($_POST['qt_contact_submit']) || !isset($_POST['_wpnonce'])) {
            return;
        }

        $back = wp_get_referer() ?: home_url('/');

        if (!wp_verify_nonce(sanitize_key(wp_unslash((string) $_POST['_wpnonce'])), self::NONCE)) {
            self::$errors[] = 'session';
            self::redirect($back);
        }

        // Honeypot: bots fill this hidden field.
        if (!empty($_POST['qt_website'])) {
            wp_safe_redirect(add_query_arg('qt_contact_sent', '1', $back));
            exit;
        }

        // Gentle rate limit: a handful of messages per visitor per hour.
        $key   = 'qt_contact_rate_' . md5((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
        $count = (int) get_transient($key);
        if ($count >= (int) apply_filters('quiet_truths_contact_rate_limit', 3)) {
            self::$errors[] = 'rate';
            self::redirect($back);
        }

        // Contact is the house's front desk — it needs a reply address.
        // Always detailed: name + email required, phone optional.
        $name    = isset($_POST['qt_name']) ? sanitize_text_field(wp_unslash((string) $_POST['qt_name'])) : '';
        $email   = isset($_POST['qt_email']) ? sanitize_email(wp_unslash((string) $_POST['qt_email'])) : '';
        $subject = isset($_POST['qt_subject']) ? sanitize_text_field(wp_unslash((string) $_POST['qt_subject'])) : '';
        $phone   = isset($_POST['qt_phone']) ? sanitize_text_field(wp_unslash((string) $_POST['qt_phone'])) : '';

        self::$old = [
            'name'    => $name,
            'email'   => $email,
            'subject' => $subject,
            'phone'   => $phone,
        ];

        if ('' === trim($name)) {
            self::$errors[] = 'name_req';
        }
        if ('' === $email || !is_email($email)) {
            self::$errors[] = 'email_req';
        }
        if ('' !== $phone && !preg_match('/^[0-9+()\-\s]{6,20}$/', $phone)) {
            self::$errors[] = 'phone';
        }
        if ('' !== $name && (function_exists('mb_strlen') && mb_strlen($name) > 100)) {
            self::$errors[] = 'name';
        }
        if ('' !== $email && (function_exists('mb_strlen') && mb_strlen($email) > 100)) {
            self::$errors[] = 'email';
        }
        if ('' !== $subject && (function_exists('mb_strlen') && mb_strlen($subject) > 150)) {
            self::$errors[] = 'subject';
        }
        if ('' !== $phone && (function_exists('mb_strlen') && mb_strlen($phone) > 20)) {
            self::$errors[] = 'phone';
        }

        $message = isset($_POST['qt_message']) ? sanitize_textarea_field(wp_unslash((string) $_POST['qt_message'])) : '';
        self::$old['message'] = $message;

        if ('' === trim($message)) {
            self::$errors[] = 'empty';
        }
        if (function_exists('mb_strlen') && mb_strlen($message) > 2000) {
            self::$errors[] = 'long';
        }

        // The house's language guard applies here too.
        if (Responses::containsForbidden($message . ' ' . $name)) {
            self::$errors[] = 'profanity';
        }

        if (!empty(self::$errors)) {
            self::redirect($back);
        }

        set_transient($key, $count + 1, HOUR_IN_SECONDS);

        $to       = get_option('admin_email');
        $subject  = '' !== $subject
            ? sprintf('[%s] %s', get_bloginfo('name'), $subject)
            : sprintf('[%s] %s', get_bloginfo('name'), __('A message from the house door', 'quiet-truths'));

        $body    = sprintf(
            "%s\n\n%s\n\n%s",
            __('Someone wrote through the contact page:', 'quiet-truths'),
            $message,
            __('(Sent with their details.)', 'quiet-truths')
        );

        if ('' !== $name) {
            $body .= "\n\n" . __('Name:', 'quiet-truths') . ' ' . $name;
        }
        if ('' !== $email) {
            $body .= "\n" . __('Email:', 'quiet-truths') . ' ' . $email;
        }
        if ('' !== $phone) {
            $body .= "\n" . __('Phone:', 'quiet-truths') . ' ' . $phone;
        }

        $headers = [];

        if ('' !== $email) {
            $headers[] = 'Reply-To: ' . $name . ' <' . $email . '>';
        }

        if (!wp_mail($to, $subject, $body, $headers)) {
            error_log('Quiet Truths: contact message could not be sent.');
            self::$errors[] = 'store';
            self::redirect($back);
        }

        self::$old = [];
        wp_safe_redirect(add_query_arg('qt_contact_sent', '1', $back));
        exit;
    }

    private static function redirect(string $back): void
    {
        set_transient('qt_contact_state', [
            'errors' => self::$errors,
            'old'    => self::$old,
        ], 60);

        wp_safe_redirect($back);
        exit;
    }
}
