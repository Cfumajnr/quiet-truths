<?php
/**
 * Quiet Truths — Config
 *
 * Loads the configuration constants and exposes a small typed accessor.
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Config
{
    private static ?self $instance = null;

    /** @var array<string, mixed> */
    private array $data = [];

    private function __construct()
    {
        require_once dirname(__DIR__) . '/config/constants.php';

        $this->data = [
            'identity' => [
                'name'        => 'Quiet Truths',
                'version'     => QT_THEME_VERSION,
                'text_domain' => QT_TEXT_DOMAIN,
            ],
            'paths' => [
                'theme'            => QT_THEME_DIR,
                'theme_uri'        => QT_THEME_URI,
                'app'              => QT_APP_DIR,
                'app_uri'          => QT_APP_URI,
                'design_system'    => QT_DESIGN_SYSTEM_DIR,
                'design_system_uri'=> QT_DESIGN_SYSTEM_URI,
                'assets_uri'       => QT_ASSETS_URI,
            ],
            'content' => [
                'story_post_type' => QT_STORY_POST_TYPE,
                'room_taxonomy'   => QT_ROOM_TAXONOMY,
                'rooms'           => QT_ROOMS,
            ],
        ];
    }

    public static function init(): self
    {
        return self::$instance ??= new self();
    }

    public static function instance(): self
    {
        return self::$instance ?? self::init();
    }

    /**
     * @param mixed $default
     * @return mixed
     */
    public function get(string $key, $default = null)
    {
        return $this->data[$key] ?? $default;
    }

    /** @return array<string, mixed> */
    public function all(): array
    {
        return $this->data;
    }
}
