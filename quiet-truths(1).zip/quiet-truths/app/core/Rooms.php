<?php
/**
 * Quiet Truths — Rooms Intelligence
 *
 * The house's sense of its own rooms. Everything here is computed live
 * from the stories themselves through the invisible concept layer —
 * nothing is hand-written, so it always tells the truth, and it shifts
 * as the house grows.
 *
 *  - atmosphere(): what a room has been made of (words + concept shape
 *                  + the story currently held) and a generated room note
 *  - houseMap():   the whole house at a glance — the concepts all
 *                  stories gather around (for All Stories)
 *  - suggestedFrom(): stories in OTHER rooms that share this room's
 *                  themes — the house leading you onward
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Rooms
{
    /**
     * Published story IDs in a room, newest first.
     *
     * @return list<int>
     */
    public static function storyIds(string $roomSlug): array
    {
        $query = new \WP_Query([
            'post_type'      => 'qt_story',
            'post_status'    => 'publish',
            'posts_per_page' => 500,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'tax_query'      => [
                [
                    'taxonomy' => 'qt_room',
                    'field'    => 'slug',
                    'terms'    => $roomSlug,
                ],
            ],
        ]);

        return array_map('intval', (array) $query->posts);
    }

    /**
     * What a room has been made of, computed from its stories.
     *
     * @return array{
     *   count:int, words:list<string>, concepts:list<array{slug:string,name:string,pct:int,count:int}>,
     *   newest:?\WP_Post, note:string
     * }
     */
    public static function atmosphere(string $roomSlug): array
    {
        $ids = self::storyIds($roomSlug);

        $out = [
            'count'    => count($ids),
            'words'    => [],
            'concepts' => [],
            'newest'   => null,
            'note'     => '',
        ];

        if (empty($ids)) {
            return $out;
        }

        $out['newest'] = get_post($ids[0]);

        $text  = '';
        $count = [];

        foreach ($ids as $id) {
            $post = get_post($id);

            if (!$post) {
                continue;
            }

            $text .= ' ' . (string) $post->post_title . ' ' . (string) $post->post_content;

            foreach (Concepts::themesOf($id) as $slug) {
                $count[$slug] = ($count[$slug] ?? 0) + 1;
            }
        }

        $out['words'] = Concepts::topWords($text, 3);

        arsort($count);
        $total = max(1, array_sum($count));

        foreach (array_slice($count, 0, 4, true) as $slug => $c) {
            $concept = Concepts::concepts()[$slug] ?? null;

            $out['concepts'][] = [
                'slug'  => (string) $slug,
                'name'  => (string) ($concept['name'] ?? $slug),
                'pct'   => (int) round($c / $total * 100),
                'count' => (int) $c,
            ];
        }

        $names = array_column($out['concepts'], 'name');
        $names = array_slice($names, 0, 2);

        if (1 === $out['count']) {
            $out['note'] = sprintf(
                /* translators: %s the concepts this single story speaks of */
                __('One story rests here so far, and it speaks of %s.', 'quiet-truths'),
                '' !== implode(' and ', $names) ? implode(' and ', $names) : __('quiet things', 'quiet-truths')
            );
        } else {
            $out['note'] = sprintf(
                /* translators: %1$s concepts, %2$s the most-kept words */
                __('This room has lately been about %1$s. The words kept here most often: %2$s.', 'quiet-truths'),
                '' !== implode(' and ', $names) ? implode(' and ', $names) : __('the quiet things of the house', 'quiet-truths'),
                '' !== implode(', ', $out['words']) ? implode(', ', $out['words']) : __('—', 'quiet-truths')
            );
        }

        return $out;
    }

    /**
     * The whole house at a glance: the concepts all stories gather
     * around, most-held first.
     *
     * @return list<array{slug:string,name:string,count:int}>
     */
    public static function houseMap(int $limit = 10): array
    {
        $query = new \WP_Query([
            'post_type'      => 'qt_story',
            'post_status'    => 'publish',
            'posts_per_page' => 500,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ]);

        $count = [];

        foreach ($query->posts as $id) {
            foreach (Concepts::themesOf((int) $id) as $slug) {
                $count[$slug] = ($count[$slug] ?? 0) + 1;
            }
        }

        arsort($count);

        $map = [];

        foreach (array_slice($count, 0, $limit, true) as $slug => $c) {
            $concept = Concepts::concepts()[$slug] ?? null;

            $map[] = [
                'slug'  => (string) $slug,
                'name'  => (string) ($concept['name'] ?? $slug),
                'count' => (int) $c,
            ];
        }

        return $map;
    }

    /**
     * Stories in OTHER rooms that share this room's themes — the house
     * leading the reader onward, across the invisible layer.
     *
     * @return list<\WP_Post>
     */
    public static function suggestedFrom(string $roomSlug, int $limit = 3): array
    {
        $ids     = self::storyIds($roomSlug);
        $profile = [];

        foreach ($ids as $id) {
            foreach (Concepts::themesOf($id) as $slug) {
                $profile[$slug] = ($profile[$slug] ?? 0) + 1;
            }
        }

        if (empty($profile)) {
            return [];
        }

        $query = new \WP_Query([
            'post_type'      => 'qt_story',
            'post_status'    => 'publish',
            'posts_per_page' => 500,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ]);

        $scored = [];

        foreach ($query->posts as $id) {
            $id = (int) $id;

            if (in_array($id, $ids, true)) {
                continue;
            }

            $terms = get_the_terms($id, 'qt_room');
            if (is_wp_error($terms) || empty($terms)) {
                continue;
            }
            if ($terms[0]->slug === $roomSlug) {
                continue;
            }

            $score = 0;

            foreach (Concepts::themesOf($id) as $slug) {
                if (isset($profile[$slug])) {
                    $score += $profile[$slug];
                }
            }

            if ($score > 0) {
                $scored[$id] = $score;
            }
        }

        arsort($scored);

        $posts = [];

        foreach (array_slice(array_keys($scored), 0, $limit, true) as $id) {
            $post = get_post($id);

            if ($post) {
                $posts[] = $post;
            }
        }

        return $posts;
    }
}
