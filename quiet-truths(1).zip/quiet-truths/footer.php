<?php
/**
 * Quiet Truths — Footer
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

$qt_loader = get_stylesheet_directory() . '/app/presentation/components/loader.php';
if (file_exists($qt_loader)) {
    require_once $qt_loader;
}
?>
<footer class="qt-footer">
    <p class="qt-footer__closing">
        <?php echo esc_html__('The website whispers, so that stories could be heard.', 'quiet-truths'); ?>
    </p>

    <div class="qt-footer__mark" aria-hidden="true"></div>

    <nav class="qt-footer__nav" aria-label="<?php echo esc_attr__('Footer', 'quiet-truths'); ?>">
        <?php
        if (function_exists('qt_footer_nav')) {
            qt_footer_nav();
        }
        ?>
    </nav>

    <p class="u-text-center u-text-subtle u-mt-xl" style="font-family:var(--font-interface);font-size:var(--text-xs)">
        &copy; <?php echo esc_html(date_i18n('Y')); ?> <?php echo esc_html__('Quiet Truths', 'quiet-truths'); ?> —
        <?php echo esc_html__('stories kept with dignity', 'quiet-truths'); ?>
    </p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
