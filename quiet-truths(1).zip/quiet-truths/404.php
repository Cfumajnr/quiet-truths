<?php
/**
 * Quiet Truths — 404
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main id="qt-main" class="starting-point" style="padding-top:var(--space-5xl);padding-bottom:var(--space-5xl)">
    <p class="starting-point__label"><?php echo esc_html__('404 — not found', 'quiet-truths'); ?></p>
    <p class="starting-point__guide">
        <?php echo esc_html__('The page you were looking for has wandered off. It may have been a draft, a goodbye, or a path that was never finished. The rooms are still open.', 'quiet-truths'); ?>
    </p>
    <div class="u-flex u-gap-sm" style="justify-content:center;margin-top:var(--space-lg)">
        <?php qt_button(home_url('/#rooms'), __('Return to the rooms', 'quiet-truths'), 'primary'); ?>
        <?php qt_button(home_url('/?s='), __('Search instead', 'quiet-truths'), 'quiet'); ?>
    </div>
</main>

<?php get_footer(); ?>
