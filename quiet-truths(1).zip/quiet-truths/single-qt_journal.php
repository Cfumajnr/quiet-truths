<?php
/**
 * Quiet Truths — Single journal (reading view, bylined)
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main id="qt-main" class="reading-container reading-container--story" style="padding-top:var(--space-3xl);padding-bottom:var(--space-4xl)">
    <?php while (have_posts()) : the_post(); ?>

        <?php $qt_byline = qt_journal_byline(get_the_ID()); ?>

        <article class="journal-single">
            <div class="journal-single__byline">
                <span class="journal-single__byline-name"><?php echo esc_html($qt_byline['name'] ?: __('A writer', 'quiet-truths')); ?></span>
                <?php if ('' !== $qt_byline['role']) : ?>
                    <span class="journal-single__byline-role"><?php echo esc_html($qt_byline['role']); ?></span>
                <?php endif; ?>
            </div>

            <h1 class="story-single__title"><?php the_title(); ?></h1>

            <p class="story-single__meta">
                <span><?php echo esc_html(get_the_date('j M Y')); ?></span>
                <?php if ('' !== qt_reading_time(get_the_ID())) : ?>
                    <span aria-hidden="true">·</span>
                    <span><?php echo esc_html(qt_reading_time(get_the_ID())); ?></span>
                <?php endif; ?>
            </p>

            <div class="story-single__body">
                <?php the_content(); ?>
            </div>

            <?php if ('' !== $qt_byline['bio']) : ?>
                <div class="journal-single__bio">
                    <span class="journal-single__bio-name"><?php echo esc_html($qt_byline['name'] ?: ''); ?></span>
                    <p><?php echo esc_html($qt_byline['bio']); ?></p>
                </div>
            <?php endif; ?>
        </article>

        <?php
        // More from the journals.
        $qt_more = new WP_Query([
            'post_type'      => 'qt_journal',
            'post_status'    => 'publish',
            'posts_per_page' => 3,
            'post__not_in'   => [get_the_ID()],
            'no_found_rows'  => true,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ]);
        ?>
        <?php if ($qt_more->have_posts()) : ?>
            <section class="story-more">
                <p class="rooms-section__label"><?php echo esc_html__('More from the journals', 'quiet-truths'); ?></p>
                <?php while ($qt_more->have_posts()) : $qt_more->the_post(); ?>
                    <?php qt_journal_card(get_the_ID()); ?>
                <?php endwhile; ?>
                <?php wp_reset_postdata(); ?>
            </section>
        <?php endif; ?>

    <?php endwhile; ?>
</main>

<?php get_footer(); ?>
