<?php
/**
 * Quiet Truths — Journal archive (post type: qt_journal)
 *
 * Long-form writing from named voices. The second wing of the house.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main id="qt-main">
    <header class="room-header">
        <?php echo qt_room_symbol('letters'); ?>
        <h1 class="room-header__name"><?php echo esc_html__('The Journals', 'quiet-truths'); ?></h1>
        <p class="room-header__description">
            <?php echo esc_html__('Long-form writing from named voices — professionals, journalists, and writers who sign their work.', 'quiet-truths'); ?>
        </p>
    </header>

    <section class="story-feed" style="padding-top:0">
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <?php qt_journal_card(get_the_ID()); ?>
            <?php endwhile; ?>
        <?php else : ?>
            <?php qt_gentle_notice('reflection', __('No journals have been published yet. When a named voice joins the house, it will appear here.', 'quiet-truths')); ?>
        <?php endif; ?>
    </section>

    <div class="u-text-center u-mt-2xl">
        <?php
        the_posts_pagination([
            'mid_size'  => 1,
            'prev_text' => '←',
            'next_text' => '→',
            'type'      => 'list',
        ]);
        ?>
    </div>
</main>

<?php get_footer(); ?>
