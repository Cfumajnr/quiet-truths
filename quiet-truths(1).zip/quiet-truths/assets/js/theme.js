/**
 * Quiet Truths — theme.js
 * Mobile navigation toggle + search overlay. No dependencies.
 */
(function () {
    'use strict';

    function ready(fn) {
        if (document.readyState !== 'loading') {
            fn();
        } else {
            document.addEventListener('DOMContentLoaded', fn);
        }
    }

    ready(function () {
        /* ── Mobile navigation ── */
        var toggle = document.querySelector('.qt-header__menu-toggle');
        var mobileNav = document.querySelector('.qt-mobile-nav');

        if (toggle && mobileNav) {
            toggle.addEventListener('click', function () {
                var open = mobileNav.classList.toggle('open');
                toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            });

            mobileNav.addEventListener('click', function (event) {
                if (event.target.tagName === 'A') {
                    mobileNav.classList.remove('open');
                    toggle.setAttribute('aria-expanded', 'false');
                }
            });
        }

        /* ── Search overlay ── */
        var overlay = document.querySelector('.qt-search-overlay');
        var triggers = document.querySelectorAll('[data-qt-overlay="search"]');

        if (overlay && triggers.length) {
            function openSearch() {
                overlay.classList.add('open');
                var input = overlay.querySelector('input[type="search"], input[name="s"]');
                if (input) {
                    input.focus();
                }
            }

            function closeSearch() {
                overlay.classList.remove('open');
            }

            triggers.forEach(function (trigger) {
                trigger.addEventListener('click', function (event) {
                    event.preventDefault();
                    openSearch();
                });
            });

            overlay.addEventListener('click', function (event) {
                if (event.target === overlay) {
                    closeSearch();
                }
            });

            document.addEventListener('keydown', function (event) {
                if (event.key === 'Escape') {
                    closeSearch();
                }
            });
        }
    });

    ready(function () {
        /* ── Explore Truth: the button opens the search ── */
        var exploreBtn = document.getElementById('qt-explore-btn');
        var explorePanel = document.getElementById('qt-explore-panel');

        if (exploreBtn && explorePanel) {
            exploreBtn.addEventListener('click', function () {
                var willOpen = explorePanel.hidden;

                explorePanel.hidden = !willOpen;
                exploreBtn.setAttribute('aria-expanded', willOpen ? 'true' : 'false');

                if (willOpen) {
                    var input = explorePanel.querySelector('input[name="s"]');

                    if (input) {
                        input.focus();
                    }
                }
            });
        }
    });

    ready(function () {
        /* ── Responses: open one reply/edit/report form at a time ── */
        var section = document.querySelector('.qt-responses');

        if (section) {
            section.addEventListener('click', function (event) {
                var button = event.target.closest('[data-qt-toggle]');

                if (!button) {
                    return;
                }

                event.preventDefault();

                var form = document.getElementById(button.getAttribute('data-qt-toggle'));

                if (!form) {
                    return;
                }

                var willOpen = !form.classList.contains('is-open');

                section.querySelectorAll('.qt-response__form.is-open').forEach(function (other) {
                    other.classList.remove('is-open');
                });

                if (willOpen) {
                    form.classList.add('is-open');
                    var textarea = form.querySelector('textarea');

                    if (textarea) {
                        textarea.focus();
                    }
                }
            });
        }
    });
})();
