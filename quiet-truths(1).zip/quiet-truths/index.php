<?php
/**
 * Quiet Truths — Index
 *
 * Fallback template: search results, archives and any unhandled query.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main id="qt-main" class="reading-container" style="padding-top:var(--space-3xl);padding-bottom:var(--space-4xl)">
    <?php if (is_search()) : ?>
        <p class="rooms-section__label"><?php
            /* translators: %s: search query */
            printf(esc_html__('Searching for “%s”', 'quiet-truths'), esc_html(get_search_query()));
        ?></p>
    <?php endif; ?>

    <?php if (have_posts()) : ?>

        <div class="story-feed" style="padding:0">
            <?php while (have_posts()) : the_post(); ?>
                <article class="story-panel">
                    <h3 class="story-panel__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <p class="story-panel__excerpt"><?php echo esc_html(get_the_excerpt() ?: wp_trim_words((string) get_the_content(), 40, '…')); ?></p>
                    <div class="story-panel__time"><?php echo esc_html(get_the_date('j M Y')); ?></div>
                </article>
            <?php endwhile; ?>
        </div>

        <div class="u-mt-2xl" style="text-align:center">
            <?php
            the_posts_pagination([
                'mid_size'  => 1,
                'prev_text' => '←',
                'next_text' => '→',
            ]);
            ?>
        </div>

    <?php else : ?>

        <?php qt_gentle_notice('reflection', __('Nothing was found — but the rooms are still open, and the search was not in vain. Try another word, or wander instead.', 'quiet-truths')); ?>
        <div class="u-text-center u-mt-xl">
            <?php qt_button(home_url('/#rooms'), __('Wander the rooms', 'quiet-truths'), 'primary'); ?>
        </div>

    <?php endif; ?>
</main>

<?php get_footer(); ?>
