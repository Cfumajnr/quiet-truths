<?php
/**
 * Quiet Truths — Single story (reading view)
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

$qt_room      = qt_story_room(get_the_ID());
$qt_room_meta = defined('QT_ROOMS') ? QT_ROOMS : [];
$qt_room_data = null;

if ($qt_room) {
    $qt_room_data = $qt_room_meta[$qt_room->slug] ?? [
        'name'        => $qt_room->name,
        'description' => (string) term_description($qt_room),
    ];
}
?>

<main id="qt-main" class="reading-container reading-container--story" style="padding-top:var(--space-3xl);padding-bottom:var(--space-4xl)">
    <?php while (have_posts()) : the_post(); ?>

        <article class="story-single">
            <?php if ($qt_room && $qt_room_data) : ?>
                <a class="story-panel__room" href="<?php echo esc_url(qt_room_url($qt_room->slug)); ?>">
                    <span class="story-panel__room-symbol" aria-hidden="true"></span>
                    <?php echo esc_html($qt_room_data['name']); ?>
                </a>
            <?php endif; ?>

            <h1 class="story-single__title"><?php the_title(); ?></h1>

            <p class="story-single__meta">
                <span><?php echo esc_html(sprintf(__('Left here on %s', 'quiet-truths'), get_the_date('j M Y'))); ?></span>
                <span aria-hidden="true">·</span>
                <span><?php echo esc_html__('kept anonymously', 'quiet-truths'); ?></span>
            </p>

            <div class="story-single__body">
                <?php the_content(); ?>
            </div>
        </article>

        <?php qt_quiet_divider(true); ?>
        <div class="u-text-center">
            <?php qt_gentle_notice('healing', __('This story was left here with care. Thank you for reading it gently.', 'quiet-truths')); ?>
            <div class="u-mt-lg">
                <?php qt_hope_marker(__('You are not alone in what you carry.', 'quiet-truths')); ?>
            </div>
        </div>

        <?php
        // The quiet invitation — no buttons, no colours, just a path.
        ?>
        <aside class="qt-continue">
            <p class="qt-continue__line"><?php echo esc_html__('Every door in this house opens quietly.', 'quiet-truths'); ?></p>
            <div class="qt-continue__links">
                <a class="qt-continue__link" href="<?php echo esc_url(qt_random_story_url()); ?>"><?php echo esc_html__('Continue wandering', 'quiet-truths'); ?></a>
                <span aria-hidden="true">·</span>
                <a class="qt-continue__link" href="<?php echo esc_url(home_url('/stories/')); ?>"><?php echo esc_html__('Return to the collection', 'quiet-truths'); ?></a>
            </div>
        </aside>

        <?php
        // The bridge: a Journal that continues this conversation.
        if (function_exists('qt_journal_bridge')) {
            qt_journal_bridge(get_the_ID());
        }
        ?>

        <?php
        if (function_exists('qt_responses_section')) {
            qt_responses_section(get_the_ID());
        }
        ?>

        <?php
        // After the responses: stories the house quietly thinks belong
        // together — across rooms, through the invisible layer.
        if (class_exists(\QuietTruths\Core\Concepts::class)) {
            $qt_similar = \QuietTruths\Core\Concepts::similarStories(get_the_ID(), 3);

            if (!empty($qt_similar)) :
        ?>
            <section class="story-more">
                <p class="rooms-section__label"><?php echo esc_html__('If this stayed with you…', 'quiet-truths'); ?></p>
                <p class="story-more__note">
                    <?php echo esc_html__('The house thought these belonged nearby — no matter which room they were left in.', 'quiet-truths'); ?>
                </p>

                <?php foreach ($qt_similar as $qt_related) : ?>
                    <?php
                    // Softer room display: "From the Unfinished Room"
                    $qt_rel_room = qt_story_room($qt_related->ID);
                    $qt_rel_time = qt_reading_time($qt_related);
                    ?>
                    <a class="qt-story-row" href="<?php echo esc_url(get_permalink($qt_related)); ?>">
                        <h3 class="qt-story-row__title"><?php echo esc_html((string) $qt_related->post_title); ?></h3>
                        <p class="qt-story-row__excerpt"><?php echo esc_html(qt_story_excerpt($qt_related, 200)); ?></p>
                        <div class="qt-story-row__meta">
                            <?php if ($qt_rel_room) : ?>
                                <span><?php echo esc_html(sprintf(__('From the %s room', 'quiet-truths'), $qt_rel_room->name)); ?></span>
                            <?php endif; ?>
                            <?php if ('' !== $qt_rel_time) : ?>
                                <span aria-hidden="true">·</span><span><?php echo esc_html($qt_rel_time); ?></span>
                            <?php endif; ?>
                        </div>
                    </a>
                <?php endforeach; ?>
            </section>
        <?php
            endif;
        }
        ?>

    <?php endwhile; ?>
</main>

<?php get_footer(); ?>
