<?php
/**
 * Quiet Truths Genesis — Child Theme of Blocksy
 *
 * Enqueues the parent theme, then boots the platform.
 * No CSS paths. No enqueues. No business logic.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * PHP 7.4 polyfills for PHP 8 string functions.
 */
if (!function_exists('str_starts_with')) {
    function str_starts_with($haystack, $needle) {
        return (string) $needle !== '' && strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}

if (!function_exists('str_ends_with')) {
    function str_ends_with($haystack, $needle) {
        if ('' === $needle || $needle === $haystack) return true;
        if ('' === $haystack) return false;
        return substr($haystack, -strlen($needle)) === $needle;
    }
}

if (!function_exists('str_contains')) {
    function str_contains($haystack, $needle) {
        return $needle !== '' && mb_strpos($haystack, $needle) !== false;
    }
}

// ── Child theme: load parent stylesheet ──
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style(
        'blocksy-parent',
        get_template_directory_uri() . '/style.css',
        [],
        wp_get_theme()->get('Version')
    );
}, 1);

// ── Boot the platform (with error guard) ──
$qt_bootstrap = get_stylesheet_directory() . '/app/core/Application.php';

add_action('after_setup_theme', function () use ($qt_bootstrap) {
    if (!file_exists($qt_bootstrap)) {
        error_log('Quiet Truths: Application.php not found at ' . $qt_bootstrap);
        return;
    }

    try {
        require_once $qt_bootstrap;
        \QuietTruths\Core\Application::boot();
    } catch (\Throwable $e) {
        error_log('Quiet Truths bootstrap error: ' . $e->getMessage());
        if (defined('WP_DEBUG') && WP_DEBUG) {
            wp_die('Quiet Truths could not start: ' . esc_html($e->getMessage()));
        }
    }
});
