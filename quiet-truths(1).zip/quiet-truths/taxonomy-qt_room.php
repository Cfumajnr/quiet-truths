<?php
/**
 * Quiet Truths — Room archive (taxonomy: qt_room)
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

$qt_term = get_queried_object();
$qt_slug = ($qt_term instanceof WP_Term) ? $qt_term->slug : '';

$qt_room_meta = defined('QT_ROOMS') ? QT_ROOMS : [];
$qt_data      = $qt_room_meta[$qt_slug] ?? [
    'name'        => ($qt_term instanceof WP_Term) ? $qt_term->name : __('A room', 'quiet-truths'),
    'description' => ($qt_term instanceof WP_Term) ? (string) term_description($qt_term) : '',
];

$qt_paged = max(1, (int) get_query_var('paged'));

$qt_query = new WP_Query([
    'post_type'      => 'qt_story',
    'post_status'    => 'publish',
    'posts_per_page' => 12,
    'paged'          => $qt_paged,
    'tax_query'      => [
        [
            'taxonomy' => 'qt_room',
            'field'    => 'slug',
            'terms'    => $qt_slug,
        ],
    ],
]);
?>

<main id="qt-main">
    <?php qt_room_header($qt_slug, $qt_data['name'], $qt_data['description']); ?>

    <?php
    // The feel of the room — computed from its own stories.
    if (class_exists(\QuietTruths\Core\Rooms::class)) {
        $qt_atmo = \QuietTruths\Core\Rooms::atmosphere($qt_slug);
        qt_room_atmosphere($qt_atmo);
    }
    ?>

    <section class="story-feed" style="padding-top:0">
        <?php if ($qt_query->have_posts()) : ?>
            <?php while ($qt_query->have_posts()) : $qt_query->the_post(); ?>
                <?php qt_story_panel(get_the_ID()); ?>
            <?php endwhile; ?>
            <?php wp_reset_postdata(); ?>
        <?php else : ?>
            <?php qt_gentle_notice('reflection', __('This room is still being furnished. Stories left here will appear when they are given a place.', 'quiet-truths')); ?>
        <?php endif; ?>
    </section>

    <?php if ($qt_query->max_num_pages > 1) : ?>
        <div class="u-text-center u-mt-2xl">
            <?php
            echo paginate_links([
                'total'     => $qt_query->max_num_pages,
                'current'   => $qt_paged,
                'prev_text' => '←',
                'next_text' => '→',
                'type'      => 'list',
            ]);
            ?>
        </div>
    <?php endif; ?>

    <?php
    // The house leading you onward, across the invisible layer.
    if (class_exists(\QuietTruths\Core\Rooms::class)) {
        $qt_cross = \QuietTruths\Core\Rooms::suggestedFrom($qt_slug, 3);
        qt_cross_room_suggest($qt_cross, $qt_data['name']);
    }
    ?>

    <section class="starting-point">
        <p class="starting-point__label"><?php echo esc_html__('Back to the whole house', 'quiet-truths'); ?></p>
        <?php qt_button(home_url('/#qt-home-doors'), __('All the doors', 'quiet-truths'), 'quiet'); ?>
    </section>
</main>

<?php get_footer(); ?>
