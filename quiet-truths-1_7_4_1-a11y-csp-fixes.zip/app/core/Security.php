<?php
/**
 * Quiet Truths — Security
 *
 * The house's own security layer — no plugin needed:
 *
 *  - security headers (nosniff, framing, referrer, permissions, CSP)
 *  - HSTS (only over HTTPS)
 *  - hides the WordPress version (html + feeds)
 *  - disables XML-RPC
 *  - generic login errors (no username enumeration)
 *  - login rate limiting per IP (brute-force guard)
 *  - blocks author-archive enumeration
 *
 * Everything can be disabled by defining a constant:
 *   define('QT_SECURITY_HEADERS', false);   // no headers
 *   define('QT_SECURITY_LOGIN', false);     // no login hardening
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Security
{
    private const LOCKOUT_ATTEMPTS = 5;
    private const LOCKOUT_SECONDS  = 15 * MINUTE_IN_SECONDS;

    /** @var string|null Per-request CSP nonce, generated once and reused for every inline script on the page. */
    private static ?string $cspNonce = null;

    public static function init(): void
    {
        if (!defined('QT_SECURITY_HEADERS') || QT_SECURITY_HEADERS) {
            add_action('send_headers', [self::class, 'headers']);
            // WordPress core (wp_localize_script, wp_add_inline_script) prints
            // inline <script> blocks — e.g. QTReactions, QTLiveSearch, QTWriter.
            // Stamp them with our CSP nonce so we can drop 'unsafe-inline'.
            add_filter('wp_inline_script_attributes', [self::class, 'nonceInlineScript']);
        }

        if (!defined('QT_SECURITY_LOGIN') || QT_SECURITY_LOGIN) {
            self::loginHardening();
        }

        remove_action('wp_head', 'wp_generator');
        add_filter('the_generator', '__return_empty_string');

        // Stories are anonymous. WordPress core still exposes an
        // `author` field on /wp-json/wp/v2/qt_story and in oEmbed
        // output unless we explicitly strip it. We do not want the
        // WP user who approved/created a story to ever be named as
        // its author publicly.
        add_filter('oembed_response_data', [self::class, 'stripOembedAuthor'], 99);
        add_filter('rest_post_dispatch', [self::class, 'stripRestAuthor'], 99);
        // In feeds, override the author to the site.
        add_filter('the_author', [self::class, 'anonymousAuthor'], 99);
        add_filter('get_the_author_display_name', [self::class, 'anonymousAuthorName'], 99, 3);
    }

    /**
     * Anonymous stories should never expose a named author in oEmbed.
     *
     * @param array<string,mixed> $data
     * @return array<string,mixed>
     */
    public static function stripOembedAuthor(array $data): array
    {
        if (!empty($data['type']) && 'rich' !== $data['type']) {
            // only touch rich/html-wrapping embeds; leave others alone.
        }
        $postId = (int) ($data['post_id'] ?? 0);
        if ($postId > 0 && 'qt_story' === get_post_type($postId)) {
            unset($data['author_name'], $data['author_url']);
        }
        return $data;
    }

    /**
     * Strip author from REST responses for qt_story.
     *
     * @param \WP_REST_Response|\WP_HTTP_Response|mixed $result
     * @return mixed
     */
    public static function stripRestAuthor($result)
    {
        if (!is_object($result) || !method_exists($result, 'get_data')) {
            return $result;
        }
        $data = $result->get_data();
        if (!is_array($data)) {
            return $result;
        }
        // Single story envelope.
        if (isset($data['type']) && 'qt_story' === $data['type']) {
            unset($data['author']);
            if (method_exists($result, 'set_data')) {
                $result->set_data($data);
            }
            if (method_exists($result, 'remove_link')) {
                try {
                    $links = $result->get_links();
                    if (isset($links['author'])) {
                        $result->remove_link('author');
                    }
                } catch (\Throwable $e) {
                    // not worth failing a response for.
                }
            }
            return $result;
        }
        // Collection of stories: strip author from each embedded item.
        if (isset($data[0]) && is_array($data[0])) {
            $changed = false;
            foreach ($data as $i => $item) {
                if (is_array($item) && isset($item['type']) && 'qt_story' === $item['type']) {
                    unset($data[$i]['author']);
                    $changed = true;
                }
            }
            if ($changed && method_exists($result, 'set_data')) {
                $result->set_data($data);
            }
        }
        return $result;
    }

    /**
     * When WP renders an "author" for a story (e.g. feeds), use the
     * house name instead of a user.
     */
    public static function anonymousAuthor(string $display): string
    {
        if (is_singular('qt_story') || is_post_type_archive('qt_story') || is_singular('qt_response')) {
            return (string) get_bloginfo('name');
        }
        return $display;
    }

    public static function anonymousAuthorName(string $name, int $userId, int $postId): string
    {
        if ($postId > 0 && 'qt_story' === get_post_type($postId)) {
            return (string) get_bloginfo('name');
        }
        return $name;
    }

    /* ─────────────── headers ─────────────── */

    public static function headers(): void
    {
        if (headers_sent()) {
            return;
        }

        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=(), interest-cohort=()');

        // HSTS only makes sense over HTTPS.
        if (is_ssl()) {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        }

        $nonce = self::cspNonce();

        // style-src keeps 'unsafe-inline': WP core and Blocksy print inline
        // style attributes/blocks in too many uncontrolled places to nonce
        // reliably. script-src does not — every inline script on this theme
        // is either JSON-LD (exempt from script-src in modern browsers) or
        // one of our own wp_localize_script blocks, which we nonce below.
        header("Content-Security-Policy: default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; script-src 'self' 'nonce-{$nonce}'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'self'; form-action 'self'");
    }

    /**
     * The nonce for this request. Generated once, lazily, so it's the
     * same value whether it's first requested by the CSP header or by
     * an inline-script filter that fires before send_headers.
     */
    public static function cspNonce(): string
    {
        if (null === self::$cspNonce) {
            self::$cspNonce = bin2hex(random_bytes(16));
        }
        return self::$cspNonce;
    }

    /**
     * Add nonce="..." to every inline <script> WordPress prints
     * (wp_localize_script data, wp_add_inline_script content).
     *
     * @param array<string,string> $attributes
     * @return array<string,string>
     */
    public static function nonceInlineScript(array $attributes): array
    {
        $attributes['nonce'] = self::cspNonce();
        return $attributes;
    }

    /* ─────────────── XML-RPC ─────────────── */

    public static function xmlRpc(bool $enabled): bool
    {
        return false;
    }

    /* ─────────────── login hardening ─────────────── */

    private static function loginHardening(): void
    {
        add_filter('xmlrpc_enabled', [self::class, 'xmlRpc']);
        add_filter('login_errors', [self::class, 'genericError']);
        add_filter('authenticate', [self::class, 'checkLock'], 30, 3);
        add_action('wp_login_failed', [self::class, 'recordFailure']);
        add_action('template_redirect', [self::class, 'blockAuthorEnumeration']);
    }

    public static function genericError(): string
    {
        return __('Incorrect details.', 'quiet-truths');
    }

    /**
     * @return \WP_Error|\WP_User|null
     */
    public static function checkLock($user, string $username, string $password)
    {
        if ($user instanceof \WP_User || is_wp_error($user)) {
            return $user;
        }

        if (self::isLocked()) {
            return new \WP_Error(
                'qt_locked',
                __('Too many attempts. The house is resting — please try again in a few minutes.', 'quiet-truths')
            );
        }

        return $user;
    }

    public static function recordFailure(string $username): void
    {
        $ip  = self::ip();
        $key = 'qt_login_' . md5($ip);

        $count = (int) get_transient($key);
        $count++;

        if ($count >= self::LOCKOUT_ATTEMPTS) {
            set_transient($key, $count, self::LOCKOUT_SECONDS);
            return;
        }

        set_transient($key, $count, self::LOCKOUT_SECONDS);
    }

    private static function isLocked(): bool
    {
        $key   = 'qt_login_' . md5(self::ip());
        $count = (int) get_transient($key);

        return $count >= self::LOCKOUT_ATTEMPTS;
    }

    /**
     * The visitor's address, as seen by the server. Used only for the
     * short-lived login lockout — never stored with any content.
     */
    private static function ip(): string
    {
        if (!empty($_SERVER['REMOTE_ADDR'])) {
            return sanitize_text_field(wp_unslash((string) $_SERVER['REMOTE_ADDR']));
        }

        return '';
    }

    /* ─────────────── author enumeration ─────────────── */

    public static function blockAuthorEnumeration(): void
    {
        if (is_admin()) {
            return;
        }

        // /author/name/ and ?author=1 both land here.
        if (is_author()) {
            wp_safe_redirect(home_url('/'));
            exit;
        }
    }
}
