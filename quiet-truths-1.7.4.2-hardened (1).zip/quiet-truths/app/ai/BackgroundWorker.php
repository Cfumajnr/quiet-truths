<?php
/**
 * Quiet Truths — Background AI Worker
 *
 * Wraps WP-Cron single events so AI work (embedding generation,
 * profiling) runs in a separate request instead of tying up the
 * PHP/FPM worker that approved the story.
 *
 * This is not a true task queue (there's no dedicated worker process);
 * WP-Cron fires on a later request (WP's own traffic or a server cron
 * that pings wp-cron.php). It is the correct trade-off: zero extra
 * dependencies, no blocking the approval response, and a clear upgrade
 * path to ActionScheduler or a CLI queue when the site grows.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

final class BackgroundWorker
{
    private const HOOK_PROFILE = 'qt_ai_profile_warm';

    /** Concept backfill (Corrections 26 & 27) — run in batches in the
     *  background so a growing archive is never rebuilt inline on a
     *  public request, and so the whole archive can be covered. */
    private const HOOK_CONCEPT_BACKFILL = 'qt_ai_concept_backfill';

    /** Number of stories tagged per background batch. Kept modest so
     *  each WP-Cron tick stays light. */
    public const BACKFILL_BATCH_SIZE = 50;

    public static function init(): void
    {
        add_action(self::HOOK_PROFILE, [self::class, 'runProfile'], 10, 1);
        add_action(self::HOOK_CONCEPT_BACKFILL, [self::class, 'runConceptBackfill'], 10, 2);
    }

    /**
     * Queue the concept backfill to run in background batches. Called by
     * Concepts::maybeBackfill() when the concept knowledge-base signature
     * changes. Cheap and safe to call repeatedly — wp_schedule_single_event
     * deduplicates on (hook, args).
     */
    public static function queueConceptBackfill(): void
    {
        if (false === wp_next_scheduled(self::HOOK_CONCEPT_BACKFILL, [0, 0])) {
            wp_schedule_single_event(time() + 5, self::HOOK_CONCEPT_BACKFILL, [0, 0], true);
        }
    }

    /**
     * Process one batch of the concept backfill and schedule the next
     * until the ENTIRE archive is covered (Correction 26). When the last
     * batch completes, the knowledge-base signature is committed so later
     * requests short-circuit.
     *
     * @param int $offset  starting story index for this batch (stable ID order).
     * @param int $attempt retained for retry bookkeeping (currently unused).
     */
    public static function runConceptBackfill(int $offset, int $attempt = 0): void
    {
        if ($offset < 0) {
            $offset = 0;
        }

        // Both Stories and Journals are tagged, so the shared ontology and
        // the Story↔Journal bridge work across the whole house (Journal
        // Bible §5, §18). Concepts::tagStory already accepts both types.
        $stories = new \WP_Query([
            'post_type'      => ['qt_story', 'qt_journal'],
            'post_status'    => ['publish', 'pending'],
            'posts_per_page' => self::BACKFILL_BATCH_SIZE,
            'offset'         => $offset,
            'fields'         => 'ids',
            'orderby'        => 'ID',
            'order'          => 'ASC',
        ]);

        foreach ($stories->posts as $id) {
            \QuietTruths\Core\Concepts::tagStory((int) $id);
        }

        // If this batch was full, more stories/journals remain — schedule
        // the next batch. Otherwise the whole archive has been covered.
        if (count($stories->posts) === self::BACKFILL_BATCH_SIZE) {
            $next = $offset + self::BACKFILL_BATCH_SIZE;
            wp_schedule_single_event(time() + 2, self::HOOK_CONCEPT_BACKFILL, [$next, 0], true);
            return;
        }

        // Done — commit the signature so future calls short-circuit.
        \QuietTruths\Core\Concepts::commitBackfill();
    }

    /**
     * Enqueue a post for profiling + embedding in a later request.
     * Safe to call multiple times — WP-Cron will not double-schedule the
     * same post when an identical task is already pending.
     *
     * Lifecycle (v1.5.6+): Profile::queueWarm() sets _rebuild_pending=true
     * without touching the stored profile's _status. A FRESH profile stays
     * FRESH while the new build runs; runProfile() atomically replaces it
     * when a dense build completes, and leaves it untouched (rescheduling)
     * on failure.
     */
    public static function enqueueProfiling(int $postId): void
    {
        if ($postId < 1) {
            return;
        }
        // We do NOT delete or demote the existing profile here. The
        // profile's _status describes the STORED content (fresh/stale),
        // and _rebuild_pending is the separate flag that says work is
        // wanted. Readers keep the last good profile until an atomic
        // replacement lands.

        // wp_schedule_single_event deduplicates on (hook, args) within
        // 10 minutes; we add a small jitter so bulk publishes don't collide.
        $when = time() + wp_rand(2, 15);
        $existing = wp_next_scheduled(self::HOOK_PROFILE, [$postId]);
        if (false === $existing) {
            wp_schedule_single_event($when, self::HOOK_PROFILE, [$postId], true);
        }
    }

    /**
     * WP-Cron callback. Runs embedding generation + profile build for one post.
     *
     * Retry behaviour (v1.5.6): when warm() reports a retryable outcome
     * (preserved_existing_dense, persisted_lexical_fallback, failed) we
     * re-schedule a later attempt with exponential back-off up to a
     * ~15-minute ceiling. A transient outage must not strand a story
     * in lexical mode forever, and must not demote a FRESH dense profile.
     * On successful dense build, the retry counter is cleared.
     */
    public static function runProfile(int $postId): void
    {
        $post = get_post($postId);
        if (!$post) return;
        if (!in_array($post->post_type, ['qt_story','qt_journal'], true)) return;
        if ('publish' !== $post->post_status && 'pending' !== $post->post_status) return;

        $result = Profile::warm($postId);

        $retryable = in_array($result, ['preserved_existing_dense', 'persisted_lexical_fallback', 'failed'], true);
        if ($retryable) {
            // Exponential back-off: 30s, 60s, 120s, 240s, 480s, 900s cap.
            // We do NOT touch the stored profile's _status during retry.
            $attempts = (int) get_post_meta($postId, '_qt_ai_retry_attempts', true);
            $attempts = min($attempts + 1, 6);
            update_post_meta($postId, '_qt_ai_retry_attempts', $attempts);
            $delay = min(15 * 60, 30 * (2 ** max(0, $attempts - 1)));
            wp_schedule_single_event(time() + $delay, self::HOOK_PROFILE, [$postId], true);
        } else {
            // Successful dense build: clear retry counter.
            delete_post_meta($postId, '_qt_ai_retry_attempts');
        }
    }
}
