<?php
/**
 * Quiet Truths — AI Kernel (the quiet librarian, central desk)
 *
 * Boots the AI subsystem. Houses the feature flag and the loopback
 * HTTP client shared by every ai/* module.
 *
 * The four non-negotiable rules:
 *   1. AI never writes words a reader sees as content.
 *   2. AI works behind the curtain — readers experience it as better
 *      search, better suggestions, better protection for writers.
 *   3. Stories never leave the server. The embedding service listens
 *      on 127.0.0.1 only; no third-party APIs.
 *   4. AI flags are always suggestions. A human moderator decides.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

final class AiKernel
{
    /* ──────────────────── boot ──────────────────── */

    public static function boot(): void
    {
        if (!self::enabled()) {
            return;
        }

        // Subsystems. Order matters: Embeddings must be registered first
        // because everything else may ask for vectors; Profile before
        // Moderation (which reads it); BackgroundWorker early so other
        // subsystems can enqueue jobs.
        Embeddings::init();
        BackgroundWorker::init();
        ContentSignals::init();
        PrivacyScanner::init();
        // ConceptInference is the canonical concept-intelligence layer.
        // The former ThemeInference name is a retired compatibility
        // shim (v1.7.3, v1.7.4 Corrections 14–16) — current code never
        // references it.
        ConceptInference::init();
        StoryUnderstanding::init();
        StoryRelations::init();
        SemanticSearch::init();
        Profile::class; // registered via autoload
        ModerationSignals::init();
    }

    /* ──────────────────── feature flag ──────────────────── */

    public static function enabled(): bool
    {
        return !defined('QT_AI_ENABLED') || QT_AI_ENABLED;
    }

    /* ──────────────────── service connectivity ──────────────────── */

    public static function host(): string
    {
        return defined('QT_AI_EMBED_HOST') ? (string) QT_AI_EMBED_HOST : '127.0.0.1';
    }

    public static function port(): int
    {
        return defined('QT_AI_EMBED_PORT') ? (int) QT_AI_EMBED_PORT : 0;
    }

    public static function serviceUrl(): string
    {
        $p = self::port();
        if ($p < 1) {
            return '';
        }
        return 'http://' . self::host() . ':' . $p;
    }

    /**
     * Is the local embedding service reachable and ready? Cached per
     * request — delegates to Embeddings::serviceMeta() which hits
     * /health (not a port probe) so we know the model is loaded.
     */
    public static function serviceReady(): bool
    {
        return self::serviceUrl() !== '' && Embeddings::serviceMeta()['ok'];
    }

    /**
     * Issue a POST to the local embedding service. Returns decoded
     * JSON or null if anything went wrong. Never raises.
     *
     * @return array<string,mixed>|null
     */
    public static function postJson(string $path, array $payload): ?array
    {
        if (!self::serviceReady()) {
            return null;
        }
        $resp = wp_remote_post(self::serviceUrl() . $path, [
            'timeout' => 3.0,
            'blocking' => true,
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode($payload),
            'sslverify' => false,
        ]);
        if (is_wp_error($resp) || 200 !== (int) wp_remote_retrieve_response_code($resp)) {
            return null;
        }
        $decoded = json_decode((string) wp_remote_retrieve_body($resp), true);
        return is_array($decoded) ? $decoded : null;
    }

    /* ──────────────────── text helpers ──────────────────── */

    public static function normalise(string $text): string
    {
        $text = wp_strip_all_tags($text);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = mb_strtolower($text, 'UTF-8');
        $text = preg_replace('/\s+/u', ' ', $text) ?: '';
        return trim($text);
    }
}
