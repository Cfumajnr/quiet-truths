<?php
/**
 * Quiet Truths — Governance Pages Loader
 *
 * Registers the six public governance documents (Privacy, Terms,
 * Submission Terms, Editorial Policy, Safety & Crisis Help,
 * Complaints & Removals) as WordPress pages the first time the
 * theme boots, and keeps their content in sync with the pack
 * shipped in app/pages/content/.
 *
 * Nothing here is editorial; the words live in the static content
 * files so counsel can edit them without touching PHP.
 *
 * @package QuietTruths\Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Governance
{
    /** @var string Version — bump when content changes so pages re-sync. */
    public const PACK_VERSION = '1.0.0-draft.7';

    /**
     * Map: slug → [title, file, label, order, parent(optional)].
     * 'house-rules' is kept as a child of editorial policy for backwards
     * compatibility with the existing URL; its content is retired and
     * points to the new policy.
     *
     * @return array<string,array{title:string,file:string,label:string,order:int,parent?:string,status?:string}>
     */
    public static function pages(): array
    {
        return [
            'privacy' => [
                'title'  => __('Privacy Notice', 'quiet-truths'),
                'file'   => '01-privacy.html',
                'label'  => __('Privacy', 'quiet-truths'),
                'order'  => 10,
            ],
            'terms' => [
                'title'  => __('Terms of Use', 'quiet-truths'),
                'file'   => '02-terms.html',
                'label'  => __('Terms', 'quiet-truths'),
                'order'  => 11,
            ],
            'submission-terms' => [
                'title'  => __('Submission & Publication Terms', 'quiet-truths'),
                'file'   => '03-submission-terms.html',
                'label'  => __('Submission Terms', 'quiet-truths'),
                'order'  => 12,
            ],
            'editorial-policy' => [
                'title'  => __('Editorial & Moderation Policy', 'quiet-truths'),
                'file'   => '04-editorial-policy.html',
                'label'  => __('Editorial Policy', 'quiet-truths'),
                'order'  => 13,
            ],
            'safety-crisis-help' => [
                'title'  => __('Safety & Crisis Help', 'quiet-truths'),
                'file'   => '05-safeguarding.html',
                'label'  => __('Safety & Crisis Help', 'quiet-truths'),
                'order'  => 14,
            ],
            'complaints-removals' => [
                'title'  => __('Complaints & Removals', 'quiet-truths'),
                'file'   => '06-complaints-removals.html',
                'label'  => __('Complaints & Removals', 'quiet-truths'),
                'order'  => 15,
            ],
            'house-rules' => [
                'title'  => __('House Rules', 'quiet-truths'),
                'file'   => 'house-rules.html',
                'label'  => __('House Rules', 'quiet-truths'),
                'order'  => 16,
                'parent' => 'editorial-policy',
            ],
            'journal-terms' => [
                'title'  => __('Journal Terms', 'quiet-truths'),
                'file'   => 'journal-terms.html',
                'label'  => __('Journal Terms', 'quiet-truths'),
                'order'  => 17,
            ],
            'journal-copyright' => [
                'title'  => __('Journal Copyright', 'quiet-truths'),
                'file'   => 'journal-copyright.html',
                'label'  => __('Journal Copyright', 'quiet-truths'),
                'order'  => 18,
            ],
        ];
    }

    public static function init(): void
    {
        add_action('init', [self::class, 'ensurePages'], 30);
        add_action('wp', [self::class, 'redirectOldPrivacy']);
        add_action('template_redirect', [self::class, 'redirectRetiredDuplicates'], 0);
        add_filter('the_content', [self::class, 'draftBanner'], 1);
        add_filter('document_title_parts', [self::class, 'amendTitle'], 10, 1);
        add_action('admin_notices', [self::class, 'draftIntakeNotice']);
    }

    /** Warn administrators when real intake is open under a draft pack. */
    public static function draftIntakeNotice(): void
    {
        if (!current_user_can('manage_options') || !class_exists(Security::class)
            || !Security::intakeOpen('all')) {
            return;
        }

        echo '<div class="notice notice-warning"><p><strong>'
            . esc_html__('Quiet Truths public intake is open while the governance pack is still a draft.', 'quiet-truths')
            . '</strong> '
            . wp_kses_post(__("Until counsel, provider locations and retention periods are complete, pause publishable submissions by adding <code>define('QT_PUBLIC_INTAKE', false);</code> to <code>wp-config.php</code>. The contact/removal form remains available.", 'quiet-truths'))
            . '</p></div>';
    }

    /**
     * Create (or update content for) the governance pages once per
     * pack version.
     */
    public static function ensurePages(): void
    {
        if (get_option('qt_gov_pack_version') === self::PACK_VERSION) {
            return;
        }

        $created = [];
        foreach (self::pages() as $slug => $meta) {
            $content = self::loadContent((string) ($meta['file'] ?? ''));
            if ('' === $content) {
                continue;
            }
            $parentId = 0;
            if (!empty($meta['parent'])) {
                $parent = get_page_by_path((string) $meta['parent']);
                $parentId = $parent ? (int) $parent->ID : 0;
            }

            $existing = self::findManagedPage($slug, (string) $meta['title'], $parentId, (string) ($meta['parent'] ?? ''));
            $postarr = [
                'post_title'    => (string) $meta['title'],
                'post_name'     => $slug,
                'post_content'  => $content,
                'post_type'     => 'page',
                'post_status'   => 'publish',
                'post_parent'   => $parentId,
                'menu_order'    => (int) ($meta['order'] ?? 0),
                'post_author'   => 0,
                'comment_status' => 'closed',
                'ping_status'   => 'closed',
            ];
            if ($existing instanceof \WP_Post) {
                $postarr['ID'] = $existing->ID;
                wp_update_post($postarr, true);
                $id = $existing->ID;
            } else {
                $id = wp_insert_post($postarr, true);
            }
            if (!is_wp_error($id)) {
                update_post_meta((int) $id, '_qt_governance_page', '1');
                update_post_meta((int) $id, '_qt_governance_slug', $slug);
                update_post_meta((int) $id, '_qt_gov_pack_version', self::PACK_VERSION);
                $created[$slug] = (int) $id;
                self::retireManagedDuplicates($slug, (string) $meta['title'], (int) $id);
            }
        }

        update_option('qt_gov_pack_version', self::PACK_VERSION);
    }

    /**
     * Find the canonical managed page without creating a new `-2` copy.
     */
    private static function findManagedPage(string $slug, string $title, int $parentId, string $parentSlug): ?\WP_Post
    {
        $path  = '' !== $parentSlug ? trailingslashit($parentSlug) . $slug : $slug;
        $exact = get_page_by_path($path, OBJECT, 'page');
        if ($exact instanceof \WP_Post) {
            return $exact;
        }

        $managed = get_posts([
            'post_type'      => 'page',
            'post_status'    => ['publish', 'draft', 'private', 'pending', 'future'],
            'posts_per_page' => 50,
            'orderby'        => 'ID',
            'order'          => 'ASC',
            'meta_query'     => [
                ['key' => '_qt_governance_page', 'value' => '1'],
            ],
        ]);

        foreach ($managed as $page) {
            $knownSlug = (string) get_post_meta($page->ID, '_qt_governance_slug', true);
            $slugLike  = (bool) preg_match('/^' . preg_quote($slug, '/') . '(?:-\d+)?$/', (string) $page->post_name);
            if (($knownSlug === $slug || ('' === $knownSlug && $slugLike && $page->post_title === $title))
                && (int) $page->post_parent === $parentId) {
                return $page;
            }
        }

        return null;
    }

    /**
     * Draft extra pages created by older path lookups and remember their
     * old paths for a permanent redirect. Only theme-managed pages are
     * touched; an unrelated editor-created page is never retired.
     */
    private static function retireManagedDuplicates(string $slug, string $title, int $canonicalId): void
    {
        $pages = get_posts([
            'post_type'      => 'page',
            'post_status'    => ['publish', 'draft', 'private', 'pending', 'future'],
            'posts_per_page' => 100,
            'orderby'        => 'ID',
            'order'          => 'ASC',
            'meta_query'     => [
                ['key' => '_qt_governance_page', 'value' => '1'],
            ],
        ]);
        $canonical = get_permalink($canonicalId);
        $redirects = get_option('qt_governance_redirects', []);
        $redirects = is_array($redirects) ? $redirects : [];

        foreach ($pages as $page) {
            if ((int) $page->ID === $canonicalId) {
                continue;
            }
            $knownSlug = (string) get_post_meta($page->ID, '_qt_governance_slug', true);
            $slugLike  = (bool) preg_match('/^' . preg_quote($slug, '/') . '(?:-\d+)?$/', (string) $page->post_name);
            if ($knownSlug !== $slug && !('' === $knownSlug && $slugLike && $page->post_title === $title)) {
                continue;
            }

            $oldUrl  = get_permalink($page);
            $oldPath = $oldUrl ? untrailingslashit((string) wp_parse_url($oldUrl, PHP_URL_PATH)) : '';
            if ('' !== $oldPath && $canonical) {
                $redirects[$oldPath] = $canonical;
            }
            if ('draft' !== $page->post_status) {
                wp_update_post(['ID' => $page->ID, 'post_status' => 'draft']);
            }
            update_post_meta($page->ID, '_qt_governance_duplicate_of', $canonicalId);
        }

        update_option('qt_governance_redirects', $redirects, false);
    }

    /** Redirect paths retired by the duplicate-page migration. */
    public static function redirectRetiredDuplicates(): void
    {
        if (!is_404()) {
            return;
        }
        $path = untrailingslashit((string) wp_parse_url(
            wp_unslash((string) ($_SERVER['REQUEST_URI'] ?? '')),
            PHP_URL_PATH
        ));
        $redirects = get_option('qt_governance_redirects', []);
        if (is_array($redirects) && !empty($redirects[$path])) {
            wp_safe_redirect((string) $redirects[$path], 301);
            exit;
        }
    }

    /**
     * The legacy /privacy/ URL will 301 to /privacy/ once WordPress
     * picks the new page at that slug — we do not need a redirect.
     * /house-rules/ is now a child of /editorial-policy/ so its URL
     * changes to /editorial-policy/house-rules/; keep the old URL
     * working via a redirect so any bookmarks land on the new page.
     */
    public static function redirectOldPrivacy(): void
    {
        // /house-rules/ as a top-level slug is now a child page; redirect
        // the old URL to the new canonical URL if needed.
        if (is_page('house-rules')) {
            $page = get_queried_object();
            if ($page instanceof \WP_Post && (int) $page->post_parent > 0) {
                $canonical = get_permalink($page);
                if ($canonical && untrailingslashit($_SERVER['REQUEST_URI'] ?? '') === '/house-rules') {
                    wp_safe_redirect($canonical, 301);
                    exit;
                }
            }
        }
    }

    /**
     * Add a DRAFT banner to every governance page. The pack is DRAFT
     * pending Kenyan legal review. The banner is filtered so mwenye
     * nyumba can dismiss it with `add_filter('quiet_truths_show_draft_banner', '__return_false')`
     * once counsel signs off.
     */
    public static function draftBanner(string $content): string
    {
        if (!is_singular('page') || !self::isGovernancePage()) {
            return $content;
        }
        if (!apply_filters('quiet_truths_show_draft_banner', true)) {
            return $content;
        }

        $banner = '<div class="qt-gov-draft" role="note">'
            . '<strong>' . esc_html__('Draft — pending legal review', 'quiet-truths') . '</strong>'
            . '<span>' . esc_html__('These governance documents are shared publicly for transparency while Kenyan legal review is completed. They will be updated — and the banner removed — once counsel signs off on the final version.', 'quiet-truths') . '</span>'
            . '</div>';

        return $banner . $content;
    }

    /**
     * Append "— Quiet Truths" only on governance pages? No — leave the
     * title untouched; WordPress handles page titles correctly. We
     * only inject an html-class hook here.
     *
     * @param array<string,string> $parts
     * @return array<string,string>
     */
    public static function amendTitle(array $parts): array
    {
        return $parts;
    }

    public static function isGovernancePage(int $postId = 0): bool
    {
        if (!$postId) {
            $post = get_queried_object();
            $postId = $post instanceof \WP_Post ? (int) $post->ID : 0;
        }
        return $postId > 0 && (bool) get_post_meta($postId, '_qt_governance_page', true);
    }

    /**
     * The footer links — ordered list, used by the footer nav fallback.
     *
     * @return list<array{slug:string,label:string,url:string}>
     */
    public static function footerLinks(): array
    {
        $links = [];
        foreach (self::pages() as $slug => $meta) {
            // House Rules is a child of Editorial Policy; keep it out of
            // the footer to avoid repeating — the Editorial Policy page
            // links to it.
            if ('house-rules' === $slug) {
                continue;
            }
            $page = get_page_by_path($slug);
            if (!$page instanceof \WP_Post || 'publish' !== $page->post_status) {
                continue;
            }
            $url = get_permalink($page);
            if (!$url) {
                continue;
            }
            $links[] = [
                'slug'  => $slug,
                'label' => (string) $meta['label'],
                'url'   => $url,
            ];
        }
        return $links;
    }

    public static function pageUrl(string $slug): string
    {
        $meta = self::pages()[$slug] ?? [];
        $path = !empty($meta['parent'])
            ? trailingslashit((string) $meta['parent']) . $slug
            : $slug;
        $page = get_page_by_path($path, OBJECT, 'page');
        if (!$page instanceof \WP_Post) {
            return '';
        }
        $url = get_permalink($page);
        return is_string($url) ? $url : '';
    }

    private static function loadContent(string $file): string
    {
        $path = dirname(__DIR__) . '/pages/content/' . basename($file);
        if (!is_file($path)) {
            return '';
        }
        $html = (string) file_get_contents($path);

        // Replace the bracketed placeholders we can fill in today.
        // Remaining placeholders (legal name, host, email provider)
        // stay visible to counsel as [bracketed] text until filled in.
        $replace = [
            '[Effective Date]'    => '8 August 2026',
            '[Last Reviewed Date]' => '8 August 2026',
            '[Privacy Email]'     => '<a href="' . esc_url(home_url('/write-to-quiet-truths/')) . '">the contact form</a>',
            '[Contact Address]'   => 'Nairobi, Kenya (via the contact form)',
        ];
        foreach ($replace as $k => $v) {
            $html = str_replace($k, $v, $html);
        }
        return $html;
    }
}
