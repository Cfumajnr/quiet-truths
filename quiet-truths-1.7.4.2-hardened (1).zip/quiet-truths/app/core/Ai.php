<?php
/**
 * Quiet Truths — AI façade (the quiet librarian)
 *
 * Backwards-compatible front door for the AI subsystem. All the work
 * now lives in app/ai/ (AiKernel + the seven layer modules); this
 * class preserves the public API that the rest of the theme (Search,
 * Concepts, Submission, Rooms, the moderation meta box) already
 * calls into, so nothing else has to change.
 *
 * The four rules remain:
 *   1. AI never writes words a reader sees as content.
 *   2. AI works behind the curtain.
 *   3. Stories never leave the server — loopback only, no third-party APIs.
 *   4. AI flags are always suggestions. A human decides.
 *
 * @package QuietTruths\Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

use QuietTruths\Ai\AiKernel;
use QuietTruths\Ai\Embeddings;
use QuietTruths\Ai\ContentSignals;
use QuietTruths\Ai\PrivacyScanner;
use QuietTruths\Ai\StoryUnderstanding;
use QuietTruths\Ai\ConceptInference;
use QuietTruths\Ai\StoryRelations;
use QuietTruths\Ai\SemanticSearch;
use QuietTruths\Ai\ModerationSignals;
use QuietTruths\Ai\Profile;
use QuietTruths\Ai\BackgroundWorker;

// Load the ai/ layer. require_once is safe on Linux; the autoloader in
// Application.php can also pick these up, but explicit loading keeps
// the boot chain airtight.
//
// v1.7.4 Correction 15: the primary AI bootstrap MUST NOT depend on
// the retired ThemeInference shim. Current code loads and references
// ConceptInference directly. The ThemeInference shim is retained as
// an autoloadable class alias for external/legacy callers only; it
// is no longer required here.
require_once __DIR__ . '/../ai/AiKernel.php';
require_once __DIR__ . '/../ai/Embeddings.php';
require_once __DIR__ . '/../ai/BackgroundWorker.php';
require_once __DIR__ . '/../ai/ContentSignals.php';
require_once __DIR__ . '/../ai/PrivacyScanner.php';
require_once __DIR__ . '/../ai/ConceptInference.php';
require_once __DIR__ . '/../ai/StoryUnderstanding.php';
require_once __DIR__ . '/../ai/Profile.php';
require_once __DIR__ . '/../ai/StoryRelations.php';
require_once __DIR__ . '/../ai/SemanticSearch.php';
require_once __DIR__ . '/../ai/ModerationSignals.php';

// The ThemeInference shim is intentionally NOT required here. It is
// loaded on-demand by the autoloader if any EXTERNAL code still
// references the old class name, at which point it aliases to
// ConceptInference transparently. (v1.7.4 Correction 15.)

final class Ai
{
    /* ──────────────────── boot / feature flag ──────────────────── */

    public static function enabled(): bool
    {
        return AiKernel::enabled();
    }

    public static function init(): void
    {
        if (!self::enabled()) {
            return;
        }
        AiKernel::boot();

        // Hooks that live on the façade itself (rather than a submodule):
        //  * On publish: deepen concept tags and persist PII flags.
        add_action('transition_post_status', [self::class, 'onStoryApproved'], 25, 3);
    }

    /* ──────────────────── identifying detail scan ──────────────────── */

    /**
     * @return list<array{kind:string,match:string,note:string,severity:string}>
     */
    public static function kenyaPiiScan(string $text): array
    {
        $res = PrivacyScanner::scan($text);
        // Normalise to the shape the rest of the theme expects: every
        // flag has kind/match/note; severity is added for callers that
        // want it.
        return array_map(static function (array $f): array {
            return [
                'kind'     => (string) ($f['kind'] ?? 'note'),
                'match'    => (string) ($f['match'] ?? ''),
                'note'     => (string) ($f['note'] ?? ''),
                'severity' => (string) ($f['severity'] ?? 'low'),
            ];
        }, $res['flags']);
    }

    /**
     * Full privacy envelope (flags + risk score + writer warnings).
     * Used by Submission::writerAssistantData to power the gentle
     * "this could identify you" chips on the form.
     *
     * @return array{flags:list<array>,risk_score:float,writer_warnings:list<string>}
     */
    public static function privacyReport(string $text): array
    {
        return PrivacyScanner::scan($text);
    }

    /* ──────────────────── concept detection ────────────────────
     *
     * Historically named expandedThemes() because v1.0 called concepts
     * "themes". That term has been retired (Edit Two of the 1.7.2 memo);
     * concepts are the canonical vocabulary. expandedThemes() is kept
     * as a deprecated alias during transition — canonical callers
     * should use expandedConcepts().
     */

    /**
     * @return list<string>
     * @deprecated Use expandedConcepts() — "theme" is a retired term.
     */
    public static function expandedThemes(string $text): array
    {
        return self::expandedConcepts($text);
    }

    /**
     * Deterministic phrase-level concept hits for a piece of text.
     *
     * @return list<string>
     */
    public static function expandedConcepts(string $text): array
    {
        return ConceptInference::conceptsFromText($text);
    }

    /* ──────────────────── similarity scoring ──────────────────── */

    /**
     * Token vectors (sparse, PHP-only) kept for callers that want a
     * cheap lexical overlap without pulling embeddings.
     *
     * @return array<string,float>
     */
    public static function tokenVector(string $text): array
    {
        return Embeddings::tokenVector($text);
    }

    /**
     * @param array<string,float> $a
     * @param array<string,float> $b
     */
    public static function cosine(array $a, array $b): float
    {
        return Embeddings::vectorSimilarity($a, $b);
    }

    /**
     * Pairwise similarity between two posts. Uses embeddings when the
     * local service is available, PHP token cosine as a floor.
     */
    public static function postSimilarity(int $a, int $b): float
    {
        $va = Embeddings::forPostRead($a);
        $vb = Embeddings::forPostRead($b);
        if (!empty($va) && !empty($vb)) {
            return Embeddings::vectorSimilarity($va, $vb);
        }
        $ap = get_post($a);
        $bp = get_post($b);
        if (!$ap || !$bp) {
            return 0.0;
        }
        return Embeddings::textSimilarity(
            (string) $ap->post_title . ' ' . (string) $ap->post_content,
            (string) $bp->post_title . ' ' . (string) $bp->post_content
        );
    }

    /** Is the local embeddings service reachable and loaded? */
    public static function embeddingsReady(): bool
    {
        return AiKernel::serviceReady();
    }

    /* ──────────────────── search / similar hooks ──────────────────── */

    /**
     * Extra search score. SemanticSearch is wired to the same filter
     * at priority 10 — here we add a small lexical overlap boost so
     * even without the service there is a soft resonance signal.
     */
    public static function searchScore(float $current, int $postId, string $query): float
    {
        $post = get_post($postId);
        if (!$post) {
            return $current;
        }
        $qv = self::tokenVector($query);
        $dv = self::tokenVector((string) $post->post_title . ' ' . (string) $post->post_content);
        $sim = self::cosine($qv, $dv);
        return $current + $sim * 2.0;
    }

    public static function similarScore(float $current, int $a, int $b): float
    {
        return $current + self::postSimilarity($a, $b) * 3.0;
    }

    /* ──────────────────── on publish ──────────────────── */

    public static function onStoryApproved(string $newStatus, string $oldStatus, $post): void
    {
        // Both Stories (lived experience) and Journals (considered depth)
        // belong to the same AI house and are profiled on publish, so
        // Journals participate in shared Concept/Thread/Domain discovery,
        // embeddings and the Story↔Journal bridge (Journal Bible §5, §26).
        if (!$post instanceof \WP_Post || !in_array($post->post_type, ['qt_story', 'qt_journal'], true)) {
            return;
        }
        if ('publish' !== $newStatus && 'pending' !== $newStatus) {
            return;
        }

        // On publish/approve: store version bookkeeping synchronously
        // and request a background rebuild (queueWarm sets
        // _rebuild_pending=true without demoting a FRESH profile to
        // stale — readers keep the last good profile until an atomic
        // replacement lands).
        update_post_meta($post->ID, '_qt_ai_version', QT_THEME_VERSION);
        update_post_meta($post->ID, '_qt_ai_profile_version', Profile::SCHEMA_VERSION);
        Profile::queueWarm($post->ID);
    }

    /* ──────────────────── content warnings ──────────────────── */

    /**
     * Gentle writer-facing content-warning tags for a piece of text.
     *
     * @return list<string>
     */
    public static function contentWarnings(string $text): array
    {
        return ContentSignals::warningsFor($text);
    }

    /**
     * Human-readable labels for the warning chips (writer.js).
     *
     * @return array<string,string>
     */
    public static function warningLabels(): array
    {
        return ContentSignals::warningLabels();
    }

    /* ──────────────────── relations (public) ──────────────────── */

    /**
     * Return typed related stories for a post.
     *
     * @return list<array{id:int,relations:list<string>,score:float,primary:string}>
     */
    public static function relatedStories(int $postId, int $limit = 4): array
    {
        return StoryRelations::relatedTo($postId, $limit);
    }

    /**
     * Human-readable label for a relation kind.
     */
    public static function relationLabel(string $kind): string
    {
        return apply_filters('quiet_truths_relation_label', '', $kind);
    }
}
