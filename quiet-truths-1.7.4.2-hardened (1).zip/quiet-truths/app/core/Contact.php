<?php
/**
 * Quiet Truths — Contact
 *
 * A quiet, theme-native contact form. No plugin. Name and email are
 * required for a reply; the message is delivered to the configured
 * mailbox and retained according to the published Privacy Notice. It is
 * never added to a marketing list.
 *
 * Guards match the house: honeypot, nonce, validation and rate limit.
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Contact
{
    private const NONCE = 'qt_contact';

    /** @var string[] */
    private static array $errors = [];

    /** @var array<string,string> */
    private static array $old = [];

    public static function init(): void
    {
        add_action('template_redirect', [self::class, 'maybeHandle']);
    }

    /* ─────────────── view state ─────────────── */

    /** @return string[] */
    public static function errors(): array
    {
        return self::$errors;
    }

    public static function old(string $key, string $default = ''): string
    {
        return self::$old[$key] ?? $default;
    }

    public static function sent(): bool
    {
        return isset($_GET['qt_contact_sent']);
    }

    /* ─────────────── handling ─────────────── */

    public static function maybeHandle(): void
    {
        if (is_admin() || (defined('REST_REQUEST') && REST_REQUEST)) {
            return;
        }
        if (empty($_POST['qt_contact_submit']) || !isset($_POST['_wpnonce'])) {
            return;
        }

        $back = is_singular()
            ? (get_permalink(get_queried_object_id()) ?: home_url('/write-to-quiet-truths/'))
            : home_url('/write-to-quiet-truths/');
        $back = remove_query_arg(['qt_contact_sent', Flash::QUERY_ARG], $back);

        if (!wp_verify_nonce(sanitize_key(wp_unslash((string) $_POST['_wpnonce'])), self::NONCE)) {
            self::$errors[] = 'session';
            self::redirect($back);
        }

        // Honeypot: bots fill this hidden field.
        if (!empty($_POST['qt_website'])) {
            wp_safe_redirect(add_query_arg('qt_contact_sent', '1', $back));
            exit;
        }

        // Gentle rate limit: a handful of messages per visitor per hour.
        // Incremented BEFORE validation so that garbage submissions
        // cannot hammer wp_mail() indefinitely.
        $key   = Security::rateKey('qt_contact_rate_');
        $count = (int) get_transient($key);
        if ($count >= (int) apply_filters('quiet_truths_contact_rate_limit', 3)) {
            self::$errors[] = 'rate';
            self::redirect($back);
        }
        set_transient($key, $count + 1, HOUR_IN_SECONDS);

        // Contact is the house's front desk — it needs a reply address.
        // Always detailed: name + email required, phone optional.
        $name    = isset($_POST['qt_name']) ? sanitize_text_field(wp_unslash((string) $_POST['qt_name'])) : '';
        $email   = isset($_POST['qt_email']) ? sanitize_email(wp_unslash((string) $_POST['qt_email'])) : '';
        $subject = isset($_POST['qt_subject']) ? sanitize_text_field(wp_unslash((string) $_POST['qt_subject'])) : '';
        $phone   = isset($_POST['qt_phone']) ? sanitize_text_field(wp_unslash((string) $_POST['qt_phone'])) : '';

        self::$old = [
            'name'    => $name,
            'email'   => $email,
            'subject' => $subject,
            'phone'   => $phone,
        ];

        if ('' === trim($name)) {
            self::$errors[] = 'name_req';
        }
        if ('' === $email || !is_email($email)) {
            self::$errors[] = 'email_req';
        }
        if ('' !== $phone && !preg_match('/^[0-9+()\-\s]{6,20}$/', $phone)) {
            self::$errors[] = 'phone';
        }
        if ('' !== $name && (function_exists('mb_strlen') && mb_strlen($name) > 100)) {
            self::$errors[] = 'name';
        }
        if ('' !== $email && (function_exists('mb_strlen') && mb_strlen($email) > 100)) {
            self::$errors[] = 'email';
        }
        if ('' !== $subject && (function_exists('mb_strlen') && mb_strlen($subject) > 150)) {
            self::$errors[] = 'subject';
        }
        if ('' !== $phone && (function_exists('mb_strlen') && mb_strlen($phone) > 20)) {
            self::$errors[] = 'phone';
        }

        $message = isset($_POST['qt_message']) ? sanitize_textarea_field(wp_unslash((string) $_POST['qt_message'])) : '';
        self::$old['message'] = $message;

        if ('' === trim($message)) {
            self::$errors[] = 'empty';
        }
        if (function_exists('mb_strlen') && mb_strlen($message) > 2000) {
            self::$errors[] = 'long';
        }

        // Do not reject safety reports or complaints because they quote
        // difficult language. Contact messages are delivered as plain text.
        if (!empty(self::$errors)) {
            self::redirect($back);
        }

        $to       = get_option('admin_email');
        $subject  = '' !== $subject
            ? sprintf('[%s] %s', get_bloginfo('name'), $subject)
            : sprintf('[%s] %s', get_bloginfo('name'), __('A message from the house door', 'quiet-truths'));

        $body    = sprintf(
            "%s\n\n%s\n\n%s",
            __('Someone wrote through the contact page:', 'quiet-truths'),
            $message,
            __('(Sent with their details.)', 'quiet-truths')
        );

        if ('' !== $name) {
            $body .= "\n\n" . __('Name:', 'quiet-truths') . ' ' . $name;
        }
        if ('' !== $email) {
            $body .= "\n" . __('Email:', 'quiet-truths') . ' ' . $email;
        }
        if ('' !== $phone) {
            $body .= "\n" . __('Phone:', 'quiet-truths') . ' ' . $phone;
        }

        $headers = [];

        if ('' !== $email) {
            $headers[] = 'Reply-To: ' . $name . ' <' . $email . '>';
        }

        if (!wp_mail($to, $subject, $body, $headers)) {
            error_log('Quiet Truths: contact message could not be sent.');
            self::$errors[] = 'store';
            self::redirect($back);
        }

        self::$old = [];
        wp_safe_redirect(add_query_arg('qt_contact_sent', '1', $back));
        exit;
    }

    private static function redirect(string $back): void
    {
        $url = Flash::url($back, 'contact', [
            'errors' => self::$errors,
            'old'    => self::$old,
        ]);

        wp_safe_redirect($url);
        exit;
    }
}
