<?php
/**
 * Quiet Truths — SEO
 *
 * A quiet, complete SEO layer:
 *  - meta descriptions (story excerpt → content, room description, home)
 *  - Open Graph + Twitter cards (so stories share beautifully)
 *  - Schema.org JSON-LD: WebSite + SearchAction, Article, BreadcrumbList
 *  - noindex on search results and 404s (never duplicate content)
 *  - a friendly robots.txt with the sitemap
 *  - self-hosted-font friendly output with no third-party preconnect
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Seo
{
    public static function init(): void
    {
        add_action('wp_head', [self::class, 'maybeNoindex'], 1);
        add_action('wp_head', [self::class, 'metaAndSocial'], 5);
        add_action('wp_head', [self::class, 'schemaJsonLd'], 10);
        add_action('wp_head', [self::class, 'favicons'], 2);
        add_filter('robots_txt', [self::class, 'robotsTxt'], PHP_INT_MAX, 2);
        // Fonts are self-hosted; no third-party resource hints are needed.
        add_filter('wp_robots', [self::class, 'robotsMeta']);
        // Intercept /favicon.ico so it always returns the house key mark,
        // never a stale host default or 404 that browsers refuse to drop.
        add_action('init', [self::class, 'serveFaviconIco'], 1);

        // If a physical robots.txt file exists in the web root, WordPress
        // never fires the robots_txt filter and the wrong sitemap URL
        // ships to crawlers. Detect that on front-end + admin and nudge.
        add_action('admin_init', [self::class, 'checkForPhysicalRobots']);
    }

    /**
     * Warn in admin if a real robots.txt is blocking the dynamic one.
     */
    public static function checkForPhysicalRobots(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        // ABSPATH . robots.txt exists on disk → WordPress short-circuits.
        if (file_exists(ABSPATH . 'robots.txt') && !get_transient('qt_robots_note_dismissed')) {
            add_action('admin_notices', static function (): void {
                echo '<div class="notice notice-warning is-dismissible"><p>'
                    . wp_kses_post(sprintf(
                        /* translators: %s is the server path to a robots.txt file. */
                        __('Quiet Truths found a physical <code>robots.txt</code> at %s. It will override the theme\'s dynamic robots.txt and may point search engines to the wrong sitemap. Please delete it (or update its <code>Sitemap:</code> line to <code>%s</code>).', 'quiet-truths'),
                        esc_html(ABSPATH . 'robots.txt'),
                        esc_url(home_url('/wp-sitemap.xml'))
                    ))
                    . '</p></div>';
            });
        }
    }

    /* ─────────────── noindex ─────────────── */

    public static function maybeNoindex(): void
    {
        // Kept for backward compatibility; the real work is in robotsMeta.
    }

    /**
     * The modern robots meta filter (WP 5.7+). No deprecated calls.
     *
     * @param array<string,bool|string> $robots
     * @return array<string,bool|string>
     */
    public static function robotsMeta(array $robots): array
    {
        // Search results and 404s must never compete with real pages.
        if (is_search() || is_404()) {
            $robots['noindex'] = true;
        }

        // The post-submission confirmation ("your story is being held")
        // is a state, not a page — never index it.
        if (isset($_GET['qt_held'])) {
            $robots['noindex'] = true;
        }

        // Room-filtered views (?qt_room=…) are thin duplicates of the
        // real /room/… pages — never index them.
        if (isset($_GET['qt_room'])) {
            $robots['noindex'] = true;
        }

        // One-time form-state and confirmation URLs are not durable pages.
        if (isset($_GET[Flash::QUERY_ARG]) || isset($_GET['qt_contact_sent'])
            || isset($_GET['qt_journal_submitted']) || isset($_GET['qt_resp'])
            || isset($_GET['qt_jc_held'])) {
            $robots['noindex'] = true;
        }

        return $robots;
    }

    /* ─────────────── favicon ─────────────── */

    /**
     * The house's mark — the key on parchment, not WordPress's.
     *
     * Browsers cache /favicon.ico ferociously and will ignore the <link>
     * tags until their cache expires unless we cache-bust with a version
     * query string. We also serve a real ICO at /favicon.ico via the
     * `faviconIco()` template redirect below, so older Safari/Edge and
     * bookmark shortcuts get the new mark too.
     */
    public static function favicons(): void
    {
        $uri    = get_stylesheet_directory_uri() . '/assets/';
        $v      = defined('QT_THEME_VERSION') ? QT_THEME_VERSION : '1';
        $suffix = '?v=' . rawurlencode($v);

        echo "\n<!-- Quiet Truths favicon -->\n";
        echo '<link rel="icon" type="image/png" sizes="32x32" href="' . esc_url($uri . 'favicon-32.png' . $suffix) . "\">\n";
        echo '<link rel="icon" type="image/png" sizes="16x16" href="' . esc_url($uri . 'favicon-16.png' . $suffix) . "\">\n";
        echo '<link rel="icon" type="image/png" sizes="512x512" href="' . esc_url($uri . 'favicon-512.png' . $suffix) . "\">\n";
        echo '<link rel="apple-touch-icon" sizes="180x180" href="' . esc_url($uri . 'apple-touch-icon.png' . $suffix) . "\">\n";
        // Shortcut icon for older browsers that ignore rel="icon" PNGs
        echo '<link rel="shortcut icon" href="' . esc_url(home_url('/favicon.ico' . $suffix)) . "\">\n";
        // The key brand colour — midnight ink for the browser UI around the parchment
        echo '<meta name="theme-color" content="#1a2c4c">' . "\n";
        echo "<!-- /Quiet Truths favicon -->\n";
    }

    /**
     * Serve a real favicon.ico from the theme assets so requests to
     * /favicon.ico (which browsers and bookmark tools hit regardless of
     * <link> tags) return the new key-on-parchment mark instead of a
     * stale/cached 404 or the host's default icon.
     *
     * Hooked on `init` — if the request is exactly /favicon.ico, serve
     * the PNG (browsers accept image/png for .ico requests just fine)
     * with long-cache headers and exit.
     */
    public static function serveFaviconIco(): void
    {
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $request = isset($_SERVER['REQUEST_URI']) ? wp_parse_url(wp_unslash((string) $_SERVER['REQUEST_URI']), PHP_URL_PATH) : '';

        if ('/favicon.ico' !== $request) {
            return;
        }

        $path = get_stylesheet_directory() . '/assets/favicon-32.png';

        if (!file_exists($path)) {
            // Fall back to a 204 so browsers don't keep retrying.
            self::sendCacheHeaders();
            status_header(204);
            exit;
        }

        self::sendCacheHeaders();
        header('Content-Type: image/png');
        header('Content-Length: ' . (string) filesize($path));
        readfile($path);
        exit;
    }

    /**
     * Shared cache headers for the favicon.ico shim: cache for a week,
     * but always revalidate with the theme version so a new version
     * busts the cache immediately.
     */
    private static function sendCacheHeaders(): void
    {
        $v = defined('QT_THEME_VERSION') ? QT_THEME_VERSION : '1';
        header('Cache-Control: public, max-age=604800');
        header('ETag: "' . md5($v) . '"');
    }

    /* ─────────────── meta + social ─────────────── */

    public static function metaAndSocial(): void
    {
        if (is_admin()) {
            return;
        }

        $description = self::description();
        $title       = wp_get_document_title();
        $url         = self::canonicalUrl();
        $image       = self::imageUrl();
        $type        = (is_singular(['qt_story', 'qt_journal', 'post', 'page'])) ? 'article' : 'website';
        $locale      = str_replace('_', '-', (string) get_locale());

        echo "\n<!-- Quiet Truths SEO -->\n";

        // Canonical URL — so ?qt_sort=… and other query params do not
        // create duplicate-content signals.
        echo '<link rel="canonical" href="' . esc_url($url) . "\">\n";

        if ('' !== $description) {
            echo '<meta name="description" content="' . esc_attr($description) . "\">\n";
        }

        // Open Graph
        echo '<meta property="og:type" content="' . esc_attr($type) . "\">\n";
        echo '<meta property="og:site_name" content="' . esc_attr(get_bloginfo('name')) . "\">\n";
        echo '<meta property="og:title" content="' . esc_attr($title) . "\">\n";
        if ('' !== $description) {
            echo '<meta property="og:description" content="' . esc_attr($description) . "\">\n";
        }
        echo '<meta property="og:url" content="' . esc_url($url) . "\">\n";
        if ('' !== $image) {
            echo '<meta property="og:image" content="' . esc_url($image) . "\">\n";
            // Only hard-code 1200×630 for the house's default share
            // image; real featured images supply their own dimensions.
            if ($image === (string) apply_filters('quiet_truths_og_image', get_stylesheet_directory_uri() . '/assets/og-default.png')) {
                echo '<meta property="og:image:width" content="1200">' . "\n";
                echo '<meta property="og:image:height" content="630">' . "\n";
            }
        }
        echo '<meta property="og:locale" content="' . esc_attr($locale) . "\">\n";

        // Twitter
        echo '<meta name="twitter:card" content="' . ('' !== $image ? 'summary_large_image' : 'summary') . "\">\n";
        echo '<meta name="twitter:title" content="' . esc_attr($title) . "\">\n";
        if ('' !== $description) {
            echo '<meta name="twitter:description" content="' . esc_attr($description) . "\">\n";
        }
        if ('' !== $image) {
            echo '<meta name="twitter:image" content="' . esc_url($image) . "\">\n";
        }

        echo "<!-- /Quiet Truths SEO -->\n";
    }

    /* ─────────────── description ─────────────── */

    private static function description(): string
    {
        // Home: the house's promise.
        if (is_front_page()) {
            return (string) apply_filters(
                'quiet_truths_meta_description_home',
                'The website whispers, so stories can be heard. Anonymous human experiences, preserved with dignity.'
            );
        }

        // A story, a post, or a page.
        if (is_singular()) {
            $post = get_queried_object();

            if ($post instanceof \WP_Post) {
                // 1. A deliberately written search description wins. This
                //    is what lets SEO scale: an editor can give each piece
                //    a keyword-rich, self-contained snippet instead of a
                //    raw slice of content. Blank → fall through.
                $manual = (string) get_post_meta($post->ID, '_qt_meta_description', true);
                if ('' !== trim($manual)) {
                    return self::trimTo($manual, 160);
                }

                // 2. Otherwise use the post excerpt if one is set.
                $text = (string) $post->post_excerpt;

                if ('' === trim($text)) {
                    // 3. Last resort: the opening content. Render
                    //    blocks/shortcodes then strip, so excerpts never
                    //    leak raw [shortcode] tags into meta tags.
                    $text = wp_strip_all_tags(strip_shortcodes((string) $post->post_content));
                }

                return self::trimTo($text, 160);
            }
        }

        // A room.
        if (is_tax('qt_room')) {
            $term = get_queried_object();

            if ($term instanceof \WP_Term) {
                $text = (string) $term->description;

                return self::trimTo($text, 160);
            }
        }

        if (is_post_type_archive('qt_story')) {
            return 'Anonymous human experiences, reviewed with care and gathered across the seven rooms of Quiet Truths.';
        }

        if (is_post_type_archive('qt_journal')) {
            return 'Considered long-form writing from named voices, held for editorial review before publication.';
        }

        return '';
    }

    private static function canonicalUrl(): string
    {
        $url = home_url('/');

        if (is_front_page()) {
            $url = home_url('/');
        } elseif (is_singular()) {
            $object = get_queried_object();
            if ($object instanceof \WP_Post) {
                $url = get_permalink($object) ?: $url;
            }
        } elseif (is_tax()) {
            $term = get_queried_object();
            if ($term instanceof \WP_Term) {
                $link = get_term_link($term);
                if (!is_wp_error($link)) {
                    $url = $link;
                }
            }
        } elseif (is_post_type_archive()) {
            $object = get_queried_object();
            $type   = $object instanceof \WP_Post_Type
                ? $object->name
                : get_query_var('post_type');
            if (is_array($type)) {
                $type = reset($type);
            }
            $archive = is_string($type) ? get_post_type_archive_link($type) : false;
            if ($archive) {
                $url = $archive;
            }
        } elseif (is_search()) {
            $url = add_query_arg('s', get_search_query(false), home_url('/'));
            $searchPage = class_exists(Search::class) ? Search::pageNumber() : 1;
            if ($searchPage > 1) {
                $url = add_query_arg('qt_page', $searchPage, $url);
            }
        } elseif (is_home()) {
            $pageForPosts = (int) get_option('page_for_posts');
            $url = $pageForPosts > 0 ? (get_permalink($pageForPosts) ?: $url) : $url;
        }

        // Archive/term pagination must canonicalise to itself, never to
        // the first post in the loop.
        $paged = max(1, (int) get_query_var('paged'));
        if ($paged > 1 && !is_search() && !is_singular()) {
            $url = get_pagenum_link($paged, false);
        }

        return (string) $url;
    }

    /**
     * The share image: the story's featured image if it has one, else
     * the house's default (assets/og-default.png).
     */
    private static function imageUrl(): string
    {
        if (is_singular()) {
            $post = get_queried_object();

            if ($post instanceof \WP_Post && has_post_thumbnail($post)) {
                $image = wp_get_attachment_image_url(get_post_thumbnail_id($post), 'large');

                if ($image) {
                    return $image;
                }
            }
        }

        $default = get_stylesheet_directory_uri() . '/assets/og-default.png';

        return (string) apply_filters('quiet_truths_og_image', $default);
    }

    private static function trimTo(string $text, int $length): string
    {
        $text = trim((string) preg_replace('/\s+/u', ' ', $text));

        if (function_exists('mb_substr')) {
            if (mb_strlen($text) <= $length) {
                return $text;
            }

            return rtrim(mb_substr($text, 0, $length - 1)) . '…';
        }

        if (strlen($text) <= $length) {
            return $text;
        }

        return rtrim(substr($text, 0, $length - 1)) . '…';
    }

    /* ─────────────── schema.org ─────────────── */

    public static function schemaJsonLd(): void
    {
        if (is_admin()) {
            return;
        }

        $schemas = [];

        // WebSite + SearchAction (home).
        if (is_front_page()) {
            $schemas[] = [
                '@context'    => 'https://schema.org',
                '@type'       => 'WebSite',
                'name'        => get_bloginfo('name'),
                'url'         => home_url('/'),
                'description' => (string) apply_filters('quiet_truths_meta_description_home', 'The website whispers, so stories can be heard.'),
                'potentialAction' => [
                    '@type'       => 'SearchAction',
                    'target'      => [
                        '@type'       => 'EntryPoint',
                        'urlTemplate' => home_url('/?s={search_term_string}'),
                    ],
                    'query-input' => 'required name=search_term_string',
                ],
            ];
        }

        // Article (stories, posts, journals).
        if (is_singular(['qt_story', 'post', 'qt_journal'])) {
            $post = get_queried_object();

            if ($post instanceof \WP_Post) {
                // Journals are signed; stories are anonymous — the house
                // is the author of anonymous ones.
                $authorType = 'Organization';
                $authorName = get_bloginfo('name');

                if ('qt_journal' === $post->post_type && function_exists('qt_journal_byline')) {
                    $byline = qt_journal_byline($post);

                    if ('' !== $byline['name']) {
                        $authorType = 'Person';
                        $authorName = $byline['name'];
                    }
                }

                $article = [
                    '@context'      => 'https://schema.org',
                    '@type'         => 'Article',
                    'headline'      => (string) $post->post_title,
                    'datePublished' => get_the_date('c', $post),
                    'dateModified'  => get_the_modified_date('c', $post),
                    'mainEntityOfPage' => get_permalink($post),
                    'author'        => [
                        '@type' => $authorType,
                        'name'  => $authorName,
                        'url'   => home_url('/'),
                    ],
                    'publisher'     => [
                        '@type' => 'Organization',
                        'name'  => get_bloginfo('name'),
                        'url'   => home_url('/'),
                    ],
                ];

                // Prefer the deliberately written search description, then
                // the excerpt, then the opening content — matching the
                // meta-description hierarchy.
                $excerpt = wp_strip_all_tags(strip_shortcodes((string) get_post_meta($post->ID, '_qt_meta_description', true)));
                if ('' === trim($excerpt)) {
                    $excerpt = wp_strip_all_tags(strip_shortcodes((string) $post->post_excerpt));
                }
                if ('' === trim($excerpt)) {
                    $excerpt = self::trimTo(wp_strip_all_tags(strip_shortcodes((string) $post->post_content)), 200);
                }
                if ('' !== $excerpt) {
                    $article['description'] = $excerpt;
                }

                $image = self::imageUrl();
                if ('' !== $image) {
                    $article['image'] = $image;
                }

                $schemas[] = $article;

                // Breadcrumbs: Home > Room (if any) > Story.
                $crumbs = [
                    ['name' => 'Home', 'url' => home_url('/')],
                ];

                $room = (function () use ($post) {
                    $terms = get_the_terms($post->ID, 'qt_room');
                    return (!is_wp_error($terms) && !empty($terms)) ? $terms[0] : null;
                })();

                if ($room instanceof \WP_Term) {
                    $link = get_term_link($room);
                    if (!is_wp_error($link)) {
                        $crumbs[] = ['name' => $room->name, 'url' => $link];
                    }
                }

                $crumbs[] = ['name' => (string) $post->post_title, 'url' => get_permalink($post)];
                $schemas[] = self::breadcrumbs($crumbs);
            }
        }

        // Room archive breadcrumbs.
        if (is_tax('qt_room')) {
            $term = get_queried_object();

            if ($term instanceof \WP_Term) {
                $link = get_term_link($term);

                $schemas[] = self::breadcrumbs([
                    ['name' => 'Home', 'url' => home_url('/')],
                    ['name' => $term->name, 'url' => is_wp_error($link) ? home_url('/') : $link],
                ]);
            }
        }

        if (empty($schemas)) {
            return;
        }

        echo "\n<!-- Quiet Truths Schema -->\n";

        foreach ($schemas as $schema) {
            echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "</script>\n";
        }

        echo "<!-- /Quiet Truths Schema -->\n";
    }

    /**
     * @param list<array{name:string,url:string}> $items
     * @return array<string,mixed>
     */
    private static function breadcrumbs(array $items): array
    {
        $list = [];

        foreach ($items as $i => $item) {
            $list[] = [
                '@type'    => 'ListItem',
                'position' => $i + 1,
                'name'     => $item['name'],
                'item'     => $item['url'],
            ];
        }

        return [
            '@context'        => 'https://schema.org',
            '@type'           => 'BreadcrumbList',
            'itemListElement' => $list,
        ];
    }

    /* ─────────────── robots.txt ─────────────── */

    public static function robotsTxt(string $output, bool $public): string
    {
        if (!$public) {
            return $output;
        }

        $lines = [
            '# Quiet Truths',
            'User-agent: *',
            'Allow: /',
            'Disallow: /wp-admin/',
            'Disallow: /wp-includes/',
            'Disallow: /wp-login.php',
            'Disallow: /xmlrpc.php',
            '',
            'Sitemap: ' . home_url('/wp-sitemap.xml'),
        ];

        return implode("\n", $lines) . "\n";
    }

    /* ─────────────── resource hints ─────────────── */

    /**
     * @param list<string> $urls
     * @param string       $relation
     * @return list<string>
     */
    public static function resourceHints(array $urls, string $relation): array
    {
        // Kept as a compatibility method for older snippets. Fonts are
        // bundled locally, so no external origin is added.
        return $urls;
    }
}
