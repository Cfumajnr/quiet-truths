<?php
/**
 * Quiet Truths — Security
 *
 * The house's own security layer — no plugin needed:
 *
 *  - security headers (nosniff, framing, referrer, permissions, CSP)
 *  - HSTS (only over HTTPS)
 *  - hides the WordPress version (html + feeds)
 *  - disables XML-RPC
 *  - generic login errors (no username enumeration)
 *  - login rate limiting per IP (brute-force guard)
 *  - blocks author-archive enumeration
 *
 * Everything can be disabled by defining a constant:
 *   define('QT_SECURITY_HEADERS', false);   // no headers
 *   define('QT_SECURITY_LOGIN', false);     // no login hardening
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Security
{
    private const LOCKOUT_ATTEMPTS = 5;
    private const LOCKOUT_SECONDS  = 15 * MINUTE_IN_SECONDS;

    public static function init(): void
    {
        // Defence in depth. The production web server must still perform
        // the HTTP→HTTPS redirect before PHP; this protects installations
        // where that rule is accidentally omitted.
        add_action('template_redirect', [self::class, 'forceHttps'], -100);
        add_action('template_redirect', [self::class, 'disableInteractiveCaching'], -90);
        add_action('init', [self::class, 'serveSecurityTxt'], 0);

        if (!defined('QT_SECURITY_HEADERS') || QT_SECURITY_HEADERS) {
            add_action('send_headers', [self::class, 'headers']);
        }

        if (!defined('QT_SECURITY_LOGIN') || QT_SECURITY_LOGIN) {
            self::loginHardening();
        }

        remove_action('wp_head', 'wp_generator');
        add_filter('the_generator', '__return_empty_string');

        // Stories are anonymous. WordPress core still exposes an
        // `author` field on /wp-json/wp/v2/qt_story and in oEmbed
        // output unless we explicitly strip it. We do not want the
        // WP user who approved/created a story to ever be named as
        // its author publicly.
        add_filter('oembed_response_data', [self::class, 'stripOembedAuthor'], 99);
        add_filter('rest_post_dispatch', [self::class, 'stripRestAuthor'], 99);
        // In feeds, override the author to the site.
        add_filter('the_author', [self::class, 'anonymousAuthor'], 99);
        add_filter('get_the_author_display_name', [self::class, 'anonymousAuthorName'], 99, 3);
    }

    /**
     * Anonymous stories should never expose a named author in oEmbed.
     *
     * @param array<string,mixed> $data
     * @return array<string,mixed>
     */
    public static function stripOembedAuthor(array $data): array
    {
        if (!empty($data['type']) && 'rich' !== $data['type']) {
            // only touch rich/html-wrapping embeds; leave others alone.
        }
        $postId = (int) ($data['post_id'] ?? 0);
        if ($postId > 0 && 'qt_story' === get_post_type($postId)) {
            unset($data['author_name'], $data['author_url']);
        }
        return $data;
    }

    /**
     * Strip author from REST responses for qt_story.
     *
     * @param \WP_REST_Response|\WP_HTTP_Response|mixed $result
     * @return mixed
     */
    public static function stripRestAuthor($result)
    {
        if (!is_object($result) || !method_exists($result, 'get_data')) {
            return $result;
        }
        $data = $result->get_data();
        if (!is_array($data)) {
            return $result;
        }
        // Single story envelope.
        if (isset($data['type']) && 'qt_story' === $data['type']) {
            unset($data['author']);
            if (method_exists($result, 'set_data')) {
                $result->set_data($data);
            }
            if (method_exists($result, 'remove_link')) {
                try {
                    $links = $result->get_links();
                    if (isset($links['author'])) {
                        $result->remove_link('author');
                    }
                } catch (\Throwable $e) {
                    // not worth failing a response for.
                }
            }
            return $result;
        }
        // Collection of stories: strip author from each embedded item.
        if (isset($data[0]) && is_array($data[0])) {
            $changed = false;
            foreach ($data as $i => $item) {
                if (is_array($item) && isset($item['type']) && 'qt_story' === $item['type']) {
                    unset($data[$i]['author']);
                    $changed = true;
                }
            }
            if ($changed && method_exists($result, 'set_data')) {
                $result->set_data($data);
            }
        }
        return $result;
    }

    /**
     * When WP renders an "author" for a story (e.g. feeds), use the
     * house name instead of a user.
     */
    public static function anonymousAuthor(string $display): string
    {
        if (is_singular('qt_story') || is_post_type_archive('qt_story') || is_singular('qt_response')) {
            return (string) get_bloginfo('name');
        }
        return $display;
    }

    public static function anonymousAuthorName(string $name, int $userId, int $postId): string
    {
        if ($postId > 0 && 'qt_story' === get_post_type($postId)) {
            return (string) get_bloginfo('name');
        }
        return $name;
    }

    /* ─────────────── headers ─────────────── */

    public static function headers(): void
    {
        if (headers_sent()) {
            return;
        }

        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(), usb=(), browsing-topics=()');

        // HSTS only makes sense over HTTPS.
        if (is_ssl()) {
            header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        }

        header("Content-Security-Policy: default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline'; font-src 'self' data:; script-src 'self' 'unsafe-inline'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'self'; form-action 'self'; upgrade-insecure-requests; block-all-mixed-content");
    }

    /** Serve the RFC 9116 responsible-disclosure contact file. */
    public static function serveSecurityTxt(): void
    {
        $path = (string) wp_parse_url(
            wp_unslash((string) ($_SERVER['REQUEST_URI'] ?? '')),
            PHP_URL_PATH
        );
        if ('/.well-known/security.txt' !== $path) {
            return;
        }

        $contact = home_url('/write-to-quiet-truths/');
        $lines   = [
            'Contact: ' . $contact,
            'Expires: ' . gmdate('Y-m-d\TH:i:s\Z', time() + YEAR_IN_SECONDS),
            'Preferred-Languages: en, sw',
            'Canonical: ' . home_url('/.well-known/security.txt'),
            'Policy: ' . home_url('/complaints-removals/'),
        ];

        status_header(200);
        header('Content-Type: text/plain; charset=UTF-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: public, max-age=86400');
        echo implode("\n", $lines) . "\n";
        exit;
    }

    /**
     * Redirect an accidental clear-text public request to the configured
     * HTTPS origin. A 308 preserves the method/body, unlike a 301/302 POST.
     * Configure the equivalent rule in Apache/LiteSpeed/nginx as the real
     * enforcement point so sensitive request bodies never reach PHP over
     * clear text.
     */
    public static function forceHttps(): void
    {
        if (is_ssl() || 'https' !== wp_parse_url(home_url('/'), PHP_URL_SCHEME)) {
            return;
        }

        // Only honour proxy headers when the operator explicitly states
        // that a trusted TLS-terminating proxy overwrites them.
        if (defined('QT_TRUST_PROXY_HTTPS') && QT_TRUST_PROXY_HTTPS) {
            $forwarded = (string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '');
            $proto = strtolower(trim(explode(',', $forwarded)[0]));
            if ('https' === $proto) {
                return;
            }
        }

        $home    = wp_parse_url(home_url('/'));
        $request = wp_parse_url(wp_unslash((string) ($_SERVER['REQUEST_URI'] ?? '/')));
        $host    = (string) ($home['host'] ?? '');

        if ('' === $host) {
            return;
        }

        $target = 'https://' . $host;
        if (!empty($home['port'])) {
            $target .= ':' . (int) $home['port'];
        }
        $target .= (string) ($request['path'] ?? '/');
        if (!empty($request['query'])) {
            $target .= '?' . (string) $request['query'];
        }

        wp_safe_redirect($target, 308, 'Quiet Truths HTTPS');
        exit;
    }

    /**
     * Public forms contain expiring WordPress nonces and may redisplay
     * personal draft text after a validation error. They must never be
     * placed in LiteSpeed/page caches.
     */
    public static function disableInteractiveCaching(): void
    {
        $interactive = is_page(['leave-a-story', 'write-to-quiet-truths', 'submit-a-journal'])
            || is_singular(['qt_story', 'qt_journal'])
            || isset($_GET[Flash::QUERY_ARG]);

        if (!$interactive) {
            return;
        }

        if (!defined('DONOTCACHEPAGE')) {
            define('DONOTCACHEPAGE', true);
        }
        nocache_headers();
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
    }

    /**
     * Operational kill switch for content intake. Keep contact/removal
     * routes available while pausing new publishable material.
     *
     * In wp-config.php: define('QT_PUBLIC_INTAKE', false);
     */
    public static function intakeOpen(string $channel = 'all'): bool
    {
        if (defined('QT_PUBLIC_INTAKE')) {
            $open = (bool) QT_PUBLIC_INTAKE;
        } else {
            // Secure default: a governance pack explicitly marked draft
            // cannot silently collect sensitive public submissions.
            $draft = class_exists(Governance::class)
                && str_contains(strtolower((string) Governance::PACK_VERSION), 'draft');
            $open = !$draft;
        }

        return (bool) apply_filters('quiet_truths_public_intake_open', $open, $channel);
    }

    /* ─────────────── XML-RPC ─────────────── */

    public static function xmlRpc(bool $enabled): bool
    {
        return false;
    }

    /* ─────────────── login hardening ─────────────── */

    private static function loginHardening(): void
    {
        add_filter('xmlrpc_enabled', [self::class, 'xmlRpc']);
        add_filter('login_errors', [self::class, 'genericError']);
        // Run after normal authentication and override even a correct credential while locked.
        add_filter('authenticate', [self::class, 'checkLock'], 99, 3);
        add_action('wp_login_failed', [self::class, 'recordFailure']);
        add_action('template_redirect', [self::class, 'blockAuthorEnumeration']);
    }

    public static function genericError(): string
    {
        return __('Incorrect details.', 'quiet-truths');
    }

    /**
     * @return \WP_Error|\WP_User|null
     */
    public static function checkLock($user, string $username, string $password)
    {
        if (self::isLocked()) {
            return new \WP_Error(
                'qt_locked',
                __('Too many attempts. The house is resting — please try again in a few minutes.', 'quiet-truths')
            );
        }

        return $user;
    }

    public static function recordFailure(string $username): void
    {
        $key = self::rateKey('qt_login_');

        $count = (int) get_transient($key);
        $count++;

        if ($count >= self::LOCKOUT_ATTEMPTS) {
            set_transient($key, $count, self::LOCKOUT_SECONDS);
            return;
        }

        set_transient($key, $count, self::LOCKOUT_SECONDS);
    }

    private static function isLocked(): bool
    {
        $key   = self::rateKey('qt_login_');
        $count = (int) get_transient($key);

        return $count >= self::LOCKOUT_ATTEMPTS;
    }

    /**
     * A keyed, non-reversible transient key for rate limiting. The raw
     * address is not placed in WordPress options/transients.
     */
    public static function rateKey(string $prefix): string
    {
        return sanitize_key($prefix) . hash_hmac('sha256', self::ip(), (string) wp_salt('nonce'));
    }

    /**
     * The visitor's address, as seen by the server. Used only for the
     * short-lived login lockout — never stored with any content.
     */
    private static function ip(): string
    {
        if (!empty($_SERVER['REMOTE_ADDR'])) {
            return sanitize_text_field(wp_unslash((string) $_SERVER['REMOTE_ADDR']));
        }

        return '';
    }

    /* ─────────────── author enumeration ─────────────── */

    public static function blockAuthorEnumeration(): void
    {
        if (is_admin()) {
            return;
        }

        // /author/name/ and ?author=1 both land here.
        if (is_author()) {
            wp_safe_redirect(home_url('/'));
            exit;
        }
    }
}
