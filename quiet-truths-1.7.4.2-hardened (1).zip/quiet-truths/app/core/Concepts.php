<?php
/**
 * Quiet Truths — Concepts
 *
 * The invisible layer beneath the rooms. Every story is quietly tagged
 * with the concepts it is really about (religion, relationships,
 * separation, grief…) — the user never sees these as navigation.
 *
 * The tags power:
 *  - semantic search across rooms ("muslim" → stories about religion)
 *  - related-story links between stories in different rooms
 *  - room suggestions while a story is being written
 *
 * Privacy: the tags are derived from the story's own words and stored
 * only as slugs on the story. No personal data is involved.
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Concepts
{
    /** @var array<string,mixed>|null */
    private static ?array $data = null;

    public static function init(): void
    {
        add_action('save_post_qt_story', [self::class, 'onStorySave'], 20, 2);
        add_action('save_post_qt_journal', [self::class, 'onStorySave'], 20, 2);
        add_action('init', [self::class, 'maybeBackfill']);
    }

    /* ─────────────── knowledge base ─────────────── */

    /**
     * @return array{concepts:array<string,array{name:string,words:list<string>}>,rooms:array<string,list<string>>}
     */
    public static function data(): array
    {
        if (null === self::$data) {
            $path = dirname(__DIR__) . '/config/concepts.php';

            if (is_file($path)) {
                $loaded = require $path;
                self::$data = is_array($loaded) ? $loaded : [];
            } else {
                self::$data = [];
            }
        }

        return self::$data;
    }

    /** @return array<string,array{name:string,words:list<string>}> */
    public static function concepts(): array
    {
        $data = self::data();

        return (array) ($data['concepts'] ?? []);
    }

    /**
     * Room → concept-slug list for the writer-facing live-suggestion UI.
     * Reads from the CANONICAL room definitions (app/config/rooms.php via
     * Config) so the UI inherits updates to the room ontology without
     * maintaining a parallel map.
     *
     * @return array<string,list<string>>
     */
    public static function roomAffinity(): array
    {
        $out = [];
        foreach (Config::instance()->roomSpecs() as $slug => $spec) {
            if (!is_array($spec)) continue;
            $out[(string) $slug] = array_values(array_filter(
                array_map('strval', (array) ($spec['concepts'] ?? []))
            ));
        }
        return $out;
    }

    /**
     * Extract the human-assigned room slug from an AI profile. Understands
     * both the new v5 shape (rooms.assigned) and the older flat array
     * (rooms = [slugs]) so consumers never have to branch.
     */
    public static function assignedRoomFromProfile(array $profile): ?string
    {
        $rooms = $profile['rooms'] ?? [];
        if (is_array($rooms) && isset($rooms['assigned'])) {
            return $rooms['assigned'] ?: null;
        }
        if (is_array($rooms) && !empty($rooms)) {
            // Older flat-list shape — return the first slug.
            foreach ($rooms as $r) {
                if (is_string($r) && '' !== $r) {
                    return $r;
                }
            }
        }
        return null;
    }

    /**
     * Return all room slugs that a story has meaningful resonance with:
     * the assigned room + any secondary AI resonances.
     *
     * @return list<string>
     */
    public static function resonantRoomsFromProfile(array $profile): array
    {
        $out = [];
        $rooms = $profile['rooms'] ?? [];
        if (is_array($rooms)) {
            if (!empty($rooms['assigned'])) {
                $out[] = (string) $rooms['assigned'];
            }
            foreach ((array) ($rooms['secondary'] ?? []) as $sec) {
                if (is_array($sec) && !empty($sec['slug'])) {
                    $out[] = (string) $sec['slug'];
                }
            }
        } elseif (is_array($rooms)) {
            foreach ($rooms as $r) {
                if (is_string($r) && '' !== $r) $out[] = $r;
            }
        }
        return array_values(array_unique(array_filter($out)));
    }

    /**
     * word → [concept slugs] — built once from the knowledge base.
     * Includes Swahili stem variants (prefix-stripped) so conjugated
     * verbs like "anafanikiwa" or "nimejificha" still find their
     * concepts.
     *
     * @return array<string,list<string>>
     */
    public static function wordMap(): array
    {
        static $map = null;

        if (null === $map) {
            $map = [];

            foreach (self::concepts() as $slug => $concept) {
                foreach ((array) ($concept['words'] ?? []) as $word) {
                    $word = mb_strtolower(trim((string) $word), 'UTF-8');

                    if ('' === $word) {
                        continue;
                    }

                    $map[$word][] = $slug;

                    // Swahili/Sheng: also index the prefix-stripped stem,
                    // so conjugated forms match (kufanikiwa → fanikiwa).
                    $stem = self::swahiliStem($word);
                    if ('' !== $stem && $stem !== $word) {
                        $map[$stem][] = $slug;
                    }
                }
            }
        }

        return $map;
    }

    /**
     * Common Swahili verbal/nominal prefixes, longest first.
     */
    private static function swahiliPrefixes(): array
    {
        return [
            'kujik', 'kuji', 'kuku', 'kuna', 'wana', 'wame', 'nime', 'ume', 'ame',
            'tuna', 'tume', 'mna', 'nina', 'ana', 'una', 'ina', 'zina', 'kina',
            'kuwa', 'kuto', 'kupa', 'kuam', 'kuji',
            'ku', 'ki', 'vi', 'ma', 'mi', 'mu', 'ji', 'zi', 'ya', 'za',
            'wa', 'ni', 'u', 'a', 'i', 'na', 'me', 'ta', 'li', 'si', 'ha', 'n', 'm',
        ];
    }

    /**
     * Strip the longest Swahili prefix from a word, leaving ≥3 chars.
     */
    private static function swahiliStem(string $word): string
    {
        foreach (self::swahiliPrefixes() as $prefix) {
            if (strlen($prefix) < 3) {
                continue; // single/double-letter prefixes are too risky
            }

            if (str_starts_with($word, $prefix) && strlen($word) - strlen($prefix) >= 3) {
                return substr($word, strlen($prefix));
            }
        }

        return $word;
    }

    /* ─────────────── detection & tagging ─────────────── */

    /**
     * Which concepts a text is about. A concept counts when at least
     * two of its words appear (after normalisation); multi-word
     * phrases (e.g. "sukuma wiki", "let go") match directly.
     *
     * @return list<string>
     */
    public static function detect(string $text, int $limit = 4): array
    {
        $normal = Responses::normalise($text);
        $tokens = preg_split('/[^a-z]+/u', $normal) ?: [];
        $tokens = array_filter($tokens, static fn (string $w) => strlen($w) >= 3);

        $scores = [];

        foreach (array_unique($tokens) as $token) {
            // Exact match first, then the Swahili prefix-stripped stem.
            foreach (self::wordMap()[$token] ?? [] as $slug) {
                $scores[$slug] = ($scores[$slug] ?? 0) + 1;
            }

            $stem = self::swahiliStem($token);
            if ($stem !== $token) {
                foreach (self::wordMap()[$stem] ?? [] as $slug) {
                    $scores[$slug] = ($scores[$slug] ?? 0) + 1;
                }
            }
        }

        // Multi-word entries match as whole phrases.
        foreach (self::concepts() as $slug => $concept) {
            foreach ((array) ($concept['words'] ?? []) as $word) {
                $word = mb_strtolower(trim((string) $word), 'UTF-8');

                if ('' === $word || !str_contains($word, ' ')) {
                    continue;
                }
                if (str_contains($normal, $word)) {
                    $scores[$slug] = ($scores[$slug] ?? 0) + 2;
                }
            }
        }

        arsort($scores);

        $out = [];
        foreach ($scores as $slug => $count) {
            if ($count >= 2) {
                $out[] = $slug;
            }
            if (count($out) >= $limit) {
                break;
            }
        }

        // Allow AI layer (or any future module) to deepen concept
        // detection with phrase/embedding signals.
        $out = array_values(array_unique(apply_filters(
            'quiet_truths_detected_concepts',
            $out,
            $text
        )));

        return array_slice($out, 0, $limit);
    }

    /**
     * Tag a story with its concepts (canonical path).
     *
     * Writes ONLY to `_qt_concepts` as a list of {slug, score} entries
     * (score 1.0 for deterministic phrase hits, matching Profile::build()).
     * The legacy `_qt_themes` key is never written by this or any other
     * current AI process (v1.7.3 Clauses 7–9).
     */
    public static function tagStory(int $postId): void
    {
        $post = get_post($postId);

        if (!$post) {
            return;
        }

        $text  = (string) $post->post_title . ' ' . (string) $post->post_content;
        $slugs = self::detect($text);

        // Canonical storage: list of {slug, score} entries. Score is 1.0
        // for deterministic phrase hits, matching how build() records
        // phrase-backed concepts.
        $canonical = [];
        foreach ($slugs as $slug) {
            $canonical[] = ['slug' => (string) $slug, 'score' => 1.0];
        }
        update_post_meta($postId, '_qt_concepts', $canonical);
    }

    /**
     * Stories like this one — across rooms, through the invisible layer.
     * Shared concepts weigh most; the same room and word echoes count
     * less. Rooms never limit what is "next" — same-room is a weak hint,
     * not a hard filter (Correction Twenty-Three: room affinity is
     * secondary to concept/thread/semantic relevance).
     *
     * Scoring (canonical vocabulary):
     *   shared concepts      → +6 each   (primary)
     *   same-room hint       → +2        (weak, non-exclusive)
     *   lexical echoes       → +1 each   (supporting, capped 0.40)
     *   semantic resonance   → AI filter boost (quiet_truths_similar_extra_score)
     *
     * @return list<\WP_Post>
     */
    public static function similarStories(int $postId, int $limit = 3): array
    {
        $post = get_post($postId);

        if (!$post) {
            return [];
        }

        $concepts = self::conceptsOf($postId);
        $keywords = self::topWords((string) $post->post_content, 10);

        $roomTerm = wp_get_object_terms($postId, 'qt_room', ['fields' => 'slugs']);
        $roomSlug = (!is_wp_error($roomTerm) && !empty($roomTerm)) ? (string) $roomTerm[0] : '';

        $pool = new \WP_Query([
            'post_type'      => 'qt_story',
            'post_status'    => 'publish',
            'posts_per_page' => 300,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ]);

        $scored = [];

        foreach ($pool->posts as $id) {
            $id = (int) $id;

            if ($id === $postId) {
                continue;
            }

            $candidate = get_post($id);

            if (!$candidate) {
                continue;
            }

            $score = 0;

            // Layer 3 (concepts): the invisible layer — shared concepts
            // connect rooms. Concepts are the primary signal here.
            $otherConcepts = self::conceptsOf($id);
            foreach ($concepts as $concept) {
                if (in_array($concept, $otherConcepts, true)) {
                    $score += 6;
                }
            }

            // Layer 2 (room): same room is a hint, not a boundary.
            // Cross-room discovery is preserved — a strongly related
            // story in another Room will outrank a weakly related one
            // in the same Room (Correction 23 / 28).
            $otherTerms = get_the_terms($id, 'qt_room');
            $otherRoom  = (!is_wp_error($otherTerms) && !empty($otherTerms)) ? $otherTerms[0]->slug : '';
            if ('' !== $roomSlug && $roomSlug === $otherRoom) {
                $score += 2;
            }

            // Lexical echoes between the two stories (capped, as always,
            // as supporting evidence — never the whole truth).
            $text = mb_strtolower((string) $candidate->post_title . ' ' . $candidate->post_content, 'UTF-8');
            foreach ($keywords as $kw) {
                if ('' !== $kw && str_contains($text, $kw)) {
                    $score += 1;
                }
            }

            // Layer 9 (semantic resonance): small boost for felt
            // similarity, never overrides explicit signals above.
            if ($score > 0 && Ai::enabled()) {
                $score = (float) $score;
                $score = apply_filters('quiet_truths_similar_extra_score', $score, $postId, $id);
                $score = (int) round($score);
            }

            if ($score > 0) {
                $scored[$id] = $score;
            }
        }

        arsort($scored);

        $similar = [];
        foreach (array_slice(array_keys($scored), 0, $limit, true) as $id) {
            $post = get_post($id);
            if ($post) {
                $similar[] = $post;
            }
        }

        return $similar;
    }

    /**
     * Related content across the whole house — Stories and Journals — for
     * a given post, ranked by shared concepts (Journal Bible §6, §22–§24,
     * §28). A Journal is a doorway into lived experiences and other
     * deeper writing; a Story can surface the Journal that examines it.
     *
     * @param int        $postId
     * @param int        $limit  total results to return
     * @param string[]   $postTypes  e.g. ['qt_story'] or ['qt_journal'] or both
     * @return list<\WP_Post>
     */
    public static function relatedContent(int $postId, int $limit = 4, array $postTypes = ['qt_story', 'qt_journal']): array
    {
        $post = get_post($postId);

        if (!$post) {
            return [];
        }

        $concepts = self::conceptsOf($postId);
        $keywords = self::topWords((string) $post->post_content, 8);

        $pool = new \WP_Query([
            'post_type'      => $postTypes,
            'post_status'    => 'publish',
            'posts_per_page' => 300,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ]);

        $scored = [];

        foreach ($pool->posts as $id) {
            $id = (int) $id;

            if ($id === $postId) {
                continue;
            }

            $candidate = get_post($id);

            if (!$candidate) {
                continue;
            }

            $score = 0;

            // Shared concepts connect everything (the invisible layer).
            $otherConcepts = self::conceptsOf($id);
            foreach ($concepts as $concept) {
                if (in_array($concept, $otherConcepts, true)) {
                    $score += 6;
                }
            }

            // Same content form is a light preference; it is not a
            // boundary. A strongly related Story may outrank a weakly
            // related Journal and vice-versa (§44 — the requested form
            // and meaning are both honoured).
            if (($candidate->post_type ?? '') === ($post->post_type ?? '')) {
                $score += 2;
            }

            $text = mb_strtolower((string) $candidate->post_title . ' ' . $candidate->post_content, 'UTF-8');
            foreach ($keywords as $kw) {
                if ('' !== $kw && str_contains($text, $kw)) {
                    $score += 1;
                }
            }

            if ($score > 0 && Ai::enabled()) {
                $score = (int) round(apply_filters('quiet_truths_similar_extra_score', (float) $score, $postId, $id));
            }

            if ($score > 0) {
                $scored[$id] = $score;
            }
        }

        arsort($scored);

        $related = [];
        foreach (array_slice(array_keys($scored), 0, $limit, true) as $id) {
            $p = get_post($id);
            if ($p) {
                $related[] = $p;
            }
        }

        return $related;
    }

    /**
     * The most distinctive words of a text (stopwords removed), most
     * frequent first.
     *
     * @return list<string>
     */
    public static function topWords(string $text, int $limit = 10): array
    {
        // Block comments/classes such as "wp-block-paragraph" were being
        // counted as room vocabulary. Remove markup before tokenisation and
        // keep Unicode letters so Swahili/Sheng words are not broken apart.
        $text = preg_replace('/<!--.*?-->/su', ' ', $text) ?: $text;
        $text = wp_strip_all_tags(strip_shortcodes($text), true);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = str_replace(['’', '‘'], "'", mb_strtolower($text, 'UTF-8'));

        $words = preg_split('/[^\p{L}\p{N}\']+/u', $text) ?: [];
        $words = array_values(array_filter($words, static function (string $word): bool {
            return mb_strlen($word, 'UTF-8') >= 3;
        }));

        $stop = array_fill_keys([
            // English function words and contractions.
            'the','and','that','this','these','those','with','from','have','has','had','was',
            'were','been','being','will','would','could','should','shall','can','may','might',
            'must','not','but','for','are','you','your','yours','they','them','their','there',
            'here','when','then','than','what','which','who','whom','about','into','over',
            'after','before','between','during','because','while','where','why','how','all',
            'any','some','more','most','other','such','only','own','same','too','very','just',
            'like','also','even','every','each','few','both','one','two','first','last','again',
            'once','upon','off','out','down','our','ours','him','his','she','her','hers','its',
            'me','my','mine','we','us','yes','did','does','doing','get','got','said','say',
            'don','dont','didn','didnt','doesn','doesnt','isn','isnt','wasn','wasnt','weren',
            'werent','haven','havent','hasn','hasnt','couldn','couldnt','wouldn','wouldnt',
            'shouldn','shouldnt','cant','cannot','wont','im','ive','ill','youre','youve',
            // Common Swahili function words; meaningful people/places remain.
            'kwa','na','ya','wa','ni','hii','hiyo','ile','sana','lakini','kama','kuwa','katika',
            'yangu','yako','yake','wangu','wako','wake','wao','mimi','sisi','yeye','pia','bado',
            'sasa','baada','kabla','wakati','kutoka','kwenda','kila','kitu','mtu','watu','hata',
            'hapa','pale','ndio','si',
            // Defensive WordPress/editor artefacts.
            'wordpress','block','blocks','paragraph','separator','strong','class','align','wp',
        ], true);

        $freq = [];
        foreach ($words as $word) {
            $key = trim($word, "'");
            if ('' === $key || isset($stop[$key])) {
                continue;
            }
            $freq[$key] = ($freq[$key] ?? 0) + 1;
        }

        arsort($freq);

        return array_slice(array_keys($freq), 0, max(0, $limit));
    }

    /**
     * The Journal that continues a story's conversation — the published
     * journal with the most shared concepts. Null when none exist or
     * none share a concept.
     */
    public static function relatedJournal(int $postId): ?\WP_Post
    {
        $concepts = self::conceptsOf($postId);

        if (empty($concepts)) {
            return null;
        }

        $journalIds = get_posts([
            'post_type'      => 'qt_journal',
            'post_status'    => 'publish',
            'posts_per_page' => 100,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ]);

        $best    = null;
        $bestHit = 0;

        foreach ($journalIds as $jid) {
            $jid       = (int) $jid;
            $jConcepts = self::conceptsOf($jid);

            // Untagged journal: detect on the fly so the bridge works
            // even before a backfill.
            if (empty($jConcepts)) {
                $jPost = get_post($jid);

                if ($jPost) {
                    $jConcepts = self::detect((string) $jPost->post_title . ' ' . (string) $jPost->post_content);
                }
            }

            $shared = count(array_intersect($concepts, $jConcepts));

            if ($shared > $bestHit) {
                $bestHit = $shared;
                $best    = get_post($jid);
            }
        }

        return $best;
    }

    /**
     * Canonical concept-slug list for a post.
     *
     * Resolution order (v1.7.4, Correction 3 / 5 / 8):
     *   1. CURRENT — `_qt_concepts` meta (canonical; written by
     *      Profile::writeBackCompat v8+ and Concepts::tagStory()).
     *   2. LEGACY FALLBACK — `_qt_themes` (READ-ONLY; pre-v1.7.3 data).
     *      This is a transitional read, not a parallel source of truth.
     *      See wp qt ai migrate:apply for translating this into the
     *      canonical key.
     *   3. Last resort — concepts from the stored AI profile.
     *      (Correction 3: uses method_exists() for the static class
     *      method, not function_exists().)
     *
     * @return list<string>
     */
    public static function conceptsOf(int $postId): array
    {
        // ── CURRENT PATH (canonical): _qt_concepts ──
        // Written by Profile::writeBackCompat v8+ and Concepts::tagStory().
        $raw = get_post_meta($postId, '_qt_concepts', true);
        if (is_array($raw) && !empty($raw)) {
            $out = [];
            foreach ($raw as $row) {
                if (is_string($row)) {
                    $out[] = $row;
                } elseif (is_array($row) && isset($row['slug'])) {
                    $out[] = (string) $row['slug'];
                }
            }
            return array_values(array_unique(array_filter($out)));
        }

        // ── LEGACY FALLBACK (READ-ONLY): _qt_themes ──
        // Pre-v1.7.3 data. Transitional only. Migration path:
        // wp qt ai migrate:apply to translate into _qt_concepts.
        // Legacy data is NEVER used as a parallel source of truth for
        // new inference (v1.7.3 Clause 8, Correction 8).
        $legacy = get_post_meta($postId, '_qt_themes', true);
        if (is_array($legacy) && !empty($legacy)) {
            return array_values(array_unique(array_filter(array_map('strval', $legacy))));
        }

        // ── Last resort: profile concepts map ──
        $profile = method_exists('\\QuietTruths\\Ai\\Profile', 'get')
            ? \QuietTruths\Ai\Profile::get($postId)
            : [];
        $fromProfile = array_keys((array) ($profile['concepts'] ?? []));
        return array_values(array_unique(array_filter(array_map('strval', $fromProfile))));
    }

    /**
     * Deprecated alias for conceptsOf().
     *
     * Retained ONLY for external/legacy code that may still call the
     * old name. Internal Quiet Truths code MUST call conceptsOf()
     * (Correction 5, v1.7.4). "themes" is a retired ontology term —
     * v1.7.3 Clauses 7–9 established _qt_concepts as the canonical
     * concept store and _qt_themes as read-only legacy.
     *
     * @deprecated 1.7.4 Use conceptsOf().
     * @return list<string>
     */
    public static function themesOf(int $postId): array
    {
        return self::conceptsOf($postId);
    }

    public static function onStorySave(int $postId, $post): void
    {
        if (!in_array(($post->post_type ?? ''), ['qt_story', 'qt_journal'], true)) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (wp_is_post_revision($postId) || wp_is_post_autosave($postId)) {
            return;
        }

        self::tagStory($postId);
    }

    /**
     * Re-tag the archive when the knowledge base changes, so the
     * invisible layer stays in step with the house's memory.
     *
     * Corrections 26 & 27: the backfill is BATCH-AWARE and BACKGROUND-SAFE.
     * A knowledge-base change never triggers a potentially enormous rebuild
     * during an ordinary public request. Instead it queues background
     * batches (BackgroundWorker::runConceptBackfill) that process the
     * archive in chunks until EVERY story is covered.
     */
    public static function maybeBackfill(): void
    {
        $path = dirname(__DIR__) . '/config/concepts.php';
        $sig  = is_file($path) ? (string) filesize($path) . '-' . (string) filemtime($path) : 'none';

        if (get_option('qt_concepts_sig') === $sig) {
            return;
        }

        // Defer to the background/CLI architecture (Correction 27).
        if (class_exists('\\QuietTruths\\Ai\\BackgroundWorker')) {
            \QuietTruths\Ai\BackgroundWorker::queueConceptBackfill();
        }
    }

    /**
     * Commit the current knowledge-base signature once the background
     * backfill has covered the entire archive (Correction 26). Called by
     * the final BackgroundWorker batch.
     */
    public static function commitBackfill(): void
    {
        $path = dirname(__DIR__) . '/config/concepts.php';
        $sig  = is_file($path) ? (string) filesize($path) . '-' . (string) filemtime($path) : 'none';

        update_option('qt_concepts_sig', $sig);
    }
}
