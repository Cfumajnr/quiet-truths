<?php
/**
 * Quiet Truths — Design System Manifest
 *
 * Order matters: tokens first, then utilities, then components and
 * page-level styles. Each entry is enqueued by AssetRegistry with the
 * handle "qt-{key}" and cascades over the previous entries.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

return [
    'tokens-color'      => ['file' => 'tokens-color.css'],
    'tokens-typography' => ['file' => 'tokens-typography.css'],
    'tokens-spacing'    => ['file' => 'tokens-spacing.css'],
    'tokens-motion'     => ['file' => 'tokens-motion.css'],
    'utilities'         => ['file' => 'utilities.css'],
    'components'        => ['file' => 'components.css'],
    'navigation'        => ['file' => 'navigation.css'],
    'home'              => ['file' => 'home.css'],
    'forms'             => ['file' => 'forms.css'],
    'stories'           => ['file' => 'stories.css'],
    'search'            => ['file' => 'search.css'],
    'responses'         => ['file' => 'responses.css'],
    'writer'            => ['file' => 'writer.css'],
    // 'doors' retired in v1.7.3 (Correction 15): the stylesheet is
    // removed because the public Doors architecture it served no
    // longer exists. Handles for 'doors' left out intentionally — the
    // AssetRegistry will simply not enqueue a file that isn't listed.
    'room-feel'         => ['file' => 'room-feel.css'],
    'entrance'          => ['file' => 'entrance.css'],
    'journals'          => ['file' => 'journals.css'],
];
