<?php
/**
 * Quiet Truths — WP-CLI AI commands.
 *
 * Provides:
 *   wp qt ai status         — show service + model status + profile counts
 *   wp qt ai warm <id>      — (re)build embedding + profile for one post
 *   wp qt ai backfill       — rebuild profiles for all published stories
 *   wp qt ai inspect <id>   — print a story's AI profile (calibration helper)
 *   wp qt ai classify <txt> — run classify pipeline against arbitrary text
 *
 * @package QuietTruths\Cli
 */

namespace QuietTruths\Cli;

if (!defined('ABSPATH')) {
    exit;
}

use QuietTruths\Ai\AiKernel;
use QuietTruths\Ai\BackgroundWorker;
use QuietTruths\Ai\Embeddings;
use QuietTruths\Ai\PrivacyScanner;
use QuietTruths\Ai\Profile;
use QuietTruths\Ai\StoryUnderstanding;
use QuietTruths\Ai\ConceptInference;
use WP_CLI;

if (!defined('WP_CLI') || !WP_CLI) {
    return;
}

class AiCommands
{
    /**
     * Show the status of the AI subsystem.
     *
     * ## EXAMPLES
     *     wp qt ai status
     */
    public function status(): void
    {
        $ready = AiKernel::serviceReady();
        $meta  = Embeddings::serviceMeta();
        WP_CLI::line('Quiet Truths AI status');
        WP_CLI::line(str_repeat('─', 40));
        WP_CLI::line(sprintf('  Theme version    : %s  (WordPress child theme; not an ontology layer)', QT_THEME_VERSION));
        WP_CLI::line(sprintf('  Profile schema   : v%d', Profile::SCHEMA_VERSION));
        WP_CLI::line(sprintf('  AI enabled       : %s', AiKernel::enabled() ? 'yes' : 'no'));
        WP_CLI::line(sprintf('  Service ready    : %s', $ready ? 'yes' : 'no'));
        if ($ready) {
            WP_CLI::line(sprintf('  Model            : %s', $meta['model']));
            WP_CLI::line(sprintf('  Dimension        : %d', $meta['dim']));
            WP_CLI::line(sprintf('  Service URL      : %s', AiKernel::serviceUrl()));
        } else {
            WP_CLI::line('  Model            : tokens-v1 (PHP fallback)');
        }

        $counts = (array) wp_count_posts('qt_story');
        $published = (int) ($counts['publish'] ?? 0);
        $pending   = (int) ($counts['pending'] ?? 0);
        global $wpdb;
        $profiled = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s",
            Profile::META_KEY
        ));
        $dense = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s",
            Embeddings::STATUS_KEY, Embeddings::STATUS_DENSE
        ));
        $pen   = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s",
            Embeddings::STATUS_KEY, Embeddings::STATUS_PENDING
        ));
        WP_CLI::line('');
        WP_CLI::line(sprintf('  Stories (publish): %d', $published));
        WP_CLI::line(sprintf('  Stories (pending): %d', $pending));
        WP_CLI::line(sprintf('  With AI profile  : %d', $profiled));
        WP_CLI::line(sprintf('  With dense embed : %d', $dense));
        WP_CLI::line(sprintf('  Pending embed    : %d', $pen));
    }

    /**
     * (Re)warm the embedding + profile for a single post.
     *
     * ## OPTIONS
     * <id>
     * : Post ID to warm.
     *
     * ## EXAMPLES
     *     wp qt ai warm 42
     */
    public function warm(array $args): void
    {
        $id = (int) ($args[0] ?? 0);
        $post = get_post($id);
        if (!$post) {
            WP_CLI::error("No post with ID $id.");
        }
        WP_CLI::line("Profiling post $id (" . $post->post_title . ")…");
        Profile::warm($id);
        $profile = Profile::get($id);
        WP_CLI::success('Done. Concepts: ' . implode(', ', array_slice(array_keys((array) ($profile['concepts'] ?? [])), 0, 6)));
    }

    /**
     * Backfill profiles for published stories using ID-pagination so we
     * never load all posts into memory at once.
     *
     * ## OPTIONS
     * [--type=<types>]
     * : Comma-separated post types to backfill. Default: qt_story.
     *
     * [--batch-size=<n>]
     * : Posts per batch. Default: 25.
     *
     * [--dry-run]
     * : Show what would be profiled without writing.
     *
     * [--force]
     * : Rebuild even if a current profile already exists.
     *
     * ## EXAMPLES
     *     wp qt ai backfill
     *     wp qt ai backfill --type=qt_story,qt_journal --batch-size=50 --force
     */
    public function backfill(array $_, array $opts): void
    {
        $types = array_map('trim', explode(',', (string) ($opts['type'] ?? 'qt_story')));
        $batch = max(5, (int) ($opts['batch-size'] ?? 25));
        $dry = !empty($opts['dry-run']);
        $force = !empty($opts['force']);

        $total = 0;
        $lastId = 0;
        $done = 0;

        // Count total first (fast).
        $countQ = new \WP_Query([
            'post_type' => $types, 'post_status' => 'publish',
            'posts_per_page' => 1, 'fields' => 'ids',
        ]);
        $total = (int) $countQ->found_posts;
        WP_CLI::line(sprintf('Found %d published %s to profile (batch size %d).', $total, implode('/', $types), $batch));

        $progress = $total > 0 ? \WP_CLI\Utils\make_progress_bar('Profiling', $total) : null;

        $preserved = 0;
        $lexicalFallback = 0;

        while (true) {
            global $wpdb;
            $ids = $wpdb->get_col($wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts}
                 WHERE post_type IN (" . implode(',', array_fill(0, count($types), '%s')) . ")
                   AND post_status = 'publish'
                   AND ID > %d
                 ORDER BY ID ASC
                 LIMIT %d",
                array_merge($types, [$lastId, $batch])
            ));
            if (empty($ids)) break;
            foreach ($ids as $pid) {
                $pid = (int) $pid;
                $lastId = max($lastId, $pid);

                $raw = get_post_meta($pid, Profile::META_KEY, true);
                $currentVer = is_array($raw) ? (int) ($raw['schema_version'] ?? 0) : 0;
                $buildComplete = is_array($raw)
                    && (($raw['semantic_build']['complete'] ?? false) === true)
                    && (($raw['semantic']['mode'] ?? '') === 'dense');
                // A post is up-to-date only when its schema is current
                // AND it carries a complete dense build. We do NOT skip
                // dense posts just because the service is currently
                // down — warm() will do the right thing (preserve the
                // existing good dense profile).
                $upToDate = $currentVer >= Profile::SCHEMA_VERSION && $buildComplete;

                if (!$force && $upToDate) {
                    if ($progress) $progress->tick();
                    continue;
                }

                if ($dry) {
                    WP_CLI::log("  · would (re)profile #$pid");
                } else {
                    // Route through warm() so the lifecycle guarantee
                    // applies here too: a transient service outage
                    // during a backfill run can never demote an
                    // existing good dense profile to lexical.
                    $result = Profile::warm($pid);
                    if ($result === 'persisted_dense') {
                        $done++;
                    } elseif ($result === 'persisted_lexical_fallback') {
                        $lexicalFallback++;
                    } elseif ($result === 'preserved_existing_dense') {
                        $preserved++;
                    }
                }
                if ($progress) $progress->tick();
            }
        }
        if ($progress) $progress->finish();
        if ($dry) {
            WP_CLI::success(sprintf('Would profile %d stories.', $total - $done));
        } else {
            $parts = [];
            if ($done > 0)             $parts[] = sprintf('%d dense', $done);
            if ($lexicalFallback > 0)  $parts[] = sprintf('%d lexical fallback', $lexicalFallback);
            if ($preserved > 0)        $parts[] = sprintf('%d existing dense preserved (service unavailable)', $preserved);
            if (empty($parts))         $parts[] = '0';
            WP_CLI::success('Profiled: ' . implode(', ', $parts) . '.');
        }
    }

    /**
     * Print a story's AI profile.
     *
     * ## OPTIONS
     * <id>
     * : Post ID to inspect.
     *
     * ## EXAMPLES
     *     wp qt ai inspect 42
     */
    public function inspect(array $args): void
    {
        $id = (int) ($args[0] ?? 0);
        $post = get_post($id);
        if (!$post) {
            WP_CLI::error("No post with ID $id.");
        }
        // Force a fresh profile so inspection is useful for calibration.
        Profile::warm($id);
        $p = Profile::get($id);
        WP_CLI::line('Title    : ' . $post->post_title);
        WP_CLI::line('Model    : ' . ($p['model'] ?? '?'));
        WP_CLI::line('Language : ' . ($p['identity']['language'] ?? '?'));
        WP_CLI::line('Confidence: ' . (int) round((float) ($p['confidence'] ?? 0) * 100) . '%');
        WP_CLI::line('Risk     : ' . (int) round((float) ($p['privacy']['risk_score'] ?? 0) * 100) . '%');
        $activeThreads = array_keys((array) ($p['threads']['active'] ?? []));
        if (!empty($activeThreads)) {
            WP_CLI::line('Threads  : ' . implode(', ', array_slice($activeThreads, 0, 8)));
        }
        WP_CLI::line('Warnings : ' . implode(', ', (array) ($p['content']['warnings'] ?? [])));
        WP_CLI::line('');
        WP_CLI::line('Concepts (top 10):');
        $i = 0;
        foreach ((array) ($p['concepts'] ?? []) as $slug => $score) {
            WP_CLI::line(sprintf('  %-20s %6.2f', $slug, $score));
            if (++$i >= 10) break;
        }
        if (!empty($p['emotional_signals'])) {
            WP_CLI::line('');
            WP_CLI::line(sprintf(
                'Emotion  : valence=%.2f arousal=%.2f labels=%s',
                (float) ($p['emotional_signals']['valence'] ?? 0),
                (float) ($p['emotional_signals']['arousal'] ?? 0),
                implode(', ', (array) ($p['emotional_signals']['labels'] ?? []))
            ));
        }
        $dirFlags = array_merge(
            (array) ($p['privacy']['direct_identifiers'] ?? []),
            (array) ($p['privacy']['contextual_identifiers'] ?? [])
        );
        if (!empty($dirFlags)) {
            WP_CLI::line('');
            WP_CLI::line('Privacy flags:');
            foreach ($dirFlags as $f) {
                WP_CLI::line(sprintf('  - %s%s %s', $f['kind'] ?? '', '' !== ($f['match'] ?? '') ? ': ' . $f['match'] : '', $f['note'] ?? ''));
            }
        }
    }

    /**
     * Run concept + privacy analysis against arbitrary text (for calibration).
     *
     * ## OPTIONS
     * <text>
     * : Text to classify, or "-" to read from stdin.
     *
     * ## EXAMPLES
     *     wp qt ai classify "I kept dialling her number after she died."
     *     cat story.txt | wp qt ai classify -
     */
    public function classify(array $args): void
    {
        $text = (string) ($args[0] ?? '');
        if ('-' === $text) {
            $text = stream_get_contents(STDIN);
        }
        $text = trim($text);
        if ('' === $text) {
            WP_CLI::error('Provide text or pipe via stdin.');
        }
        $under = StoryUnderstanding::understand($text, []);
        $priv  = PrivacyScanner::scan($text);

        WP_CLI::line('Model       : ' . Embeddings::activeModel());
        WP_CLI::line('Language    : ' . ($under['language'] ?? '?'));
        WP_CLI::line('Confidence  : ' . (int) round((float) ($under['confidence'] ?? 0) * 100) . '%');
        WP_CLI::line('Risk        : ' . (int) round((float) ($priv['risk_score'] ?? 0) * 100) . '%');
        // v8: doors are retired as a dimension; we print concepts instead.
        WP_CLI::line('Concepts    : ' . implode(', ', array_slice((array) ($under['concepts'] ?? []), 0, 8)));
        WP_CLI::line('Warnings    : ' . implode(', ', (array) ($under['warnings'] ?? [])));
        WP_CLI::line('');
        WP_CLI::line('Semantic concepts:');
        foreach ((array) ($under['concept_scores'] ?? []) as $slug => $s) {
            WP_CLI::line(sprintf('  %-20s %6.2f%s', $slug, $s, $s >= ConceptInference::SEMANTIC_THRESHOLD ? '  <--' : ''));
        }
        if (!empty($priv['flags'])) {
            WP_CLI::line('');
            WP_CLI::line('Privacy flags:');
            foreach ($priv['flags'] as $f) {
                WP_CLI::line(sprintf('  [%s] %s%s', $f['severity'] ?? 'low', $f['kind'] ?? '', '' !== ($f['match'] ?? '') ? ': ' . $f['match'] : ''));
            }
        }
    }

    /**
     * wp qt ai journal-patterns
     *
     * Discover recurring patterns across the story archive that might
     * merit a Journal — candidate suggestions only, never authority
     * (Journal Bible §45–§46).
     *
     * ## OPTIONS
     * [--min=<n>]  minimum stories to consider a pattern (default 4)
     * [--limit=<n>] max suggestions (default 6)
     *
     * @param array $_
     * @param array $opts
     */
    public function journal_patterns(array $_, array $opts): void
    {
        $min   = max(2, (int) ($opts['min'] ?? 4));
        $limit = max(1, (int) ($opts['limit'] ?? 6));

        if (!class_exists(\QuietTruths\Ai\JournalPatterns::class)) {
            WP_CLI::error('JournalPatterns not available.');
        }

        $suggestions = \QuietTruths\Ai\JournalPatterns::suggest($min, $limit);

        if (empty($suggestions)) {
            WP_CLI::line('No recurring patterns above the evidence threshold yet.');
            return;
        }

        WP_CLI::line(sprintf('Candidate Journal subjects (evidence >= %d stories):', $min));
        WP_CLI::line('');

        foreach ($suggestions as $s) {
            WP_CLI::line('• ' . $s['subject'] . '  (' . $s['evidence_count'] . ' stories)');
            WP_CLI::line('    threads : ' . implode(', ', (array) $s['threads']));
            WP_CLI::line('    domains : ' . implode(', ', (array) $s['domains']));
        }

        WP_CLI::line('');
        WP_CLI::line('These are candidate patterns only — they suggest questions worth');
        WP_CLI::line('exploring, not claims of universal truth (Journal Bible §46).');
    }
}

if (class_exists('WP_CLI')) {
    WP_CLI::add_command('qt ai', __NAMESPACE__ . '\\AiCommands');
}
