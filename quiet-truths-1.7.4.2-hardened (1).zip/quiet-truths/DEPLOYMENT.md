# Quiet Truths 1.7.4.2 — deployment checklist

## 1. Before deployment

1. Back up the database and the current `quiet-truths` theme separately.
2. Test this release on staging with the same WordPress, Blocksy, PHP, LiteSpeed and Wordfence versions as production.
3. Keep publishable-content intake paused in `wp-config.php`:

```php
define('QT_PUBLIC_INTAKE', false);
define('FORCE_SSL_ADMIN', true);
define('DISALLOW_FILE_EDIT', true);
define('WP_ENVIRONMENT_TYPE', 'production');
```

The contact/removal form remains available when public intake is paused.

4. Do not define `QT_WRITER_RECOGNITION`. It is deliberately disabled. Do not enable it without a documented purpose, DPIA/privacy assessment and updated notice.
5. If TLS terminates at a trusted reverse proxy, configure WordPress to recognise HTTPS at the server level. Only then, if required, define `QT_TRUST_PROXY_HTTPS` as `true`. Never trust a client-supplied forwarding header unless the proxy overwrites it.

## 2. Force HTTPS before PHP

The PHP 308 redirect is defence in depth; it cannot protect a request body that has already travelled to PHP over clear text. Put the following at the top of the document-root `.htaccess`, before WordPress/LiteSpeed rules:

```apache
RewriteEngine On

# Canonical HTTPS origin in one hop.
RewriteCond %{HTTPS} !=on [OR]
RewriteCond %{HTTP_HOST} !^quiettruths\.co\.ke$ [NC]
RewriteRule ^ https://quiettruths.co.ke%{REQUEST_URI} [R=308,L,NE]
```

For a LiteSpeed/Apache virtual host, also disable TRACE in server/vhost configuration:

```apache
TraceEnable off
```

For nginx, use a dedicated clear-text server:

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name quiettruths.co.ke www.quiettruths.co.ke;
    return 308 https://quiettruths.co.ke$request_uri;
}

server {
    listen 443 ssl http2;
    server_name www.quiettruths.co.ke;
    return 308 https://quiettruths.co.ke$request_uri;
}
```

Test all host/scheme combinations, including direct POST protection, before enabling intake.

## 3. Install and migrate

1. Install the ZIP as the active Blocksy child theme.
2. Load WP Admin once. The release will:
   - resynchronise the draft governance pack;
   - correctly reuse the nested House Rules page;
   - draft extra theme-managed governance copies such as `terms-2` and `house-rules-3`;
   - retain 301 mappings for their old paths;
   - remove legacy cross-submission writer hashes when recognition is disabled;
   - clean the duplicated Journal-submission introduction.
3. Purge LiteSpeed page/object caches and any upstream CDN cache.
4. In LiteSpeed, exclude these routes from full-page cache even though the theme defines `DONOTCACHEPAGE`:
   - `/leave-a-story/`
   - `/write-to-quiet-truths/`
   - `/submit-a-journal/`
   - `/story/*`
   - `/journal/*`
   - requests containing `qt_flash`, `qt_held`, `qt_ref`, `qt_contact_sent`, `qt_journal_submitted`, `qt_resp` or `qt_jc_held`

## 4. Governance launch gate

Do not set `QT_PUBLIC_INTAKE` to `true` until all visible placeholders are replaced and the live practices match the documents. At minimum confirm:

- accountable controller/operator legal name and contact details;
- dedicated privacy/security contact route;
- contracted host, upstream infrastructure, email, backup, security and support providers;
- actual database, server, mail, log and backup countries;
- processor/data-processing agreements and international-transfer safeguards;
- final retention periods and automated/manual deletion procedure;
- ODPC registration or documented exemption assessment;
- DPIA/high-risk-processing assessment;
- crisis, takedown, breach and moderator escalation runbooks;
- whether the local embedding service writes request text to logs (it must not);
- that raw Story text is absent from notification emails, monitoring traces and WAF request-body logs.

The supplied public IP was in a Contabo European network during the review; obtain written data-location evidence rather than describing the server as Kenyan without verification.

## 5. Operational security gate

- Enforce MFA for every administrator/editor and remove shared accounts.
- Use least-privilege editorial roles.
- Verify WordPress, Blocksy, Wordfence, PHP and LiteSpeed update procedures.
- Encrypt off-site backups, restrict keys and perform a restore test.
- Confirm database/backup access logging and moderator confidentiality.
- Separate authoritative DNS and incident email from the web server where practical.
- Validate SPF and DKIM, then move DMARC from monitoring (`p=none`) toward enforcement after observing legitimate mail.
- Configure uptime checks for Home, Stories, all seven Rooms, search page 2, forms, `security.txt`, and a synthetic no-content form validation.
- Add a request-size limit at the web server/WAF and alert on queue spikes.

## 6. Smoke tests

Expected outcomes:

```text
http://quiettruths.co.ke/*                  308 → https://quiettruths.co.ke/*
http://www.quiettruths.co.ke/*              308 → https://quiettruths.co.ke/*
https://www.quiettruths.co.ke/*             308 → https://quiettruths.co.ke/*
/room/{each-room}/                           200, no “critical error”
/stories/ and /stories/page/2/               200, self-canonical
/?s=test&qt_page=2                           200, not 404
/.well-known/security.txt                    200 text/plain
interactive pages                            Cache-Control: no-store/private
```

With intake still paused, Story, Journal, Response and Journal-comment forms should be replaced by pause notices while Contact remains available.

After governance and operational sign-off, explicitly open intake:

```php
define('QT_PUBLIC_INTAKE', true);
```

Then run an invited closed beta before public promotion. Test submission, moderation, fiction/composite disclosure, correction re-moderation, reporting, withdrawal, deletion and backup restoration end to end.

## 7. Known work not solved by a theme ZIP

- Final Kenyan legal review and provider details
- Verified hosting/backup geography and processor contracts
- ODPC/DPIA decisions
- Database and backup encryption configuration
- Administrator MFA enforcement
- Mail delivery/authentication configuration
- Automated retention jobs after final periods are chosen
- A private supporting-file service (the public Journal form intentionally accepts writing only)
- Redundant DNS/mail infrastructure

Do not place private supporting files in the ordinary public WordPress Media Library.
