# Quiet Truths 1.7.4.2 — hardening release

## Critical fixes

- Fixed all Room archives returning HTTP 500. `Rooms` and three AI classes imported classes from the wrong namespaces.
- Replaced global form-error transients with one-time, high-entropy visitor-specific flash state. This prevents one visitor from receiving another visitor's contact details or draft text.
- Renamed the Story textarea POST field from `qt_story` to `qt_story_text`; the old name collided with WordPress's custom-post-type query variable and caused validation failures to render as false 404 pages.
- Fixed successful Story and Journal submissions redirecting away from their confirmation screens.
- Added an operational `QT_PUBLIC_INTAKE` kill switch. Because the bundled governance pack is explicitly a draft, publishable-content intake is closed by default until the operator explicitly sets `QT_PUBLIC_INTAKE` to `true`.
- Added a PHP-level HTTPS 308 fallback and supplied server-level redirect examples. Server-level enforcement remains mandatory.
- Disabled full-page caching on forms, Story pages and Journal pages containing expiring nonces or personal form state.

## Privacy and security

- Cross-submission writing-style recognition is now disabled by default. Legacy writer hashes/link metadata and the year-long writer cookie are removed when disabled.
- Story email notifications no longer copy Story text into email; they contain only a content ID and protected admin link.
- Response edit tokens are stored as keyed hashes rather than plaintext. Legacy plaintext tokens migrate on first successful use.
- Rate-limit keys now use a keyed HMAC rather than unsalted MD5 values derived from IP addresses.
- Self-hosted Crimson Pro and Inter fonts; public pages no longer contact Google Fonts. SIL OFL licences are bundled.
- Tightened CSP to local font/style origins and added mixed-content upgrade directives.
- Added `/.well-known/security.txt` with the contact and policy routes.
- Updated Permissions-Policy.
- Fixed login lockout ordering so a locked request cannot bypass the check merely because WordPress has already returned a user or error.
- Added one-report-per-response/network guard so one visitor cannot trigger the two-report auto-hold alone.
- Added noindex handling for one-time confirmation and flash-state URLs.

## Moderation integrity

- A Response edit now returns the Response to `pending` moderation instead of changing approved public text immediately.
- Public Response counts are updated when an edit or reports hold a Response.
- Removed automatic rejection based solely on difficult words. Stories, Journals, Responses and comments remain pending for contextual human moderation; safety complaints are not rejected because they quote harmful language.
- Journal commenters can no longer impersonate an author simply by typing the byline name. The Author badge requires a moderator-verified flag.
- Fixed the Journal-comment Approve action, which previously returned immediately on every admin request.
- Added a moderator UI for verified Journal-author comments.
- Added age/moderation confirmations to Journal comments and nested Story replies.

## Functionality and discoverability

- Fixed semantic-search pagination by using `qt_page`; result pages no longer become WordPress 404s when the native lexical result count is smaller.
- Search now scores Stories, Posts and Journals; ordinary governance Pages appear only on an exact title/slug request.
- Fixed canonical and Open Graph URLs for Story archives, Journal archives, Room terms and paginated archives.
- Added archive meta descriptions and Journal `article` Open Graph type.
- Governance page generation now finds child pages correctly, retires old managed `-2`, `-3`, etc. duplicates, and preserves 301 redirects.
- Fixed House Rules URL lookup.
- Fixed duplicated Submit-a-Journal introduction.
- Replaced misleading Journal-upload controls with an honest writing-only notice. Future supporting files must use a separately designed private channel.
- Added a required Story classification: lived experience, fiction, or composite/details changed. Fiction and composite Stories receive public disclosures.
- Fixed doubled Response totals.
- Fixed Room vocabulary extraction counting WordPress markup such as `paragraph`, `strong` and `separator`.

## Accessibility

- Added the homepage H1 and an accessible label to the overlay search input.
- Darkened semantic colour tokens to WCAG AA contrast levels.
- Underlined in-text governance/form links so they do not rely on colour alone.
- Fixed placeholder contrast.

## Tests completed

- PHP 8.4 syntax check: 79 files passed.
- JavaScript syntax check: 4 files passed.
- WordPress 7.0.3 + Blocksy 2.1.52 integration environment.
- Room, Story, Journal, governance, search and pagination route checks.
- Story, Journal, Response, Contact and Journal-comment submission workflows.
- One-time flash-state isolation test with two independent sessions.
- Journal comment approval and author-impersonation test.
- Governance duplicate migration and redirect test.
- HTTPS 308 fallback test.
- Desktop and mobile browser audit across 18 page/viewport combinations: zero console errors, failed resources, horizontal overflow, external requests or automated WCAG A/AA violations.
