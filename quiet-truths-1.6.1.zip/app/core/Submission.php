<?php
/**
 * Quiet Truths — Story Submission & Review Queue
 *
 * The public "leave a story" flow and its private review queue:
 *
 *   visitor → anonymous form → qt_story (status: pending) → admin approves → public
 *
 * Guards:
 *  - minimum word count (default 20) — a blank or one-word story is refused
 *  - rate limits: per 10 minutes, per hour, per day
 *  - profanity filter (app/config/bad-words.php), shared with Responses
 *  - honeypot for bots
 *
 * Privacy:
 *  - only the words are kept; no name, no email, no stored IP
 *  - a wordless "voice fingerprint" (cookie + salted hash) lets the house
 *    recognise a returning writer without ever knowing who they are
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Submission
{
    private const WRITER_COOKIE = 'qt_writer';

    /** @var string[] Error codes for the current request. */
    private static array $errors = [];

    /** @var array<string,string> Last submitted field values. */
    private static array $old = [];

    public static function init(): void
    {
        add_action('template_redirect', [self::class, 'maybeHandleSubmission']);
        add_action('admin_post_qt_approve_story', [self::class, 'handleApprove']);
        add_action('admin_notices', [self::class, 'pendingNotice']);
        add_filter('post_row_actions', [self::class, 'rowActions'], 10, 2);
        add_filter('manage_qt_story_posts_columns', [self::class, 'storyColumns']);
        add_action('manage_qt_story_posts_custom_column', [self::class, 'storyColumnValue'], 10, 2);
    }

    /* ─────────────── view state ─────────────── */

    /** @return string[] */
    public static function errors(): array
    {
        return self::$errors;
    }

    public static function old(string $key, string $default = ''): string
    {
        return self::$old[$key] ?? $default;
    }

    public static function held(): bool
    {
        return isset($_GET['qt_held']);
    }

    /* ─────────────── submission ─────────────── */

    public static function maybeHandleSubmission(): void
    {
        if (is_admin() || (defined('REST_REQUEST') && REST_REQUEST)) {
            return;
        }
        if (empty($_POST['qt_story_submit']) || !isset($_POST['_wpnonce'])) {
            return;
        }

        // Expired or forged session.
        if (!wp_verify_nonce(sanitize_key(wp_unslash((string) $_POST['_wpnonce'])), 'qt_leave_story')) {
            self::$errors[] = 'session';
            return;
        }

        // Honeypot: bots fill this hidden field. Pretend it worked.
        if (!empty($_POST['qt_website'])) {
            wp_safe_redirect(add_query_arg('qt_held', '1', home_url('/')));
            exit;
        }

        // Gentle rate limits — three windows: 10 minutes, hour, day.
        $rate10  = self::passesRate('qt_rate_', (int) apply_filters('quiet_truths_rate_limit', 2), 10 * MINUTE_IN_SECONDS);
        $rateHr  = self::passesRate('qt_rate_hour_', (int) apply_filters('quiet_truths_story_rate_hour', 3), HOUR_IN_SECONDS);
        $rateDay = self::passesRate('qt_rate_day_', (int) apply_filters('quiet_truths_story_rate_day', 5), DAY_IN_SECONDS);

        if (!$rate10) {
            self::$errors[] = 'rate';
            return;
        }
        if (!$rateHr) {
            self::$errors[] = 'rate_hour';
            return;
        }
        if (!$rateDay) {
            self::$errors[] = 'rate_day';
            return;
        }

        $story    = isset($_POST['qt_story']) ? sanitize_textarea_field(wp_unslash((string) $_POST['qt_story'])) : '';
        $heading  = isset($_POST['qt_heading']) ? sanitize_text_field(wp_unslash((string) $_POST['qt_heading'])) : '';
        $warnings = isset($_POST['qt_warnings']) ? sanitize_text_field(wp_unslash((string) $_POST['qt_warnings'])) : '';
        $room     = isset($_POST['qt_room']) ? sanitize_key(wp_unslash((string) $_POST['qt_room'])) : '';

        self::$old = [
            'story'    => $story,
            'heading'  => $heading,
            'warnings' => $warnings,
            'room'     => $room,
        ];

        $maxChars  = (int) apply_filters('quiet_truths_story_max_length', 4000);
        $minWords  = (int) apply_filters('quiet_truths_story_min_words', 20);
        $wordCount = self::countWords($story);

        if ($wordCount < $minWords) {
            self::$errors[] = 'short';
        }
        if (self::strLen($story) > $maxChars) {
            self::$errors[] = 'long';
        }
        if (self::strLen($heading) > 120) {
            self::$errors[] = 'heading';
        }
        if (self::strLen($warnings) > 200) {
            self::$errors[] = 'warnings';
        }

        $rooms = defined('QT_ROOMS') ? array_keys(QT_ROOMS) : [];
        if (!in_array($room, $rooms, true)) {
            self::$errors[] = 'room';
        }

        // The language guard — shared with the response system.
        if (Responses::containsForbidden($heading . ' ' . $story)) {
            self::$errors[] = 'profanity';
        }

        // Consent boxes: unticked confirmations prevent submission.
        if (empty($_POST['qt_consent_age_rules'])) {
            self::$errors[] = 'consent_age';
        }
        if (empty($_POST['qt_consent_publish'])) {
            self::$errors[] = 'consent_publish';
        }

        if (!empty(self::$errors)) {
            return;
        }

        $title = '' !== $heading ? $heading : self::makeTitle($story);

        $postId = wp_insert_post([
            'post_type'    => 'qt_story',
            'post_status'  => 'pending',
            'post_title'   => $title,
            'post_content' => $story,
            'post_author'  => 0, // anonymous
        ], true);

        if (is_wp_error($postId)) {
            error_log('Quiet Truths: could not store a submitted story — ' . $postId->get_error_message());
            self::$errors[] = 'store';
            return;
        }

        wp_set_object_terms($postId, [$room], 'qt_room');
        update_post_meta($postId, '_qt_anonymous', '1');
        update_post_meta($postId, '_qt_submitted_at', current_time('mysql', true));
        update_post_meta($postId, '_qt_words', $wordCount);

        // Record the policy pack version the submitter agreed to. This
        // is a minimal audit record (content ID, date, version) — no IP
        // is stored here per the governance guidance.
        update_post_meta($postId, '_qt_consent_at', current_time('mysql', true));
        update_post_meta($postId, '_qt_consent_version', defined('QT_THEME_VERSION') ? QT_THEME_VERSION : '1.0');
        update_post_meta($postId, '_qt_consent_age_rules', '1');
        update_post_meta($postId, '_qt_consent_publish', '1');

        if ('' !== $warnings) {
            update_post_meta($postId, '_qt_warnings', $warnings);
        }

        // The invisible layer: tag this story with the concepts it is
        // really about (religion, separation, healing…) so it can be
        // found from any room, and linked across rooms.
        Concepts::tagStory($postId);

        // Voice fingerprint: recognises a returning writer without a name
        // or an IP. The hash cannot be reversed into words.
        $hash = self::writerFingerprint($story, $room);
        if ('' !== $hash) {
            update_post_meta($postId, '_qt_writer_hash', $hash);

            $previous = self::findWriterPrevious($hash, $postId);

            if (!empty($previous)) {
                update_post_meta($postId, '_qt_writer_returning', '1');
                update_post_meta($postId, '_qt_writer_prev', array_slice($previous, 0, 5));
            }
        }

        // How many stories this voice has left — counted before the
        // cookie is bumped, so the number includes the one just held.
        $visits = self::writerCount() + 1;

        self::bumpWriterCookie($room);

        self::notifyAdmin($postId, $room);

        // Related-story suggestions are served on the confirmation page
        // through a short-lived reference to the story itself.
        $ref = wp_generate_password(8, false);
        set_transient('qt_ref_' . $ref, [
            'story_id' => $postId,
            'words'    => $wordCount,
            'visits'   => $visits,
        ], 15 * MINUTE_IN_SECONDS);

        self::$old = [];

        wp_safe_redirect(add_query_arg(
            ['qt_held' => '1', 'qt_ref' => $ref],
            wp_get_referer() ?: home_url('/')
        ));
        exit;
    }

    /* ─────────────── moderation ─────────────── */

    public static function handleApprove(): void
    {
        $postId = absint($_GET['post_id'] ?? 0);

        if (!$postId) {
            wp_die(__('No story was specified.', 'quiet-truths'));
        }

        check_admin_referer('qt_approve_' . $postId);

        $post = get_post($postId);
        if (!$post || 'qt_story' !== $post->post_type) {
            wp_die(__('That is not a story.', 'quiet-truths'));
        }
        if (!current_user_can('edit_post', $postId)) {
            wp_die(__('You are not allowed to do that.', 'quiet-truths'));
        }

        wp_update_post([
            'ID'          => $postId,
            'post_status' => 'publish',
        ]);

        wp_safe_redirect(admin_url('edit.php?post_type=qt_story&post_status=pending'));
        exit;
    }

    /**
     * One-click "Approve" on pending stories in the Quiet Stories list.
     *
     * @param array<string,string> $actions
     * @param \WP_Post             $post
     * @return array<string,string>
     */
    public static function rowActions(array $actions, $post): array
    {
        if ('qt_story' !== $post->post_type || 'pending' !== $post->post_status) {
            return $actions;
        }
        if (!current_user_can('edit_post', $post->ID)) {
            return $actions;
        }

        $url = wp_nonce_url(
            admin_url('admin-post.php?action=qt_approve_story&post_id=' . $post->ID),
            'qt_approve_' . $post->ID
        );

        $actions['qt_approve'] = sprintf(
            '<a href="%s" aria-label="%s">%s</a>',
            esc_url($url),
            esc_attr__('Approve this story and hold it publicly', 'quiet-truths'),
            esc_html__('Approve', 'quiet-truths')
        );

        return $actions;
    }

    public static function pendingNotice(): void
    {
        if (!current_user_can('edit_posts')) {
            return;
        }

        $counts  = wp_count_posts('qt_story');
        $pending = (int) ($counts->pending ?? 0);

        if ($pending < 1) {
            return;
        }

        $url = admin_url('edit.php?post_type=qt_story&post_status=pending');

        echo '<div class="notice notice-info"><p>' . wp_kses_post(sprintf(
            /* translators: %1$d number of stories, %2$s "story"/"stories", %3$s URL */
            __('%1$d %2$s waiting in the review queue, to be read and — if ready — held publicly. <a href="%3$s">Open the queue</a>.', 'quiet-truths'),
            $pending,
            _n('story', 'stories', $pending, 'quiet-truths'),
            esc_url($url)
        )) . '</p></div>';
    }

    /**
     * @param array<string,string> $columns
     * @return array<string,string>
     */
    public static function storyColumns(array $columns): array
    {
        $new = [];

        foreach ($columns as $key => $label) {
            $new[$key] = $label;
            if ('title' === $key) {
                $new['qt_writer'] = __('Writer', 'quiet-truths');
            }
        }

        return $new;
    }

    public static function storyColumnValue(string $column, int $postId): void
    {
        if ('qt_writer' !== $column) {
            return;
        }

        if ('1' === get_post_meta($postId, '_qt_writer_returning', true)) {
            $previous = get_post_meta($postId, '_qt_writer_prev', true);
            $n        = is_array($previous) ? count($previous) : 0;

            printf(
                '<span style="color:#8a6d3b;font-weight:600" title="%s">%s</span>',
                esc_attr__('This story matches the writing voice of earlier submissions.', 'quiet-truths'),
                /* translators: %d number of earlier stories by the same voice */
                esc_html(sprintf(_n('returning voice (%d earlier)', 'returning voice (%d earlier)', $n, 'quiet-truths'), $n))
            );
        } else {
            echo '<span class="qt-muted">' . esc_html__('new voice', 'quiet-truths') . '</span>';
        }
    }

    /* ─────────────── client-side privacy nudges ─────────────── */

    /**
     * Lightweight rules writer.js uses to surface gentle "this may
     * identify you" chips as the writer types. No regex is perfect;
     * server-side PrivacyScanner is the authority.
     *
     * @return array{patterns:array<string,string>,places:list<string>,workplaces:list<string>}
     */
    private static function privacyRules(): array
    {
        return [
            'patterns' => [
                'phone'  => '\\b(?:\\+?254[\\s-]?|0)[17]\\d{2}[\\s-]?\\d{3}[\\s-]?\\d{3}\\b',
                'email'  => '\\b[\\w.+-]+@[\\w-]+\\.[\\w.-]+\\b',
                'id'     => '\\b(?:id|i\\.d\\.?|national\\s+id|kra\\s*pin)\\s*[:#-]?\\s*\\d{6,9}\\b',
                'mpesa'  => '\\bm-?pesa\\b[^\\w]{0,20}[a-z0-9]{6,12}\\b',
                'social' => '\\b(?:facebook|instagram|twitter|tiktok|linkedin)\\.com\\/[^\\s<>"]+',
                'url'    => 'https?:\\/\\/[^\\s<>"]+',
            ],
            'constellation' => [
                'age'    => '\\b(?:i(?:\'m| am)|aged?\\s*)?(?:twenty|thirty|forty|fifty|[2-5][0-9])\\b',
                'gender' => '\\b(?:female|male|woman|man|mother|father|wife|husband)\\b',
                'job'    => '\\b(?:doctor|nurse|teacher|engineer|accountant|lawyer|police|soldier|farmer|driver|matatu|pastor|priest|journalist|reporter|waiter|cashier|receptionist|fundi)\\b',
                'city'   => '\\b(nairobi|mombasa|kisumu|nakuru|eldoret|thika|kitale|nyeri|kakamega|kisii|kericho|machakos|garissa|malindi|diani)\\b',
                'named_child' => '\\b(?:my\\s+(?:daughter|son|child|baby|kid)\\s+(?:called|named)\\s+[a-z][a-z]+)\\b',
                'workplace' => '\\b(safaricom|equity|kcb|kra|kenya power|jkia|strathmore|uon|kenyatta university|nairobi hospital)\\b',
            ],
            // Client only sees shortlists — a coarse nudge; the server-side
            // scanner is authoritative.
            'placeThreshold'     => 1,
            'constellationThreshold' => 3,
            'uniquenessThreshold' => 3,
            'nudgeMessages' => [
                'phone'   => __('a phone number is visible — please remove it', 'quiet-truths'),
                'email'   => __('an email address is visible — please remove it', 'quiet-truths'),
                'id'      => __('an ID/KRA PIN is visible — please remove it', 'quiet-truths'),
                'mpesa'   => __('an M-Pesa reference is visible — please remove it', 'quiet-truths'),
                'social'  => __('a social-media link is visible — please remove it', 'quiet-truths'),
                'url'     => __('a web address is visible — please consider removing it', 'quiet-truths'),
                'cluster' => __('several details together could identify you — consider softening one', 'quiet-truths'),
                'uniqueness' => __('a named detail plus your age/job/city could identify you — consider softening one', 'quiet-truths'),
            ],
        ];
    }

    /* ─────────────── writing assistant data ─────────────── */

    /**
     * Data embedded into the form so the textarea can give gentle live
     * feedback (word count, repeated words, soft profanity warning) and
     * suggest rooms the story could belong to.
     *
     * @return array{minWords:int,maxChars:int,badWords:list<string>,badPhrases:list<string>,concepts:list<array{slug:string,name:string,words:list<string>}>,rooms:array<string,string>,roomAffinity:array<string,list<string>>}
     */
    public static function writerAssistantData(): array
    {
        $bad = Responses::badWordsList();

        $concepts = [];
        foreach (Concepts::concepts() as $slug => $concept) {
            $concepts[] = [
                'slug'  => (string) $slug,
                'name'  => (string) ($concept['name'] ?? $slug),
                'words' => array_values((array) ($concept['words'] ?? [])),
            ];
        }

        $rooms = [];
        foreach (defined('QT_ROOMS') ? QT_ROOMS : [] as $slug => $room) {
            $rooms[(string) $slug] = (string) ($room['name'] ?? $slug);
        }

        $warningMap = Ai::enabled() ? Ai::warningLabels() : [];

        return [
            'minWords'     => (int) apply_filters('quiet_truths_story_min_words', 20),
            'maxChars'     => (int) apply_filters('quiet_truths_story_max_length', 4000),
            'badWords'     => array_values((array) ($bad['words'] ?? [])),
            'badPhrases'   => array_values((array) ($bad['phrases'] ?? [])),
            'concepts'     => $concepts,
            'rooms'        => $rooms,
            'roomAffinity' => Concepts::roomAffinity(),
            'warnMap'      => $warningMap,
            // Writer-protection rules are sent as plain patterns (phones, emails,
            // ID/M-PESA/social-regex strings + keyword lists) so the JS can do a
            // live client-side nudge without ever sending words to a server.
            'privacyRules' => Ai::enabled() ? self::privacyRules() : [],
        ];
    }

    /* ─────────────── confirmation data ─────────────── */

    /**
     * Everything the "your story is held" screen needs: how many stories
     * this voice has left, the word count, and related stories to read
     * while waiting.
     *
     * @return array{visits:int,words:int,related:list<\WP_Post>}
     */
    public static function confirmationData(): array
    {
        $ref  = isset($_GET['qt_ref']) ? sanitize_key(wp_unslash((string) $_GET['qt_ref'])) : '';
        $data = '' !== $ref ? get_transient('qt_ref_' . $ref) : false;
        $data = is_array($data) ? $data : [];

        $storyId = (int) ($data['story_id'] ?? 0);

        $related = $storyId > 0 ? self::relatedStories($storyId, 3) : [];

        return [
            'visits' => (int) ($data['visits'] ?? self::writerCount()),
            'words'  => (int) ($data['words'] ?? 0),
            'related'=> $related,
        ];
    }

    /* ─────────────── related stories ─────────────── */

    /**
     * Find published stories connected to the submitted one — across
     * rooms, through the invisible concept layer (shared themes) plus
     * the room they chose and word echoes.
     *
     * @return list<\WP_Post>
     */
    private static function relatedStories(int $postId, int $limit = 3): array
    {
        $story = get_post($postId);

        if (!$story) {
            return [];
        }

        $themes   = Concepts::themesOf($postId);
        $roomTerm = wp_get_object_terms($postId, 'qt_room', ['fields' => 'slugs']);
        $roomSlug = (!is_wp_error($roomTerm) && !empty($roomTerm)) ? (string) $roomTerm[0] : '';
        $keywords = self::extractKeywords((string) $story->post_content, 10);

        $pool = new \WP_Query([
            'post_type'      => 'qt_story',
            'post_status'    => 'publish',
            'posts_per_page' => 300,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ]);

        $scored = [];

        foreach ($pool->posts as $id) {
            $id = (int) $id;

            if ($id === $postId) {
                continue;
            }

            $post = get_post($id);

            if (!$post) {
                continue;
            }

            $score = 0;

            // The invisible layer: shared concepts connect stories
            // across different rooms.
            $otherThemes = Concepts::themesOf($id);
            foreach ($themes as $theme) {
                if (in_array($theme, $otherThemes, true)) {
                    $score += 5;
                }
            }

            $otherTerms = get_the_terms($id, 'qt_room');
            $otherRoom  = (!is_wp_error($otherTerms) && !empty($otherTerms)) ? $otherTerms[0]->slug : '';
            if ('' !== $roomSlug && $roomSlug === $otherRoom) {
                $score += 3;
            }

            $text = mb_strtolower((string) $post->post_title . ' ' . $post->post_content, 'UTF-8');
            foreach ($keywords as $kw) {
                if ('' !== $kw && str_contains($text, $kw)) {
                    $score += 1;
                }
            }

            if ($score > 0 && \QuietTruths\Core\Ai::enabled()) {
                $score = (float) $score;
                $score = apply_filters('quiet_truths_similar_extra_score', $score, $postId, $id);
                $score = (int) round($score);
            }

            if ($score > 0) {
                $scored[$id] = $score;
            }
        }

        arsort($scored);

        $related = [];
        foreach (array_slice(array_keys($scored), 0, $limit, true) as $id) {
            $post = get_post($id);
            if ($post) {
                $related[] = $post;
            }
        }

        return $related;
    }

    /* ─────────────── writer fingerprint ─────────────── */

    /**
     * How many stories this browser's voice has left.
     */
    public static function writerCount(): int
    {
        if (empty($_COOKIE[self::WRITER_COOKIE])) {
            return 0;
        }

        $data = json_decode(stripslashes((string) $_COOKIE[self::WRITER_COOKIE]), true);

        return is_array($data) ? (int) ($data['n'] ?? 0) : 0;
    }

    private static function bumpWriterCookie(string $room): void
    {
        $n = self::writerCount() + 1;

        // SameSite=Lax so the cookie survives modern browser defaults.
        if (PHP_VERSION_ID >= 70300) {
            setcookie(self::WRITER_COOKIE, wp_json_encode(['n' => $n, 'room' => $room]), [
                'expires'  => time() + 365 * DAY_IN_SECONDS,
                'path'     => (string) COOKIEPATH,
                'domain'   => (string) (COOKIE_DOMAIN ?: ''),
                'secure'   => is_ssl(),
                'httponly' => false,
                'samesite' => 'Lax',
            ]);
        } else {
            setcookie(
                self::WRITER_COOKIE,
                wp_json_encode(['n' => $n, 'room' => $room]),
                time() + 365 * DAY_IN_SECONDS,
                COOKIEPATH . '; SameSite=Lax',
                (string) (COOKIE_DOMAIN ?: ''),
                is_ssl(),
                false
            );
        }
    }

    /**
     * A wordless digest of writing style: frequent words, sentence length,
     * vocabulary richness, punctuation, length bucket, room. Salted with
     * the site's auth key so it can never be reversed into the words.
     */
    private static function writerFingerprint(string $story, string $room): string
    {
        $words = self::contentWords($story);

        if (count($words) < 5) {
            return '';
        }

        $freq = array_count_values($words);
        arsort($freq);
        $top = array_slice(array_keys($freq), 0, 8);

        $bigrams = [];
        for ($i = 0; $i < count($words) - 1 && count($bigrams) < 3; $i++) {
            $pair = $words[$i] . ' ' . $words[$i + 1];
            $bigrams[$pair] = ($bigrams[$pair] ?? 0) + 1;
        }
        arsort($bigrams);
        $topBigrams = array_slice(array_keys($bigrams), 0, 3);

        $sentences = preg_split('/[.!?]+/u', trim($story));
        $sentences = array_values(array_filter(array_map('trim', $sentences)));
        $avgSent   = count($sentences) > 0 ? round(count($words) / count($sentences), 1) : 0;

        $avgLen = round(array_sum(array_map('strlen', $words)) / max(1, count($words)), 1);
        $punct  = round(strlen((string) preg_replace('/[^\p{P}]/u', '', $story)) / max(1, self::strLen($story)), 2);
        $vocab  = round(count($freq) / max(1, count($words)), 2);

        $features = implode('|', [
            implode(',', $top),
            implode('|', $topBigrams),
            (string) $avgLen,
            (string) $avgSent,
            (string) $punct,
            (string) $vocab,
            (string) (int) floor(self::strLen($story) / 400),
            $room,
        ]);

        return hash_hmac('sha256', $features, (string) wp_salt('auth'));
    }

    /**
     * Stories previously written in the same voice (same fingerprint).
     *
     * @return list<int>
     */
    private static function findWriterPrevious(string $hash, int $exceptId): array
    {
        $query = new \WP_Query([
            'post_type'      => 'qt_story',
            'post_status'    => ['publish', 'pending'],
            'posts_per_page' => 300,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'meta_query'     => [
                ['key' => '_qt_writer_hash', 'value' => $hash, 'compare' => '='],
            ],
        ]);

        $previous = [];

        foreach ($query->posts as $id) {
            if ((int) $id !== $exceptId) {
                $previous[] = (int) $id;
            }
        }

        return $previous;
    }

    /* ─────────────── helpers ─────────────── */

    private static function passesRate(string $keyPrefix, int $limit, int $window): bool
    {
        if ($limit < 1) {
            return true;
        }

        $key   = $keyPrefix . md5((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
        $count = (int) get_transient($key);

        if ($count >= $limit) {
            return false;
        }

        set_transient($key, $count + 1, $window);
        return true;
    }

    public static function countWords(string $text): int
    {
        $words = preg_split('/\s+/u', trim($text)) ?: [];

        return count(array_filter($words, static fn ($w) => '' !== $w));
    }

    /**
     * Words that carry meaning (stopwords removed), for keywords.
     *
     * @return list<string>
     */
    private static function contentWords(string $text): array
    {
        $words = preg_split('/[^a-z]+/u', mb_strtolower($text, 'UTF-8')) ?: [];
        $words = array_values(array_filter($words, static fn (string $w) => strlen($w) >= 3));

        $stop = self::stopwords();

        return array_values(array_filter($words, static fn (string $w) => !isset($stop[$w])));
    }

    /**
     * @return list<string> Top meaningful words, most frequent first.
     */
    private static function extractKeywords(string $text, int $limit = 12): array
    {
        $words = self::contentWords($text);

        if (empty($words)) {
            return [];
        }

        $freq = array_count_values($words);
        arsort($freq);

        return array_slice(array_keys($freq), 0, $limit);
    }

    /**
     * @return array<string,bool>
     */
    private static function stopwords(): array
    {
        static $stop = null;

        if (null === $stop) {
            $list = [
                'the', 'and', 'that', 'this', 'these', 'those', 'with', 'from', 'have', 'has', 'had',
                'was', 'were', 'been', 'being', 'will', 'would', 'could', 'should', 'shall', 'can',
                'may', 'might', 'must', 'not', 'but', 'for', 'are', 'was', 'you', 'your', 'yours',
                'they', 'them', 'their', 'there', 'here', 'when', 'then', 'than', 'what', 'which',
                'who', 'whom', 'about', 'into', 'over', 'after', 'before', 'between', 'during',
                'because', 'while', 'where', 'why', 'how', 'all', 'any', 'some', 'more', 'most',
                'other', 'such', 'only', 'own', 'same', 'too', 'very', 'just', 'like', 'also',
                'even', 'every', 'each', 'few', 'both', 'one', 'two', 'first', 'last', 'again',
                'once', 'upon', 'off', 'out', 'up', 'down', 'in', 'on', 'at', 'by', 'to', 'of',
                'a', 'an', 'i', 'me', 'my', 'we', 'our', 'us', 'he', 'him', 'his', 'she', 'her',
                'it', 'its', 'they', 'im', 'ive', 'id', 'youre', 'youve', 'youll', 'dont', 'cant',
                'wont', 'isnt', 'wasnt', 'werent', 'havent', 'hasnt', 'didnt', 'doesnt', 'couldnt',
                'wouldnt', 'shouldnt', 'it\'s', 'i\'m', 'i\'ve', 'don\'t', 'can\'t', 'won\'t',
            ];
            $stop = array_fill_keys($list, true);
        }

        return $stop;
    }

    private static function makeTitle(string $story): string
    {
        $words = preg_split('/\s+/u', trim($story)) ?: [];
        $title = rtrim(implode(' ', array_slice($words, 0, 8)), '.,;:!?');
        $title = self::strSubstr($title, 0, 90);

        return '' !== $title
            ? $title
            : sprintf(__('A story held on %s', 'quiet-truths'), wp_date('j M Y'));
    }

    private static function notifyAdmin(int $postId, string $room): void
    {
        $to = get_option('admin_email');
        if (empty($to)) {
            return;
        }

        $subject = sprintf('[%s] %s', get_bloginfo('name'), __('A new story awaits your care', 'quiet-truths'));
        $preview = self::strSubstr(wp_strip_all_tags((string) get_post_field('post_content', $postId)), 0, 240);

        $body = sprintf(
            /* translators: %1$s room name, %2$s story preview, %3$s queue URL */
            __("Someone left a story in the room “%1$s”.\n\n%2$s\n\nIt is waiting in the review queue:\n%3$s", 'quiet-truths'),
            $room,
            $preview,
            admin_url('edit.php?post_type=qt_story&post_status=pending')
        );

        if (!wp_mail($to, $subject, $body)) {
            error_log('Quiet Truths: admin notification for story ' . $postId . ' could not be sent.');
        }
    }

    private static function strLen(string $s): int
    {
        return function_exists('mb_strlen') ? mb_strlen($s) : strlen($s);
    }

    private static function strSubstr(string $s, int $start, ?int $length = null): string
    {
        if (function_exists('mb_substr')) {
            return null === $length ? mb_substr($s, $start) : mb_substr($s, $start, $length);
        }
        return null === $length ? substr($s, $start) : substr($s, $start, $length);
    }
}
