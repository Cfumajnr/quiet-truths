<?php
/**
 * Quiet Truths — Concepts
 *
 * The invisible layer beneath the rooms. Every story is quietly tagged
 * with the concepts it is really about (religion, relationships,
 * separation, grief…) — the user never sees these as navigation.
 *
 * The tags power:
 *  - semantic search across rooms ("muslim" → stories about religion)
 *  - related-story links between stories in different rooms
 *  - room suggestions while a story is being written
 *
 * Privacy: the tags are derived from the story's own words and stored
 * only as slugs on the story. No personal data is involved.
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Concepts
{
    /** @var array<string,mixed>|null */
    private static ?array $data = null;

    public static function init(): void
    {
        add_action('save_post_qt_story', [self::class, 'onStorySave'], 20, 2);
        add_action('save_post_qt_journal', [self::class, 'onStorySave'], 20, 2);
        add_action('init', [self::class, 'maybeBackfill']);
    }

    /* ─────────────── knowledge base ─────────────── */

    /**
     * @return array{concepts:array<string,array{name:string,words:list<string>}>,rooms:array<string,list<string>>}
     */
    public static function data(): array
    {
        if (null === self::$data) {
            $path = dirname(__DIR__) . '/config/concepts.php';

            if (is_file($path)) {
                $loaded = require $path;
                self::$data = is_array($loaded) ? $loaded : [];
            } else {
                self::$data = [];
            }
        }

        return self::$data;
    }

    /** @return array<string,array{name:string,words:list<string>}> */
    public static function concepts(): array
    {
        $data = self::data();

        return (array) ($data['concepts'] ?? []);
    }

    /**
     * Room → concept-slug list for the writer-facing live-suggestion UI.
     * Reads from the CANONICAL room definitions (app/config/rooms.php via
     * Config) so the UI inherits updates to the room ontology without
     * maintaining a parallel map.
     *
     * @return array<string,list<string>>
     */
    public static function roomAffinity(): array
    {
        $out = [];
        foreach (Config::instance()->roomSpecs() as $slug => $spec) {
            if (!is_array($spec)) continue;
            $out[(string) $slug] = array_values(array_filter(
                array_map('strval', (array) ($spec['concepts'] ?? []))
            ));
        }
        return $out;
    }

    /**
     * Extract the human-assigned room slug from an AI profile. Understands
     * both the new v5 shape (rooms.assigned) and the older flat array
     * (rooms = [slugs]) so consumers never have to branch.
     */
    public static function assignedRoomFromProfile(array $profile): ?string
    {
        $rooms = $profile['rooms'] ?? [];
        if (is_array($rooms) && isset($rooms['assigned'])) {
            return $rooms['assigned'] ?: null;
        }
        if (is_array($rooms) && !empty($rooms)) {
            // Older flat-list shape — return the first slug.
            foreach ($rooms as $r) {
                if (is_string($r) && '' !== $r) {
                    return $r;
                }
            }
        }
        return null;
    }

    /**
     * Return all room slugs that a story has meaningful resonance with:
     * the assigned room + any secondary AI resonances.
     *
     * @return list<string>
     */
    public static function resonantRoomsFromProfile(array $profile): array
    {
        $out = [];
        $rooms = $profile['rooms'] ?? [];
        if (is_array($rooms)) {
            if (!empty($rooms['assigned'])) {
                $out[] = (string) $rooms['assigned'];
            }
            foreach ((array) ($rooms['secondary'] ?? []) as $sec) {
                if (is_array($sec) && !empty($sec['slug'])) {
                    $out[] = (string) $sec['slug'];
                }
            }
        } elseif (is_array($rooms)) {
            foreach ($rooms as $r) {
                if (is_string($r) && '' !== $r) $out[] = $r;
            }
        }
        return array_values(array_unique(array_filter($out)));
    }

    /**
     * word → [concept slugs] — built once from the knowledge base.
     * Includes Swahili stem variants (prefix-stripped) so conjugated
     * verbs like "anafanikiwa" or "nimejificha" still find their
     * concepts.
     *
     * @return array<string,list<string>>
     */
    public static function wordMap(): array
    {
        static $map = null;

        if (null === $map) {
            $map = [];

            foreach (self::concepts() as $slug => $concept) {
                foreach ((array) ($concept['words'] ?? []) as $word) {
                    $word = mb_strtolower(trim((string) $word), 'UTF-8');

                    if ('' === $word) {
                        continue;
                    }

                    $map[$word][] = $slug;

                    // Swahili/Sheng: also index the prefix-stripped stem,
                    // so conjugated forms match (kufanikiwa → fanikiwa).
                    $stem = self::swahiliStem($word);
                    if ('' !== $stem && $stem !== $word) {
                        $map[$stem][] = $slug;
                    }
                }
            }
        }

        return $map;
    }

    /**
     * Common Swahili verbal/nominal prefixes, longest first.
     */
    private static function swahiliPrefixes(): array
    {
        return [
            'kujik', 'kuji', 'kuku', 'kuna', 'wana', 'wame', 'nime', 'ume', 'ame',
            'tuna', 'tume', 'mna', 'nina', 'ana', 'una', 'ina', 'zina', 'kina',
            'kuwa', 'kuto', 'kupa', 'kuam', 'kuji',
            'ku', 'ki', 'vi', 'ma', 'mi', 'mu', 'ji', 'zi', 'ya', 'za',
            'wa', 'ni', 'u', 'a', 'i', 'na', 'me', 'ta', 'li', 'si', 'ha', 'n', 'm',
        ];
    }

    /**
     * Strip the longest Swahili prefix from a word, leaving ≥3 chars.
     */
    private static function swahiliStem(string $word): string
    {
        foreach (self::swahiliPrefixes() as $prefix) {
            if (strlen($prefix) < 3) {
                continue; // single/double-letter prefixes are too risky
            }

            if (str_starts_with($word, $prefix) && strlen($word) - strlen($prefix) >= 3) {
                return substr($word, strlen($prefix));
            }
        }

        return $word;
    }

    /* ─────────────── detection & tagging ─────────────── */

    /**
     * Which concepts a text is about. A concept counts when at least
     * two of its words appear (after normalisation); multi-word
     * phrases (e.g. "sukuma wiki", "let go") match directly.
     *
     * @return list<string>
     */
    public static function detect(string $text, int $limit = 4): array
    {
        $normal = Responses::normalise($text);
        $tokens = preg_split('/[^a-z]+/u', $normal) ?: [];
        $tokens = array_filter($tokens, static fn (string $w) => strlen($w) >= 3);

        $scores = [];

        foreach (array_unique($tokens) as $token) {
            // Exact match first, then the Swahili prefix-stripped stem.
            foreach (self::wordMap()[$token] ?? [] as $slug) {
                $scores[$slug] = ($scores[$slug] ?? 0) + 1;
            }

            $stem = self::swahiliStem($token);
            if ($stem !== $token) {
                foreach (self::wordMap()[$stem] ?? [] as $slug) {
                    $scores[$slug] = ($scores[$slug] ?? 0) + 1;
                }
            }
        }

        // Multi-word entries match as whole phrases.
        foreach (self::concepts() as $slug => $concept) {
            foreach ((array) ($concept['words'] ?? []) as $word) {
                $word = mb_strtolower(trim((string) $word), 'UTF-8');

                if ('' === $word || !str_contains($word, ' ')) {
                    continue;
                }
                if (str_contains($normal, $word)) {
                    $scores[$slug] = ($scores[$slug] ?? 0) + 2;
                }
            }
        }

        arsort($scores);

        $out = [];
        foreach ($scores as $slug => $count) {
            if ($count >= 2) {
                $out[] = $slug;
            }
            if (count($out) >= $limit) {
                break;
            }
        }

        // Allow AI layer (or any future module) to deepen concept
        // detection with phrase/embedding signals.
        $out = array_values(array_unique(apply_filters(
            'quiet_truths_detected_concepts',
            $out,
            $text
        )));

        return array_slice($out, 0, $limit);
    }

    /**
     * Tag a story with its concepts (stored as a list in _qt_themes).
     */
    public static function tagStory(int $postId): void
    {
        $post = get_post($postId);

        if (!$post) {
            return;
        }

        $text  = (string) $post->post_title . ' ' . (string) $post->post_content;
        $slugs = self::detect($text);

        update_post_meta($postId, '_qt_themes', $slugs);
    }

    /**
     * Stories like this one — across rooms, through the invisible layer.
     * Shared concepts weigh most; the same room and word echoes count
     * less. Rooms never limit what is "next".
     *
     * @return list<\WP_Post>
     */
    public static function similarStories(int $postId, int $limit = 3): array
    {
        $post = get_post($postId);

        if (!$post) {
            return [];
        }

        $themes   = self::themesOf($postId);
        $keywords = self::topWords((string) $post->post_content, 10);

        $roomTerm = wp_get_object_terms($postId, 'qt_room', ['fields' => 'slugs']);
        $roomSlug = (!is_wp_error($roomTerm) && !empty($roomTerm)) ? (string) $roomTerm[0] : '';

        $pool = new \WP_Query([
            'post_type'      => 'qt_story',
            'post_status'    => 'publish',
            'posts_per_page' => 300,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ]);

        $scored = [];

        foreach ($pool->posts as $id) {
            $id = (int) $id;

            if ($id === $postId) {
                continue;
            }

            $candidate = get_post($id);

            if (!$candidate) {
                continue;
            }

            $score = 0;

            // The invisible layer: shared concepts connect rooms.
            $otherThemes = self::themesOf($id);
            foreach ($themes as $theme) {
                if (in_array($theme, $otherThemes, true)) {
                    $score += 6;
                }
            }

            // Same room is a hint, not a limit.
            $otherTerms = get_the_terms($id, 'qt_room');
            $otherRoom  = (!is_wp_error($otherTerms) && !empty($otherTerms)) ? $otherTerms[0]->slug : '';
            if ('' !== $roomSlug && $roomSlug === $otherRoom) {
                $score += 2;
            }

            // Word echoes between the two stories.
            $text = mb_strtolower((string) $candidate->post_title . ' ' . $candidate->post_content, 'UTF-8');
            foreach ($keywords as $kw) {
                if ('' !== $kw && str_contains($text, $kw)) {
                    $score += 1;
                }
            }

            // AI resonance — small boost for felt similarity, never
            // overrides the explicit signals above.
            if ($score > 0 && Ai::enabled()) {
                $score = (float) $score;
                $score = apply_filters('quiet_truths_similar_extra_score', $score, $postId, $id);
                $score = (int) round($score);
            }

            if ($score > 0) {
                $scored[$id] = $score;
            }
        }

        arsort($scored);

        $similar = [];
        foreach (array_slice(array_keys($scored), 0, $limit, true) as $id) {
            $post = get_post($id);
            if ($post) {
                $similar[] = $post;
            }
        }

        return $similar;
    }

    /**
     * The most distinctive words of a text (stopwords removed), most
     * frequent first.
     *
     * @return list<string>
     */
    public static function topWords(string $text, int $limit = 10): array
    {
        $words = preg_split('/[^a-z]+/u', mb_strtolower($text, 'UTF-8')) ?: [];
        $words = array_values(array_filter($words, static fn (string $w) => strlen($w) >= 3));

        $stop = [
            'the','and','that','this','these','those','with','from','have','has','had','was',
            'were','been','being','will','would','could','should','shall','can','may','might',
            'must','not','but','for','are','you','your','they','them','their','there','here',
            'when','then','than','what','which','who','whom','about','into','over','after',
            'before','between','during','because','while','where','why','how','all','any',
            'some','more','most','other','such','only','own','same','too','very','just','like',
            'also','even','every','each','few','both','one','two','first','last','again','once',
            'upon','off','out','up','down','in','on','at','by','to','of','a','an','i','me','my',
            'we','our','us','he','him','his','she','her','it','its','im','ive','id','dont',
            'cant','wont','isnt','wasnt','werent','havent','hasnt','didnt','doesnt','couldnt',
            'wouldnt','shouldnt',
        ];

        $freq = [];

        foreach ($words as $word) {
            if (in_array($word, $stop, true)) {
                continue;
            }
            $freq[$word] = ($freq[$word] ?? 0) + 1;
        }

        arsort($freq);

        return array_slice(array_keys($freq), 0, $limit);
    }

    /**
     * The Journal that continues a story's conversation — the published
     * journal with the most shared concepts. Null when none exist or
     * none share a theme.
     */
    public static function relatedJournal(int $postId): ?\WP_Post
    {
        $themes = self::themesOf($postId);

        if (empty($themes)) {
            return null;
        }

        $journalIds = get_posts([
            'post_type'      => 'qt_journal',
            'post_status'    => 'publish',
            'posts_per_page' => 100,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ]);

        $best    = null;
        $bestHit = 0;

        foreach ($journalIds as $jid) {
            $jid     = (int) $jid;
            $jThemes = self::themesOf($jid);

            // Untagged journal: detect on the fly so the bridge works
            // even before a backfill.
            if (empty($jThemes)) {
                $jPost = get_post($jid);

                if ($jPost) {
                    $jThemes = self::detect((string) $jPost->post_title . ' ' . (string) $jPost->post_content);
                }
            }

            $shared = count(array_intersect($themes, $jThemes));

            if ($shared > $bestHit) {
                $bestHit = $shared;
                $best    = get_post($jid);
            }
        }

        return $best;
    }

    /**
     * @return list<string>
     */
    public static function themesOf(int $postId): array
    {
        $themes = get_post_meta($postId, '_qt_themes', true);

        return is_array($themes) ? $themes : [];
    }

    public static function onStorySave(int $postId, $post): void
    {
        if (!in_array(($post->post_type ?? ''), ['qt_story', 'qt_journal'], true)) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (wp_is_post_revision($postId) || wp_is_post_autosave($postId)) {
            return;
        }

        self::tagStory($postId);
    }

    /**
     * Re-tag everything once when the knowledge base changes, so the
     * invisible layer stays in step with the house's memory.
     */
    public static function maybeBackfill(): void
    {
        $path = dirname(__DIR__) . '/config/concepts.php';
        $sig  = is_file($path) ? (string) filesize($path) . '-' . (string) filemtime($path) : 'none';

        if (get_option('qt_concepts_sig') === $sig) {
            return;
        }

        $stories = new \WP_Query([
            'post_type'      => 'qt_story',
            'post_status'    => ['publish', 'pending'],
            'posts_per_page' => 500,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ]);

        foreach ($stories->posts as $id) {
            self::tagStory((int) $id);
        }

        update_option('qt_concepts_sig', $sig);
    }
}
