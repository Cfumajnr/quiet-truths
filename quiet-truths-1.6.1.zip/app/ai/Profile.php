<?php
/**
 * Quiet Truths — AI Story Profile
 *
 * Single source of truth for everything the AI knows about a story.
 *
 * IMPORTANT: the READ PATH is read-only. Profile::get() never initiates
 * network calls or expensive computation. If a profile doesn't exist
 * (or is from an older schema, or was built by a different model class),
 * get() returns a LIGHTWEIGHT FALLBACK built from already-persisted
 * meta + fast lexical checks. Building the full profile (embeddings,
 * semantic concept scores) is the job of Profile::build()/warm(),
 * called only from the background worker or WP-CLI.
 *
 * Schema (v5) — the Ontology:
 *
 *   identity     — post_id, language
 *   observations — hard facts: word count, direct flags, named-child,
 *                  workplace, school, place, signals
 *   semantic     — embedding_model, embedding_dim, has_embedding
 *
 *   // The four ontology layers
 *   rooms        — room affinity scores (slug => 0..1). 'primary' is
 *                  the librarian's strongest suggestion; 'secondary'
 *                  are cross-resonances above SECONDARY_THRESHOLD.
 *                  'assigned' is the human-chosen room (from taxonomy)
 *                  and always wins for public placement.
 *   concepts     — what the story is about (slug => score)
 *   signals      — human texture:
 *                    emotional     (grief, longing, joy, shame, fear, ...)
 *                    relationship  (mother, father, child, deceased, ...)
 *                    time          (childhood, recent, long_past, ...)
 *                    context       (poverty_hardship, illness, work, ...)
 *                    communication (unsent_letter, apology, confession,
 *                                   address_to_deceased, address_to_younger_self, ...)
 *   relationships— typed relations to other stories (filled by StoryRelations)
 *
 *   // Reader-facing
 *   content      — warnings
 *   privacy      — risk_score + observations + writer_warnings
 *
 *   // Administrative notes (not published, not shown in HTML):
 *   editorial    — semantic_affinity vs editorial_prevalence kept
 *                  separate. Heavy Hearts gravity is semantic (0.02
 *                  bias), not a popularity weight. Counts of how many
 *                  stories landed in each room are tracked elsewhere
 *                  (operational stats), never used to bias scoring.
 *
 *   confidence   — 0..1
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

use QuietTruths\Core\Concepts;

final class Profile
{
    public const META_KEY = '_qt_ai_profile';

    /**
     * Bump when profile SHAPE changes. Existing profiles below this
     * version are considered stale.
     *
     * v6 adds:
     *   - semantic.mode ('dense'|'lexical') — honest flag for which
     *     embedding path produced the affinity scores on THIS build.
     *   - semantic.raw_similarities.{rooms,threads} — best raw cosine per
     *     room/thread BEFORE the (cos - 0.25)/0.40 remap, for calibration.
     *   - rooms.raw / threads.raw diagnostic blocks.
     *   - semantic_build block (mode / complete / retryable) — an explicit
     *     declaration of what kind of build this was, so warm() and future
     *     consumers can authoritatively decide whether to persist it over
     *     an existing good dense profile. This is the lifecycle guard
     *     that prevents a transient BGE-M3 outage from demoting a good
     *     dense profile to lexical.
     */
    public const SCHEMA_VERSION = 6;

    public const FRESH = 'fresh';
    public const STALE = 'stale';

    /**
     * Meta key for the rebuild-request flag. This is SEPARATE from the
     * profile's own _status:
     *   _status             — QUALITY of the stored profile.
     *                         FRESH  = built by a full build() run with
     *                                  whatever semantic mode was
     *                                  achievable; safe to serve, safe
     *                                  to use for editorial/SQL/related-
     *                                  story work. Does NOT guarantee
     *                                  the content hasn't changed since
     *                                  — see `source` below for that.
     *                         STALE  = provisional (lexical fallback
     *                                  for a brand-new post whose dense
     *                                  build hasn't landed yet, or a
     *                                  pre-migration profile).
     *   _rebuild_pending    — boolean flag; true means a background
     *                         (re)build has been requested and not yet
     *                         completed.
     *   source              — provenance: which post_modified_gmt and
     *                         content_hash this profile was built
     *                         against, and when it was built. With
     *                         this, consumers can tell the difference
     *                         between "this is a fresh profile for the
     *                         current content" and "this is a still-
     *                         good older profile, a rebuild is queued
     *                         for the new revision."
     *
     * v1.5.8 correction: FRESH no longer claims to describe current
     * content. FRESH describes build quality; source describes currency.
     * On edit we set _rebuild_pending=true WITHOUT demoting the FRESH
     * profile, and source.is_current will report false until the new
     * build lands atomically. STALE is reserved for genuinely provi-
     * sional profiles (lexical-first-build), not for "edit happened.
     */
    public const REBUILD_PENDING_KEY = '_qt_ai_rebuild_pending';

    /**
     * READ-ONLY access to a post's stored profile. NEVER computes embeddings
     * or makes HTTP calls. If nothing is stored, returns a fast lexical
     * fallback so consumers always have something to work with.
     *
     * @return array<string,mixed>
     */
    public static function get(int $postId): array
    {
        $post = get_post($postId);
        if (!$post) {
            return [];
        }

        $raw = get_post_meta($postId, self::META_KEY, true);

        $schemaOk = is_array($raw) && !empty($raw)
            && (int) ($raw['schema_version'] ?? 0) >= self::SCHEMA_VERSION;

        // Valid profile (schema matches) → return it. FRESH profiles are
        // served unconditionally, even while a rebuild is pending — the
        // rebuild flag means "a new build is wanted," not "the current
        // profile is bad." STALE profiles are returned too (readers
        // always get the last usable profile), but consumers may down-
        // weight them or annotate them as provisional.
        if ($schemaOk) {
            return $raw;
        }

        // Missing or schema-too-old → return a lightweight lexical
        // fallback. This is read-only and does not hit the service.
        return self::lightweightFallback($post);
    }

    /**
     * Is a profile ready for downstream consumers (related stories,
     * search, editorial view)?
     *
     * "Ready" means BUILD QUALITY, not currency:
     *   - requireDense=false: any schema-current FRESH profile counts,
     *     even if a rebuild is pending for a newer revision. The
     *     existing profile is still a useful, well-formed reading of
     *     (some recent version of) the story.
     *   - requireDense=true : also requires the stored vector to be a
     *     dense model vector (used for consumers that NEED cosine over
     *     dense vectors, e.g. semantic search).
     *
     * Consumers that need to know whether the profile matches the
     * CURRENT content (as opposed to a still-good previous revision)
     * should call Profile::isCurrent($id) separately.
     */
    public static function isReady(int $postId, bool $requireDense = false): bool
    {
        $raw = get_post_meta($postId, self::META_KEY, true);
        if (!is_array($raw) || empty($raw)) return false;
        if ((int) ($raw['schema_version'] ?? 0) < self::SCHEMA_VERSION) return false;
        if (($raw['_status'] ?? self::FRESH) !== self::FRESH) return false;
        if ($requireDense && Embeddings::embeddingStatus($postId) !== Embeddings::STATUS_DENSE) return false;
        return true;
    }

    /**
     * Is a background rebuild currently queued/in-flight for this post?
     * Exposed so readers/editors can show a gentle "refreshing" note
     * without being forced to treat the live profile as bad data.
     */
    public static function rebuildPending(int $postId): bool
    {
        return (bool) get_post_meta($postId, self::REBUILD_PENDING_KEY, true);
    }

    /**
     * Mark an existing profile as STALE (without deleting it). Use this
     * when the stored profile is known to be a bad representation of the
     * content — e.g. a lexical fallback persisted because the service
     * was down on first publish, or a pre-v6 profile that has not yet
     * been rebuilt. STALE is a statement ABOUT the stored profile, not
     * about whether work is queued.
     *
     * Do NOT call this on every content edit; call requestRebuild()
     * instead, which leaves a FRESH profile FRESH while a new build
     * runs.
     */
    public static function markStale(int $postId): void
    {
        $raw = get_post_meta($postId, self::META_KEY, true);
        if (!is_array($raw) || empty($raw)) {
            return;
        }
        if (($raw['_status'] ?? self::FRESH) !== self::STALE) {
            $raw['_status'] = self::STALE;
            update_post_meta($postId, self::META_KEY, $raw);
        }
    }

    /**
     * Request a background rebuild WITHOUT demoting the existing stored
     * profile. This is the correct call on content edit/publish: the
     * existing good profile (if any) stays FRESH and keeps serving
     * readers until an atomic replacement lands; we only set the
     * rebuild-pending flag so the background worker knows work is
     * wanted.
     */
    public static function requestRebuild(int $postId): void
    {
        update_post_meta($postId, self::REBUILD_PENDING_KEY, true);
    }

    /**
     * BUILD the full profile. May call the embedding service. Call only
     * from background / CLI contexts.
     *
     * @return array<string,mixed>
     */
    public static function build(\WP_Post $post): array
    {
        $text     = (string) $post->post_title . "\n\n" . (string) $post->post_content;
        $themes   = Concepts::themesOf($post->ID);
        $under    = StoryUnderstanding::understand($text, $themes);
        $priv     = PrivacyScanner::scan($text);
        $signals  = Signals::forText($text);
        $warnings = ContentSignals::warningsFor($text);
        $assignedRooms = wp_get_object_terms($post->ID, 'qt_room', ['fields' => 'slugs']);
        $assignedRooms = is_wp_error($assignedRooms) ? [] : (array) $assignedRooms;
        $assignedRoom  = !empty($assignedRooms) ? (string) $assignedRooms[0] : null;

        $conceptScores = (array) ($under['concept_scores'] ?? []);

        // ── ONE-BATCH SEMANTIC EMBED ──────────────────────────────
        // Story text + all room prototypes + all thread prototypes go
        // to the embeddings service in a SINGLE HTTP call when the
        // prototype caches are cold. When the caches are warm (the
        // common case), the prototypes come from wp_options and only
        // the story is embedded — one HTTP call per story total, not
        // 18 (previously: 1 story + 7 room proto batches + 10 thread
        // proto batches = 18 calls).
        $roomProtos   = RoomAffinity::allPrototypes();
        $threadProtos = ThreadInference::allPrototypes();
        [$storyVec, $roomProtoVecs, $threadProtoVecs, $semanticMode] =
            PrototypeCache::embedStoryAndPrototypes($text, $roomProtos, $threadProtos);

        // ── Room affinity (semantic when dense, lexical otherwise) ──
        $roomResult   = RoomAffinity::score($text, $conceptScores, $signals, $storyVec, $roomProtoVecs);
        $roomAffinity = (array) $roomResult['affinity'];
        $roomRaw      = (array) ($roomResult['raw'] ?? []);
        $roomPS       = RoomAffinity::primarySecondary($roomAffinity);

        // ── Threads (cross-cutting invisible textures) ──
        $threadResult = ThreadInference::scoreThreads($text, $conceptScores, $signals, $storyVec, $threadProtoVecs);
        $threadScores = (array) $threadResult['scores'];
        $threadRaw    = (array) ($threadResult['raw'] ?? []);
        $activeThreads = [];
        foreach ($threadScores as $slug => $score) {
            if ($score >= ThreadInference::THREAD_THRESHOLD) {
                $activeThreads[$slug] = round((float) $score, 2);
            }
        }

        // Hard observations (facts, not interpretations).
        $directFlags = self::filterBySeverity($priv['flags'] ?? [], ['critical','high']);
        $contextFlags = self::filterBySeverity($priv['flags'] ?? [], ['medium','low']);
        $observations = [
            'word_count'           => (int) (get_post_meta($post->ID, '_qt_words', true) ?: self::countWords($text)),
            'has_phone'            => self::hasKind($directFlags, 'phone'),
            'has_email'            => self::hasKind($directFlags, 'email'),
            'has_id_number'        => self::hasKind($directFlags, 'id_number'),
            'has_mpesa'            => self::hasKind($directFlags, 'mpesa'),
            'has_social'           => self::hasKind($directFlags, 'social'),
            'has_url'              => self::hasKind($priv['flags'] ?? [], 'url'),
            'has_named_workplace'  => self::hasKind($contextFlags, 'workplace'),
            'has_named_school'     => self::hasKind($contextFlags, 'school'),
            'has_named_place'      => self::hasKind($contextFlags, 'place'),
            'has_named_child'      => self::hasKind($contextFlags, 'named_child') || self::hasKind($contextFlags, 'child'),
            'has_age_signal'       => (bool) preg_match('/\b(?:twenty|thirty|forty|fifty|[2-5][0-9])\b/u', $text),
            'has_gender_signal'    => (bool) preg_match('/\b(?:female|male|woman|man|mother|father|wife|husband)\b/u', $text),
            'has_city_signal'      => self::citySignal($text),
            'communication_mode'   => self::primaryCommunicationMode($signals['communication'] ?? []),
        ];

        $vectorMeta = self::vectorMetaFor($post->ID);

        // ── SEMANTIC BUILD DECLARATION ─────────────────────────────
        // This block is the AUTHORITATIVE contract for what kind of
        // build this run produced. warm() uses it to decide whether
        // to persist this profile over an existing good one.
        //
        //   mode       — 'dense'  : embedDense() succeeded; storyVec is
        //                           a validated dense BGE-M3 vector;
        //                           all prototype comparisons are dense.
        //                'lexical': embedDense() failed or service was
        //                           unavailable; scoring used token
        //                           vectors / lexical evidence only.
        //   complete   — true ONLY when mode==='dense'. Only a complete
        //                dense build is allowed to replace a previously
        //                stored dense profile. (Lifecycle rule: a good
        //                dense profile must never be demoted by a
        //                transient service outage.)
        //   retryable  — true when the build fell back to lexical
        //                because of a transient service failure; the
        //                background worker should try again later.
        $hasStoredDense = !empty($vectorMeta['has_embedding']);
        if ($semanticMode === 'dense') {
            $embStatus     = Embeddings::STATUS_DENSE;
            $semanticBuild = [
                'mode'      => 'dense',
                'complete'  => true,
                'retryable' => false,
            ];
        } else {
            // Lexical fallback. The stored vector status reflects what
            // is actually on disk: if a dense vector is already stored,
            // the post remains STATUS_DENSE (readers keep serving it),
            // but THIS build's mode is 'lexical' — that is the honest
            // answer about which path produced the scores below.
            // warm() will see complete=false and refuse to overwrite
            // an existing good dense profile.
            $embStatus     = $hasStoredDense ? Embeddings::STATUS_DENSE : Embeddings::STATUS_PENDING;
            $semanticBuild = [
                'mode'      => 'lexical',
                'complete'  => false,
                'retryable' => true,
                'reason'    => $hasStoredDense
                    ? 'service_unavailable_preserving_dense'
                    : 'service_unavailable_no_prior_dense',
            ];
        }

        $semanticForProfile = [
            // 'mode' tells consumers what path produced THIS build's
            // scores. It is the truth of this run, not a summary of
            // what is on disk. warm() is the only place that decides
            // whether to persist this profile over an existing one.
            'mode'            => $semanticMode,
            'embedding_model' => $semanticMode === 'dense' ? $vectorMeta['embedding_model'] : '',
            'embedding_dim'   => $semanticMode === 'dense' ? $vectorMeta['embedding_dim']   : 0,
            'has_embedding'   => $semanticMode === 'dense' ? (bool) $vectorMeta['has_embedding'] : false,
            'status'          => $embStatus,
            // Raw best-cosines for calibration (before 0..1 remap).
            // These are the numbers to inspect when tuning thresholds.
            'raw_similarities' => [
                'rooms'   => (array) ($roomRaw['proto_best'] ?? []),
                'threads' => (array) ($threadRaw['proto_best'] ?? []),
            ],
        ];

        // Emotional summary — preserve simple valence/arousal for backward compat.
        $emotionalSignals = (array) ($signals['emotional'] ?? []);
        $emotional = [
            'valence' => (float) ($emotionalSignals['_valence'] ?? 0.0),
            'arousal' => 0.0, // arousal computed more softly
            'labels'  => self::emotionalLabels($emotionalSignals),
            'signals' => array_diff_key($emotionalSignals, ['_valence' => 0]),
        ];

        // Life context — merged from old lifeContextSignals() + signals context.
        $life_context = [
            'stages'      => self::lifeStages($signals),
            'relationship'=> array_keys(array_filter((array) ($signals['relationship'] ?? []), fn($v) => $v >= 0.45)),
            'time'        => array_keys(array_filter((array) ($signals['time'] ?? []), fn($v) => $v >= 0.45)),
            'context'     => array_keys(array_filter((array) ($signals['context'] ?? []), fn($v) => $v >= 0.45)),
        ];

        // model: for a dense build use the live model name; for a
        // lexical build the vector used was tokens-v1.
        $modelName = $semanticMode === 'dense'
            ? ($vectorMeta['embedding_model'] ?: Embeddings::activeModel())
            : 'tokens-v1';

        $source = self::sourceFor($post);

        return [
            'schema_version' => self::SCHEMA_VERSION,
            'generated_at'   => $source['built_at'],   // back-compat alias
            'model'          => $modelName,
            'theme_version'  => QT_THEME_VERSION,
            '_status'        => self::FRESH,

            'identity' => [
                'post_id'  => (int) $post->ID,
                'language' => (string) ($under['language'] ?? 'en'),
            ],

            // Provenance: exactly which revision of the content this
            // profile was built against. Consumers can compare
            // source.content_hash to contentHash($post) to answer
            // "is this profile current?" without overloading _status.
            'source' => $source,

            // Hard facts — observations, not interpretations.
            'observations' => $observations,

            // Semantic metadata (mode describes THIS build's scoring path).
            'semantic'       => $semanticForProfile,
            // Authoritative build declaration — warm() uses this to decide
            // whether it is safe to persist this profile over an existing
            // good dense profile.
            //   complete=true  → dense build OK, persist unconditionally.
            //   complete=false → lexical fallback; only persist if there
            //                    is no existing good dense profile to
            //                    protect (and mark retryable).
            'semantic_build' => $semanticBuild,

            // ───── The four ontology layers ─────
            'rooms' => [
                'assigned'      => $assignedRoom,
                'affinity'      => $roomAffinity,
                'primary'       => $roomPS['primary'],
                'primary_score' => $roomPS['score'],
                'secondary'     => $roomPS['secondary'],
                'raw'           => [
                    'proto_best' => (array) ($roomRaw['proto_best'] ?? []),
                ],
            ],

            'concepts' => $conceptScores,

            'threads' => [
                'scores' => $threadScores,
                'active' => $activeThreads,
                'raw'    => [
                    'proto_best' => (array) ($threadRaw['proto_best'] ?? []),
                ],
            ],

            'signals' => [
                'emotional'     => (array) ($signals['emotional'] ?? []),
                'relationship'  => (array) ($signals['relationship'] ?? []),
                'time'          => (array) ($signals['time'] ?? []),
                'context'       => (array) ($signals['context'] ?? []),
                'communication' => (array) ($signals['communication'] ?? []),
            ],

            // Legacy shortcuts for older code that reads emotional/life_context/themes.
            'emotional'       => $emotional,
            'life_context'    => $life_context,
            'themes'          => array_values((array) ($under['doors'] ?? [])),

            // RELATIONSHIPS to other stories (filled later by StoryRelations).
            'relationships' => [],

            // Reader-facing content.
            'content' => ['warnings' => $warnings],

            'privacy' => [
                'risk_score'             => round((float) ($priv['risk_score'] ?? 0.0), 2),
                'direct_identifiers'     => $directFlags,
                'contextual_identifiers'=> $contextFlags,
                'constellation_risk'    => self::hasFlagKind($priv['flags'] ?? [], ['constellation','uniqueness']),
                'writer_warnings'       => array_values((array) ($priv['writer_warnings'] ?? [])),
            ],

            'editorial' => [
                'semantic_affinity'    => true,
                'popularity_biased'    => false,
                'primary_by_ai'        => $roomPS['primary'],
                'assigned_by_mwenye'   => $assignedRoom,
            ],

            'confidence' => round((float) ($under['confidence'] ?? 0.0), 2),
        ];
    }

    /**
     * BUILD + PERSIST. Call from background/CLI only.
     *
     * LIFECYCLE GUARANTEE (v1.5.6):
     *
     *   PROFILE _status   = freshness of what is STORED (fresh/stale).
     *   REBUILD_PENDING   = whether a new build is WANTED (bool).
     *
     * These are independent. A profile can be FRESH while a rebuild is
     * pending (the common case after an edit: the existing good profile
     * keeps serving readers until a new dense build atomically replaces
     * it). A profile can be STALE with rebuild cleared (only when we
     * deliberately persist a lexical fallback and will upgrade later).
     *
     * Decisions:
     *   1. Dense build COMPLETE      → atomic replace; _status=FRESH;
     *                                  clear rebuild_pending.
     *   2. Lexical build + existing
     *      good dense profile        → DO NOT TOUCH the stored profile,
     *                                  _status, or rebuild_pending;
     *                                  leave it for retry. Readers keep
     *                                  the FRESH dense profile.
     *   3. Lexical build + no good
     *      existing profile          → persist lexical fallback with
     *                                  _status=STALE; keep rebuild_pending
     *                                  true so the dense upgrade fires
     *                                  when service returns.
     *
     * The old profile is never made semantically worse merely because
     * the new computation failed.
     *
     * @return string One of: 'persisted_dense', 'persisted_lexical_fallback',
     *                'preserved_existing_dense', 'failed'.
     */
    public static function warm(int $postId): string
    {
        $post = get_post($postId);
        if (!$post) return 'failed';
        try {
            // Compute/persist the story vector. forPostWrite() already
            // respects the "don't downgrade stored dense vector" rule
            // and leaves STATUS_KEY at dense_ready when preserving.
            Embeddings::forPostWrite($postId);

            $profile  = self::build($post);
            $build    = (array) ($profile['semantic_build'] ?? []);
            $complete = (bool) ($build['complete'] ?? false);

            // ── AUTHORITATIVE PERSISTENCE DECISION ────────────────
            if ($complete) {
                // Dense build succeeded: atomic replacement.
                $profile['_status'] = self::FRESH;
                update_post_meta($postId, self::META_KEY, $profile);
                self::writeBackCompat($postId, $profile);
                delete_post_meta($postId, self::REBUILD_PENDING_KEY);
                return 'persisted_dense';
            }

            // Incomplete (lexical) build. Inspect what is already stored.
            $existing = get_post_meta($postId, self::META_KEY, true);
            $existingIsGoodDense = is_array($existing)
                && (int) ($existing['schema_version'] ?? 0) >= self::SCHEMA_VERSION
                && ($existing['semantic_build']['complete'] ?? false) === true
                && ($existing['semantic']['mode'] ?? '') === 'dense'
                && ($existing['_status'] ?? self::FRESH) === self::FRESH;

            if ($existingIsGoodDense) {
                // Protect the good dense profile completely. We do NOT:
                //   - replace the profile array
                //   - flip _status to stale
                //   - clear rebuild_pending (we still want the rebuild)
                //   - touch writeBackCompat meta
                // Readers keep serving the FRESH dense profile. The
                // background worker will retry on backoff.
                return 'preserved_existing_dense';
            }

            // No good dense profile exists yet (first publish, or all
            // prior profiles were lexical/stale). Persist the lexical
            // fallback with _status=STALE so consumers know scores are
            // provisional; leave rebuild_pending=true so the next
            // successful dense run will upgrade it.
            $profile['_status'] = self::STALE;
            update_post_meta($postId, self::META_KEY, $profile);
            self::writeBackCompat($postId, $profile);
            // rebuild_pending stays true (or becomes true) — we want dense.
            update_post_meta($postId, self::REBUILD_PENDING_KEY, true);
            return 'persisted_lexical_fallback';
        } catch (\Throwable $e) {
            error_log('Quiet Truths: profile warmup failed for post ' . $postId . ': ' . $e->getMessage());
            return 'failed';
        }
    }

    /**
     * Queue a post for background profiling. Does NOT demote an
     * existing FRESH profile to STALE — it only sets the rebuild-
     * pending flag and schedules the background worker.
     */
    public static function queueWarm(int $postId): void
    {
        if ($postId < 1) return;
        // Two-state lifecycle: request rebuild without touching the
        // existing profile's _status. A FRESH profile stays FRESH while
        // the new build runs; if the build fails, the FRESH profile is
        // still there, untouched.
        self::requestRebuild($postId);
        // If there is no vector yet, mark status pending so the embed
        // lifecycle knows work is wanted (does NOT flip existing DENSE).
        if (Embeddings::needsDense($postId)) {
            $curStatus = Embeddings::embeddingStatus($postId);
            if ($curStatus !== Embeddings::STATUS_DENSE) {
                update_post_meta($postId, Embeddings::STATUS_KEY, Embeddings::STATUS_PENDING);
            }
        }
        BackgroundWorker::enqueueProfiling($postId);
    }

    public static function forget(int $postId): void
    {
        delete_post_meta($postId, self::META_KEY);
        delete_post_meta($postId, self::REBUILD_PENDING_KEY);
        delete_post_meta($postId, '_qt_ai_retry_attempts');
        Embeddings::purge($postId);
        delete_post_meta($postId, '_qt_doors');
        delete_post_meta($postId, '_qt_themes');
    }

    /* ──────────────────── lightweight fallback (read path) ──────────────────── */

    /**
     * Cheap fallback that NEVER calls the embedding service. Good enough
     * for search/relations scoring during the window before the background
     * job completes, or when the service is down. Produces the same v5
     * shape as build() so consumers never need to branch.
     *
     * @return array<string,mixed>
     */
    private static function lightweightFallback(\WP_Post $post): array
    {
        $id    = (int) $post->ID;
        $text  = (string) $post->post_title . "\n\n" . (string) $post->post_content;
        $assignedRooms = wp_get_object_terms($id, 'qt_room', ['fields' => 'slugs']);
        $assignedRooms = is_wp_error($assignedRooms) ? [] : (array) $assignedRooms;
        $assignedRoom  = !empty($assignedRooms) ? (string) $assignedRooms[0] : null;

        // Lexical-only concept hints (phrase signatures, no embed).
        $phraseHits = ThemeInference::conceptsFromText($text);
        $conceptScores = [];
        foreach ($phraseHits as $slug) {
            $conceptScores[$slug] = 0.55;
        }
        $warnings = ContentSignals::warningsFor($text);
        $doors    = ThemeInference::doorsFor($text, $phraseHits);

        // On fallback we use the cheap lexical signal detectors (Signals
        // may do a bit more work but never embeds, so it is safe).
        try {
            $signals = Signals::forText($text);
        } catch (\Throwable $e) {
            $signals = ['emotional'=>[],'relationship'=>[],'time'=>[],'context'=>[],'communication'=>[]];
        }

        try {
            $roomRes    = RoomAffinity::score($text, $conceptScores, $signals);
            $affinity   = (array) ($roomRes['affinity'] ?? []);
            $ps         = RoomAffinity::primarySecondary($affinity);
        } catch (\Throwable $e) {
            $affinity = [];
            $ps       = ['primary' => $assignedRoom, 'score' => 0.5, 'secondary' => []];
        }

        try {
            $threadRes      = ThreadInference::scoreThreads($text, $conceptScores, $signals);
            $threadScoresAll = (array) ($threadRes['scores'] ?? []);
            $activeThreads = [];
            foreach ($threadScoresAll as $slug => $score) {
                if ($score >= ThreadInference::THREAD_THRESHOLD) {
                    $activeThreads[$slug] = round((float) $score, 2);
                }
            }
        } catch (\Throwable $e) {
            $threadScoresAll = [];
            $activeThreads   = [];
        }

        $emo = self::emotionalSignals($text);
        $emotional = [
            'valence' => (float) $emo['valence'],
            'arousal' => (float) $emo['arousal'],
            'labels'  => (array) $emo['labels'],
            'signals' => (array) ($signals['emotional'] ?? []),
        ];
        $life_context = [
            'stages'       => self::lifeContextSignals($text)['stages'] ?? [],
            'relationship' => array_keys(array_filter((array) ($signals['relationship'] ?? []), fn($v) => $v >= 0.45)),
            'time'         => array_keys(array_filter((array) ($signals['time'] ?? []), fn($v) => $v >= 0.45)),
            'context'      => array_keys(array_filter((array) ($signals['context'] ?? []), fn($v) => $v >= 0.45)),
        ];

        // Privacy: use cached PII flags if present (set on submit), else
        // surface nothing rather than re-scanning on the read path.
        $storedFlags = get_post_meta($id, '_qt_ai_pii_flags', true);
        $storedFlags = is_array($storedFlags) ? $storedFlags : [];
        $riskScore   = (float) get_post_meta($id, '_qt_ai_risk_score', true);

        $v = Embeddings::forPostRead($id);
        $model = (string) get_post_meta($id, Embeddings::MODEL_KEY, true);
        if ('' === $model) { $model = empty($v) ? 'none' : 'tokens-v1'; }

        $fbSource = [
            'post_modified_gmt' => (string) $post->post_modified_gmt,
            'content_hash'      => self::contentHash($post),
            'built_at'          => gmdate('c'),
        ];
        return [
            'schema_version' => self::SCHEMA_VERSION,
            'generated_at'   => $fbSource['built_at'],
            'model'          => 'fallback',
            'theme_version'  => QT_THEME_VERSION,
            'source'         => $fbSource,
            'identity'       => ['post_id' => $id, 'language' => self::detectLanguageCheap($text)],
            'observations'   => [
                'word_count'         => self::countWords($text),
                'has_phone'          => false,
                'has_email'          => false,
                'stale'              => true,
                'communication_mode' => self::primaryCommunicationMode((array) ($signals['communication'] ?? [])),
            ],
            'semantic' => [
                'mode'            => 'lexical',
                'embedding_model' => '',
                'embedding_dim'   => 0,
                'has_embedding'   => false,
                'status'          => empty($v) ? Embeddings::STATUS_PENDING : Embeddings::STATUS_LEXICAL,
                'raw_similarities' => ['rooms' => [], 'threads' => []],
            ],
            // Fallback is lexical by definition — never allowed to
            // replace a stored good dense profile.
            'semantic_build' => [
                'mode'      => 'lexical',
                'complete'  => false,
                'retryable' => true,
                'reason'    => 'read_path_fallback_no_stored_profile',
            ],
            'rooms' => [
                'assigned'      => $assignedRoom,
                'affinity'      => $affinity,
                'primary'       => $ps['primary'],
                'primary_score' => $ps['score'],
                'secondary'     => $ps['secondary'],
            ],
            'concepts'     => $conceptScores,
            'threads'      => [
                'scores' => $threadScoresAll,
                'active' => $activeThreads,
            ],
            'signals'      => [
                'emotional'     => (array) ($signals['emotional'] ?? []),
                'relationship'  => (array) ($signals['relationship'] ?? []),
                'time'          => (array) ($signals['time'] ?? []),
                'context'       => (array) ($signals['context'] ?? []),
                'communication' => (array) ($signals['communication'] ?? []),
            ],
            'relationships' => [],
            // Backward-compat keys so older readers keep working.
            'rooms_flat'   => $assignedRooms,
            'emotional_bc' => $emo,
            'themes'       => $doors,
            'emotional_arr'=> $emotional,
            'life_context' => $life_context,
            'content'      => ['warnings' => $warnings],
            'privacy'      => [
                'risk_score'             => round($riskScore, 2),
                'direct_identifiers'     => self::filterBySeverity($storedFlags, ['critical','high']),
                'contextual_identifiers'=> self::filterBySeverity($storedFlags, ['medium','low']),
                'constellation_risk'    => false,
                'writer_warnings'       => [],
            ],
            'editorial' => [
                'semantic_affinity'    => true,
                'popularity_biased'    => false,
                'primary_by_ai'        => $ps['primary'],
                'assigned_by_mwenye'   => $assignedRoom,
            ],
            'confidence' => 0.25,
            '_fallback'  => true,
        ];
    }

    /* ──────────────────── emotional & life signals ──────────────────── */

    /**
     * Pick the primary communication mode label from scored signals.
     * Returns a single string so consumers can branch quickly on form.
     */
    private static function primaryCommunicationMode(array $comm): string
    {
        if (empty($comm)) {
            return 'narrative';
        }
        arsort($comm);
        $top = key($comm);
        // If the top signal is weak, fall through to narrative.
        return ($comm[$top] ?? 0) >= 0.55 ? (string) $top : 'narrative';
    }

    /**
     * Build a small set of reader-facing labels from scored emotional signals.
     *
     * @param array<string,float> $emo
     * @return list<string>
     */
    private static function emotionalLabels(array $emo): array
    {
        $labels = [];
        $v = (float) ($emo['_valence'] ?? 0.0);
        if ($v <= -0.4)      $labels[] = 'sorrowful';
        elseif ($v <= -0.1)  $labels[] = 'heavy';
        elseif ($v >= 0.4)   $labels[] = 'hopeful';
        elseif ($v >= 0.1)   $labels[] = 'light';
        else                 $labels[] = 'quiet';

        // If grief/loss/shame dominate at high signal, mark 'weighted'.
        $weighted = max(
            (float) ($emo['grief'] ?? 0),
            (float) ($emo['shame'] ?? 0),
            (float) ($emo['betrayal'] ?? 0)
        );
        if ($weighted >= 0.7) $labels[] = 'weighted';

        if ((float) ($emo['longing'] ?? 0) >= 0.55) $labels[] = 'longing';
        if ((float) ($emo['relief'] ?? 0)  >= 0.55)  $labels[] = 'relieved';

        return array_values(array_unique($labels));
    }

    /**
     * Map the signal arrays into life-stage labels for back-compat with
     * the old life_context.stages shape.
     *
     * @param array<string,array<string,float>> $signals
     * @return array{stages:list<string>,relationship:list<string>,time:list<string>,context:list<string>}
     */
    private static function lifeStages(array $signals): array
    {
        $stageMap = [
            'childhood','adolescence','young_adult','new_parent',
            'marriage_early','recent_past','long_past','now_present',
            'looking_back','looking_forward',
        ];
        $stages = [];
        foreach ($stageMap as $s) {
            if ((($signals['time'][$s] ?? 0) >= 0.45) || in_array($s, ['childhood','young_adult'], true) && (($signals['context'][($s==='young_adult'?'work_hustle':'')] ?? 0) >= 0.4)) {
                if (in_array($s, ['childhood','adolescence','young_adult','new_parent','marriage_early'], true)) {
                    $stages[] = $s;
                }
            }
        }
        // More direct stage detection from context.
        foreach (['parenting' => ['pregnancy_birth','new_parent'],
                  'marriage'  => ['marriage_early'],
                  'midlife'   => ['long_past'],
                  'school'    => ['adolescence','young_adult']] as $stage => $sources) {
            foreach ($sources as $src) {
                if ((($signals['time'][$src] ?? 0) >= 0.45) || (($signals['context']['school_fees'] ?? 0) >= 0.5 && $stage === 'school')) {
                    $stages[] = $stage;
                    break;
                }
            }
        }
        return array_values(array_unique($stages));
    }

    /**
     * Cheap lexical emotional scores used only in the lightweight
     * fallback (read path when no profile is built yet). The full
     * Signals class is used during build().
     *
     * @return array{valence:float,arousal:float,labels:list<string>}
     */
    private static function emotionalSignals(string $text): array
    {
        $t = AiKernel::normalise($text);
        $pos = ['happy','laughed','smiled','forgave','healed','lighter','hope','grateful','thankful','better','peace','breathed','slept','warmth','furahi','furaha','amepumzika','amefurahi','asante','nashukuru'];
        $neg = ['cried','afraid','scared','broke','broken','died','funeral','shame','ashamed','empty','dark','alone','lost','failed','tired','hurt','analia','nimechoka','anaogopa','huzuni','mbaya','maumivu'];
        $high = ['shouted','screamed','hit','beat','ran','yelled','slapped','choked'];
        $low = ['quiet','silent','sat alone','stared','kimya','bubu'];
        $pc=0; foreach($pos as $w) if(str_contains($t,$w)) $pc++;
        $nc=0; foreach($neg as $w) if(str_contains($t,$w)) $nc++;
        $ha=0; foreach($high as $w) if(str_contains($t,$w)) $ha++;
        $la=0; foreach($low as $w) if(str_contains($t,$w)) $la++;
        $tot = $pc + $nc;
        $valence = $tot > 0 ? ($pc - $nc) / $tot : 0.0;
        $arousal = max(-1.0, min(1.0, 0.5*($ha - $la)));
        $labels = [];
        if ($valence <= -0.4) $labels[] = 'sorrowful';
        elseif ($valence <= -0.1) $labels[] = 'heavy';
        elseif ($valence >= 0.4) $labels[] = 'hopeful';
        elseif ($valence >= 0.1) $labels[] = 'light';
        else $labels[] = 'quiet';
        if ($arousal >= 0.3) $labels[] = 'intense';
        elseif ($arousal <= -0.3) $labels[] = 'still';
        return ['valence' => round($valence,2),'arousal' => round($arousal,2),'labels' => $labels];
    }

    /** @return array{stages:list<string>} */
    private static function lifeContextSignals(string $text): array
    {
        $t = AiKernel::normalise($text);
        $signals = [];
        $map = [
            'childhood'   => ['when i was young','child','growing up','primary school','kid','nilipokuwa mdogo'],
            'adolescence' => ['high school','secondary school','form ','teenage','campus','chuo'],
            'young_adult' => ['campus','university','after campus','first job','biashara'],
            'parenting'   => ['my child','my son','my daughter','mtoto wangu','became a mother','became a father'],
            'marriage'    => ['my husband','my wife','married','ndoa','harusi','my marriage'],
            'midlife'     => ['thirty','forty','after years','years later','miaka baadaye'],
            'loss_later'  => ['after they died','after the burial','old age','uzeeni'],
        ];
        foreach ($map as $k => $ph) {
            foreach ($ph as $p) if (str_contains($t,$p)) { $signals[] = $k; break; }
        }
        return ['stages' => array_values(array_unique($signals))];
    }

    /* ──────────────────── utilities ──────────────────── */

    /** @return array{embedding_model:string,embedding_dim:int,has_embedding:bool} */
    private static function vectorMetaFor(int $postId): array
    {
        $v     = Embeddings::forPostReadOnly($postId);
        $model = (string) get_post_meta($postId, Embeddings::MODEL_KEY, true);
        $dim   = (int) get_post_meta($postId, Embeddings::DIM_KEY, true);
        // Only claim an embedding when it is a real dense model vector.
        $hasDense = !empty($v) && Embeddings::isDenseModel($model);
        return [
            'embedding_model' => $hasDense ? $model : '',
            'embedding_dim'   => $hasDense ? $dim : 0,
            'has_embedding'   => $hasDense,
        ];
    }

    /**
     * Stable content fingerprint for a post. Hash is taken over the
     * title + raw post_content (wp_strip_all_tags, whitespace-
     * normalised) — exactly the text build() uses for embedding.
     * Stored in `source.content_hash` so we can answer "was this
     * profile built against the current content?" without guesswork.
     */
    public static function contentHash(\WP_Post $post): string
    {
        $title = wp_strip_all_tags((string) $post->post_title);
        $body  = wp_strip_all_tags((string) $post->post_content);
        $text  = trim(preg_replace('/\s+/u', ' ', $title . "\n\n" . $body) ?? '');
        // 16 hex chars = 64 bits of collision resistance — ample for
        // "did the content change?" checks inside a single site.
        return substr(sha1($text), 0, 16);
    }

    /**
     * Build the `source` provenance block for a profile at build time.
     * @return array{post_modified_gmt:string,content_hash:string,built_at:string}
     */
    private static function sourceFor(\WP_Post $post): array
    {
        return [
            'post_modified_gmt' => (string) $post->post_modified_gmt,
            'content_hash'      => self::contentHash($post),
            'built_at'          => gmdate('c'),
        ];
    }

    /**
     * Was this profile built against the post's current content?
     * Looks at source.content_hash so the answer is based on actual
     * content identity, not timestamps or status flags.
     */
    public static function isCurrent(int $postId): bool
    {
        $raw = get_post_meta($postId, self::META_KEY, true);
        $post = get_post($postId);
        if (!is_array($raw) || !$post) return false;
        $storedHash = (string) ($raw['source']['content_hash'] ?? '');
        if ('' === $storedHash) return false;
        return hash_equals($storedHash, self::contentHash($post));
    }

    private static function detectLanguageCheap(string $text): string
    {
        $swWords = ['nilipata','akasema','alisema','alikufa','nimechoka','sijui','kwa','yangu','wangu','aliniambia','niliomba','kama','lakini','mimi','yeye','sana','kila','baada','kabla','tena','mpaka','kwa sababu','niko','sawa','habari','asante','pole','nyumbani','kijijini','ushago','kwangu'];
        $n = AiKernel::normalise($text);
        $hits = 0;
        foreach ($swWords as $w) if (preg_match('/\b' . preg_quote($w,'/') . '\b/u', $n)) $hits++;
        $en = preg_match_all('/\b(the|and|was|that|this|with|have|had|not|but|for|are)\b/u', $n);
        if ($hits >= 3) return $en >= 3 ? 'sw-en' : 'sw';
        return 'en';
    }

    private static function countWords(string $text): int
    {
        $w = preg_split('/\s+/u', trim(wp_strip_all_tags($text))) ?: [];
        return count(array_filter($w, fn($x) => '' !== $x));
    }

    private static function citySignal(string $text): bool
    {
        $t = AiKernel::normalise($text);
        foreach (['nairobi','mombasa','kisumu','nakuru','eldoret','thika','kitale','nyeri','kakamega','kisii','kericho','machakos','garissa','malindi','diani'] as $c) {
            if (str_contains($t, $c)) return true;
        }
        return false;
    }

    /** @param list<array> $flags */
    private static function filterBySeverity(array $flags, array $severities): array
    { return array_values(array_filter($flags, fn($f) => in_array($f['severity'] ?? 'low', $severities, true))); }

    /** @param list<array> $flags */
    private static function hasFlagKind(array $flags, array $kinds): bool
    {
        foreach ($flags as $f) if (in_array($f['kind'] ?? '', $kinds, true)) return true;
        return false;
    }

    private static function hasKind(array $flags, string $kind): bool
    { return self::hasFlagKind($flags, [$kind]); }

    /**
     * Write legacy meta keys so older code / SQL reports keep working.
     * @param array<string,mixed> $p
     */
    private static function writeBackCompat(int $postId, array $p): void
    {
        update_post_meta($postId, '_qt_ai_version', (string) ($p['theme_version'] ?? QT_THEME_VERSION));
        update_post_meta($postId, '_qt_ai_profile_version', (int) ($p['schema_version'] ?? self::SCHEMA_VERSION));
        update_post_meta($postId, '_qt_ai_risk_score', (float) ($p['privacy']['risk_score'] ?? 0.0));
        $all = array_merge(
            (array) ($p['privacy']['direct_identifiers'] ?? []),
            (array) ($p['privacy']['contextual_identifiers'] ?? [])
        );
        update_post_meta($postId, '_qt_ai_pii_flags', $all);
        update_post_meta($postId, '_qt_doors', (array) ($p['themes'] ?? []));
        $slugs = array_slice(array_keys((array) ($p['concepts'] ?? [])), 0, 6);
        update_post_meta($postId, '_qt_themes', $slugs);
        // Persist embedding status for operational visibility.
        $s = (string) ($p['semantic']['status'] ?? Embeddings::STATUS_PENDING);
        update_post_meta($postId, Embeddings::STATUS_KEY, $s);
    }
}
