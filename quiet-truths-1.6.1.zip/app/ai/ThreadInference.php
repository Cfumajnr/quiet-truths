<?php
/**
 * Quiet Truths — Thread Inference
 *
 * Threads are the cross-cutting textures of human experience that run
 * through every room. They are NOT categories — readers never see them,
 * and a single story can participate in many threads at once. They
 * sit between rooms (where a story lives) and concepts (what words it
 * uses), capturing broad currents like Family, Faith, Love & Intimacy,
 * Work/Money/Hustle, the Body, Violence & Survival, Silence & the
 * Unsaid, Justice, Place & Belonging, and Time/Memory/Age.
 *
 * A thread is scored 0..1 for a story. Scoring combines:
 *   - concept evidence (concepts mapped to this thread)
 *   - direct lexical cues from the thread's own word list
 *   - signal evidence (relationship, context, time, emotional signals
 *     that imply the thread)
 *   - semantic prototype similarity (when BGE-M3 is available) against
 *     the thread's prototype phrases. Prototypes are vectorised once
 *     via PrototypeCache and reused across every story.
 *
 * Prototype-cosine thresholds are PROVISIONAL — the raw best-cosine is
 * recorded per thread in $raw['proto_best'] so future calibration can
 * tune THREAD_THRESHOLD against real corpus judgments without rewriting
 * the pipeline.
 *
 * HIERARCHY OF EVIDENCE (strongest first):
 *     semantic prototype (0.30)
 *        -> concepts (0.18)
 *        -> signals (0.12)
 *        -> lexical cues (capped at 0.40 via diminishing returns)
 *
 * Lexical word lists are supporting evidence, not the intelligence.
 * When a thread is being missed, add prototype phrases before expanding
 * lexical lists.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

use QuietTruths\Core\AiKernel;
use QuietTruths\Core\Config;

final class ThreadInference
{
    /**
     * Thread detection threshold. Below this, a thread is not considered
     * present in the story.
     */
    public const THREAD_THRESHOLD = 0.35;

    public const PROTO_FLOOR = 0.25;
    public const PROTO_RANGE = 0.40;

    /**
     * Flatten all thread prototype phrases (for batched embedding).
     *
     * @return list<string>
     */
    public static function allPrototypes(): array
    {
        $out = [];
        foreach (self::threadDefinitions() as $def) {
            foreach ((array) ($def['prototypes'] ?? []) as $p) {
                $out[] = $p;
            }
        }
        return array_values(array_unique($out));
    }

    /**
     * Score every thread for a text.
     *
     * @param string              $text       Full text (title + content).
     * @param array<string,float> $concepts   Concept slug => score.
     * @param array<string,mixed> $signals    Signals from Signals::forText().
     * @param array<float>|array<string,float>|null $storyVec   Precomputed story vector.
     * @param array<string,array<float>|array<string,float>>|null $protoVecs  Prototype phrase→vec cache.
     *
     * @return array{scores:array<string,float>,raw:array<string,mixed>}
     */
    public static function scoreThreads(
        string $text,
        array $concepts = [],
        array $signals = [],
        $storyVec = null,
        ?array $protoVecs = null
    ): array {
        $t = AiKernel::normalise($text);
        $threads = self::threadDefinitions();
        $scores  = [];
        $raw     = ['proto_best' => [], 'mode' => 'lexical'];

        // If precomputed vectors not supplied, pull from PrototypeCache so
        // the function is still safe to call standalone (CLI/tests).
        if (null === $storyVec || null === $protoVecs) {
            $protoVecs = PrototypeCache::vectors('threads', self::allPrototypes());
            $storyVecs = Embeddings::embed([$t]);
            $storyVec  = $storyVecs[0] ?? [];
            $raw['mode'] = Embeddings::canWriteDense() && !empty($storyVec) ? 'dense' : 'lexical';
        } else {
            $raw['mode'] = (!empty($storyVec) && is_array($storyVec) && isset($storyVec[0])) ? 'dense' : 'lexical';
        }

        foreach ($threads as $slug => $def) {
            $score = 0.0;
            $bestCos = 0.0;

            // 1) Concept evidence.
            foreach ((array) ($def['concepts'] ?? []) as $c) {
                if (isset($concepts[$c])) {
                    $score += 0.18 * (float) $concepts[$c];
                }
            }

            // 2) Direct lexical cues.
            $lexHits = 0;
            foreach ((array) ($def['words'] ?? []) as $w) {
                if (str_contains($t, mb_strtolower($w, 'UTF-8'))) {
                    $lexHits++;
                }
            }
            if ($lexHits > 0) {
                $score += min(0.40, 0.15 + 0.08 * ($lexHits - 1));
            }

            // 3) Signal evidence.
            foreach ((array) ($def['signals'] ?? []) as $sigRef) {
                [$group, $name] = explode(':', $sigRef . ':');
                $groupArr = (array) ($signals[$group] ?? []);
                if (isset($groupArr[$name])) {
                    $score += 0.12 * (float) $groupArr[$name];
                }
            }

            // 4) Semantic prototype similarity.
            if (!empty($storyVec) && !empty($protoVecs)) {
                foreach ((array) ($def['prototypes'] ?? []) as $p) {
                    $pv = $protoVecs[$p] ?? [];
                    if (empty($pv)) continue;
                    $sim = Embeddings::vectorSimilarity($storyVec, $pv);
                    if ($sim > $bestCos) $bestCos = $sim;
                }
            }
            $protoMapped = max(0.0, min(1.0,
                ($bestCos - self::PROTO_FLOOR) / max(0.01, self::PROTO_RANGE)
            ));
            $score += 0.30 * $protoMapped;

            $scores[$slug] = min(0.99, round($score, 2));
            $raw['proto_best'][$slug] = round($bestCos, 3);
        }

        arsort($scores);
        return ['scores' => $scores, 'raw' => $raw];
    }

    /**
     * Thread definitions.
     *
     * @return array<string,array{concepts:list<string>,words:list<string>,signals:list<string>,prototypes:list<string>}>
     */
    /**
     * The 10 frozen thread definitions. Public so the Rooms/Core layer
     * can aggregate thread distributions for atmosphere/houseMap.
     *
     * @return array<string,array{name?:string,concepts:list<string>,words:list<string>,signals:list<string>,prototypes:list<string>}>
     */
    public static function definitions(): array
    {
        return self::threadDefinitions();
    }

    /**
     * @return array<string,array{name?:string,concepts:list<string>,words:list<string>,signals:list<string>,prototypes:list<string>}>
     */
    private static function threadDefinitions(): array
    {
        return [
            'family' => [
                'concepts' => ['family','parenthood','home','origins','aging'],
                'words'    => ['family','mother','father','mum','mom','dad','parents','sister','brother','grandmother','grandfather','grandma','grandpa','uncle','aunt','cousin','child','son','daughter','siblings','ancestors','clan','tribe','lineage','heritage','marriage','married','husband','wife','in-laws','dowry','familia','mama','baba','mzazi','wazazi','ndugu','dada','kaka','babu','bibi','nyanya','jamaa','ukoo','kizazi','mzaa','ndoa','mume','mke','harusi','mahari'],
                'signals'  => ['relationship:mother','relationship:father','relationship:child','relationship:sibling','relationship:spouse_partner','relationship:grandparent','relationship:in_laws','relationship:deceased'],
                'prototypes' => [
                    'growing up with my mother and father in our small house',
                    'the way my parents sacrificed so we could go to school',
                    'my grandmother sitting on her stool telling us stories',
                    'family gatherings at christmas after a long year',
                    'fighting with my brother and then making up',
                    'inheriting my father\'s hands or my mother\'s way of speaking',
                    'the responsibility of sending money home to the family',
                    'teaching my own child what my parents taught me',
                ],
            ],
            'faith' => [
                'concepts' => ['religion','hope','peace','silence','forgiveness'],
                'words'    => ['god','allah','jesus','church','mosque','prayer','prayed','praying','worship','faith','spiritual','belief','pastor','imam','priest','quran','bible','heaven','hell','blessing','miracle','soul','divine','mungu','maombi','sala','kusali','kanisa','msikiti','baraka','dua','imani','roho','dhambi','injili','dini','kwa sababu mungu','niliomba','aliniombea'],
                'signals'  => ['emotional:hope','emotional:peace','emotional:forgiveness','context:inherited_faith'],
                'prototypes' => [
                    'i knelt and prayed even when i did not know what to say',
                    'my mother\'s faith carried our family through hard times',
                    'doubt and belief living side by side in the same chest',
                    'going back to church or to the mosque after years away',
                    'when my imam or pastor sat with me in silence',
                    'gratitude to god for seeing me through another day',
                    'losing my faith and finding something quieter underneath',
                ],
            ],
            'love-intimacy' => [
                'concepts' => ['relationships','love','friendship','jealousy','vulnerability','betrayal','separation','forgiveness'],
                'words'    => ['love','loved','loving','lover','beloved','romance','romantic','tenderness','affection','kissed','held me','her hand','his hand','fell in love','heartbreak','boyfriend','girlfriend','partner','fiancé','fiancée','spouse','intimacy','intimate','made love','fell for him','fell for her','mapenzi','kupendana','mpenzi','penzi','mchumba','uchumba','ndoa','talaka','kuachana'],
                'signals'  => ['emotional:love','emotional:longing','emotional:vulnerability','emotional:betrayal','relationship:spouse_partner','relationship:friend','relationship:ex','communication:unsent_letter'],
                'prototypes' => [
                    'the first time i realised i loved her',
                    'learning to be held after being hurt before',
                    'marriage through the years when love is not loud',
                    'a friend who showed up when everyone else left',
                    'the softness between two people who have been through it',
                    'heartbreak that taught me what i needed',
                    'loving someone from a distance because that is all you can do',
                    'forgiving him but choosing myself anyway',
                ],
            ],
            'work-money-hustle' => [
                'concepts' => ['work','money','ambition','education','justice'],
                'words'    => ['job','work','boss','colleague','salary','wage','rent','debt','loan','mortgage','bills','broke','poverty','poor','savings','hustle','side hustle','biashara','kazi','mshahara','mkopo','deni','kodi','pesa','hela','maskini','umasikini','kufukuzwa kazi','chama','akiba','makali ya maisha','mchana kucha','kuchapa kazi','kukosa pesa','kubana mkono','kupigania mchana'],
                'signals'  => ['emotional:relief','context:work_hustle','context:school_fees','context:poverty_hardship','context:unemployment','context:success_escape'],
                'prototypes' => [
                    'waking up at four to get to work across the city',
                    'the first salary i sent home to my mother',
                    'chama meetings that kept us afloat when salaries delayed',
                    'sleeping hungry because rent took everything',
                    'starting a small biashara with no capital',
                    'the day i finally cleared my school fees balance',
                    'losing my job and not knowing how to tell anyone',
                    'side hustles that kept the lights on',
                ],
            ],
            'body' => [
                'concepts' => ['health','addiction','parenthood'],
                'words'    => ['health','illness','sick','sickness','disease','cancer','hospital','doctor','nurse','surgery','medicine','pills','pain','chronic','disabled','disability','wheelchair','pregnant','pregnancy','miscarriage','gave birth','postpartum','depression','anxiety','panic','trauma','therapy','counselling','afya','ugonjwa','mgonjwa','kuugua','hospitali','daktari','kansa','sukari','damu','maumivu','upasuaji','ujauzito','mimba','kujifungua','mfadhaiko','wasiwasi','kuwa mgonjwa','kilema','mlemavu'],
                'signals'  => ['emotional:fear','emotional:shame','context:illness','context:pregnancy_birth','context:addiction'],
                'prototypes' => [
                    'the day the doctor said the word cancer',
                    'carrying a pregnancy that did not make it',
                    'living with pain that never fully goes away',
                    'walking out of the hospital with a new kind of quiet',
                    'postpartum and nobody telling me how hard it would be',
                    'depression that looked like silence',
                    'getting sober one day at a time',
                    'living with a disability the world does not always see',
                ],
            ],
            'violence-survival' => [
                'concepts' => ['fear','betrayal','shame','courage'],
                'words'    => ['beat','beaten','hit','hit me','slapped','choked','raped','rape','assault','abused','abusive','domestic violence','gbv','defiled','defilement','threatened','knife','panga','gun','police','arrested','detained','survived','survivor','ran away','escaped','kupigwa','kupiga','kubakwa','unyanyasaji','ukatili','dhuluma','kukimbia','kutoroka','kuokoka','nimeokoka','alimpiga','alinipiga','mashambulizi'],
                'signals'  => ['emotional:fear','emotional:shock','emotional:shame','context:domestic_violence','context:infidelity'],
                'prototypes' => [
                    'the night i decided to leave',
                    'hiding bruises so the children would not see',
                    'calling 1195 when i thought i could not anymore',
                    'reporting to the police and being turned away',
                    'surviving something i thought would kill me',
                    'growing up in a house where shouting was normal',
                    'finding safety after years of fear',
                ],
            ],
            'silence-unsaid' => [
                'concepts' => ['secrets','silence'],
                'words'    => ['secret','secrets','unspoken','unsaid','never told','tell no one','kept it to myself','hidden','buried','carried it','heavy secret','nobody knew','no one knew','pretended','silent','silence','did not say','never said','could not tell anyone','locked away','siri','kimya','kunyamaza','kuficha','sijamwambia','sikuambia','kubeba mzigo','siri ya moyo','msalaba wangu','nimekaa kimya','sikuwaambia'],
                'signals'  => ['communication:confession','emotional:shame','emotional:loneliness','context:success_escape'],
                'prototypes' => [
                    'i carried it for twenty years without saying a word',
                    'the thing i have never told anyone',
                    'smiling at the funeral while falling apart inside',
                    'pretending everything was fine',
                    'a family secret everyone knew but nobody spoke',
                    'letters i wrote but never sent',
                    'the relief of finally saying it out loud',
                ],
            ],
            'justice' => [
                'concepts' => ['justice','anger'],
                'words'    => ['justice','injustice','unfair','court','courts','police','lawyer','evidence','vindicated','accountability','wronged','complaint','compensation','corruption','bribe','arrested','case','haki','dhuluma','kudhulumiwa','mahakama','polisi','mwanasheria','ushahidi','kesi','rushwa','mafisadi','kubughu','kutendewa isivyo haki','kupigania haki','kusema ukweli'],
                'signals'  => ['emotional:anger','relationship:police_authority','context:poverty_hardship'],
                'prototypes' => [
                    'the day the judge ruled against me',
                    'fighting for what was right even when it cost me',
                    'a bribe i would not pay',
                    'speaking up when everyone else was quiet',
                    'the police who did nothing when we reported',
                    'being compensated after years of fighting',
                    'injustice done to people who had no voice',
                ],
            ],
            'place-belonging' => [
                'concepts' => ['home','origins','identity'],
                'words'    => ['home','village','hometown','neighbourhood','neighborhood','community','landlord','tenant','estate','apartment','diaspora','abroad','overseas','migrated','migration','immigrant','homeland','ancestral','shamba','farm','countryside','city','town','nyumbani','kwetu','kwao','kijijini','shambani','mtaa','mjini','jiji','rudi nyumbani','mtaani','kumiss nyumbani','nilikotoka','asili yangu','bedsitter','nyumba ya kupanga','mpangaji','kukodisha','kufukuzwa'],
                'signals'  => ['relationship:community','time:childhood','time:looking_back','context:migration_diaspora','emotional:longing'],
                'prototypes' => [
                    'going back to the village after years in nairobi',
                    'the smell of my grandmother\'s kitchen',
                    'living abroad and missing home in the body',
                    'the estate where i grew up now all changed',
                    'the shamba we walked to as children',
                    'finding belonging in a new city',
                    'a house that always felt like home',
                    'the matatu ride back to where i am from',
                ],
            ],
            'time-memory' => [
                'concepts' => ['memory','aging','waiting'],
                'words'    => ['memory','memories','remember','remembering','remembered','recall','nostalgia','flashback','forget','forgotten','childhood','old days','looking back','growing up','growing old','aging','grey hair','wrinkles','retired','retirement','years later','ten years','twenty years','it has been','still remember','kumbukumbu','nakumbuka','zamani','siku za nyuma','utotoni','miaka iliyopita','ukizeeka','uzee','mzee','wazee','miaka inapita','bado nakumbuka'],
                'signals'  => ['time:childhood','time:adolescence','time:long_past','time:looking_back','time:anniversary','relationship:grandparent','relationship:deceased'],
                'prototypes' => [
                    'i still remember the way her voice sounded',
                    'ten years later it still visits me',
                    'looking back on the girl i used to be',
                    'watching my parents grow old',
                    'a memory that comes back when it rains',
                    'the way photographs hold people who are gone',
                    'seasons changing and the years moving faster',
                    'waiting for something that never came',
                ],
            ],
        ];
    }
}
