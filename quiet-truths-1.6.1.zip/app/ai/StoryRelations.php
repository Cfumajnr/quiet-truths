<?php
/**
 * Quiet Truths — Story Relations (Layer 3)
 *
 * Typed relationships between two stories, computed by reading both
 * stories' AI Profiles rather than recomputing signals from raw text.
 * This is critical: once every story has a profile, the "why" of a
 * connection comes from structured signals the house has already
 * decided on, not ad-hoc re-derivation.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

final class StoryRelations
{
    public static function init(): void
    {
        add_filter('quiet_truths_relation_label', [self::class, 'labelFor'], 10, 2);
    }

    /**
     * Classify relation between two stories using their profiles.
     *
     * @return array{relations:list<string>,scores:array<string,float>,score:float,primary:string,why:list<string>}
     */
    public static function classify(int $a, int $b): array
    {
        $pa = get_post($a);
        $pb = get_post($b);
        if (!$pa || !$pb) {
            return ['relations' => [], 'scores' => [], 'score' => 0.0, 'primary' => '', 'why' => []];
        }

        $profA = Profile::get($a);
        $profB = Profile::get($b);

        // Vector similarity (read-only; uses stored vector or transient
        // token fallback — never makes HTTP calls on read path).
        $va = Embeddings::forPostRead($a);
        $vb = Embeddings::forPostRead($b);
        $sem = (!empty($va) && !empty($vb)) ? Embeddings::vectorSimilarity($va, $vb) : 0.0;

        // Signals from profiles (no re-parsing text).
        $aConcepts = (array) ($profA['concepts'] ?? []);
        $bConcepts = (array) ($profB['concepts'] ?? []);
        $aSlugs    = array_keys($aConcepts);
        $bSlugs    = array_keys($bConcepts);
        $overlap   = array_intersect($aSlugs, $bSlugs);
        $union     = array_unique(array_merge($aSlugs, $bSlugs));
        $iou       = empty($union) ? 0.0 : count($overlap) / count($union);

        // Weighted concept overlap (uses scores, not just presence).
        $conceptSim = 0.0;
        if (!empty($overlap)) {
            $num = 0.0; $den = 0.0;
            foreach ($overlap as $slug) {
                $num += min((float) ($aConcepts[$slug] ?? 0), (float) ($bConcepts[$slug] ?? 0));
                $den += max((float) ($aConcepts[$slug] ?? 0), (float) ($bConcepts[$slug] ?? 0));
            }
            $conceptSim = $den > 0 ? $num / $den : 0.0;
        }

        // Thread overlap (cross-cutting human-experience currents). A
        // Heavy-Hearts+Family story sits beside a Homecoming+Grief story
        // even when the surface concepts differ.
        $aThreads = (array) ($profA['threads']['active'] ?? []);
        $bThreads = (array) ($profB['threads']['active'] ?? []);
        $threadOverlap = array_intersect_key($aThreads, $bThreads);
        $threadSim = 0.0;
        if (!empty($threadOverlap)) {
            $tnum = 0.0; $tden = 0.0;
            foreach ($threadOverlap as $slug => $_) {
                $tnum += min((float) ($aThreads[$slug] ?? 0), (float) ($bThreads[$slug] ?? 0));
                $tden += max((float) ($aThreads[$slug] ?? 0), (float) ($bThreads[$slug] ?? 0));
            }
            $threadSim = $tden > 0 ? $tnum / $tden : 0.0;
        }

        // Room overlap: a story's assigned room, plus any secondary
        // AI resonances, all count as rooms the story lives in.
        $aRooms = self::roomSlugsFromProfile($profA);
        $bRooms = self::roomSlugsFromProfile($profB);
        $sameRoom = !empty(array_intersect($aRooms, $bRooms));

        $aDoors = (array) ($profA['themes'] ?? []);
        $bDoors = (array) ($profB['themes'] ?? []);
        $sameDoor = !empty(array_intersect($aDoors, $bDoors));

        $aVal = (float) ($profA['emotional']['valence'] ?? 0);
        $bVal = (float) ($profB['emotional']['valence'] ?? 0);
        $valenceGap = abs($aVal - $bVal);

        $aStages = (array) ($profA['life_context']['stages'] ?? []);
        $bStages = (array) ($profB['life_context']['stages'] ?? []);
        $sameStage = !empty(array_intersect($aStages, $bStages));

        // ── per-relation scoring ──
        $scores = [];
        $scores['similar_experience'] =
            ($sameRoom ? 0.25 : 0.0) + $conceptSim * 0.35 + $threadSim * 0.20 + $sem * 0.35;
        $scores['same_theme'] =
            (count($overlap) >= 2 ? 0.30 : (count($overlap) >= 1 ? 0.15 : 0.0))
            + $threadSim * 0.20
            + $sem * 0.25 + ($sameDoor ? 0.10 : 0.0) + $conceptSim * 0.15;
        $scores['emotional_kin'] =
            $sem * 0.45 + $threadSim * 0.20 + (1.0 - $iou) * 0.10 + ($sameRoom ? 0.0 : 0.05)
            + (abs($aVal - $bVal) < 0.30 ? 0.15 : 0.0);
        $scores['same_life'] =
            ($sameDoor && !$sameRoom ? 0.20 : 0.0) + $sem * 0.25 + $conceptSim * 0.10
            + $threadSim * 0.20 + ($sameStage ? 0.20 : 0.0);
        $scores['contrasting'] =
            ($valenceGap >= 0.6 ? 0.40 : $valenceGap * 0.55) + $sem * 0.20 + ($sameDoor ? 0.05 : 0.0)
            + $threadSim * 0.15;
        $scores['continuation'] =
            ($conceptSim > 0.20 ? 0.20 : 0.0) + $sem * 0.25 + ($sameDoor ? 0.05 : 0.0)
            + $threadSim * 0.15
            + (self::hasArc($a, $b, $profA, $profB) ? 0.25 : 0.0);
        $scores['same_concept_other_room'] =
            (!$sameRoom && $sameDoor && count($overlap) >= 1 ? 0.35 : 0.0)
            + $sem * 0.20 + $conceptSim * 0.10 + $threadSim * 0.15;
        $scores['related_different'] =
            $sem * 0.40 + $threadSim * 0.25 + $conceptSim * 0.10;

        foreach ($scores as $k => $v) {
            $scores[$k] = max(0.0, min(1.0, $v));
        }

        $floors = [
            'similar_experience'     => 0.55,
            'same_theme'             => 0.40,
            'emotional_kin'          => 0.45,
            'same_life'              => 0.40,
            'contrasting'            => 0.50,
            'continuation'           => 0.45,
            'same_concept_other_room'=> 0.50,
            'related_different'      => 0.40,
        ];
        $relations = [];
        foreach ($scores as $k => $v) {
            if ($v >= ($floors[$k] ?? 0.5)) {
                $relations[] = $k;
            }
        }
        uasort($scores, fn($x, $y) => $y <=> $x);
        usort($relations, fn($x, $y) => ($scores[$y] ?? 0) <=> ($scores[$x] ?? 0));

        $primary = $relations[0] ?? '';
        $overall = $sem * 0.35 + $conceptSim * 0.25 + $threadSim * 0.20
                 + ($sameRoom ? 0.08 : 0.0)
                 + ($sameDoor ? 0.04 : 0.0) + ($sameStage ? 0.08 : 0.0);
        $overall = max(0.0, min(1.0, $overall));

        // Build a short "why" chain of the top 2 overlapping concepts —
        // future work will walk the ontology tree (GRIEF→ABSENCE→RITUAL)
        // once parent/child edges exist.
        $why = array_slice(array_values($overlap), 0, 2);

        return [
            'relations' => $relations,
            'scores'    => $scores,
            'score'     => round($overall, 3),
            'primary'   => $primary,
            'why'       => $why,
        ];
    }

    public static function labelFor(string $label, string $relation): string
    {
        if ('' !== $label) return $label;
        return match ($relation) {
            'similar_experience'     => __('Another story like this', 'quiet-truths'),
            'same_theme'             => __('On the same theme', 'quiet-truths'),
            'emotional_kin'          => __('Walks similar ground', 'quiet-truths'),
            'same_life'              => __('From the same season of life', 'quiet-truths'),
            'contrasting'            => __('A different ending', 'quiet-truths'),
            'continuation'           => __('A later chapter', 'quiet-truths'),
            'related_different'      => __('You might also sit with', 'quiet-truths'),
            'same_concept_other_room'=> __('The same truth, another room', 'quiet-truths'),
            default                  => '',
        };
    }

    /**
     * @return list<array{id:int,relations:list<string>,scores:array<string,float>,score:float,primary:string,label:string,why:list<string>}>
     */
    public static function relatedTo(int $postId, int $limit = 4): array
    {
        $post = get_post($postId);
        if (!$post || 'publish' !== $post->post_status) return [];
        $q = new \WP_Query([
            'post_type' => ['qt_story'], 'post_status' => 'publish',
            'posts_per_page' => 80, 'post__not_in' => [$postId],
            'no_found_rows' => true, 'orderby' => 'date', 'order' => 'DESC', 'fields' => 'ids',
        ]);
        $scored = [];
        foreach ((array) ($q->posts ?: []) as $cid) {
            $rel = self::classify($postId, (int) $cid);
            if ($rel['score'] < 0.15 || empty($rel['primary'])) continue;
            $scored[] = array_merge(
                ['id' => (int) $cid, 'label' => self::labelFor('', $rel['primary'])],
                $rel
            );
        }
        usort($scored, fn($x,$y) => $y['score'] <=> $x['score']);
        return array_slice($scored, 0, $limit);
    }

    /**
     * Heuristic for "continuation": one story is later in time and shares
     * themes/doors with the other.
     */
    private static function hasArc(int $a, int $b, array $profA, array $profB): bool
    {
        foreach ([$a => $profA, $b => $profB] as $pid => $p) {
            $post = get_post($pid);
            if (!$post) continue;
            $t = AiKernel::normalise((string) $post->post_title . ' ' . (string) $post->post_content);
            foreach (['years later','months later','afterwards','now i','today i','miaka baadaye','baadaye','sasa mimi','since then'] as $cue) {
                if (str_contains($t, $cue)) return true;
            }
        }
        return false;
    }

    /**
     * Extract all meaningful room slugs from a profile, understanding
     * both v5 (rooms.assigned + rooms.secondary) and older flat shapes.
     *
     * @return list<string>
     */
    private static function roomSlugsFromProfile(array $profile): array
    {
        $rooms = $profile['rooms'] ?? [];
        $out = [];
        if (is_array($rooms)) {
            if (!empty($rooms['assigned'])) $out[] = (string) $rooms['assigned'];
            if (!empty($rooms['primary']) && $rooms['primary'] !== ($rooms['assigned'] ?? null)) {
                $out[] = (string) $rooms['primary'];
            }
            foreach ((array) ($rooms['secondary'] ?? []) as $sec) {
                if (is_array($sec) && !empty($sec['slug'])) $out[] = (string) $sec['slug'];
            }
            // Flat list fallbacks (v4 and earlier, plus lexical fallback).
            foreach ($rooms as $k => $v) {
                if (is_string($k) && in_array($k, ['assigned','primary','secondary','affinity','primary_score'], true)) continue;
                if (is_string($v) && '' !== $v && !is_numeric($v)) $out[] = $v;
            }
        }
        return array_values(array_unique(array_filter($out)));
    }
}
