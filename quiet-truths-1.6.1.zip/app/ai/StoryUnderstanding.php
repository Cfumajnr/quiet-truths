<?php
/**
 * Quiet Truths — Story Understanding (Layer 1)
 *
 * Where the house learns what a story is about. Merges:
 *   - deterministic phrase concept hits (ThemeInference::conceptsFromText)
 *   - semantic concept hits via embedding anchors (ThemeInference::semanticConcepts)
 *   - content-warning signals (ContentSignals)
 *   - door signals (ThemeInference::conceptToDoor)
 *   - room suggestions from concept/atmosphere overlap
 *
 * Deterministic signals always run; semantic signals only run when the
 * embedding service is up (ThemeInference returns [] otherwise).
 *
 * Also produces and persists a full "AI profile" per approved story
 * (concepts, doors, rooms, warnings, emotional signals, risk, language,
 * model versions) so later searches and relations don't recompute what
 * the house already knows.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

use QuietTruths\Core\Concepts;

final class StoryUnderstanding
{
    public static function init(): void
    {
        add_filter('quiet_truths_detected_concepts', [self::class, 'deepenConcepts'], 10, 2);
    }

    /* ──────────────────── public API ──────────────────── */

    /**
     * Full understanding envelope for a piece of text.
     *
     * @return array{
     *   concepts:list<string>,
     *   concept_scores:array<string,float>,
     *   doors:list<string>,
     *   rooms:list<string>,
     *   warnings:list<string>,
     *   language:string,
     *   confidence:float,
     *   model:string,
     *   profile_version:int,
     *   generated_at:string
     * }
     */
    public static function understand(string $text, array $existingConcepts = []): array
    {
        $phraseConcepts = ThemeInference::conceptsFromText($text);
        $semConcepts    = ThemeInference::semanticConcepts($text);
        $warnConcepts   = self::warningsToConcepts(ContentSignals::warningsFor($text));

        // Merge: deterministic hits always get score 1.0 (they matched a
        // specific phrase); semantic hits carry their cosine score.
        $scores = [];
        foreach (array_merge($existingConcepts, $phraseConcepts, $warnConcepts) as $slug) {
            $scores[$slug] = 1.0;
        }
        foreach ($semConcepts as $slug => $s) {
            if (!isset($scores[$slug]) || $s > $scores[$slug]) {
                $scores[$slug] = $s;
            }
        }
        arsort($scores);

        $concepts = array_keys($scores);
        $doors    = ThemeInference::doorsFor($text, $concepts);
        $rooms    = self::roomsFromConcepts($concepts);
        $warnings = ContentSignals::warningsFor($text);
        $lang     = self::detectLanguage($text);

        // Confidence: more signals = higher confidence, but we cap it
        // and express honest uncertainty (especially when semantic mode
        // is off).
        $semCount = count($semConcepts);
        $phraseCount = count($phraseConcepts) + count($warnConcepts);
        $base = 0.20 + 0.05 * $phraseCount;
        if ($semCount > 0) {
            $base += 0.15 + 0.04 * $semCount;
        }
        $confidence = min(0.90, $base);

        return [
            'concepts'        => array_slice($concepts, 0, 8),
            'concept_scores'  => array_slice($scores, 0, 12),
            'doors'           => array_slice($doors, 0, 4),
            'rooms'           => $rooms,
            'warnings'        => $warnings,
            'language'        => $lang,
            'confidence'      => round($confidence, 2),
            'model'           => Embeddings::activeModel(),
            'profile_version' => Embeddings::PROFILE_VERSION,
            'generated_at'    => gmdate('c'),
        ];
    }

    /**
     * Hooked into quiet_truths_detected_concepts.
     *
     * @param  list<string> $concepts
     * @return list<string>
     */
    public static function deepenConcepts(array $concepts, string $text): array
    {
        $extra = ThemeInference::conceptsFor($text);
        return array_values(array_unique(array_merge($concepts, $extra)));
    }

    /* ──────────────────── internals ──────────────────── */

    /**
     * Map content-warning tags → concept slugs.
     *
     * @param  list<string> $warnings
     * @return list<string>
     */
    private static function warningsToConcepts(array $warnings): array
    {
        $map = [
            'grief' => 'grief', 'loss' => 'loss', 'abuse' => 'abuse',
            'violence' => 'violence', 'suicide' => 'suicide', 'illness' => 'illness',
            'money' => 'money', 'faith' => 'faith', 'sex' => 'sex',
            'family' => 'family', 'children' => 'parenthood',
            'addiction' => 'addiction',
        ];
        $out = [];
        foreach ($warnings as $w) {
            if (isset($map[$w])) {
                $out[] = $map[$w];
            }
        }
        return array_values(array_unique($out));
    }

    /**
     * Lightweight language hint. 'sw', 'sw-en' (code-switched), or 'en'.
     * We don't need a perfect detector — this is for the AI profile so
     * we can, in future, weigh cross-language signals appropriately.
     */
    private static function detectLanguage(string $text): string
    {
        $swWords = [
            'nilipata','akasema','alisema','alikufa','nimechoka','sijui','kwa',
            'yangu','wangu','aliniambia','niliomba','kama','lakini','mimi',
            'yeye','sana','kila','baada','kabla','tena','mpaka','kwa sababu',
            'niko','sawa','habari','asante','pole','tafadhali','nyumbani',
            'kijijini','ushago','kwangu','kwake','aliporudi','hakukuwa',
        ];
        $normal = AiKernel::normalise($text);
        $swHits = 0;
        foreach ($swWords as $w) {
            if (preg_match('/\b' . preg_quote($w, '/') . '\b/u', $normal)) {
                $swHits++;
            }
        }
        if ($swHits >= 3) {
            // If it also contains lots of English words, call it code-switched.
            $enHints = preg_match_all('/\b(the|and|was|that|this|with|have|had|not|but|for|are)\b/u', $normal);
            return $enHints >= 3 ? 'sw-en' : 'sw';
        }
        return 'en';
    }

    /**
     * Suggest room slugs from concept overlap with the CANONICAL room
     * concept lists. This is a fast lexical hint (used only by the
     * UNDERSTAND envelope for diagnostics/doors); primary room
     * assignment for stories comes from RoomAffinity::score() in the
     * profile build, which uses prototypes/signals/concepts/lexical
     * with the full evidence hierarchy.
     *
     * Reads from Config::roomSpecs() (canonical) instead of expecting
     * an 'atmosphere' key on QT_ROOMS (which only carries
     * name/description for public UI).
     *
     * @param  list<string> $concepts
     * @return list<string>
     */
    private static function roomsFromConcepts(array $concepts): array
    {
        $specs  = \QuietTruths\Core\Config::instance()->roomSpecs();
        // Defensive fallback when Config hasn't booted (CLI/tests).
        if (empty($specs)) {
            $f = dirname(__DIR__) . '/config/rooms.php';
            if (is_file($f)) {
                $specs = (array) require $f;
            }
        }
        $scored = [];
        foreach ($specs as $slug => $room) {
            if (!is_array($room)) continue;
            $hit = 0;
            foreach ((array) ($room['concepts'] ?? []) as $rc) {
                $rc = strtolower((string) $rc);
                if (in_array($rc, $concepts, true)) {
                    $hit++;
                }
            }
            // Letters gets a small lift when an unsent-letter-ish phrase
            // appears in the concepts, matching the primary/secondary
            // logic in RoomAffinity::score().
            if ($slug === 'letters' && in_array('secrets', $concepts, true)) {
                $hit += 1;
            }
            if ($hit > 0) {
                $scored[$slug] = $hit;
            }
        }
        arsort($scored);
        return array_slice(array_keys($scored), 0, 3);
    }
}
