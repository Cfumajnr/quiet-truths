<?php
/**
 * Quiet Truths — Presentation Component Loader
 *
 * Required by front-page.php (and header.php/footer.php). Defines the
 * theme's render helpers: room symbols, room cards, story panels,
 * notices, buttons and page furniture.
 *
 * All functions are guarded with function_exists() so this file is safe
 * to require more than once.
 *
 * @package QuietTruths
 * @subpackage Presentation
 */

if (!defined('ABSPATH')) {
    exit;
}

// Constants may not be loaded yet if this file is required outside the
// normal boot sequence — load them defensively.
if (!defined('QT_APP_DIR')) {
    require_once dirname(__DIR__, 2) . '/config/constants.php';
}

/* ════════════════════════ rooms ════════════════════════ */

if (!function_exists('qt_get_rooms')) {
    /**
     * All rooms, each decorated with its best-known URL.
     *
     * @return array<int, array{slug:string,name:string,description:string,href:string}>
     */
    function qt_get_rooms(): array
    {
        $rooms = defined('QT_ROOMS') ? QT_ROOMS : [];

        foreach ($rooms as &$room) {
            $room['href'] = qt_room_url($room['slug']);
        }
        unset($room);

        return array_values($rooms);
    }
}

if (!function_exists('qt_room_url')) {
    /**
     * Link to a room: its taxonomy archive when the term exists,
     * otherwise a filtered view of the front page.
     */
    function qt_room_url(string $slug): string
    {
        $term = get_term_by('slug', sanitize_title($slug), 'qt_room');

        if ($term && !is_wp_error($term)) {
            $link = get_term_link($term);
            if (!is_wp_error($link)) {
                return $link;
            }
        }

        return home_url('/?qt_room=' . rawurlencode($slug));
    }
}

if (!function_exists('qt_room_symbol')) {
    /**
     * The small geometric mark for a room.
     */
    function qt_room_symbol(string $slug, string $label = ''): string
    {
        $slug = sanitize_title($slug);
        $out  = '<span class="room-symbol room-symbol--' . esc_attr($slug) . '" aria-hidden="true"></span>';

        if ('' !== $label) {
            $out .= '<span class="room-symbol__label">' . esc_html($label) . '</span>';
        }

        return $out;
    }
}

if (!function_exists('qt_room_card')) {
    /**
     * A tappable room card for the rooms grid.
     *
     * @param array{slug:string,name:string,description:string,href?:string} $room
     */
    function qt_room_card(array $room): void
    {
        $slug = sanitize_title($room['slug'] ?? '');
        $href = $room['href'] ?? qt_room_url($slug);

        echo '<a class="qt-room-card u-flex u-flex-col u-gap-sm" href="' . esc_url($href) . '">';
        echo qt_room_symbol($slug);
        echo '<span class="qt-room-card__name">' . esc_html($room['name'] ?? '') . '</span>';
        echo '<span class="qt-room-card__desc">' . esc_html($room['description'] ?? '') . '</span>';
        echo '</a>';
    }
}

if (!function_exists('qt_room_header')) {
    /**
     * Room page header: symbol, name, description.
     */
    function qt_room_header(string $slug, string $name, string $description): void
    {
        echo '<header class="room-header">';
        echo qt_room_symbol($slug);
        echo '<h1 class="room-header__name">' . esc_html($name) . '</h1>';
        echo '<p class="room-header__description">' . esc_html($description) . '</p>';
        echo '</header>';
    }
}

/* ════════════════════════ stories ════════════════════════ */

if (!function_exists('qt_story_excerpt')) {
    /**
     * The intentional excerpt. The writer may set one in the editor
     * (a first sentence, a beautiful line from the middle — or leave
     * it to the house). When none is set, the first sentence of the
     * story is used, trimmed gently.
     */
    function qt_story_excerpt($post, int $max = 200): string
    {
        $post = get_post($post);

        if (!$post) {
            return '';
        }

        $excerpt = trim((string) $post->post_excerpt);

        if ('' !== $excerpt) {
            return $excerpt;
        }

        $text = trim((string) preg_replace('/\s+/u', ' ', wp_strip_all_tags((string) $post->post_content)));
        $first = preg_split('/(?<=[.!?])\s+/u', $text, 2);

        $sentence = '' !== $first[0] ? $first[0] : $text;

        return function_exists('mb_strimwidth')
            ? mb_strimwidth($sentence, 0, $max, '…')
            : substr($sentence, 0, $max);
    }
}

if (!function_exists('qt_story_row')) {
    /**
     * A story as it appears on the shelf — no image, no buttons.
     * Title, two lines, room, reading time. Click anywhere.
     */
    function qt_story_row($post = null): void
    {
        $post = get_post($post);

        if (!$post) {
            return;
        }

        $room = qt_story_room($post->ID);
        $time = qt_reading_time($post);

        echo '<a class="qt-story-row" href="' . esc_url(get_permalink($post)) . '">';
        echo '<h3 class="qt-story-row__title">' . esc_html((string) $post->post_title) . '</h3>';
        echo '<p class="qt-story-row__excerpt">' . esc_html(qt_story_excerpt($post, 200)) . '</p>';
        echo '<div class="qt-story-row__meta">';
        if ($room) {
            echo '<span>' . esc_html($room->name) . '</span>';
        }
        if ('' !== $time) {
            echo '<span aria-hidden="true">·</span><span>' . esc_html($time) . '</span>';
        }
        echo '</div>';
        echo '</a>';
    }
}

if (!function_exists('qt_random_story_url')) {
    /**
     * A story the house chooses — the quiet invitation's path.
     */
    function qt_random_story_url(): string
    {
        $random = new \WP_Query([
            'post_type'      => 'qt_story',
            'post_status'    => 'publish',
            'posts_per_page' => 1,
            'orderby'        => 'rand',
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ]);

        return empty($random->posts)
            ? home_url('/stories/')
            : get_permalink((int) $random->posts[0]);
    }
}

if (!function_exists('qt_story_panel')) {
    /**
     * A story card for the feed.
     *
     * @param int|\WP_Post|null $post
     * @param bool              $showRoom Whether to show the room label.
     *                                    Search hides it: rooms are
     *                                    placeholders, never answers.
     */
    function qt_story_panel($post = null, bool $showRoom = true): void
    {
        $post = get_post($post);

        if (!$post) {
            return;
        }

        $terms = get_the_terms($post, 'qt_room');
        $room  = (!is_wp_error($terms) && !empty($terms)) ? $terms[0] : null;
        $date  = get_the_date('j M Y', $post);

        echo '<article class="story-panel">';

        if ($room && $showRoom) {
            echo '<div class="story-panel__room">';
            echo '<span class="story-panel__room-symbol" aria-hidden="true"></span>';
            /* translators: %s the room name — e.g. "From the Unfinished room" */
            echo esc_html(sprintf(__('From the %s room', 'quiet-truths'), $room->name));
            echo '</div>';
        }

        echo '<h3 class="story-panel__title"><a href="' . esc_url(get_permalink($post)) . '">'
            . esc_html(get_the_title($post)) . '</a></h3>';

        $excerpt = has_excerpt($post) ? get_the_excerpt($post) : wp_trim_words((string) get_post_field('post_content', $post), 40, '…');
        echo '<p class="story-panel__excerpt">' . esc_html($excerpt) . '</p>';

        echo '<div class="story-panel__attributes"><span>Held ' . esc_html($date) . '</span></div>';
        echo '<div class="story-panel__time">' . esc_html(qt_relative_time(get_post_time('U', true, $post))) . '</div>';
        echo '</article>';
    }
}

if (!function_exists('qt_relative_time')) {
    /**
     * Gentle, approximate relative time. Uses current_time('timestamp')
     * so the configured WordPress timezone (e.g. Nairobi, UTC+3) is honoured.
     */
    function qt_relative_time(int $timestamp): string
    {
        $now  = (int) current_time('timestamp');
        $diff = max(0, $now - $timestamp);

        if ($diff < 3600) {
            return __('Just now', 'quiet-truths');
        }
        if ($diff < 86400) {
            $h = (int) floor($diff / 3600);
            return sprintf(_n('%d hour ago', '%d hours ago', $h, 'quiet-truths'), $h);
        }
        if ($diff < 604800) {
            $d = (int) floor($diff / 86400);
            return sprintf(_n('%d day ago', '%d days ago', $d, 'quiet-truths'), $d);
        }

        return date_i18n('j M Y', $timestamp);
    }
}

if (!function_exists('qt_story_feed')) {
    /**
     * The front-page story feed, optionally filtered by ?qt_room=slug.
     *
     * @param array<string, mixed> $args
     */
    function qt_story_feed(array $args = []): void
    {
        $queryArgs = wp_parse_args($args, [
            'post_type'      => 'qt_story',
            'post_status'    => 'publish',
            'posts_per_page' => 5,
            'no_found_rows'  => true,
        ]);

        if (!empty($_GET['qt_room'])) {
            $queryArgs['tax_query'] = [
                [
                    'taxonomy' => 'qt_room',
                    'field'    => 'slug',
                    'terms'    => sanitize_title(wp_unslash((string) $_GET['qt_room'])),
                ],
            ];
        }

        $query = new WP_Query($queryArgs);

        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                qt_story_panel(get_the_ID());
            }
            wp_reset_postdata();
            return;
        }

        qt_gentle_notice(
            'reflection',
            __('The shelves are still being filled. When a story is left here, it will be held with care — and read slowly.', 'quiet-truths')
        );
    }
}

if (!function_exists('qt_story_room')) {
    /**
     * First room term of a story, or null.
     *
     * @return \WP_Term|null
     */
    function qt_story_room(int $postId)
    {
        $terms = get_the_terms($postId, 'qt_room');

        return (!is_wp_error($terms) && !empty($terms)) ? $terms[0] : null;
    }
}

/* ════════════════════ notices & markers ════════════════════ */

if (!function_exists('qt_gentle_notice')) {
    /**
     * A bordered note. Variants: healing, reflection, attention.
     */
    function qt_gentle_notice(string $variant = 'reflection', string $content = ''): void
    {
        $variant = in_array($variant, ['healing', 'reflection', 'attention'], true) ? $variant : 'reflection';

        echo '<div class="gentle-notice gentle-notice--' . esc_attr($variant) . '" role="note">';
        echo '<span aria-hidden="true">✦</span>';
        echo '<p>' . wp_kses_post($content) . '</p>';
        echo '</div>';
    }
}

if (!function_exists('qt_reflection_card')) {
    function qt_reflection_card(string $content): void
    {
        echo '<div class="reflection-card"><p>' . wp_kses_post($content) . '</p></div>';
    }
}

if (!function_exists('qt_hope_marker')) {
    function qt_hope_marker(string $text): void
    {
        echo '<span class="hope-marker"><span aria-hidden="true">✦</span> ' . esc_html($text) . '</span>';
    }
}

if (!function_exists('qt_quiet_divider')) {
    function qt_quiet_divider(bool $short = false): void
    {
        echo '<hr class="quiet-divider' . ($short ? ' quiet-divider--short' : '') . '">';
    }
}

if (!function_exists('qt_button')) {
    /**
     * @param array<string, string> $attrs Extra attributes (data-*, id, …).
     */
    function qt_button(string $href, string $label, string $variant = 'primary', array $attrs = []): void
    {
        $variant = in_array($variant, ['primary', 'quiet'], true) ? $variant : 'primary';
        $out     = '<a href="' . esc_url($href) . '" class="qt-button qt-button--' . $variant . '"';

        foreach ($attrs as $key => $value) {
            $out .= ' ' . sanitize_key($key) . '="' . esc_attr($value) . '"';
        }

        $out .= '>' . esc_html($label) . '</a>';
        echo $out;
    }
}

/* ════════════════════════ furniture ════════════════════════ */

if (!function_exists('qt_primary_menu_items')) {
    /**
     * Fallback links for the primary menu when none is assigned.
     *
     * The five quiet links of the house: Home, All stories, Leave a story,
     * Write to Quiet Truths, About. The seven rooms live INSIDE the
     * collection (on /stories/), not in the masthead of every page.
     */
    function qt_primary_menu_items(): void
    {
        $links = [
            home_url('/')                          => __('Home', 'quiet-truths'),
            home_url('/stories/')                  => __('All stories', 'quiet-truths'),
            home_url('/leave-a-story/')            => __('Leave a story', 'quiet-truths'),
            home_url('/write-to-quiet-truths/')    => __('Write to Quiet Truths', 'quiet-truths'),
            home_url('/about/')                    => __('About', 'quiet-truths'),
        ];

        foreach ($links as $url => $label) {
            echo '<a href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
        }
    }
}

if (!function_exists('qt_mobile_menu_items')) {
    /**
     * Mobile primary nav mirrors the desktop primary nav exactly —
     * same five links, same order. Rooms are reached through All stories.
     */
    function qt_mobile_menu_items(): void
    {
        qt_primary_menu_items();
    }
}

if (!function_exists('qt_clean_menu_links')) {
    /**
     * Return a menu's links as plain <a> tags — no <li> wrappers, so no
     * list markers can ever render (Home, no dots).
     */
    function qt_clean_menu_links(array $args): string
    {
        $menu = wp_nav_menu(wp_parse_args($args, [
            'container'      => false,
            'items_wrap'     => '%3$s',
            'depth'          => 1,
            'echo'           => false,
        ]));

        $menu = (string) $menu;
        $menu = preg_replace('/<li[^>]*>/', '', $menu) ?? $menu;
        $menu = str_replace('</li>', '', $menu);

        return $menu;
    }
}

if (!function_exists('qt_header_nav')) {
    function qt_header_nav(): void
    {
        echo '<nav class="qt-header__nav" aria-label="' . esc_attr__('Primary', 'quiet-truths') . '">';
        echo qt_clean_menu_links([
            'theme_location' => 'primary',
            'fallback_cb'    => 'qt_primary_menu_items',
        ]);
        echo '</nav>';
    }
}

if (!function_exists('qt_mobile_nav')) {
    function qt_mobile_nav(): void
    {
        echo '<nav class="qt-mobile-nav" id="qt-mobile-nav" aria-label="' . esc_attr__('Mobile', 'quiet-truths') . '">';
        echo qt_clean_menu_links([
            'theme_location' => 'primary',
            'fallback_cb'    => 'qt_mobile_menu_items',
        ]);
        echo '</nav>';
    }
}

if (!function_exists('qt_footer_nav')) {
    function qt_footer_nav(): void
    {
        // Render the user-assigned footer menu (or the fallback), then
        // append any governance/legal links that are not already
        // present. This lets mwenye nyumba curate a footer menu in WP
        // Admin without worrying about duplicate Privacy / Terms links.
        $menu_html = (string) wp_nav_menu([
            'theme_location' => 'footer',
            'container'      => false,
            'items_wrap'     => '%3$s',
            'depth'          => 1,
            'echo'           => false,
            'fallback_cb'    => function () {
                // No menu assigned — sensible house defaults.
                // Note: do NOT include privacy/terms here;
                // Governance::footerLinks() appends those.
                $links = [
                    home_url('/')                => __('The Rooms', 'quiet-truths'),
                    home_url('/stories/')        => __('All Stories', 'quiet-truths'),
                    home_url('/leave-a-story/')  => __('Leave a story', 'quiet-truths'),
                    home_url('/about/')          => __('About', 'quiet-truths'),
                    home_url('/write-to-quiet-truths/') => __('Write to Quiet Truths', 'quiet-truths'),
                ];
                $out = '';
                foreach ($links as $url => $label) {
                    $out .= '<a href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
                }
                return $out;
            },
        ]);

        // Strip <li> wrappers (same as qt_clean_menu_links) so no
        // list markers ever render.
        $menu_html = preg_replace('/<li[^>]*>/', '', $menu_html) ?? $menu_html;
        $menu_html = str_replace('</li>', '', $menu_html);

        // Collect the paths already linked in the rendered menu so we
        // don't repeat them when appending governance links.
        $existing_paths = [];
        if (preg_match_all('/href="([^"]+)"/i', $menu_html, $m)) {
            foreach ($m[1] as $href) {
                $path = (string) wp_parse_url($href, PHP_URL_PATH);
                $path = untrailingslashit($path);
                if ('' !== $path) {
                    $existing_paths[] = $path;
                }
            }
        }

        echo $menu_html;

        // Append governance links (if the pages exist and are published),
        // skipping any that are already in the footer menu.
        if (class_exists(\QuietTruths\Core\Governance::class)) {
            foreach (\QuietTruths\Core\Governance::footerLinks() as $link) {
                $url_path = (string) wp_parse_url((string) $link['url'], PHP_URL_PATH);
                $url_path = untrailingslashit($url_path);
                // A menu item pointing to the same path counts as a
                // duplicate (e.g. /privacy/ == /privacy).
                $dup = false;
                foreach ($existing_paths as $ep) {
                    if ($ep === $url_path) { $dup = true; break; }
                }
                if ($dup) {
                    continue;
                }
                echo '<a href="' . esc_url($link['url']) . '">' . esc_html($link['label']) . '</a>';
                $existing_paths[] = $url_path;
            }
        }
    }
}

if (!function_exists('qt_search_overlay')) {
    function qt_search_overlay(): void
    {
        ?>
        <div class="qt-search-overlay" id="qt-search-overlay" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr__('Search stories', 'quiet-truths'); ?>">
            <div class="qt-search-overlay__panel">
                <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                    <p class="qt-search-overlay__prompt"><?php echo esc_html__('What are you looking for?', 'quiet-truths'); ?></p>
                    <input class="qt-search-overlay__input" type="search" name="s"
                           placeholder="<?php echo esc_attr__('Search for truth…', 'quiet-truths'); ?>"
                           value="<?php echo esc_attr(get_search_query()); ?>" autocomplete="off">
                </form>
                <div class="qt-live-suggest" id="qt-live-suggest" hidden></div>
            </div>
        </div>
        <?php
    }
}

if (!function_exists('qt_search_bar')) {
    /**
     * The typed search bar: an input with a search icon.
     *
     * @param string $value
     * @param string $id    Optional id for the input (for live search).
     */
    function qt_search_bar(string $value = '', string $id = ''): void
    {
        $idAttr = '' !== $id ? ' id="' . esc_attr($id) . '"' : '';

        echo '<form class="qt-searchbar" role="search" method="get" action="' . esc_url(home_url('/')) . '">';
        echo '<input class="qt-searchbar__input"' . $idAttr . ' data-qt-live type="search" name="s" placeholder="' . esc_attr__('Type what you are looking for…', 'quiet-truths') . '" value="' . esc_attr($value) . '" autocomplete="off" aria-label="' . esc_attr__('Search the house', 'quiet-truths') . '">';
        echo '<button class="qt-searchbar__button" type="submit" aria-label="' . esc_attr__('Search', 'quiet-truths') . '">';
        echo '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>';
        echo '</button>';
        echo '</form>';
    }
}

if (!function_exists('qt_concept_chips')) {
    /**
     * Tappable feeling labels — each opens the SEARCH RESULTS page in
     * concept mode: every story that is ABOUT the word, found through
     * the invisible layer, not by matching the word. The s= parameter
     * keeps WordPress on the search template, never the homepage.
     *
     * @param string[] $slugs Concept slugs from the knowledge base.
     */
    function qt_concept_chips(array $slugs, string $class = 'search-invitation__example'): void
    {
        $concepts = class_exists(\QuietTruths\Core\Concepts::class)
            ? \QuietTruths\Core\Concepts::concepts()
            : [];

        foreach ($slugs as $slug) {
            if (!isset($concepts[$slug])) {
                continue;
            }

            $name = (string) ($concepts[$slug]['name'] ?? $slug);

            echo '<a class="' . esc_attr($class) . '" href="' . esc_url(home_url('/?s=' . rawurlencode($name) . '&qt_concept=' . rawurlencode((string) $slug))) . '">'
                . esc_html($name) . '</a>';
        }
    }
}

if (!function_exists('qt_theme_card')) {
    /**
     * A theme door on the homepage — a promise of stories, not a room.
     * Just a name; nothing else. Quiet.
     *
     * @param array{name:string,tagline?:string,concepts:list<string>} $theme
     */
    function qt_theme_card(string $slug, array $theme): void
    {
        $name = (string) ($theme['name'] ?? $slug);

        echo '<a class="qt-door" href="' . esc_url(home_url('/?qt_theme=' . rawurlencode($slug))) . '">';
        echo '<span class="qt-door__name">' . esc_html($name) . '</span>';
        echo '</a>';
    }
}

if (!function_exists('qt_room_atmosphere')) {
    /**
     * The feel of a room, computed from its stories' AI profiles.
     *
     * Shows: a composed note, the top concepts (calibrated semantic
     * weights), the dominant invisible threads (family, grief, faith...),
     * and the most recently received story. Everything additive —
     * missing data is simply not rendered.
     *
     * @param array{count:int,words:list<string>,
     *   concepts:list<array{slug:string,name:string,weight:float,pct:int,stories:int}>,
     *   threads:list<array{slug:string,name:string,weight:float,pct:int,stories:int}>,
     *   emotions:list<array{label:string,stories:int}>,tone:string,
     *   comm_modes:list<string>,dense_share:int,newest:?\WP_Post,note:string} $atmo
     */
    function qt_room_atmosphere(array $atmo): void
    {
        if (empty($atmo['count'])) {
            return;
        }

        echo '<section class="room-atmosphere">';

        if (!empty($atmo['note'])) {
            echo '<p class="room-atmosphere__note">' . esc_html($atmo['note']) . '</p>';
        }

        if (!empty($atmo['concepts'])) {
            echo '<div class="room-shape" role="img" aria-label="' . esc_attr__('What this room has been made of', 'quiet-truths') . '">';
            echo '<p class="room-shape__heading">' . esc_html__('What is held here', 'quiet-truths') . '</p>';
            foreach ($atmo['concepts'] as $shape) {
                echo '<div class="room-shape__row">';
                echo '<span class="room-shape__name">' . esc_html((string) $shape['name']) . '</span>';
                echo '<span class="room-shape__track"><span class="room-shape__fill" style="width:' . (int) $shape['pct'] . '%"></span></span>';
                echo '<span class="room-shape__pct">' . (int) $shape['pct'] . '%</span>';
                echo '</div>';
            }
            echo '</div>';
        }

        if (!empty($atmo['threads'])) {
            echo '<div class="room-threads">';
            echo '<p class="room-threads__heading">' . esc_html__('Running through the stories', 'quiet-truths') . '</p>';
            $threadLabels = [];
            foreach ($atmo['threads'] as $thr) {
                $threadLabels[] = (string) ($thr['name'] ?? '');
            }
            $threadLabels = array_values(array_filter(array_map('strval', $threadLabels)));
            if (!empty($threadLabels)) {
                echo '<p class="room-threads__list">' . esc_html(implode(' · ', $threadLabels)) . '</p>';
            }
            echo '</div>';
        }

        if (!empty($atmo['comm_modes'])) {
            echo '<p class="room-comm">' . esc_html(implode(' · ', (array) $atmo['comm_modes'])) . '</p>';
        }

        if (!empty($atmo['newest']) && $atmo['newest'] instanceof \WP_Post) {
            $qt_newest = $atmo['newest'];

            echo '<div class="currently-held">';
            echo '<span class="currently-held__label">' . esc_html__('Currently held', 'quiet-truths') . '</span>';
            echo '<a class="currently-held__title" href="' . esc_url(get_permalink($qt_newest)) . '">' . esc_html((string) $qt_newest->post_title) . '</a>';
            echo '<span class="currently-held__meta">' . esc_html(get_the_date('j M Y', $qt_newest)) . '</span>';
            echo '</div>';
        }

        echo '</section>';
    }
}

if (!function_exists('qt_house_map')) {
    /**
     * The whole house at a glance — for All Stories.
     *
     * @param list<array{slug:string,name:string,count:int}> $map
     */
    function qt_house_map(array $map, int $total): void
    {
        if (empty($map)) {
            return;
        }

        echo '<section class="house-map">';
        echo '<p class="house-map__line">' . esc_html(sprintf(
            /* translators: %d number of stories */
            _n('The house holds %d story, gathered around:', 'The house holds %d stories, gathered around:', $total, 'quiet-truths'),
            $total
        )) . '</p>';
        echo '<div class="search-invitation__examples">';

        foreach ($map as $entry) {
            $n = (int) ($entry['stories'] ?? $entry['count'] ?? 0);
            echo '<a class="search-invitation__example" href="' . esc_url(home_url('/?s=' . rawurlencode((string) $entry['name']) . '&qt_concept=' . rawurlencode((string) $entry['slug']))) . '">'
                . esc_html((string) $entry['name'] . ' · ' . $n) . '</a>';
        }

        echo '</div>';
        echo '</section>';
    }
}

if (!function_exists('qt_cross_room_suggest')) {
    /**
     * Stories in other rooms that share this room's themes.
     *
     * @param list<\WP_Post> $posts
     */
    function qt_cross_room_suggest(array $posts, string $roomName): void
    {
        if (empty($posts)) {
            return;
        }

        echo '<section class="cross-suggest">';
        echo '<p class="rooms-section__label">' . esc_html__('From here, the house suggests', 'quiet-truths') . '</p>';
        echo '<p class="cross-suggest__note">' . esc_html(sprintf(
            /* translators: %s the name of the current room */
            __('Stories in other rooms that share what %s has been about.', 'quiet-truths'),
            $roomName
        )) . '</p>';

        foreach ($posts as $qt_cross) {
            qt_story_panel($qt_cross);
        }

        echo '</section>';
    }
}

/* ════════════════════════ journals ════════════════════════ */

if (!function_exists('qt_journal_byline')) {
    /**
     * The byline of a journal: name (meta override or WordPress author),
     * role, and bio.
     *
     * @return array{name:string,role:string,bio:string}
     */
    function qt_journal_byline($post): array
    {
        $post = get_post($post);

        if (!$post) {
            return ['name' => '', 'role' => '', 'bio' => ''];
        }

        $name = (string) get_post_meta($post->ID, '_qt_byline_name', true);
        $role = (string) get_post_meta($post->ID, '_qt_byline_role', true);
        $bio  = (string) get_post_meta($post->ID, '_qt_byline_bio', true);

        if ('' === trim($name)) {
            $author = get_userdata((int) $post->post_author);
            $name   = $author ? $author->display_name : '';
        }

        return [
            'name' => $name,
            'role' => $role,
            'bio'  => $bio,
        ];
    }
}

if (!function_exists('qt_journal_card')) {
    /**
     * A journal card for the archive — signed, not anonymous.
     *
     * @param int|\WP_Post|null $post
     */
    function qt_journal_card($post = null): void
    {
        $post = get_post($post);

        if (!$post) {
            return;
        }

        $byline = qt_journal_byline($post);
        $date   = get_the_date('j M Y', $post);
        $time   = qt_reading_time($post);

        echo '<article class="journal-panel">';
        echo '<div class="journal-panel__byline">';
        echo '<span class="journal-panel__byline-name">' . esc_html($byline['name'] ?: __('A writer', 'quiet-truths')) . '</span>';
        if ('' !== $byline['role']) {
            echo '<span class="journal-panel__byline-role">' . esc_html($byline['role']) . '</span>';
        }
        echo '</div>';

        echo '<h3 class="journal-panel__title"><a href="' . esc_url(get_permalink($post)) . '">' . esc_html((string) $post->post_title) . '</a></h3>';

        $excerpt = has_excerpt($post) ? get_the_excerpt($post) : wp_trim_words(wp_strip_all_tags((string) $post->post_content), 40, '…');
        echo '<p class="journal-panel__excerpt">' . esc_html($excerpt) . '</p>';

        echo '<div class="journal-panel__meta">';
        echo '<span>' . esc_html($date) . '</span>';
        if ('' !== $time) {
            echo '<span aria-hidden="true">·</span><span>' . esc_html($time) . '</span>';
        }
        echo '</div>';
        echo '</article>';
    }
}

if (!function_exists('qt_reading_time')) {
    /**
     * Approximate reading time for long-form pieces.
     *
     * Uses a Unicode-aware word split instead of str_word_count(),
     * which is ASCII-only and undercounts Swahili/Sheng and any
     * accented or non-Latin words.
     */
    function qt_reading_time($post): string
    {
        $post = get_post($post);

        if (!$post) {
            return '';
        }

        $words = preg_split('/\s+/u', trim(wp_strip_all_tags((string) $post->post_content))) ?: [];
        $words = array_filter($words, static fn ($w) => '' !== $w);
        $count = count($words);

        if ($count < 60) {
            return __('under a minute', 'quiet-truths');
        }

        $minutes = (int) ceil($count / 200);

        /* translators: %d minutes */
        return sprintf(_n('%d min read', '%d min read', $minutes, 'quiet-truths'), $minutes);
    }
}

if (!function_exists('qt_journal_bridge')) {
    /**
     * The quiet bridge at the end of a story: if a Journal continues
     * the conversation (most shared concepts), offer it — never push.
     */
    function qt_journal_bridge(int $storyId): void
    {
        if (!class_exists(\QuietTruths\Core\Concepts::class)) {
            return;
        }

        $journal = \QuietTruths\Core\Concepts::relatedJournal($storyId);

        if (!$journal) {
            return;
        }

        echo '<aside class="qt-bridge">';
        echo '<p>' . esc_html__('If you would like a deeper reflection on this subject, there is a Journal that continues the conversation:', 'quiet-truths') . '</p>';
        echo '<a class="qt-bridge__link" href="' . esc_url(get_permalink($journal)) . '">' . esc_html((string) $journal->post_title) . '</a>';
        echo '</aside>';
    }
}

if (!function_exists('qt_pagination')) {
    /**
     * The house's pagination — it turns pages; it does not speak in
     * numbers. "Turn the page →" / "← The page before".
     */
    function qt_pagination(): void
    {
        $next = get_next_posts_link(__('Turn the page →', 'quiet-truths'));
        $prev = get_previous_posts_link(__('← The page before', 'quiet-truths'));

        if (!$next && !$prev) {
            return;
        }

        echo '<nav class="qt-pagination" aria-label="' . esc_attr__('Pages of the collection', 'quiet-truths') . '">';

        if ($prev) {
            echo '<span class="qt-pagination__prev">' . $prev . '</span>';
        }

        if ($next) {
            echo '<span class="qt-pagination__next">' . $next . '</span>';
        }

        echo '</nav>';
    }
}

if (!function_exists('qt_search_invitation')) {
    /**
     * The feelings of the house — a few words a visitor might be
     * carrying, each opening the stories about it. No search box here;
     * the search lives behind "Begin here".
     *
     * @param string[] $conceptSlugs
     */
    function qt_search_invitation(array $conceptSlugs = []): void
    {
        $conceptSlugs = $conceptSlugs ?: ['hope', 'joy', 'happiness', 'success', 'peace', 'love'];

        echo '<section class="search-invitation">';
        echo '<p class="search-invitation__prompt">' . esc_html__('Looking for something in particular?', 'quiet-truths') . '</p>';
        echo '<div class="search-invitation__examples">';
        qt_concept_chips($conceptSlugs);
        echo '</div>';
        echo '</section>';
    }
}

/* ── Public "leave a story" form (shortcode + view) ──
 * Loaded last: it may call the qt_* helpers defined above.
 */
if (!defined('QT_STORY_FORM_LOADED')) {
    define('QT_STORY_FORM_LOADED', true);
    require_once __DIR__ . '/story-form.php';
}

/* ── Anonymous responses (view layer) ── */
if (!defined('QT_RESPONSES_VIEW_LOADED')) {
    define('QT_RESPONSES_VIEW_LOADED', true);
    require_once __DIR__ . '/responses.php';
}

/* ── Contact form (view layer) ── */
if (!defined('QT_CONTACT_VIEW_LOADED')) {
    define('QT_CONTACT_VIEW_LOADED', true);
    require_once __DIR__ . '/contact-form.php';
}
