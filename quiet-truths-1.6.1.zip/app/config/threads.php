<?php
/**
 * Quiet Truths — Threads (cross-cutting AI layer)
 *
 * Threads are the librarian's threads — the deep textures of human
 * experience that run through every room. They are *not* categories.
 * They do not appear as navigation, cards, or chips to readers or
 * writers. They are how the house understands the inside of a story
 * across the seven doors.
 *
 * A story goes in exactly ONE room (Beginnings, Heavy Hearts, …). But
 * many threads can be present in the same story: a single letter might
 * hold faith, family, love, and silence all at once. The room is
 * where the story is placed; the threads are what it is made of.
 *
 * Threads serve:
 *   - richer related-story suggestions across rooms (a Crossroads
 *     story about a mother might sit beside a Heavy Hearts story
 *     about the same mother);
 *   - semantic search ("stories about faith" pulls from every room
 *     without requiring a Faith category);
 *   - calibration of the AI ontology as the corpus grows;
 *   - future quiet surfaces (e.g. "more stories about fathers" under
 *     a story, as a soft link rather than a taxonomy).
 *
 * Threads are built from existing concepts. Add threads sparingly
 * — a thread must be a shape of experience broad enough to cross
 * every room, and deep enough that readers feel its presence even
 * when it is not named. A concept that belongs in only one room is
 * a concept, not a thread.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

return [
    /**
     * Family — the people we come from and the people we make.
     * Covers mothers, fathers, children, siblings, grandparents,
     * in-laws, ancestors, clan, marriage, inheritance, parenthood,
     * the family table, the family name.
     */
    'family' => [
        'name'        => 'Family',
        'description' => 'The people we come from — parents, children, siblings, elders, ancestors, the family that shapes us.',
        'concepts'    => ['family', 'parenthood', 'relationships', 'aging'],
        'words'       => [
            // family words are largely already in the family concept;
            // the thread adds marriage-specific and extended-family
            // vocabulary that spans rooms.
            'ndoa', 'mume', 'mke', 'mchumba', 'mahari', 'harusi',
            'familia', 'jamaa', 'ndugu', 'kizazi', 'ukoo', 'mzaa',
            'my mother', 'my father', 'my parents', 'our family',
            'married', 'wedding', 'husband', 'wife', 'fiancé', 'fiancée',
            'mother-in-law', 'father-in-law', 'in-laws', 'dowry',
            'bride price', 'polygamy', 'co-wife',
        ],
    ],

    /**
     * Faith & Belief — what we believe when no one is watching.
     * Covers Islam, Christianity, traditional belief, doubt, losing
     * faith, finding faith, prayer, the sacred, the question of God.
     * Deliberately named broadly so agnostic, atheist, and traditional-
     * belief stories are also held here.
     */
    'faith' => [
        'name'        => 'Faith & Belief',
        'description' => 'What we believe in — God, ancestors, prayer, doubt, losing and finding faith, the sacred.',
        'concepts'    => ['religion', 'hope', 'silence'],
        'words'       => [
            'mungu', 'allah', 'yesu', 'maombi', 'sala', 'kusali',
            'kanisa', 'msikiti', 'baraka', 'dua', 'imani',
            'malaika', 'roho', 'dhambi', 'toba', 'injili', 'quran',
            'bible', 'pastor', 'imam', 'priest', 'church', 'mosque',
            'prayer', 'praying', 'worship', 'faith', 'spiritual',
            'belief', 'doubt my faith', 'losing my faith', 'answered prayer',
            'miracle', 'sin', 'heaven', 'hell', 'soul', 'divine',
            'ancestors', 'traditional healer', 'mganga', 'mugumo', 'sacrifice',
        ],
    ],

    /**
     * Love & Intimacy — every way we hold one another.
     * Romantic love, friendship, marriage, affection, sex, heartbreak,
     * chosen family, the love that lasts, the love that breaks you.
     */
    'love' => [
        'name'        => 'Love & Intimacy',
        'description' => 'The ways we hold one another — romance, friendship, marriage, heartbreak, chosen family, closeness.',
        'concepts'    => ['relationships', 'love', 'friendship', 'jealousy', 'vulnerability', 'betrayal', 'separation'],
        'words'       => [
            'mpenzi', 'mapenzi', 'penzi', 'kupendana', 'ndoa',
            'mume', 'mke', 'mchumba', 'uchumba', 'talaka', 'kuachana',
            'love', 'loved', 'loving', 'lover', 'beloved', 'cherish',
            'romance', 'romantic', 'tenderness', 'affection',
            'in love', 'fell in love', 'fell out of love',
            'kissed', 'held me', 'held her', 'his hand', 'her hand',
            'boyfriend', 'girlfriend', 'partner', 'ex', 'break up',
            'broke up', 'divorced', 'cheating', 'affair', 'infidelity',
            'intimacy', 'intimate', 'sex', 'sexual', 'made love',
        ],
    ],

    /**
     * Work, Money & The Hustle — survival, sweat, what it costs.
     * Career, side hustle, chama, rent, school fees, retrenchment,
     * black tax, hunger, not having fare, getting out of bed when
     * you are tired. The economic texture of almost every life.
     */
    'work-money' => [
        'name'        => 'Work, Money & The Hustle',
        'description' => 'What we do to survive — work, hustle, rent, school fees, chama, hunger, the daily grind.',
        'concepts'    => ['work', 'money', 'education', 'ambition', 'justice', 'origins'],
        'words'       => [
            'kazi', 'biashara', 'pesa', 'hela', 'mshahara', 'mkopo',
            'deni', 'kodi', 'rent', 'bills', 'chama', 'akiba',
            'kukopa', 'kulipa', 'kufilisika', 'maskini', 'umasikini',
            'hustle', 'hustler', 'side hustle', 'kuchapa kazi',
            'boss', 'bosi', 'fired', 'sacked', 'retrenched', 'resigned',
            'salary', 'wages', 'debt', 'loan', 'rent arrears',
            'school fees', 'karo', 'kukosa karo', 'kutimuliwa shule',
            'black tax', 'supporting my family', 'sending money home',
            'mboga', 'sukuma wiki', 'githeri', 'ugali', 'no food',
            'hungry', 'kulala njaa', 'matatu fare', 'no fare',
            'kubana mkono', 'kupigania mchana',
        ],
    ],

    /**
     * The Body — health, illness, pregnancy, disability, pain.
     * Sickness, cancer, HIV, pregnancy, miscarriage, disability,
     * chronic pain, mental distress that lives in the body.
     */
    'body' => [
        'name'        => 'The Body',
        'description' => 'Health, illness, pregnancy, pain, disability — what the body carries and what it fails to carry.',
        'concepts'    => ['health', 'parenthood', 'addiction', 'healing'],
        'words'       => [
            'afya', 'ugonjwa', 'mgonjwa', 'kuugua', 'hospitali',
            'daktari', 'dawa', 'kansa', 'sukari', 'shinikizo',
            'damu', 'vidonge', 'upasuaji', 'kuumwa', 'maumivu',
            'pregnancy', 'pregnant', 'miscarriage', 'stillborn',
            'childbirth', 'kujifungua', 'kuzaa', 'kunyonyesha',
            'hospital', 'doctor', 'nurse', 'surgery', 'cancer',
            'diabetes', 'hypertension', 'hiv', 'asthma', 'chronic',
            'pain', 'disabled', 'disability', 'wheelchair', 'mlemavu',
            'kilema', 'chronic pain', 'bedridden', 'terminal',
            'depression', 'anxiety', 'panic', 'mfadhaiko', 'wasiwasi',
            'breakdown', 'panic attack', 'therapy', 'counselling',
        ],
    ],

    /**
     * Violence & Survival — the things people survive.
     * GBV, assault, abuse, rape, police, war, conflict, cruelty,
     * abandonment, neglect. Heavy. Never trafficked as entertainment.
     */
    'violence-survival' => [
        'name'        => 'Violence & Survival',
        'description' => 'The things people survive — abuse, assault, violence, neglect, cruelty, and the will to keep going.',
        'concepts'    => ['fear', 'betrayal', 'shame', 'courage', 'trauma'],
        'words'       => [
            'kupigwa', 'kupiga', 'kudhalilishwa', 'kubakwa',
            'unyanyasaji', 'ukatili', 'dhuluma', 'mashambulizi',
            'abuse', 'abused', 'abusive', 'beaten', 'beat me', 'hit me',
            'hit him', 'hit her', 'raped', 'rape', 'sexual assault',
            'assaulted', 'choked', 'strangled', 'domestic violence',
            'gbv', 'gender-based violence', 'defiled', 'defilement',
            'police', 'arrested', 'beaten by police', 'kupigwa na polisi',
            'neglected', 'abandoned', 'left me for dead', 'survived',
            'survivor', 'ran away', 'kukimbia', 'kutoroka',
            'threatened', 'threaten', 'gun', 'panga', 'knife',
        ],
    ],

    /**
     * Secrets & The Unsaid — what was never spoken.
     * Hidden truths, silence, confessions, the thing carried alone,
     * the thing you never told anyone, the lie, the double life.
     */
    'silence-secrets' => [
        'name'        => 'Silence & The Unsaid',
        'description' => 'Secrets, silence, the things never spoken — what is carried without being named.',
        'concepts'    => ['secrets', 'silence', 'shame', 'separation', 'memory'],
        'words'       => [
            'siri', 'kimya', 'kunyamaza', 'kuficha', 'kujificha',
            'sijamwambia', 'sikuambia', 'sikuzungumzia', 'kubeba mzigo',
            'msalaba wangu', 'secret', 'secrets', 'hidden', 'never told',
            'never said', 'kept to myself', 'unspoken', 'unsaid',
            'buried', 'locked away', 'hid from', 'hid it', 'hid him',
            'carried it', 'carrying it', 'heavy secret', 'nobody knew',
            'no one knew', 'pretended', 'pretending', 'double life',
            'lie', 'lied', 'lied to', 'deceit', 'cover up', 'covered up',
            'silent for years', 'never spoke of it', 'the quiet between us',
        ],
    ],

    /**
     * Justice & Fairness — being wronged, being heard.
     * Court, police, lawyer, accountability, corruption, being
     * cheated, winning a case, being failed by the system.
     */
    'justice' => [
        'name'        => 'Justice & Fairness',
        'description' => 'Being wronged, seeking fairness — court, police, corruption, accountability, being heard.',
        'concepts'    => ['justice', 'anger', 'courage'],
        'words'       => [
            'haki', 'dhuluma', 'kudhulumiwa', 'mahakama', 'polisi',
            'mwanasheria', 'ushahidi', 'kesi', 'kortini', 'mahakama',
            'rushwa', 'mafisadi', 'upholder', 'unfair', 'injustice',
            'court', 'courts', 'lawyer', 'evidence', 'vindicated',
            'accountability', 'wronged', 'complaint', 'compensation',
            'arrested', 'detained', 'locked up', 'jela', 'gereza',
            'kufungwa', 'corruption', 'bribe', 'bribery', 'rushwa',
            'fair', 'unfairly treated', 'fought back', 'reported it',
            'spoke up', 'spoke out', 'no one listened',
        ],
    ],

    /**
     * Place & Belonging — where we are from and where we land.
     * Home, village, city, estate, diaspora, abroad, migration,
     * the shamba, the single room, the estate, the homeland.
     */
    'place' => [
        'name'        => 'Place & Belonging',
        'description' => 'Where we are from and where we land — home, village, city, diaspora, belonging, displacement.',
        'concepts'    => ['home', 'origins', 'identity', 'migration'],
        'words'       => [
            'nyumbani', 'kwetu', 'kwao', 'kijijini', 'shambani',
            'mtaa', 'mjini', 'jiji', 'nyumba', 'asili yangu',
            'nilikotoka', 'nilikulia', 'home', 'village', 'rural',
            'hometown', 'neighbourhood', 'neighborhood', 'mtaa',
            'estate', 'kayole', 'kibera', 'mathare', 'mukuru',
            'eastlands', 'ghetto', 'geto', 'mtaani', 'landlord',
            'mpangaji', 'evicted', 'diaspora', 'abroad', 'overseas',
            'immigrant', 'migrated', 'moved to nairobi', 'moved abroad',
            'homesick', 'nostalgia', 'roots', 'ancestral home',
            'shamba', 'farm', 'countryside', 'compound', 'homestead',
            'bedsitter', 'single room', 'nyumba ya kupanga',
        ],
    ],

    /**
     * Time, Memory & Age — the years passing.
     * Childhood, growing up, aging, parents growing old, memory,
     * nostalgia, looking back, how fast time moves, waiting.
     */
    'time-memory' => [
        'name'        => 'Time, Memory & Age',
        'description' => 'The years passing — childhood, memory, nostalgia, aging, waiting, the long view.',
        'concepts'    => ['memory', 'aging', 'waiting', 'nostalgia'],
        'words'       => [
            'kumbukumbu', 'nakumbuka', 'zamani', 'siku za nyuma',
            'utotoni', 'uzee', 'mzee', 'wazee', 'miaka inapita',
            'memory', 'memories', 'remember', 'remembering', 'recall',
            'nostalgia', 'nostalgic', 'flashback', 'childhood',
            'growing up', 'grew up', 'when i was young', 'as a child',
            'old', 'older', 'growing old', 'elderly', 'grey hair',
            'wrinkles', 'retired', 'retirement', 'my mother is getting old',
            'my father', 'my parents are aging', 'time passes',
            'years later', 'looking back', 'looking back now',
            'waiting', 'subiri', 'kungoja', 'kusubiri', 'took years',
            'it took years', 'ten years later', 'i still remember',
            'haunt', 'haunted', 'echo',
        ],
    ],
];
