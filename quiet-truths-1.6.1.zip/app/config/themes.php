<?php
/**
 * Quiet Truths — House Doors (cross-cutting themes)
 *
 * DOORS ARE NOT ROOMS.
 *
 * The seven ROOMS (Beginnings · Heavy Hearts · Crossroads · Homecoming ·
 * Mending · Letters · Small Mercies) are where a story is PLACED by
 * mwenye nyumba — one room per story, defined canonically in
 * app/config/rooms.php.
 *
 * DOORS are reader-facing cross-cutting themes (family, work, faith,
 * love, loss, growth, healing). A story in any room can be opened via
 * any door; doors are search filters on the front page and All Stories
 * view, not placement categories. They exist so a reader can say "show
 * me stories about family" without caring which room those stories
 * live in.
 *
 * The AI's Thread layer (Family, Faith & Belief, Love & Intimacy, Work/
 * Money/The Hustle, The Body, Violence & Survival, Silence & The Unsaid,
 * Justice & Fairness, Place & Belonging, Time/Memory & Age) is separate
 * again — invisible, multi-valued, never shown as chips.
 *
 *   ROOMS   : where a story is placed    (canonical → config/rooms.php)
 *   THREADS : invisible textures the AI sees (→ config/threads.php)
 *   DOORS   : reader-facing cross-cuts   (this file)
 *
 * Keep these three layers distinct. Do not use doors to influence room
 * placement; room assignment is governed by RoomAffinity (AI) and by
 * mwenye nyumba (editorial).
 *
 * The eight doors below are frozen alongside the seven rooms.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

return [
    'family'    => ['name' => 'Family',    'tagline' => 'the people we come from',              'concepts' => ['family', 'parenthood', 'origins', 'home', 'aging', 'memory']],
    'work'      => ['name' => 'Work',      'tagline' => 'what we do, and what it costs',        'concepts' => ['work', 'money', 'education', 'ambition', 'justice']],
    'tradition' => ['name' => 'Tradition', 'tagline' => 'what was handed down to us',           'concepts' => ['religion', 'origins', 'family', 'memory']],
    'faith'     => ['name' => 'Faith',     'tagline' => 'what we believe when no one is watching', 'concepts' => ['religion', 'hope', 'healing', 'silence', 'peace']],
    'love'      => ['name' => 'Love',      'tagline' => 'the ways we hold one another',         'concepts' => ['relationships', 'friendship', 'joy', 'love', 'jealousy', 'boundaries']],
    'loss'      => ['name' => 'Loss',      'tagline' => 'what stays when someone goes',         'concepts' => ['grief', 'separation', 'loneliness', 'memory', 'aging', 'silence']],
    'growth'    => ['name' => 'Growth',    'tagline' => 'becoming, slowly',                     'concepts' => ['growth', 'identity', 'courage', 'education', 'ambition', 'vulnerability']],
    'healing'   => ['name' => 'Healing',   'tagline' => 'the mending that takes time',          'concepts' => ['healing', 'forgiveness', 'hope', 'peace', 'boundaries', 'silence']],
];
