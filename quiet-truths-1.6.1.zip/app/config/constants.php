<?php
/**
 * Quiet Truths — Configuration Constants
 *
 * Loaded by app/core/Config.php. Idempotent: safe to require more than once.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

if (defined('QT_THEME_VERSION')) {
    return;
}

/* ── Identity ── */
define('QT_THEME_VERSION', '1.6.1');
define('QT_TEXT_DOMAIN', 'quiet-truths');

/* ── Paths ── */
define('QT_THEME_DIR', get_stylesheet_directory());
define('QT_THEME_URI', get_stylesheet_directory_uri());
define('QT_APP_DIR', QT_THEME_DIR . '/app');
define('QT_APP_URI', QT_THEME_URI . '/app');
define('QT_DESIGN_SYSTEM_DIR', QT_APP_DIR . '/design-system');
define('QT_DESIGN_SYSTEM_URI', QT_APP_URI . '/design-system');
define('QT_ASSETS_URI', QT_THEME_URI . '/assets');

/* ── Content model ── */
define('QT_STORY_POST_TYPE', 'qt_story');
define('QT_ROOM_TAXONOMY', 'qt_room');

/* ── The house, directly ── */
define('QT_CONTACT_EMAIL', 'admin@quiettruths.co.ke');

/* Social links — fill these when the house is ready; leave '' to hide. */
define('QT_SOCIAL_FACEBOOK', '');
define('QT_SOCIAL_WHATSAPP', '');
define('QT_SOCIAL_X', '');

/* ── The rooms ──
 * Public-facing name/description for templates/navigation.
 *
 * THE CANONICAL ROOM DEFINITIONS live in app/config/rooms.php (loaded
 * by Config::init() at boot) — name, description, purpose, concepts,
 * signals, lexical cues, bias, prototype phrases all in ONE place.
 * This hard-coded array is a DEFENSIVE FALLBACK used only if Config
 * has not booted, so templates still have slug/name/description to
 * render. Do NOT expand this with concepts/lexical/prototypes.
 *
 *   ROOMS   : app/config/rooms.php   (placement + AI ontology; single source)
 *   THREADS : app/config/threads.php (invisible cross-cutting textures)
 *   DOORS   : app/config/themes.php  (reader-facing cross-cuts: family,
 *                                     work, faith, love, loss, growth,
 *                                     healing — NOT placement categories)
 *
 * These three layers are DISTINCT. AI components SCORE rooms
 * (RoomAffinity, Profile, StoryUnderstanding) but never REDEFINE what
 * a room means. "A room has one canonical definition."
 *
 * Seven rooms, FROZEN: Beginnings, Heavy Hearts (semantic gravity 0.02),
 * Crossroads, Homecoming, Mending, Letters, Small Mercies. Old slugs
 * (becoming, after-storm, unfinished, everyday-grace, quiet-victories)
 * are redirected below so no existing link breaks.
 */
if (!defined('QT_ROOMS')) {
    define('QT_ROOMS', [
        'beginnings' => [
            'slug'        => 'beginnings',
            'name'        => 'Beginnings',
            'description' => 'For when something starts — the first day, the first love, the city, the child, the morning after.',
        ],
        'heavy-hearts' => [
            'slug'        => 'heavy-hearts',
            'name'        => 'Heavy Hearts',
            'description' => 'Grief, betrayal, loneliness, illness, the weight carried quietly. What is heavy.',
        ],
        'crossroads' => [
            'slug'        => 'crossroads',
            'name'        => 'Crossroads',
            'description' => 'Choices that ask something of you — work, money, school fees, leaving, staying, the decision before you.',
        ],
        'homecoming' => [
            'slug'        => 'homecoming',
            'name'        => 'Homecoming',
            'description' => 'Family, village, the people you come from, faith handed down, the door that still knows your name.',
        ],
        'mending' => [
            'slug'        => 'mending',
            'name'        => 'Mending',
            'description' => 'Healing that is not finished — forgiveness, sobriety, learning to sleep again, putting yourself back together.',
        ],
        'letters' => [
            'slug'        => 'letters',
            'name'        => 'Letters',
            'description' => 'Words written to someone who may not read them — to the father, the child, the younger self, the stranger who was kind.',
        ],
        'small-mercies' => [
            'slug'        => 'small-mercies',
            'name'        => 'Small Mercies',
            'description' => 'Everyday kindness, the friend who showed up, the cup of tea, the day nothing went wrong, paying fees on time.',
        ],
    ]);
}

/* ── Old room slugs that no longer exist ──
 * Stories in these rooms are gently carried to the room that best
 * receives them; archive URLs are 301-redirected so no link breaks.
 */
if (!defined('QT_ROOM_REDIRECTS')) {
    define('QT_ROOM_REDIRECTS', [
        'becoming'        => 'beginnings',   // the work of becoming is the start of something
        'after-storm'     => 'mending',      // after the storm is the mending
        'unfinished'      => 'letters',      // unfinished truths live in letters and heavy-hearts
        'everyday-grace'  => 'small-mercies',// renamed, same room
        'quiet-victories' => 'small-mercies',// folded into small mercies
    ]);
}
