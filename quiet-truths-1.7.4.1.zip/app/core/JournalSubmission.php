<?php
/**
 * Quiet Truths — Journal Submission (formal editorial submission)
 *
 * A Journal is NOT public posting. It is a considered submission for
 * editorial review (Journal Bible §4, §14, §29). Unlike a Story, a
 * Journal requires accountable author information so the house can
 * establish authorship, communicate with the author, assess the work,
 * handle copyright/permissions and, if accepted, publish with an
 * appropriate byline.
 *
 * Collected:
 *   required — full name, email, age confirmation, author bio,
 *              Journal title, Journal content, copyright/permission
 *              declaration, Journal Terms agreement.
 *   optional — WhatsApp number, profession / area of work,
 *              areas of interest, supporting material.
 *
 * Privacy (§13): the email and WhatsApp are NEVER published. Only the
 * author name, bio, profession (if chosen) and approved material become
 * public — and only by editorial decision.
 *
 * The submission is stored as a `pending` qt_journal post with author
 * meta; final publication remains a human editorial gate (§14, §29).
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class JournalSubmission
{
    private const NONCE = 'qt_journal_submit';
    private const HOOK  = 'qt_journal_submission';

    /** @var list<string> */
    private static array $errors = [];

    /** @var array<string,string> */
    private static array $old = [];

    public static function init(): void
    {
        add_action('template_redirect', [self::class, 'maybeHandle']);
        add_action('wp_ajax_qt_journal_submit', [self::class, 'handleAjax']);
        add_action('wp_ajax_nopriv_qt_journal_submit', [self::class, 'handleAjax']);
        add_action('init', [self::class, 'registerShortcode'], 20);
        add_action('init', [self::class, 'ensureSubmissionPage'], 30);
    }

    /**
     * Ensure the /submit-a-journal/ page exists (one-time), containing the
     * submission-form shortcode. The operator/editor can edit it as needed.
     */
    public static function ensureSubmissionPage(): void
    {
        if (get_option('qt_journal_submit_page_done')) {
            return;
        }

        $existing = get_page_by_path('submit-a-journal');
        if ($existing instanceof \WP_Post) {
            update_option('qt_journal_submit_page_done', '1');
            return;
        }

        $id = wp_insert_post([
            'post_title'    => __('Submit a Journal', 'quiet-truths'),
            'post_name'     => 'submit-a-journal',
            'post_content'  => "<!-- wp:paragraph --><p>" . esc_html__('Journals enter editorial review. Submitting does not publish — the house decides.', 'quiet-truths') . "</p><!-- /wp:paragraph -->\n\n[qt_journal_submission]",
            'post_type'     => 'page',
            'post_status'   => 'publish',
            'post_author'   => 0,
            'comment_status'=> 'closed',
            'ping_status'   => 'closed',
        ], true);

        if (!is_wp_error($id)) {
            update_option('qt_journal_submit_page_done', '1');
        }
    }

    /**
     * Register the submission form shortcode. The component file defines
     * the shortcode renderer; ensure it is loaded wherever the form can
     * appear.
     */
    public static function registerShortcode(): void
    {
        $view = dirname(__DIR__) . '/presentation/components/journal-submission.php';
        if (is_file($view) && !defined('QT_JOURNAL_SUBMIT_VIEW_LOADED')) {
            define('QT_JOURNAL_SUBMIT_VIEW_LOADED', true);
            require_once $view;
        }
    }

    /** @return list<string> */
    public static function errors(): array
    {
        return self::$errors;
    }

    /** @return array<string,string> */
    public static function old(): array
    {
        return self::$old;
    }

    public static function held(): bool
    {
        return isset($_GET['qt_journal_submitted']);
    }

    public static function nonce(): string
    {
        return wp_create_nonce(self::NONCE);
    }

    /** The editorial relationship — submit, not publish (§29). */
    public static function submitLabel(): string
    {
        return __('Submit Journal for Editorial Review', 'quiet-truths');
    }

    /* ─────────────── handling ─────────────── */

    public static function maybeHandle(): void
    {
        if (is_admin() || (defined('REST_REQUEST') && REST_REQUEST)) {
            return;
        }
        if (empty($_POST['qt_journal_submit']) || !isset($_POST['_wpnonce'])) {
            return;
        }
        if (!wp_verify_nonce(sanitize_key(wp_unslash((string) $_POST['_wpnonce'])), self::NONCE)) {
            self::$errors[] = 'session';
            return;
        }

        self::process();

        if (!empty(self::$errors)) {
            return;
        }

        self::$old = [];
        wp_safe_redirect(add_query_arg('qt_journal_submitted', '1', wp_get_referer() ?: home_url('/journals/')));
        exit;
    }

    public static function handleAjax(): void
    {
        check_ajax_referer(self::NONCE, '_wpnonce');
        self::process();

        if (!empty(self::$errors)) {
            wp_send_json_error(['errors' => self::$errors]);
        }

        wp_send_json_success(['message' => 'submitted']);
    }

    /**
     * Validate and store the submission. Adds to self::$errors on any
     * problem; otherwise creates a pending qt_journal post with author
     * metadata and notifies the house.
     */
    private static function process(): void
    {
        // Honeypot: bots fill this hidden field.
        if (!empty($_POST['qt_website'])) {
            return;
        }

        if (!self::passesRate()) {
            self::$errors[] = 'rate';
            return;
        }

        $name       = isset($_POST['qt_j_name']) ? sanitize_text_field(wp_unslash((string) $_POST['qt_j_name'])) : '';
        $email      = isset($_POST['qt_j_email']) ? sanitize_email(wp_unslash((string) $_POST['qt_j_email'])) : '';
        $whatsapp   = isset($_POST['qt_j_whatsapp']) ? sanitize_text_field(wp_unslash((string) $_POST['qt_j_whatsapp'])) : '';
        $profession = isset($_POST['qt_j_profession']) ? sanitize_text_field(wp_unslash((string) $_POST['qt_j_profession'])) : '';
        $interests  = isset($_POST['qt_j_interests']) ? sanitize_textarea_field(wp_unslash((string) $_POST['qt_j_interests'])) : '';
        $bio        = isset($_POST['qt_j_bio']) ? sanitize_textarea_field(wp_unslash((string) $_POST['qt_j_bio'])) : '';
        $title      = isset($_POST['qt_j_title']) ? sanitize_text_field(wp_unslash((string) $_POST['qt_j_title'])) : '';
        $content    = isset($_POST['qt_j_content']) ? wp_kses_post(wp_unslash((string) $_POST['qt_j_content'])) : '';
        $material   = isset($_POST['qt_j_material']) ? sanitize_key(wp_unslash((string) $_POST['qt_j_material'])) : 'self';

        self::$old = [
            'name'       => $name,
            'email'      => $email,
            'whatsapp'   => $whatsapp,
            'profession' => $profession,
            'interests'  => $interests,
            'bio'        => $bio,
            'title'      => $title,
            'content'    => $content,
            'material'   => $material,
        ];

        // ── Required author information (§6) ──
        if ('' === trim($name) || mb_strlen($name) > 100) {
            self::$errors[] = 'name';
        }
        if ('' === $email || !is_email($email)) {
            self::$errors[] = 'email';
        }
        if ('' === trim($bio)) {
            self::$errors[] = 'bio';
        }
        if (mb_strlen($bio) > 800) {
            self::$errors[] = 'bio_long';
        }
        if (mb_strlen($profession) > 100) {
            self::$errors[] = 'profession';
        }
        if (mb_strlen($interests) > 500) {
            self::$errors[] = 'interests';
        }

        // ── The Journal itself (§7) ──
        if ('' === trim($title) || mb_strlen($title) > 140) {
            self::$errors[] = 'title';
        }

        $minWords = (int) apply_filters('quiet_truths_journal_min_words', 800);
        $wordCount = preg_split('/\s+/u', trim(wp_strip_all_tags($content))) ?: [];
        $wordCount = count(array_filter($wordCount, static fn ($w) => '' !== $w));

        if ($wordCount < $minWords) {
            self::$errors[] = 'short';
        }
        if (mb_strlen($content) > 40000) {
            self::$errors[] = 'long';
        }

        if (Responses::containsForbidden($title . ' ' . wp_strip_all_tags($content))) {
            self::$errors[] = 'profanity';
        }

        // ── Declarations (§5, §9, §11, §20) ──
        if (empty($_POST['qt_j_age'])) {
            self::$errors[] = 'age';
        }
        if (empty($_POST['qt_j_copyright'])) {
            self::$errors[] = 'copyright';
        }
        if (empty($_POST['qt_j_terms'])) {
            self::$errors[] = 'terms';
        }
        if (empty($_POST['qt_j_copyright_terms'])) {
            self::$errors[] = 'copyright_terms';
        }
        if (empty($_POST['qt_j_editorial'])) {
            self::$errors[] = 'editorial';
        }

        // Material relationship (§9).
        $allowedMaterial = ['self', 'permission', 'lawful', 'other'];
        if (!in_array($material, $allowedMaterial, true)) {
            self::$errors[] = 'material';
        }

        if (!empty(self::$errors)) {
            return;
        }

        // Store as a pending journal post with author metadata (§6, §13).
        $postId = wp_insert_post([
            'post_type'    => 'qt_journal',
            'post_status'  => 'pending',
            'post_title'   => $title,
            'post_content' => $content,
            'post_author'  => 0,
        ], true);

        if (is_wp_error($postId)) {
            error_log('Quiet Truths: could not store a Journal submission — ' . $postId->get_error_message());
            self::$errors[] = 'store';
            return;
        }

        update_post_meta($postId, '_qt_byline_name', $name);
        update_post_meta($postId, '_qt_byline_email', $email);
        if ('' !== $whatsapp)   update_post_meta($postId, '_qt_byline_whatsapp', $whatsapp);
        if ('' !== $profession) update_post_meta($postId, '_qt_byline_role', $profession);
        if ('' !== $interests)  update_post_meta($postId, '_qt_byline_interests', $interests);
        update_post_meta($postId, '_qt_byline_bio', $bio);
        update_post_meta($postId, '_qt_journal_material', $material);

        // Consent / declaration audit record.
        update_post_meta($postId, '_qt_journal_consent_at', current_time('mysql', true));
        update_post_meta($postId, '_qt_journal_consent_version', defined('QT_THEME_VERSION') ? QT_THEME_VERSION : '1.0');
        update_post_meta($postId, '_qt_journal_age', '18plus');
        update_post_meta($postId, '_qt_journal_copyright', '1');
        update_post_meta($postId, '_qt_journal_terms', '1');
        update_post_meta($postId, '_qt_journal_copyright_policy', '1');
        update_post_meta($postId, '_qt_journal_editorial_ack', '1');

        // The invisible layer — tag so discovery works during review.
        Concepts::tagStory($postId);

        self::notifyAdmin($postId, $name, $title, $email);
        self::notifyAuthor($postId, $name, $email, $title);
    }

    /**
     * Email confirmation to the author (§25).
     */
    private static function notifyAuthor(int $postId, string $name, string $email, string $title): void
    {
        if ('' === $email) {
            return;
        }

        $subject = __('[Quiet Truths] Your Journal submission has been received', 'quiet-truths');
        $body    = sprintf(
            "Dear %s,\n\nThank you for submitting your Journal — \"%s\" — to Quiet Truths.\n\nYour submission has been received and will be considered by our editorial team. Submission does not guarantee publication. If we need clarification or additional information, we will contact you using the details you provided.\n\nIf you need to follow up, please use the contact form on the site and reference your submission.\n\nWith care,\nQuiet Truths",
            $name,
            $title
        );

        wp_mail($email, $subject, $body, ['Content-Type: text/plain; charset=UTF-8']);
    }

    private static function passesRate(): bool
    {
        $key  = 'qt_jsub_rate_' . md5((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
        $lim  = (int) apply_filters('quiet_truths_journal_rate_limit', 3);
        $cnt  = (int) get_transient($key);

        if ($cnt >= $lim) {
            return false;
        }
        set_transient($key, $cnt + 1, HOUR_IN_SECONDS);
        return true;
    }

    private static function notifyAdmin(int $postId, string $name, string $title, string $email): void
    {
        $admin = get_option('admin_email');
        if (!$admin) {
            return;
        }

        wp_mail(
            $admin,
            __('[Quiet Truths] New Journal submission for editorial review', 'quiet-truths'),
            sprintf(
                "A Journal has been submitted for editorial review.\n\nName: %s\nEmail: %s\nTitle: %s\n\nReview it: %s",
                $name,
                $email,
                $title,
                admin_url('post.php?post=' . $postId . '&action=edit')
            ),
            ['Content-Type: text/plain; charset=UTF-8']
        );
    }
}
