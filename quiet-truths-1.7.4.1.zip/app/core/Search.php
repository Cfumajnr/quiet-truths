<?php
/**
 * Quiet Truths — Semantic Search
 *
 * Search that thinks, not just matches:
 *
 *  - Scope: stories (qt_story) and posts (post) only. Pages are excluded
 *    unless the query explicitly names a page (exact title or slug).
 *  - Expansion: the query is expanded through the search lexicon, so
 *    "marriage" also finds stories about weddings, vows and divorce.
 *  - Ranking: exact phrase > title > excerpt > content > synonym hits,
 *    with room-name matches boosted. Newest first within ties.
 *
 * The template search.php renders the results; this class does the work.
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Search
{
    public const PER_PAGE = 10;

    /**
     * Bound on how many scored candidates are retained in memory during
     * ranking (Corrections 30 & 31). Only the strongest candidates
     * survive the streaming batches; the rest are discarded before the
     * final sort. This keeps search scalable without ever loading the
     * whole archive into ranking memory — memory is bounded, not the
     * archive that is searched.
     *
     * This is a RANKING PARAMETER, not an intelligence ceiling
     * (Correction 6). It is configurable via the
     * `quiet_truths_search_top_k` filter, so it can change without
     * redesigning the search system.
     */
    public const TOP_K = 250;

    /**
     * Resolve the configured Top-K ranking bound (Correction 6). Allows
     * the value to be tuned as a ranking parameter while keeping the
     * archive search fully traversed and memory bounded.
     */
    public static function topK(): int
    {
        return max(1, (int) apply_filters('quiet_truths_search_top_k', self::TOP_K));
    }

    public static function init(): void
    {
        add_action('pre_get_posts', [self::class, 'scopeMainSearch']);
        add_filter('query_vars', static function (array $vars): array {
            $vars[] = 'qt_concept';

            return $vars;
        });
    }

    /**
     * Keep the main search query scoped to stories + posts so the
     * canonical s= query behaves like our custom one even before the
     * template takes over. Concept searches (?qt_concept=…) are made
     * to look like searches so the search template renders them.
     */
    public static function scopeMainSearch($query): void
    {
        if (is_admin() || !$query->is_main_query()) {
            return;
        }

        $concept = $query->get('qt_concept');

        if ('' !== (string) $concept && '' === (string) $query->get('s')) {
            $query->set('s', (string) $concept);
        }

        if (!$query->is_search()) {
            return;
        }

        $query->set('post_type', ['qt_story', 'post', 'qt_journal', 'page']);
    }

    /**
     * Concept search: all stories that are ABOUT a concept (hope, grief,
     * healing…), found through the invisible layer's tags — not by
     * matching the word in the story. Rooms are never shown.
     *
     * Note (Correction 5): `total`/`max_pages` reflect the ranked
     * discovery window (the strongest Top-K retained candidates), not
     * an exhaustive count of every matching story in the archive.
     *
     * @return array{
     *   query:string, expanded:list<string>, total:int,
     *   results:list<\WP_Post>, page:?\WP_Post, suggestions:list<string>,
     *   paged:int, max_pages:int, concept:?array{slug:string,name:string}
     * }
     */
    public static function runConcept(string $slug): array
    {
        $slug   = sanitize_key($slug);
        $concept = Concepts::concepts()[$slug] ?? null;

        // Unknown concept: fall back to ordinary semantic search.
        if (!$concept) {
            return self::run($slug);
        }

        $name  = (string) ($concept['name'] ?? $slug);
        $words = array_values((array) ($concept['words'] ?? []));
        $terms = array_slice($words, 0, 16);
        $paged = max(1, (int) get_query_var('paged'));

        // Candidate pool: the ENTIRE published archive, processed in
        // streaming batches so growth never causes search blindness or
        // memory pressure (Corrections 17, 25).
        $scored = [];

        self::forEachPublished(['qt_story', 'post', 'qt_journal', 'page'], function (int $id) use ($slug, $terms, &$scored): void {
            $post = get_post($id);

            if (!$post) {
                return;
            }

            // Layer 3 (concepts): tagged as about this concept. Uses
            // canonical conceptsOf() — reads _qt_concepts first, falls
            // back to legacy _qt_themes for older stories.
            if (in_array($slug, Concepts::conceptsOf($id), true)) {
                self::addScored($scored, $id, 'concept', 10);
            }

            $title   = mb_strtolower((string) $post->post_title, 'UTF-8');
            $content = mb_strtolower(wp_strip_all_tags((string) $post->post_content), 'UTF-8');

            foreach ($terms as $term) {
                if ('' === $term) {
                    continue;
                }
                if (str_contains($title, $term)) {
                    self::addScored($scored, $id, 'lexical', 4);
                } elseif (str_contains($content, $term)) {
                    self::addScored($scored, $id, 'lexical', 2);
                }
            }
        });

        $rankedIds = self::finalizeRanking($scored);

        $total    = count($rankedIds);
        $maxPages = max(1, (int) ceil($total / self::PER_PAGE));
        $paged    = min($paged, $maxPages);
        $slice    = array_slice($rankedIds, ($paged - 1) * self::PER_PAGE, self::PER_PAGE, true);

        $results = [];
        foreach ($slice as $id) {
            $post = get_post($id);
            if ($post) {
                $results[] = $post;
            }
        }

        // Other concepts worth offering when this one is empty.
        $suggestions = [];
        foreach (Concepts::concepts() as $otherSlug => $other) {
            if ($otherSlug === $slug) {
                continue;
            }
            $suggestions[] = (string) $otherSlug;
            if (count($suggestions) >= 6) {
                break;
            }
        }

        return [
            'query'       => $name,
            'expanded'    => $terms,
            'total'       => $total,
            'results'     => $results,
            'page'        => null,
            'suggestions' => $suggestions,
            'paged'       => $paged,
            'max_pages'   => $maxPages,
            'concept'     => ['slug' => $slug, 'name' => $name],
        ];
    }

    /**
     * Run the expanded search.
     *
     * @return array{
     *   query:string, expanded:list<string>, total:int,
     *   results:list<\WP_Post>, page:?\WP_Post, suggestions:list<string>,
     *   paged:int, max_pages:int
     * }
     */
    public static function run(string $rawQuery): array
    {
        $rawQuery = trim($rawQuery);
        $paged    = max(1, (int) get_query_var('paged'));

        if ('' === $rawQuery) {
            return self::emptyResult($paged);
        }

        $terms       = self::expandTerms($rawQuery);
        $suggestions = self::suggestionsFor($terms);
        $explicitPage = self::explicitPageMatch($rawQuery);

        // Candidate pool: the ENTIRE published archive, processed in
        // streaming batches so growth never causes search blindness or
        // memory pressure (Corrections 17, 25).
        $scored = [];

        self::forEachPublished(['qt_story', 'post', 'qt_journal', 'page'], function (int $id) use ($rawQuery, $terms, &$scored): void {
            $score = self::scorePost($id, $rawQuery, $terms);

            if ($score > 0) {
                // Lexical evidence component (Corrections 1–4). Bounded
                // top-K retention operates on the final weighted score.
                self::addScored($scored, $id, 'lexical', $score);
            }
        });

        // The invisible layer: stories tagged with a concept the query
        // touches are included even if the exact word never appears.
        self::addConceptMatches($terms, $scored);

        // The search-intent layer (Corrections 19–22): interpret the
        // natural-language query into concepts/threads/domains/context
        // and fan relevance across ALL seven Rooms. A Room is never a
        // search boundary — a query may surface stories from any Room.
        self::applyIntent($rawQuery, $scored);

        // Finalize ranking only after ALL evidence has been collected
        // (Corrections 1 & 4): compute final totals, then retain Top-K.
        $rankedIds = self::finalizeRanking($scored);

        $total     = count($rankedIds);
        $maxPages  = max(1, (int) ceil($total / self::PER_PAGE));
        $paged     = min($paged, $maxPages);
        $slice     = array_slice($rankedIds, ($paged - 1) * self::PER_PAGE, self::PER_PAGE, true);

        $results = [];
        foreach ($slice as $id) {
            $post = get_post($id);
            if ($post) {
                $results[] = $post;
            }
        }

        return [
            'query'       => $rawQuery,
            'expanded'    => $terms,
            'total'       => $total,
            'results'     => $results,
            'page'        => $explicitPage,
            'suggestions' => $suggestions,
            'paged'       => $paged,
            'max_pages'   => $maxPages,
            'concept'     => null,
        ];
    }

    /* ─────────────── term expansion ─────────────── */

    /**
     * @return list<string> Lowercased search terms, original words plus
     *                     concept expansions, capped for performance.
     */
    private static function expandTerms(string $rawQuery): array
    {
        $words = preg_split('/[\s,.;:!?"\'()]+/u', mb_strtolower($rawQuery, 'UTF-8')) ?: [];
        $words = array_values(array_filter(array_map('trim', $words), static fn (string $w) => '' !== $w));

        $terms   = [];
        $wordMap = Concepts::wordMap();

        foreach ($words as $word) {
            $terms[$word] = true;

            // Every concept that knows this word contributes its whole
            // family, so "muslim" brings in religion's other words.
            foreach ($wordMap[$word] ?? [] as $slug) {
                $concept = Concepts::concepts()[$slug] ?? null;

                if (!$concept) {
                    continue;
                }

                foreach ((array) ($concept['words'] ?? []) as $synonym) {
                    if (count($terms) >= 16) {
                        break 2;
                    }
                    $terms[$synonym] = true;
                }
            }

            if (count($terms) >= 16) {
                break;
            }
        }

        return array_keys($terms);
    }

    /**
     * @param list<string> $terms
     * @return list<string> Related words worth offering after an empty search.
     */
    private static function suggestionsFor(array $terms): array
    {
        $suggested = [];
        $wordMap   = Concepts::wordMap();

        foreach ($terms as $term) {
            foreach ($wordMap[$term] ?? [] as $slug) {
                $concept = Concepts::concepts()[$slug] ?? null;

                if (!$concept) {
                    continue;
                }

                $name = mb_strtolower((string) ($concept['name'] ?? ''), 'UTF-8');

                if ('' !== $name && !in_array($name, $terms, true) && !in_array($name, $suggested, true)) {
                    $suggested[] = $name;
                }

                foreach (array_slice((array) ($concept['words'] ?? []), 0, 4) as $word) {
                    if (!in_array($word, $terms, true) && !in_array($word, $suggested, true) && count($suggested) < 8) {
                        $suggested[] = $word;
                    }
                }
            }
        }

        return array_slice($suggested, 0, 8);
    }

    /* ─────────────── scoring ─────────────── */

    /**
     * @param list<string> $terms
     */
    private static function scorePost(int $postId, string $rawQuery, array $terms): int
    {
        $post = get_post($postId);

        if (!$post || 'publish' !== $post->post_status) {
            return 0;
        }

        $title   = mb_strtolower((string) $post->post_title, 'UTF-8');
        $content = mb_strtolower(wp_strip_all_tags((string) $post->post_content), 'UTF-8');
        $excerpt = mb_strtolower(wp_strip_all_tags((string) $post->post_excerpt), 'UTF-8');
        $raw     = mb_strtolower($rawQuery, 'UTF-8');

        $score = 0;

        // Exact phrase in the title is the strongest signal.
        if ('' !== $raw && str_contains($title, $raw)) {
            $score += 14;
        }
        if ('' !== $raw && str_contains($content, $raw)) {
            $score += 8;
        }

        foreach ($terms as $term) {
            if ('' === $term) {
                continue;
            }
            if (str_contains($title, $term)) {
                $score += 6;
            }
            if (str_contains($excerpt, $term)) {
                $score += 4;
            }
            if (str_contains($content, $term)) {
                $score += 3;
            }
        }

        // A story that lives in a room whose name or description echoes the
        // query deserves a nudge toward the top of its room.
        if ('qt_story' === $post->post_type) {
            $roomText = self::roomText($postId);

            if ('' !== $roomText) {
                foreach ($terms as $term) {
                    if ('' !== $term && str_contains($roomText, $term)) {
                        $score += 5;
                        break;
                    }
                }
            }
        }

        // The quiet librarian (AI layer) is allowed to add a small
        // resonance boost. The signal is soft (capped, weighted at 0..3)
        // so it never overrides exact-title or concept hits.
        if (Ai::enabled()) {
            $score = (int) round(apply_filters(
                'quiet_truths_search_extra_score',
                (float) $score,
                $postId,
                $rawQuery
            ));
        }

        return $score;
    }

    private static function roomText(int $postId): string
    {
        $terms = get_the_terms($postId, 'qt_room');

        if (is_wp_error($terms) || empty($terms)) {
            return '';
        }

        $room   = $terms[0];
        $pieces = [mb_strtolower($room->name, 'UTF-8'), mb_strtolower((string) $room->description, 'UTF-8')];

        $meta = defined('QT_ROOMS') ? QT_ROOMS : [];
        if (isset($meta[$room->slug])) {
            $pieces[] = mb_strtolower($meta[$room->slug]['name'], 'UTF-8');
            $pieces[] = mb_strtolower($meta[$room->slug]['description'], 'UTF-8');
        }

        return implode(' ', array_filter($pieces));
    }

    /* ─────────────── concept matching ─────────────── */

    /**
     * For every term, find the concepts that know it, then add stories
     * tagged with those concepts — with a healthy score. This is how
     * searching "muslim" finds a story about mosque and faith that
     * never says the word.
     *
     * @param list<string>     $terms
     * @param array<int,int>   $scored
     */
    private static function addConceptMatches(array $terms, array &$scored): void
    {
        $wordMap = Concepts::wordMap();
        $slugs   = [];

        foreach ($terms as $term) {
            foreach ($wordMap[$term] ?? [] as $slug) {
                $slugs[$slug] = true;
            }
        }

        if (empty($slugs)) {
            return;
        }

        // CURRENT SEARCH — canonical _qt_concepts (v8+ profiles) and
        // LEGACY FALLBACK (READ-ONLY) — _qt_themes (pre-v1.7.3 stories).
        //
        // Both are merged into a single concept-relevance layer so
        // visitors experience ONE search system, but they are resolved
        // SEPARATELY internally (Correction 24) and never conflated:
        //   - canonical concept match  → higher weight (current truth)
        //   - legacy concept match     → lower weight (transitional)
        //
        // CRITICAL BUG FIX (Correction 23): the old meta query used a
        // `NOT EXISTS` clause on the canonical key, which pulled posts
        // WITHOUT `_qt_concepts` into the result path regardless of
        // whether they contained the requested concept. That clause is
        // REMOVED. The canonical search now matches ONLY posts that
        // actually contain the requested Concept in `_qt_concepts`.
        //
        // Matching is done in PHP in streaming batches against the whole
        // archive so growth never causes search blindness or memory
        // pressure (Corrections 17, 25).
        self::forEachPublished(['qt_story', 'qt_journal'], function (int $id) use ($slugs, &$scored): void {
            if (self::hasCanonicalConcept($id, $slugs)) {
                // Canonical concept match (Correction 24).
                self::addScored($scored, $id, 'concept', 10);
            } elseif (self::hasLegacyTheme($id, $slugs)) {
                // Legacy concept match — separate, lower-weighted path.
                self::addScored($scored, $id, 'concept', 7);
            }
        });
    }

    /**
     * Does this post's canonical `_qt_concepts` store contain any of the
     * requested concept slugs? Canonical concept match (Correction 23/24).
     *
     * @param array<string,true> $slugs
     */
    private static function hasCanonicalConcept(int $postId, array $slugs): bool
    {
        $raw = get_post_meta($postId, '_qt_concepts', true);
        if (!is_array($raw)) {
            return false;
        }
        foreach ($raw as $row) {
            $s = is_string($row) ? $row : (is_array($row) ? (string) ($row['slug'] ?? '') : '');
            if ('' !== $s && isset($slugs[$s])) {
                return true;
            }
        }
        return false;
    }

    /**
     * Does this post's legacy `_qt_themes` store contain any of the
     * requested slugs? Read-only transitional path (Correction 24).
     *
     * @param array<string,true> $slugs
     */
    private static function hasLegacyTheme(int $postId, array $slugs): bool
    {
        $raw = get_post_meta($postId, '_qt_themes', true);
        if (!is_array($raw)) {
            return false;
        }
        foreach ($raw as $s) {
            if (isset($slugs[(string) $s])) {
                return true;
            }
        }
        return false;
    }

    /**
     * Per-layer contribution ceilings for the compositional search score
     * (Corrections 1 & 2). Each evidence layer is weighted and bounded so
     * no single layer (nor an accumulation of them) can run away; a story
     * can converge multiple forms of evidence without amassing unbounded
     * points. Exact weights remain tunable — this is the architecture.
     */
    private const SCORE_CAPS = [
        'lexical'  => 40,   // title/content/excerpt/room echo — strong
        'concept'  => 24,   // canonical + legacy concept matches — strong
        'thread'   => 16,   // recurring-current overlap — moderate
        'domain'   => 14,   // area-of-life overlap — moderate
        'context'  => 8,    // life-stage/tense/circumstance — light
        'semantic' => 8,    // vector-similarity fallback — bounded
        'depth'    => 8,    // content-type intent bias (story vs journal)
    ];

    /** @return array<string,int> */
    private static function newCandidate(): array
    {
        return [
            'lexical'  => 0,
            'concept'  => 0,
            'thread'   => 0,
            'domain'   => 0,
            'context'  => 0,
            'semantic' => 0,
            'total'    => 0,
        ];
    }

    /**
     * Add bounded evidence to one component of a candidate and recompute
     * the weighted total (Corrections 1–4). Each layer has a defined
     * ceiling, so converging evidence is accumulated without one story
     * amassing unbounded points.
     *
     * @param array<string,int> $cand
     */
    private static function addComponent(array &$cand, string $component, int $value): void
    {
        if ($value <= 0) {
            return;
        }
        $cap = self::SCORE_CAPS[$component] ?? PHP_INT_MAX;
        $cand[$component] = min($cap, $cand[$component] + $value);
        $cand['total'] = 0;
        foreach (self::SCORE_CAPS as $key => $_) {
            $cand['total'] += (int) ($cand[$key] ?? 0);
        }
    }

    /**
     * Add a bounded evidence component to the candidate pool, creating
     * the candidate if needed (Corrections 1–4).
     *
     * IMPORTANT: this method ONLY ACCUMULATES evidence. It never evicts
     * a candidate. A candidate must not be discarded while its evidence
     * is still being assembled (Correction 1) — it may look weak after
     * only one layer, then receive strong evidence from Concepts,
     * Threads, Domains, Context or semantic similarity. Ranking and
     * Top-K retention happen ONCE, in finalizeRanking(), after all
     * evidence passes have completed and every candidate's score is
     * complete.
     *
     * @param array<int,array<string,int>> $top  id => candidate
     * @param int                          $id
     * @param string                       $component
     * @param int                          $value
     */
    private static function addScored(array &$top, int $id, string $component, int $value): void
    {
        if ($value <= 0) {
            return;
        }
        if (!isset($top[$id])) {
            $top[$id] = self::newCandidate();
        }
        self::addComponent($top[$id], $component, $value);
    }

    /**
     * Finalize ranking AFTER all evidence has been collected: recompute
     * each candidate's final weighted total, sort descending, and retain
     * only the strongest Top-K completed candidates (Corrections 1–4, 5).
     *
     * The archive is fully searched; only the ranking window is bounded.
     * Eviction never happens on a partial score — only on complete ones.
     *
     * @param array<int,array<string,int>> $top  id => candidate (mutated)
     * @return list<int> ordered post IDs of the retained candidates
     */
    private static function finalizeRanking(array &$top): array
    {
        // Recompute final totals (each component is already capped).
        foreach ($top as $id => $cand) {
            $total = 0;
            foreach (self::SCORE_CAPS as $key => $_) {
                $total += (int) ($cand[$key] ?? 0);
            }
            $top[$id]['total'] = $total;
        }

        // Sort by final total, descending.
        uasort($top, static fn ($a, $b) => (int) $b['total'] <=> (int) $a['total']);

        // Retain only the strongest completed candidates.
        if (count($top) > self::topK()) {
            $top = array_slice($top, 0, self::topK(), true);
        }

        return array_keys($top);
    }

    /**
     * Stream the ENTIRE published archive of the given types in batches,
     * invoking $fn for every post ID (Correction 17).
     *
     * Unlike collecting every ID into an array first, this processes one
     * batch at a time and discards it before the next, so search can
     * grow substantially without memory becoming the new ceiling. Stable
     * ID ordering prevents pages shifting mid-iteration.
     *
     * @param list<string>   $postTypes
     * @param callable(int):void $fn
     */
    private static function forEachPublished(array $postTypes, callable $fn, int $per = 250): void
    {
        $page = 1;

        while (true) {
            $q = new \WP_Query([
                'post_type'      => $postTypes,
                'post_status'    => 'publish',
                'posts_per_page' => $per,
                'paged'          => $page,
                'fields'         => 'ids',
                'orderby'        => 'ID',
                'order'          => 'ASC',
                'no_found_rows'  => false,
            ]);
            if (empty($q->posts)) {
                break;
            }
            foreach ($q->posts as $id) {
                $fn((int) $id);
            }
            $page++;
            if ($page > (int) $q->max_num_pages) {
                break;
            }
        }
    }

    /* ─────────────── search intent layer ─────────────── */

    /**
     * Interpret a natural-language query into the background ontology
     * (concepts/threads/domains) and apply a cross-Room relevance boost
     * (Corrections 19–22, 46).
     *
     * This is an interpretation layer ONLY. It never creates new public
     * taxonomy (Correction 21) — it maps the query onto the existing
     * private Concepts/Threads/Domains and fans discovery across ALL
     * seven Rooms (Correction 22). A Room is a home, never a search
     * boundary.
     *
     * @param string         $rawQuery
     * @param array<int,int> $scored
     */
    private static function applyIntent(string $rawQuery, array &$scored): void
    {
        if ('' === trim($rawQuery)) {
            return;
        }

        $intent = self::parseIntent($rawQuery);
        $lexicalSignal = count($intent['concepts']) + count($intent['threads']) + count($intent['domains']);

        // Depth intent (Journal Bible §11–§14, §39–§42): does the reader
        // want lived experience (Stories), understanding (Journals), or
        // both? The reader is never asked — the AI decides silently.
        $depthIntent = self::depthIntent($rawQuery);

        // Ontology + context relevance (Corrections 1–4, 26): each layer
        // contributes a bounded component — concept, thread, domain and
        // context — that is ACCUMULATED (not max-of) toward the final
        // score. Cross-Room by design: it reads the profile, never the
        // assigned Room (Correction 18). Applied whenever any lexical
        // interpretation is present. The content-type bias is applied
        // inside the loop so a Journal can be favoured only when the
        // query genuinely calls for deeper exploration (§25 — depth is
        // not always better; the requested form is honoured).
        if ($lexicalSignal > 0) {
            self::forEachPublished(['qt_story', 'qt_journal'], function (int $id) use ($intent, $rawQuery, $depthIntent, &$scored): void {
                $profile = \QuietTruths\Ai\Profile::get($id);
                if (empty($profile)) {
                    return;
                }

                $concepts = array_keys((array) ($profile['concepts'] ?? []));
                $threadBlock = (array) ($profile['threads'] ?? []);
                $threads = array_keys((array) ($threadBlock['active'] ?? $threadBlock['scores'] ?? $threadBlock));
                // Domains are stored as { scores: {...}, derived_from: '...' }.
                // Domain intent must read the ACTUAL domain scores, not the
                // top-level keys (which include the 'scores'/'derived_from'
                // wrapper keys). Correction 2.
                $domainBlock = (array) ($profile['domains'] ?? []);
                $domains = array_keys((array) ($domainBlock['scores'] ?? []));

                if (count(array_intersect($concepts, $intent['concepts'])) > 0) {
                    self::addScored($scored, $id, 'concept', 6 * count(array_intersect($concepts, $intent['concepts'])));
                }
                if (count(array_intersect($threads, $intent['threads'])) > 0) {
                    self::addScored($scored, $id, 'thread', 5 * count(array_intersect($threads, $intent['threads'])));
                }
                if (count(array_intersect($domains, $intent['domains'])) > 0) {
                    self::addScored($scored, $id, 'domain', 4 * count(array_intersect($domains, $intent['domains'])));
                }

                // Context relevance (Correction 27): small, controlled.
                self::addScored($scored, $id, 'context', self::scoreContext($profile, $rawQuery));

                // Content-type bias (bounded) — the depth-intent layer
                // (Journal Bible §11–§14). A separate, capped component so
                // it refines ranking without overpowering ontology evidence.
                self::addScored($scored, $id, 'depth', self::contentTypeBias($profile, $depthIntent));
            });
        }

        // Semantic fallback (Corrections 21, 22): when lexical
        // Concept/Thread/Domain interpretation is weak, let semantic
        // similarity still help interpret the query so the system can
        // discover subjects it was never explicitly programmed to
        // anticipate — including word variations that no phrase list
        // could exhaustively cover. The boost is deliberately capped so
        // semantic never dominates strong lexical/concept evidence.
        if ($lexicalSignal <= 1) {
            self::semanticIntentFallback($rawQuery, $scored);
        }
    }

    /**
     * Classify the reader's depth intent from natural language
     * (Journal Bible §11–§14, §39–§42). The reader is never asked to
     * choose between Stories and Journals; the AI decides silently.
     *
     * Returns a signed bias in roughly [-3, +3]:
     *   negative → favour lived experience (Stories)
     *   positive → favour understanding / depth (Journals)
     *   ~0      → show both, let ranking decide
     *
     * @return int
     */
    private static function depthIntent(string $rawQuery): int
    {
        $raw = mb_strtolower($rawQuery, 'UTF-8');

        $experience = [
            'stories', 'story about', 'someone who', 'people who', 'stories from',
            'i want to read about', 'show me stories', 'went through', 'experienced',
            'have you been through', 'read about someone',
        ];
        $understanding = [
            'why', 'what does', 'what does it mean', 'why does', 'why do',
            'explain', 'understand', 'tell me about the', 'tell me why',
            'what lies', 'what surrounds', 'what can we', 'what have we',
            'the meaning', 'in depth', 'deeper', 'examine', 'what happens',
            'how does', 'analysis', 'reflect', 'question of',
        ];

        $e = 0;
        foreach ($experience as $cue) {
            if (str_contains($raw, $cue)) $e++;
        }
        $u = 0;
        foreach ($understanding as $cue) {
            if (str_contains($raw, $cue)) $u++;
        }

        // A plain single subject with no intent marker (e.g. "school
        // fees") → neutral: show both, let relevance decide (§42).
        if (0 === $e && 0 === $u) {
            return 0;
        }

        // Slight bounded weight so neither side overpowers the shared
        // ontology evidence (Correction 26 / §25).
        return max(-3, min(3, $u - $e));
    }

    /**
     * Apply the depth-intent bias to a single candidate's profile.
     * Journals are preferred only when the query calls for deeper
     * exploration; Stories are honoured when the reader asks for lived
     * experience (§25 — depth is not automatically better).
     */
    private static function contentTypeBias(array $profile, int $depthIntent): int
    {
        if (0 === $depthIntent) {
            return 0;
        }

        $isJournal = ('journal' === ($profile['content_type'] ?? 'story'));

        // Positive intent → the reader wants understanding/depth → the
        // Journal is the favoured form. Negative intent → lived experience
        // → the Story is favoured. Return a small non-negative boost to
        // whichever form the query favours; the other form gets none, so
        // it is naturally ranked by the shared ontology evidence alone.
        if ($depthIntent > 0) {
            return $isJournal ? $depthIntent * 2 : 0;
        }

        return $isJournal ? 0 : (-1 * $depthIntent) * 2;
    }

    /**
     * Parse a natural-language query into the background ontology.
     *
     * @return array{concepts:list<string>,threads:list<string>,domains:list<string>}
     */
    private static function parseIntent(string $rawQuery): array
    {
        $raw   = mb_strtolower($rawQuery, 'UTF-8');
        $words = preg_split('/[\s,.;:!?"\'()]+/u', $raw) ?: [];
        $words = array_values(array_filter(array_map('trim', $words), static fn (string $w) => '' !== $w));

        $conceptSlugs = [];
        $threadSlugs  = [];
        $domainSlugs  = [];

        $wordMap   = Concepts::wordMap();
        $threadMap = self::threadWordMap();
        $domainMap = self::domainWordMap();

        foreach ($words as $w) {
            foreach ($wordMap[$w] ?? [] as $c)   $conceptSlugs[$c] = true;
            foreach ($threadMap[$w] ?? [] as $t) $threadSlugs[$t]  = true;
            foreach ($domainMap[$w] ?? [] as $d) $domainSlugs[$d]  = true;
        }

        // Multi-word intent phrases that single tokens miss.
        self::phraseIntent($raw, $conceptSlugs, $threadSlugs, $domainSlugs);

        return [
            'concepts' => array_keys($conceptSlugs),
            'threads'  => array_keys($threadSlugs),
            'domains'  => array_keys($domainSlugs),
        ];
    }

    /**
     * thread word → thread slug map, built once from the LIVE open-ended
     * thread definitions (Corrections 16–18). Reads via
     * ThreadInference::definitions() so candidate threads stay gated by
     * their own lifecycle — only established vocabulary is indexed here.
     *
     * @return array<string,list<string>>
     */
    private static function threadWordMap(): array
    {
        static $map = null;
        if (null !== $map) {
            return $map;
        }
        $map = [];
        if (!class_exists('\\QuietTruths\\Ai\\ThreadInference')) {
            return $map;
        }
        try {
            $defs = \QuietTruths\Ai\ThreadInference::definitions();
        } catch (\Throwable $e) {
            $defs = [];
        }
        foreach ($defs as $slug => $def) {
            foreach ((array) ($def['words'] ?? []) as $w) {
                $w = mb_strtolower(trim((string) $w), 'UTF-8');
                if ('' !== $w) {
                    $map[$w][] = $slug;
                }
            }
        }
        return $map;
    }

    /**
     * domain keyword → domain slug map, built once from the private
     * domain knowledge base (Correction 15). Multi-word natural-language
     * aliases are handled by phraseIntent() separately.
     *
     * @return array<string,list<string>>
     */
    private static function domainWordMap(): array
    {
        static $map = null;
        if (null !== $map) {
            return $map;
        }
        $map = [];

        $domains = [];
        try {
            $domains = \QuietTruths\Core\Config::instance()->domains();
        } catch (\Throwable $e) {
            $domains = [];
        }
        if (!is_array($domains)) {
            $domains = [];
        }
        foreach ($domains as $slug => $d) {
            if (!is_array($d)) {
                continue;
            }
            $text = mb_strtolower((string) ($d['name'] ?? '') . ' ' . (string) ($d['description'] ?? ''), 'UTF-8');
            foreach (preg_split('/[\s,.;:!?"\'()]+/u', $text) ?: [] as $w) {
                $w = trim($w);
                if ('' !== $w && mb_strlen($w, 'UTF-8') >= 3) {
                    $map[$w][] = $slug;
                }
            }
        }

        return $map;
    }

    /**
     * Curated multi-word natural-language intents (Corrections 20, 46).
     * These map whole phrases — which single tokens miss — onto the
     * existing private Concepts/Threads/Domains. They are interpretation
     * aliases, never new public taxonomy.
     *
     * @param array<string,true> $conceptSlugs
     * @param array<string,true> $threadSlugs
     * @param array<string,true> $domainSlugs
     */
    private static function phraseIntent(string $raw, array &$conceptSlugs, array &$threadSlugs, array &$domainSlugs): void
    {
        $phrases = [
            // "people struggling to pay school fees"
            'school fees'        => [['money','education','parenthood','family'], ['responsibility','sacrifice','care'], ['money-material','education-growth','family-care','work-livelihood']],
            'school-fees'        => [['money','education','parenthood','family'], ['responsibility','sacrifice','care'], ['money-material','education-growth','family-care','work-livelihood']],
            'paying school fees' => [['money','education','parenthood','family'], ['responsibility','sacrifice','care'], ['money-material','education-growth','family-care']],
            'raise a child'      => [['parenthood','family'], ['responsibility','care'], ['family-care','life-stages']],
            'raising a child'    => [['parenthood','family'], ['responsibility','care'], ['family-care','life-stages']],
            // "people starting again after losing their jobs"
            'starting again'     => [['hope','work','money'], ['becoming','transition','survival-resilience'], ['healing-recovery','life-stages','work-livelihood']],
            'starting over'      => [['hope'], ['becoming','transition','survival-resilience'], ['healing-recovery','life-stages']],
            'start over'         => [['hope'], ['becoming','transition','survival-resilience'], ['healing-recovery','life-stages']],
            'lost my job'        => [['work','money'], ['survival-resilience','transition','loss'], ['work-livelihood','loss-change','money-material']],
            'losing my job'      => [['work','money'], ['survival-resilience','transition','loss'], ['work-livelihood','loss-change','money-material']],
            // "going home after many years"
            'going home'         => [['home','origins','family'], ['belonging','memory','aging-legacy'], ['home-belonging','memory-time','place-environment']],
            'after many years'   => [['memory','origins'], ['memory','waiting','aging-legacy'], ['memory-time','life-stages']],
            'migration'          => [['origins','home'], ['transition','belonging'], ['home-belonging','life-stages','place-environment']],
            'caregiving'         => [['family'], ['care','responsibility'], ['family-care','health-vulnerability']],
            'taking care'        => [['family'], ['care','responsibility'], ['family-care','health-vulnerability']],
            'lifestyle'          => [[], [], ['everyday-life','identity-self','home-belonging','culture-society']],
        ];

        foreach ($phrases as $phrase => [$cons, $threads, $doms]) {
            if (str_contains($raw, $phrase)) {
                foreach ($cons    as $c) $conceptSlugs[$c] = true;
                foreach ($threads as $t) $threadSlugs[$t]  = true;
                foreach ($doms    as $d) $domainSlugs[$d]  = true;
            }
        }
    }

    /**
     * Small, controlled context-relevance signal for search intent
     * (Correction 27). Reads the profile's context block (tense, life
     * stage, circumstance, relationships) and rewards overlap with the
     * reader's own contextual wording. Capped low so it refines, never
     * dominates, discovery.
     *
     * @param array<string,mixed> $profile
     */
    private static function scoreContext(array $profile, string $raw): int
    {
        $context = (array) ($profile['context'] ?? []);
        $score   = 0;
        $raw     = mb_strtolower($raw, 'UTF-8');

        // Relationship / life-stage / circumstance overlap.
        $refs = [];
        foreach ((array) ($context['life_stage'] ?? []) as $v) {
            $refs[] = str_replace('-', ' ', mb_strtolower((string) $v, 'UTF-8'));
        }
        foreach ((array) ($context['circumstance'] ?? []) as $v) {
            $refs[] = str_replace('-', ' ', mb_strtolower((string) $v, 'UTF-8'));
        }
        foreach ((array) ($context['relationships'] ?? []) as $v) {
            $refs[] = str_replace('-', ' ', mb_strtolower((string) $v, 'UTF-8'));
        }

        $words = preg_split('/[\s,.;:!?"\'()]+/u', $raw) ?: [];
        $words = array_values(array_filter(array_map('trim', $words), static fn (string $w) => mb_strlen($w, 'UTF-8') >= 3));

        foreach ($refs as $ref) {
            if ('' === $ref) {
                continue;
            }
            foreach ($words as $w) {
                if ('' !== $w && (str_contains($ref, $w) || str_contains($w, $ref))) {
                    $score += 2;
                    break;
                }
            }
        }

        // Tense-orientation overlap (e.g. a remembered/past query vs a
        // hoped-for future one are meaningfully different contexts).
        $tense = (array) ($context['tense'] ?? []);
        $tenseSignals = [
            'past'          => ['was', 'had', 'before', 'ago', 'remember', 'used to', 'lost', 'left', 'died', 'back', 'after'],
            'remembered'    => ['remember', 'memory', 'used to', 'when i was'],
            'future_hoped'  => ['hope', 'will', 'someday', 'one day', 'dream', 'looking forward', 'want to'],
            'future_feared' => ['afraid', 'fear', 'might', 'worried', 'dread'],
            'present'       => ['now', 'still', 'today'],
        ];
        foreach ($tenseSignals as $slot => $cues) {
            if (($tense[$slot] ?? 0) <= 0.3) {
                continue;
            }
            foreach ($cues as $cue) {
                if (str_contains($raw, $cue)) {
                    $score += 2;
                    break;
                }
            }
        }

        return min($score, 6);
    }

    /**
     * Semantic fallback for search intent (Corrections 21, 22): when
     * lexical Concept/Thread/Domain interpretation is weak, embed the
     * query and score stories by vector similarity against their stored
     * representation. This lets the system converge word variations
     * ("school fees" / "paying school fees" / "can't afford my child's
     * school") toward the same background meaning without a manual
     * phrase for every variant. The boost is capped so semantic evidence
     * refines but never dominates strong lexical evidence (Correction 26).
     *
     * @param array<int,int> $scored
     */
    private static function semanticIntentFallback(string $rawQuery, array &$scored): void
    {
        if (!class_exists('\\QuietTruths\\Ai\\Embeddings')) {
            return;
        }
        // Embed the query once. Falls back to a local token vector if the
        // embedding service is down, so discovery still works offline.
        try {
            $qvec = \QuietTruths\Ai\Embeddings::embed([$rawQuery]);
        } catch (\Throwable $e) {
            $qvec = null;
        }
        $qvec = is_array($qvec) ? ($qvec[0] ?? []) : [];
        if (empty($qvec)) {
            return;
        }

        self::forEachPublished(['qt_story', 'qt_journal'], function (int $id) use ($qvec, &$scored): void {
            $dvec = \QuietTruths\Ai\Embeddings::forPostRead($id);
            if (empty($dvec)) {
                return;
            }
            $sim = \QuietTruths\Ai\Embeddings::vectorSimilarity($qvec, $dvec);
            $boost = (int) round($sim * 12);
            if ($boost > 0) {
                // Semantic component — bounded and accumulated alongside
                // the other layers (Correction 14). It refines discovery
                // but its ceiling keeps it from overpowering strong
                // direct/ontology evidence.
                self::addScored($scored, $id, 'semantic', min($boost, 8));
            }
        });
    }

    /* ─────────────── explicit page ─────────────── */

    /**
     * A page only surfaces when the visitor is clearly asking for it:
     * the query equals the page title, or the page slug.
     */
    private static function explicitPageMatch(string $rawQuery): ?\WP_Post
    {
        $raw   = mb_strtolower(trim($rawQuery), 'UTF-8');
        $slug  = sanitize_title($rawQuery);
        $pages = get_posts([
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'posts_per_page' => 100,
        ]);

        foreach ($pages as $page) {
            $title = mb_strtolower((string) $page->post_title, 'UTF-8');
            $pageSlug = (string) $page->post_name;

            if ($raw === $title || $raw === $pageSlug || $slug === $pageSlug) {
                return $page;
            }
        }

        return null;
    }

    private static function emptyResult(int $paged): array
    {
        return [
            'query'       => '',
            'expanded'    => [],
            'total'       => 0,
            'results'     => [],
            'page'        => null,
            'suggestions' => [],
            'paged'       => $paged,
            'max_pages'   => 1,
            'concept'     => null,
        ];
    }
}
