<?php
/**
 * Quiet Truths — Application
 *
 * The boot point called by functions.php:
 *
 *     \QuietTruths\Core\Application::boot();
 *
 * Wires configuration, assets, theme supports, menus and the
 * content model (stories + rooms).
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

/* ── Deterministic class loading ──
 * Explicit requires keep the boot chain airtight; the autoloader is a
 * safety net for any future QuietTruths\* classes. (Linux filesystems
 * are case-sensitive, so the autoloader also tries a lowercase path.)
 */
require_once __DIR__ . '/Config.php';
require_once __DIR__ . '/AssetRegistry.php';
require_once __DIR__ . '/Submission.php';
require_once __DIR__ . '/Search.php';
require_once __DIR__ . '/Responses.php';
require_once __DIR__ . '/Reactions.php';
require_once __DIR__ . '/JournalSubmission.php';
require_once __DIR__ . '/JournalComments.php';
require_once __DIR__ . '/Concepts.php';
require_once __DIR__ . '/Themes.php';
require_once __DIR__ . '/Seo.php';
require_once __DIR__ . '/Contact.php';
require_once __DIR__ . '/Rooms.php';
require_once __DIR__ . '/Security.php';
require_once __DIR__ . '/Ai.php';
require_once __DIR__ . '/Governance.php';

// AI layer (profile, embeddings, signals, threads, ontology)
require_once dirname(__DIR__) . '/ai/Signals.php';
require_once dirname(__DIR__) . '/ai/RoomAffinity.php';
require_once dirname(__DIR__) . '/ai/ThreadInference.php';
require_once dirname(__DIR__) . '/ai/PrototypeCache.php';

spl_autoload_register(static function (string $class): void {
    $prefix = 'QuietTruths\\';

    if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
        return;
    }

    $base       = dirname(__DIR__);
    $relative   = str_replace('\\', '/', substr($class, strlen($prefix)));
    $candidates = [$relative, strtolower($relative)];

    foreach ($candidates as $candidate) {
        $path = $base . '/' . $candidate . '.php';

        if (is_file($path)) {
            require_once $path;
            return;
        }
    }
});

final class Application
{
    private static bool $booted = false;

    public static function boot(): void
    {
        if (self::$booted) {
            return;
        }
        self::$booted = true;

        Config::init();
        AssetRegistry::init();
        Submission::init();
        Search::init();
        Responses::init();
        Reactions::init();
        JournalSubmission::init();
        JournalComments::init();
        Concepts::init();
        Themes::init();
        Seo::init();
        Contact::init();
        Security::init();
        Ai::init();
        Governance::init();

        // House-keeping: the site has no WordPress comments, so do not
        // advertise a comments feed. XML-RPC is already disabled in
        // Security.php (login hardening); we reinforce it here by also
        // emptying the methods table and disabling pingbacks.
        add_filter('feed_links_show_comments_feed', '__return_false');
        add_filter('xmlrpc_methods', '__return_empty_array', PHP_INT_MAX);
        add_filter('pings_open', '__return_false');

        add_action('template_redirect', [self::class, 'redirectOldStoryLinks']);
        add_action('template_redirect', [self::class, 'redirectOldRooms'], 1);
        add_filter('wp_get_nav_menu_items', [self::class, 'cleanMenuItems'], 10, 2);
        add_action('pre_get_posts', [self::class, 'storyArchiveSort']);
        add_action('pre_get_posts', [self::class, 'roomArchivePagination']);
        add_action('init', [self::class, 'ensureStoryMeta'], 30);

        self::registerThemeSupports();
        self::registerMenus();
        self::registerStoryPostType();
        self::registerJournalPostType();
        self::registerRoomTaxonomy();
        self::ensureRoomTerms();
        self::migrateRemovedRooms();
        self::registerRoomPicker();
        self::registerJournalByline();
        self::registerMetaDescription();

        add_action('after_switch_theme', [self::class, 'flushRewriteRules']);

        // WP-CLI commands register on cli_init so they only load when
        // a wp-cli process is running (never on web requests). The
        // autoloader already maps QuietTruths\Cli\* to app/cli/*.
        if (defined('WP_CLI') && WP_CLI) {
            add_action('cli_init', [self::class, 'registerCliCommands']);
        }

        // One-time backfill: anonymise any existing story whose
        // post_author still points at a WP user. The post type is
        // anonymous; older imports / manual approvals may have left a
        // user id attached. We only run once.
        add_action('init', [self::class, 'anonymiseStoryAuthors'], 20);
    }

    /**
     * Register WP-CLI commands for the Quiet Truths AI subsystem.
     *
     * Kept deliberately tiny — each command class self-registers on
     * load via WP_CLI::add_command(). Web requests never touch this.
     */
    public static function registerCliCommands(): void
    {
        if (!defined('WP_CLI') || !WP_CLI) {
            return;
        }
        require_once dirname(__DIR__) . '/cli/AiCommands.php';
        require_once dirname(__DIR__) . '/cli/MigrateCommands.php';
    }

    /**
     * Set post_author = 0 for every qt_story that still has a user id.
     * Runs exactly once per version where the story post type changes
     * its anonymity guarantees.
     */
    public static function anonymiseStoryAuthors(): void
    {
        if (get_option('qt_story_authors_anonymised') === QT_THEME_VERSION) {
            return;
        }

        global $wpdb;

        // Direct UPDATE is safe here — we touch only the post_author
        // column on the qt_story post type. wp_update_post would trigger
        // hooks and re-profile every story unnecessarily.
        $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$wpdb->posts} SET post_author = 0 WHERE post_type = %s AND post_author != 0",
                'qt_story'
            )
        );

        update_option('qt_story_authors_anonymised', QT_THEME_VERSION);
    }

    /**
     * Menus: the house's navigation carries only the everyday paths.
     * The Journals are reached through their door on the entrance —
     * never through the navigation. That is a design rule, not an
     * oversight: the door is the only way in.
     *
     * Also drops items that point at anchors that no longer exist on
     * the homepage.
     *
     * @param list<\WP_Post> $items
     * @return list<\WP_Post>
     */
    public static function cleanMenuItems(array $items, $menu): array
    {
        $filtered = [];

        foreach ($items as $item) {
            $url = (string) ($item->url ?? '');

            // Journals stay behind their door — never in a menu.
            if (str_contains($url, '/journals') || str_contains($url, '/journal/')) {
                continue;
            }

            // Dead anchors from the old homepage.
            if (str_contains($url, '#rooms') || str_contains($url, '#qt-home-doors')) {
                continue;
            }

            $filtered[] = $item;
        }

        return array_values($filtered);
    }

    /**
     * Stories migrated from Posts keep their old /slug/ URLs working:
     * a 404 on a bare slug that matches a published story is redirected
     * (301) to its new /story/slug/ home.
     */
    public static function redirectOldStoryLinks(): void
    {
        if (!is_404()) {
            return;
        }

        $uri  = sanitize_text_field(wp_unslash($_SERVER['REQUEST_URI'] ?? ''));
        $path = trim((string) parse_url($uri, PHP_URL_PATH), '/');

        if ('' === $path) {
            return;
        }

        $segments = explode('/', $path);
        $slug     = sanitize_title((string) end($segments));

        if ('' === $slug || 'story' === $slug) {
            return;
        }

        $story = get_posts([
            'name'           => $slug,
            'post_type'      => 'qt_story',
            'post_status'    => 'publish',
            'posts_per_page' => 1,
            'no_found_rows'  => true,
        ]);

        if (!empty($story)) {
            wp_safe_redirect(get_permalink($story[0]), 301);
            exit;
        }
    }

    /**
     * Old room URLs (from the v1.0–v1.4 room set) are permanently
     * redirected to the new room that best receives their stories.
     * This protects existing bookmarks and any links shared before
     * v1.5.0. The redirects are only fired on qt_room archives and
     * leave all other URLs untouched.
     */
    public static function redirectOldRooms(): void
    {
        if (!is_tax('qt_room') || is_admin()) {
            return;
        }

        $term = get_queried_object();

        if (!($term instanceof \WP_Term)) {
            return;
        }

        $redirects = defined('QT_ROOM_REDIRECTS') ? QT_ROOM_REDIRECTS : [];

        if (!isset($redirects[$term->slug])) {
            return;
        }

        $target = get_term_by('slug', $redirects[$term->slug], 'qt_room');

        if (!($target instanceof \WP_Term)) {
            return;
        }

        $link = get_term_link($target);

        if (!is_wp_error($link)) {
            wp_safe_redirect($link, 301);
            exit;
        }
    }

    public static function flushRewriteRules(): void
    {
        flush_rewrite_rules();
    }

    /**
     * Room archives should show 12 stories per page — the house's own
     * pace, rather than the WordPress default of 10. Sits beside
     * storyArchiveSort() on pre_get_posts.
     */
    public static function roomArchivePagination($query): void
    {
        if (is_admin() || !$query->is_main_query() || !is_tax('qt_room')) {
            return;
        }

        $query->set('posts_per_page', 12);
    }

    /**
     * The collection shelf — default arrival order (recent). The former
     * "Ways of wandering" sort chips (Recently shared / Most responded
     * to / Short reads / Long reads) were removed from the All Stories
     * page so the page stays quiet: a search bar and the seven rooms
     * are enough. The room/category is felt when reading a single story.
     */
    public static function storyArchiveSort($query): void
    {
        if (is_admin() || !$query->is_main_query() || !is_post_type_archive('qt_story')) {
            return;
        }

        $query->set('posts_per_page', 20);
    }

    /**
     * One-time backfill so the shelf's sorts have their numbers:
     * word counts for every story, and published-response counts.
     */
    public static function ensureStoryMeta(): void
    {
        if (!get_option('qt_story_meta_words_done')) {
            $ids = get_posts([
                'post_type'      => 'qt_story',
                'post_status'    => ['publish', 'pending'],
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'no_found_rows'  => true,
            ]);

            foreach ($ids as $id) {
                if ('' === get_post_meta($id, '_qt_words', true)) {
                    $post = get_post($id);
                    if ($post) {
                        update_post_meta($id, '_qt_words', \QuietTruths\Core\Submission::countWords((string) $post->post_content));
                    }
                }
            }

            update_option('qt_story_meta_words_done', '1');
        }

        if (!get_option('qt_story_meta_responses_done')) {
            $ids = get_posts([
                'post_type'      => 'qt_story',
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'no_found_rows'  => true,
            ]);

            foreach ($ids as $id) {
                \QuietTruths\Core\Responses::touchCount((int) $id);
            }

            update_option('qt_story_meta_responses_done', '1');
        }
    }

    /* ─────────────────────────── theme ─────────────────────────── */

    private static function registerThemeSupports(): void
    {
        add_theme_support('title-tag');
        add_theme_support('post-thumbnails');
        add_theme_support('automatic-feed-links');
        add_theme_support('align-wide');
        add_theme_support('responsive-embeds');
        add_theme_support('html5', [
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        ]);
        add_theme_support('custom-logo', [
            'height'      => 48,
            'width'       => 240,
            'flex-height' => true,
            'flex-width'  => true,
        ]);
        add_theme_support('customize-selective-refresh-widgets');
    }

    private static function registerMenus(): void
    {
        register_nav_menus([
            'primary' => __('Primary Navigation', 'quiet-truths'),
            'footer'  => __('Footer Navigation', 'quiet-truths'),
        ]);
    }

    /**
     * A story belongs to ONE room — it is placed there. The invisible
     * concept layer holds everything else it is about. Replace the
     * default checkbox box with a single-choice radio picker.
     */
    private static function registerRoomPicker(): void
    {
        add_action('add_meta_boxes', function (): void {
            remove_meta_box('qt_roomdiv', 'qt_story', 'side');

            add_meta_box('qt_room_picker', __('Room', 'quiet-truths'), function ($post): void {
                wp_nonce_field('qt_room_picker', 'qt_room_picker_nonce');

                $current = wp_get_object_terms($post->ID, 'qt_room', ['fields' => 'slugs']);
                $current = (!is_wp_error($current) && !empty($current)) ? (string) $current[0] : '';

                $rooms = defined('QT_ROOMS') ? QT_ROOMS : [];

                echo '<p style="margin:0 0 8px;color:#757575;font-size:12px">'
                    . esc_html__('Choose the room where this story is placed.', 'quiet-truths') . '</p>';

                foreach ($rooms as $slug => $room) {
                    printf(
                        '<label style="display:block;margin:4px 0"><input type="radio" name="qt_room_single" value="%s"%s> %s</label>',
                        esc_attr((string) $slug),
                        checked($current, (string) $slug, false),
                        esc_html((string) ($room['name'] ?? $slug))
                    );
                }
            }, 'qt_story', 'side', 'high');
        });

        add_action('save_post_qt_story', function (int $postId): void {
            if (!is_admin() || !isset($_POST['qt_room_picker_nonce'])
                || !wp_verify_nonce(sanitize_key(wp_unslash((string) $_POST['qt_room_picker_nonce'])), 'qt_room_picker')) {
                return;
            }
            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
                return;
            }
            if (wp_is_post_revision($postId) || wp_is_post_autosave($postId)) {
                return;
            }
            if (!current_user_can('edit_post', $postId) || empty($_POST['qt_room_single'])) {
                return;
            }

            wp_set_object_terms($postId, [sanitize_key(wp_unslash((string) $_POST['qt_room_single']))], 'qt_room');
        }, 12);
    }

    /* ─────────────────────── content model ─────────────────────── */

    /**
     * Journals — long-form writing from named voices: professionals,
     * journalists, writers who sign their work. The second wing of the
     * house, beside the anonymous Stories.
     */
    private static function registerJournalPostType(): void
    {
        register_post_type('qt_journal', [
            'labels' => [
                'name'          => __('Journals', 'quiet-truths'),
                'singular_name' => __('Journal', 'quiet-truths'),
                'add_new'       => __('Add Journal', 'quiet-truths'),
                'add_new_item'  => __('Add a Journal', 'quiet-truths'),
                'edit_item'     => __('Edit Journal', 'quiet-truths'),
                'new_item'      => __('New Journal', 'quiet-truths'),
                'view_item'     => __('Read Journal', 'quiet-truths'),
                'search_items'  => __('Search Journals', 'quiet-truths'),
                'not_found'     => __('No journals have been published yet.', 'quiet-truths'),
                'menu_name'     => __('Journals', 'quiet-truths'),
            ],
            'public'       => true,
            'has_archive'  => 'journals',
            'menu_icon'    => 'dashicons-welcome-write-blog',
            'menu_position'=> 22,
            'rewrite'      => ['slug' => 'journal', 'with_front' => false],
            'supports'     => ['title', 'editor', 'excerpt', 'thumbnail', 'author', 'revisions'],
            'show_in_rest' => true,
        ]);

        // One-time flush so /journal/… and /journals/ work.
        add_action('init', static function (): void {
            if (!get_option('qt_journal_rewrite_flushed')) {
                flush_rewrite_rules();
                update_option('qt_journal_rewrite_flushed', '1');
            }
        }, 20);
    }

    /**
     * The byline — the writer's details, accompanied by choice.
     * Name (defaults to the WordPress author), role/title, and a
     * short bio shown at the end of the article.
     */
    private static function registerJournalByline(): void
    {
        add_action('add_meta_boxes', function (): void {
            add_meta_box('qt_journal_byline', __('Byline — the writer\'s details', 'quiet-truths'), function ($post): void {
                wp_nonce_field('qt_journal_byline', 'qt_journal_byline_nonce');

                $name = get_post_meta($post->ID, '_qt_byline_name', true);
                $role = get_post_meta($post->ID, '_qt_byline_role', true);
                $bio  = get_post_meta($post->ID, '_qt_byline_bio', true);

                echo '<p style="margin:0 0 10px;color:#757575;font-size:12px">'
                    . esc_html__('Leave blank to use the WordPress author\'s name. The role and bio are optional — shown with the article.', 'quiet-truths') . '</p>';

                echo '<p><label style="display:block;margin-bottom:4px;font-weight:600">'
                    . esc_html__('Name', 'quiet-truths') . '</label>';
                echo '<input type="text" name="qt_byline_name" style="width:100%" value="' . esc_attr((string) $name) . '"></p>';

                echo '<p><label style="display:block;margin-bottom:4px;font-weight:600">'
                    . esc_html__('Role / title', 'quiet-truths') . '</label>';
                echo '<input type="text" name="qt_byline_role" style="width:100%" value="' . esc_attr((string) $role) . '"></p>';

                echo '<p><label style="display:block;margin-bottom:4px;font-weight:600">'
                    . esc_html__('Short bio', 'quiet-truths') . '</label>';
                echo '<textarea name="qt_byline_bio" rows="3" style="width:100%">' . esc_textarea((string) $bio) . '</textarea></p>';
            }, 'qt_journal', 'side', 'high');
        });

        add_action('save_post_qt_journal', function (int $postId): void {
            if (!is_admin() || !isset($_POST['qt_journal_byline_nonce'])
                || !wp_verify_nonce(sanitize_key(wp_unslash((string) $_POST['qt_journal_byline_nonce'])), 'qt_journal_byline')) {
                return;
            }
            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
                return;
            }
            if (wp_is_post_revision($postId) || wp_is_post_autosave($postId)) {
                return;
            }
            if (!current_user_can('edit_post', $postId)) {
                return;
            }

            update_post_meta($postId, '_qt_byline_name', sanitize_text_field(wp_unslash((string) ($_POST['qt_byline_name'] ?? ''))));
            update_post_meta($postId, '_qt_byline_role', sanitize_text_field(wp_unslash((string) ($_POST['qt_byline_role'] ?? ''))));
            update_post_meta($postId, '_qt_byline_bio', sanitize_textarea_field(wp_unslash((string) ($_POST['qt_byline_bio'] ?? ''))));
        }, 12);
    }

    /**
     * A deliberate search-engine description for a story, journal, post
     * or page.
     *
     * SEO at scale cannot rely on the automatic fallback alone (the
     * first 160 characters of the raw content). This field lets an
     * editor write a short, keyword-rich description per item. When it
     * is left blank, the existing automatic behaviour continues to be
     * used, so nothing breaks.
     *
     * Stored in `_qt_meta_description`; consumed by Seo::description().
     */
    private static function registerMetaDescription(): void
    {
        add_action('add_meta_boxes', function (): void {
            add_meta_box('qt_meta_description', __('Search description', 'quiet-truths'), function ($post): void {
                wp_nonce_field('qt_meta_description', 'qt_meta_description_nonce');

                $value = get_post_meta($post->ID, '_qt_meta_description', true);

                echo '<p style="margin:0 0 8px;color:#757575;font-size:12px">'
                    . esc_html__('A short, self-contained description of this piece for search engines and social shares. Leave blank to use the automatic one.', 'quiet-truths') . '</p>';

                echo '<textarea name="qt_meta_description" rows="3" maxlength="320" style="width:100%" placeholder="'
                    . esc_attr__('e.g. A woman returns to the village after losing everything in the city, and must face the version of herself she left behind.', 'quiet-truths')
                    . '">' . esc_textarea((string) $value) . '</textarea>';

                echo '<p style="margin:6px 0 0;color:#999;font-size:12px">'
                    . esc_html__('About 150–160 characters is ideal. Used only if filled in.', 'quiet-truths') . '</p>';
            }, ['qt_story', 'qt_journal', 'post', 'page'], 'normal', 'high');
        });

        add_action('save_post', function (int $postId): void {
            if (!is_admin() || !isset($_POST['qt_meta_description_nonce'])
                || !wp_verify_nonce(sanitize_key(wp_unslash((string) $_POST['qt_meta_description_nonce'])), 'qt_meta_description')) {
                return;
            }
            if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
                return;
            }
            if (wp_is_post_revision($postId) || wp_is_post_autosave($postId)) {
                return;
            }
            if (!current_user_can('edit_post', $postId)) {
                return;
            }

            $value = sanitize_textarea_field(wp_unslash((string) ($_POST['qt_meta_description'] ?? '')));

            if ('' === trim($value)) {
                delete_post_meta($postId, '_qt_meta_description');
            } else {
                update_post_meta($postId, '_qt_meta_description', $value);
            }
        }, 12);
    }

    /**
     * One-time migration: if stories are still in removed rooms (from
     * the older room set), move them to the new room that best receives
     * them. Runs once per version. This does not delete the old terms —
     * the editor may wish to keep them in the database for reference —
     * but ensures published stories always sit in a live room.
     */
    private static function migrateRemovedRooms(): void
    {
        $option = 'qt_rooms_migrated_' . QT_THEME_VERSION;

        if (get_option($option)) {
            return;
        }

        $redirects = defined('QT_ROOM_REDIRECTS') ? QT_ROOM_REDIRECTS : [];

        if (empty($redirects)) {
            update_option($option, '1');
            return;
        }

        foreach ($redirects as $oldSlug => $newSlug) {
            $oldTerm = get_term_by('slug', $oldSlug, 'qt_room');
            $newTerm = get_term_by('slug', $newSlug, 'qt_room');

            if (!$oldTerm || !$newTerm) {
                continue;
            }

            // Reassign stories directly — wp_set_object_terms handles
            // the term_relationships table safely.
            $posts = get_posts([
                'post_type'      => ['qt_story'],
                'post_status'    => ['publish', 'pending', 'draft'],
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'tax_query'      => [[
                    'taxonomy' => 'qt_room',
                    'field'    => 'slug',
                    'terms'    => $oldSlug,
                ]],
                'no_found_rows' => true,
            ]);

            foreach ($posts as $pid) {
                wp_set_object_terms((int) $pid, [$newSlug], 'qt_room', false);
            }
        }

        update_option($option, '1');
    }

    /**
     * Make sure every room in QT_ROOMS exists as a real taxonomy term.
     *
     * Without this, /room/{slug}/ archives 404 until a story happens to
     * create the term. Runs once per rooms-set (tracked by an option);
     * flushes rewrite rules once so the /room/ and /story/ URL rules
     * register even if the theme was replaced while still active.
     */
    private static function ensureRoomTerms(): void
    {
        $rooms = defined('QT_ROOMS') ? QT_ROOMS : [];

        if (empty($rooms)) {
            return;
        }

        $signature = QT_THEME_VERSION . '|' . count($rooms) . '|' . implode(',', array_keys($rooms));

        if ((string) get_option('qt_room_terms_seeded') === $signature) {
            return;
        }

        $changed = false;

        foreach ($rooms as $slug => $room) {
            if (get_term_by('slug', $slug, 'qt_room')) {
                continue;
            }

            $insert = wp_insert_term($room['name'], 'qt_room', [
                'slug'        => $slug,
                'description' => $room['description'],
            ]);

            if (!is_wp_error($insert)) {
                $changed = true;
            }
        }

        update_option('qt_room_terms_seeded', $signature);

        if ($changed) {
            flush_rewrite_rules();
        }
    }

    private static function registerStoryPostType(): void
    {
        register_post_type('qt_story', [
            'labels' => [
                'name'          => __('Stories', 'quiet-truths'),
                'singular_name' => __('Story', 'quiet-truths'),
                'add_new'       => __('Add Story', 'quiet-truths'),
                'add_new_item'  => __('Add a Story', 'quiet-truths'),
                'edit_item'     => __('Edit Story', 'quiet-truths'),
                'new_item'      => __('New Story', 'quiet-truths'),
                'view_item'     => __('Read Story', 'quiet-truths'),
                'search_items'  => __('Search Stories', 'quiet-truths'),
                'not_found'     => __('No stories have been left here yet.', 'quiet-truths'),
                'menu_name'     => __('Quiet Stories', 'quiet-truths'),
            ],
            'public'       => true,
            'has_archive'  => 'stories',
            'menu_icon'    => 'dashicons-book-alt',
            'menu_position'=> 21,
            'rewrite'      => ['slug' => 'story', 'with_front' => false],
            // Stories are anonymous. We deliberately omit 'author' from
            // supports so the Author meta box does not appear in the
            // editor — a named author beside an "Anonymous" label is a
            // contradiction the house will not show. Journals keep
            // 'author' because they are signed voices.
            'supports'     => ['title', 'editor', 'excerpt', 'thumbnail', 'revisions'],
            'show_in_rest' => true,
        ]);

        // Belt-and-braces: even if another plugin or Blocksy adds the
        // author box back, remove it from the story editor. Stories are
        // held anonymously; the WP user who approved a story must not
        // appear as its "author" anywhere.
        add_action('add_meta_boxes', function (): void {
            remove_meta_box('authordiv', 'qt_story', 'normal');
            remove_meta_box('authordiv', 'qt_story', 'side');
            remove_meta_box('authordiv', 'qt_story', 'advanced');
        }, 99);

        // Strip the author field from REST responses for stories so
        // oEmbed / wp-json / Gutenberg cannot leak a user id.
        add_filter('rest_prepare_qt_story', function ($response) {
            $data = is_object($response) && method_exists($response, 'get_data')
                ? $response->get_data()
                : null;
            if (is_array($data) && array_key_exists('author', $data)) {
                unset($data['author']);
                if (is_object($response) && method_exists($response, 'set_data')) {
                    $response->set_data($data);
                }
            }
            if (is_object($response) && method_exists($response, 'remove_link')) {
                // WordPress adds an "author" link in _links.
                try {
                    $links = $response->get_links();
                    if (isset($links['author'])) {
                        $response->remove_link('author');
                    }
                } catch (\Throwable $e) {
                    // Not worth breaking a response over.
                }
            }
            return $response;
        }, 99);
    }

    private static function registerRoomTaxonomy(): void
    {
        register_taxonomy('qt_room', ['qt_story'], [
            'labels' => [
                'name'          => __('Rooms', 'quiet-truths'),
                'singular_name' => __('Room', 'quiet-truths'),
                'search_items'  => __('Search Rooms', 'quiet-truths'),
                'all_items'     => __('All Rooms', 'quiet-truths'),
                'edit_item'     => __('Edit Room', 'quiet-truths'),
                'update_item'   => __('Update Room', 'quiet-truths'),
                'add_new_item'  => __('Add Room', 'quiet-truths'),
                'new_item_name' => __('New Room Name', 'quiet-truths'),
                'menu_name'     => __('Rooms', 'quiet-truths'),
            ],
            'hierarchical'       => true,
            'public'             => true,
            'show_admin_column'  => true,
            'show_in_rest'       => true,
            'show_in_quick_edit' => true,
            'rewrite'            => ['slug' => 'room', 'with_front' => false],
        ]);
    }
}
