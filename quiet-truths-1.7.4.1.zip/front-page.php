<?php
/**
 * Quiet Truths — Front Page
 *
 * The entrance to the house. Two doors — the Stories (anonymous,
 * held with care) and the Journals (named voices, long-form) — and
 * then Begin: a free search of everything. Quiet, nothing else.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

$qt_loader = get_stylesheet_directory() . '/app/presentation/components/loader.php';

if (!file_exists($qt_loader)) {
    error_log('Quiet Truths: component loader missing at ' . $qt_loader);
    if (defined('WP_DEBUG') && WP_DEBUG) {
        wp_die('Quiet Truths is missing its presentation loader: ' . esc_html($qt_loader));
    }
    return;
}

require_once $qt_loader;

// Old concept links (without s=) would otherwise land back on the
// homepage — carry them to the search results instead.
if (!empty($_GET['qt_concept'])) {
    $qt_cslug = sanitize_key(wp_unslash((string) $_GET['qt_concept']));
    $qt_cname = $qt_cslug;

    if (class_exists(\QuietTruths\Core\Concepts::class)) {
        $qt_cdata = \QuietTruths\Core\Concepts::concepts()[$qt_cslug] ?? null;
        if ($qt_cdata) {
            $qt_cname = (string) ($qt_cdata['name'] ?? $qt_cslug);
        }
    }

    wp_safe_redirect(home_url('/?s=' . rawurlencode($qt_cname) . '&qt_concept=' . rawurlencode($qt_cslug)));
    exit;
}

get_header();
?>

<main id="qt-main">

    <!-- ── The entrance ── -->
    <section class="home-opening">
        <div class="home-opening__inner">
            <p class="home-opening__wordmark fade-in">
                <?php echo esc_html__('Quiet', 'quiet-truths'); ?> <span><?php echo esc_html__('Truths', 'quiet-truths'); ?></span>
            </p>
            <p class="home-opening__line fade-in fade-in--1">
                <?php echo esc_html__('The website whispers, so stories can be heard.', 'quiet-truths'); ?>
            </p>
            <p class="home-opening__welcome fade-in fade-in--1">
                <?php echo esc_html__('Welcome to the house.', 'quiet-truths'); ?>
            </p>
        </div>
    </section>

    <!-- ── Above the doors ── -->
    <section class="entrance-lead fade-in fade-in--2">
        <p><?php echo esc_html__('Some truths are lived. Others are reflected upon.', 'quiet-truths'); ?></p>
    </section>

    <!-- ── The two doors ── -->
    <section class="entrance-doors" aria-label="<?php echo esc_attr__('The two doors of the house', 'quiet-truths'); ?>">
        <a class="qt-cta fade-in fade-in--2" href="<?php echo esc_url(home_url('/stories/')); ?>">
            <span class="qt-cta__symbol" aria-hidden="true"></span>
            <span class="qt-cta__name"><?php echo esc_html__('The Stories', 'quiet-truths'); ?></span>
            <span class="qt-cta__line"><?php echo esc_html__('Anonymous stories, held with care — read them slowly.', 'quiet-truths'); ?></span>
        </a>

        <a class="qt-cta fade-in fade-in--3" href="<?php echo esc_url(home_url('/journals/')); ?>">
            <span class="qt-cta__symbol" aria-hidden="true"></span>
            <span class="qt-cta__name"><?php echo esc_html__('The Journals', 'quiet-truths'); ?></span>
            <span class="qt-cta__line"><?php echo esc_html__('There is more here than stories — an invitation to go deeper.', 'quiet-truths'); ?></span>
        </a>
    </section>

    <!-- ── Trust line ── -->
    <section class="trust-header">
        <p class="trust-header__label"><?php echo esc_html__('In this house', 'quiet-truths'); ?></p>
        <div class="trust-header__principles">
            <p><?php echo esc_html__('Every story is held.', 'quiet-truths'); ?></p>
            <p><?php echo esc_html__('Every voice is treated with dignity.', 'quiet-truths'); ?></p>
            <p><?php echo esc_html__('Nothing shared here is ever taken lightly.', 'quiet-truths'); ?></p>
        </div>
    </section>

    <!-- ── Explore Truth ── -->
    <section class="explore" id="qt-explore">
        <p class="explore__label"><?php echo esc_html__('Begin', 'quiet-truths'); ?></p>
        <button class="qt-button qt-button--primary qt-explore__button" type="button" id="qt-explore-btn" aria-expanded="false" aria-controls="qt-explore-panel">
            <?php echo esc_html__('Explore Truth', 'quiet-truths'); ?>
        </button>

        <div class="qt-explore__panel" id="qt-explore-panel" hidden>
            <p class="qt-explore__line"><?php echo esc_html__("You don't need the right word. Start wherever you are.", 'quiet-truths'); ?></p>
            <?php qt_search_bar('', 'qt-begin-search'); ?>
            <div class="qt-live-suggest" id="qt-live-suggest-begin" hidden></div>
        </div>
    </section>

    <!-- ── The closing ── -->
    <section class="home-closing">
        <p>
            <?php echo esc_html__('You can begin with a feeling, a question, or a single word. Then kindly follow it into the stories and see what truth finds you.', 'quiet-truths'); ?>
        </p>
    </section>

</main>

<?php get_footer(); ?>
