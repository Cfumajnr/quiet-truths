<?php
/**
 * Quiet Truths — Single
 *
 * Story reading view (and a generic single-post fallback).
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

$qt_is_story = is_singular('qt_story');
?>

<main id="qt-main" class="reading-container reading-container--narrow" style="padding-top:var(--space-3xl);padding-bottom:var(--space-4xl)">
    <?php while (have_posts()) : the_post(); ?>

        <?php if ($qt_is_story) : ?>
            <?php
            $qt_room = qt_story_room(get_the_ID());
            if ($qt_room) {
                $qt_room_meta = defined('QT_ROOMS') ? QT_ROOMS : [];
                $qt_room_data = $qt_room_meta[$qt_room->slug] ?? ['name' => $qt_room->name, 'description' => $qt_room->description];
                qt_room_header($qt_room->slug, $qt_room_data['name'], $qt_room_data['description']);
            }
            ?>
        <?php endif; ?>

        <article class="story-panel">
            <h1 class="story-panel__title" style="font-size:var(--text-2xl)"><?php the_title(); ?></h1>

            <?php if ($qt_is_story) : ?>
                <p class="story-panel__time"><?php echo esc_html(sprintf(__('Left here on %s', 'quiet-truths'), get_the_date('j M Y'))); ?></p>
            <?php endif; ?>

            <div style="margin-top:var(--space-lg)">
                <?php the_content(); ?>
            </div>
        </article>

        <?php if ($qt_is_story) : ?>
            <?php qt_quiet_divider(true); ?>
            <div class="u-text-center">
                <?php qt_gentle_notice('healing', __('This story was left here with care. Thank you for reading it gently.', 'quiet-truths')); ?>
                <div class="u-mt-lg">
                    <?php qt_hope_marker(__('You are not alone in what you carry.', 'quiet-truths')); ?>
                </div>
            </div>
        <?php endif; ?>

    <?php endwhile; ?>
</main>

<?php get_footer(); ?>
