# Quiet Truths release history

## 1.7.5.2 — a truthful About page for the house

- Replaced the generic blockquote About page with a dedicated, literary account of Quiet Truths as an independent human archive—not a magazine or feed.
- Corrected inaccurate legacy claims that the house collects only words, guarantees that no detail can identify a writer, is kept by a small team, and deletes every declined Story immediately.
- Added a release-managed canonical `/about/` page so public privacy, moderation, AI and retention promises cannot silently drift away from code or governance. The existing page is reused; no `about-2` duplicate is created.
- Explained the separate roles of anonymous Stories, signed Journals and moderated Responses; the seven Rooms; the sole human moderator; the 32-Story Founding Collection; and the first native Story.
- Published the plain-language lifecycle accurately: anonymous-by-default intake, private queue, human decision, immediate AI blocking/forgetting, seven-day declined/withdrawn text deletion, 30-day unreviewed limit and 30-day backup ageing.
- Added the public boundary “AI assists the House. Humans govern the House.” Remote AI endpoints remain rejected; AI does not author Stories, make final editorial decisions or profile the anonymous writer.
- Governance links render only when the reviewed documents are genuinely public, and the “Leave a Story” action appears only while intake is actually open.
- Added a dedicated responsive About design, accessible heading structure, quiet Room/process motifs, AboutPage structured data, a deliberate search description and correct `website` Open Graph type.
- Added About-page checks to static, integration, HTTP, browser and production verification suites.

## 1.7.5.1 — mandatory Unicode runtime and explicit legal confirmation

- Declared PHP `mbstring` as a mandatory production dependency.
- Added a pre-application dependency gate that uses no mbstring functions itself: WP Admin and Site Health remain reachable, while public/REST/application processing fails closed with HTTP 503 if mbstring is unavailable.
- Added a critical WordPress Site Health test and private Quiet Truths Health check for mbstring.
- Removed the remaining fallback polyfill dependency on `mb_strpos` before the requirement gate.
- Removed obsolete application-layer `function_exists('mb_*')`, `strlen` and `substr` fallback branches from Submission, Responses, Contact, SEO and presentation code; all Unicode operations now rely consistently on mandatory mbstring.
- Added a static regression check that fails if an application mbstring fallback is reintroduced.
- Reset `counsel_approved` to `0`; governance pages and publishable intake remain gated until the operator explicitly confirms completed legal review in **Tools → Quiet Truths Governance**.
- No package may claim legal approval merely because a prior build or developer default set the value.

## 1.7.5.0 — coherent lifecycle final hardening

- Enforced literal-loopback-only AI transport (`127.0.0.1` / `::1`); remote hosts, IPs and URLs are rejected and SSL-verification bypasses removed.
- Added authoritative `ProfileStore`, `ProfileLifecycle`, `ProfileBuilder` and `AiPolicy` boundaries; AI profile schema is now v10.
- Added idempotent AI forgetting and lifecycle-generation/content-fingerprint job tickets; declined, withdrawn, trashed, deleted or superseded Stories cannot be processed or resurrected by old jobs.
- Added first-class Declined and Withdrawn states, restore-to-review, seven-day active deletion and thirty-day unreviewed deletion.
- Added file-backed HMAC withdrawal/deletion tombstones and pre-job reconciliation to resist database-backup resurrection.
- Added Story-not-person persistence policy and evidence-based privacy constellations.
- Added least-privilege Quiet Truths capabilities for the sole operator, private AI/privacy access, minimum non-content audit table and three-year audit cleanup.
- Added private contact-message storage with six-month code-enforced retention; email receives only an ID/protected link, never form words or contact details.
- Added deterministic WP-CLI operations runner, retention runner, queue generation checks and private health dashboard including UpdraftPlus policy verification.
- Governance pages now require complete factual configuration and confirmed legal review; unresolved pages are unpublished and publishable intake remains closed until promises and providers are complete.
- Governance now discloses local AI, derived personal information, person-profiling prohibition, revision invalidation, forgetting, backup limits, moderator access, breach response and exact privacy-minimal retention.
- Added reproducible static, unit, clean-WordPress integration, HTTP form, browser accessibility and production verification tests.
- Added `DATA-LIFECYCLE.md`, `AI-BOUNDARY.md` and `PRODUCTION-VERIFICATION.md` as operational architecture.

## 1.7.4.6 — source and chronology remain independent

- Split editorial **Story source** from historical **Story chronology** at the storage level, not only in the interface.
- A Story can now be both **Migrated Founding Collection** and **From the House** without one value overwriting the other.
- Public submissions write `_qt_story_source=anonymous_submission`; the founding schedule writes chronology to `_qt_origin` and preserves any House source.
- The first native Story receives both native chronology and House source when the founding schedule is applied.
- Added seamless read/migration compatibility for the short-lived 1.7.4.5 overloaded origin values.
- Founding-schedule backup and restore now include both chronology and source.

## 1.7.4.5 — invitation and House provenance

- Hidden the numeric Response count when it is zero; the first reader now receives a gentle invitation to leave the first Response instead of seeing “0 responses”.
- Added a separate Story-origin model so truth form (`Fiction`, `Composite`, lived experience) is not confused with provenance (`From the House`, anonymous submission, founding collection or editorial contribution).
- Added a protected **Story origin** editor control. Public submitters cannot claim House provenance.
- Native Quiet Truths and `From the House` Stories now carry a visible **From the House** label; Fiction and Composite labels can appear beside it on single Stories, collection rows, Room cards and search results.
- Public form submissions are automatically marked as anonymous submissions.
- House-origin Stories suppress automated duplicate/spam-origin pattern suspicion while retaining privacy, safety, content-warning and semantic AI analysis.
- Existing legal complaints and genuine safety/privacy review remain available; House provenance is context, not immunity.

## 1.7.4.4 — founding chronology

- Added a provenance layer that distinguishes the 32 migrated founding Stories from native Quiet Truths Stories.
- Added an explicit, reversible **Quiet Stories → Founding Schedule** admin tool; it never runs automatically.
- Added the approved weekly release arc: one Story every Thursday from 1 January through 6 August 2026, followed by the first native Story, “The Woman Who Went Back,” on 9 August.
- Added a complete pre-application backup and one-click restore for dates, Rooms and provenance metadata.
- The Room arc fills only the 11 migrated Stories that currently have no Room; existing non-empty Room assignments are preserved.
- Founding Story sitemap `<lastmod>` now uses the meaningful house date—not the common 5 August technical migration timestamp—until the title, excerpt or body is substantively edited.
- Article schema uses the same meaningful `dateModified`, keeping sitemap and structured data consistent.
- AI/profile rebuilds, taxonomy changes and metadata-only saves do not manufacture a fresh modification date.
- Founding Stories display “Brought into this house on…” while native Stories retain “Left here on…”.

## 1.7.4.3 — the house remains open

- Restored the operator's intended default: Story, Journal, Response and Journal-comment intake remain open when no configuration constant is present.
- Kept the emergency/maintenance switch. `define('QT_PUBLIC_INTAKE', false);` deliberately pauses publishable intake while leaving the Contact/removal route open.
- Governance drafts continue to display their public banner and administrator warning, but no longer make the intake decision automatically.
- All 1.7.4.2 security, privacy, moderation, accessibility and reliability fixes remain intact.

## 1.7.4.2 — hardening release

### Critical fixes

- Fixed all Room archives returning HTTP 500. `Rooms` and three AI classes imported classes from the wrong namespaces.
- Replaced global form-error transients with one-time, high-entropy visitor-specific flash state. This prevents one visitor from receiving another visitor's contact details or draft text.
- Renamed the Story textarea POST field from `qt_story` to `qt_story_text`; the old name collided with WordPress's custom-post-type query variable and caused validation failures to render as false 404 pages.
- Fixed successful Story and Journal submissions redirecting away from their confirmation screens.
- Added an operational `QT_PUBLIC_INTAKE` kill switch. Version 1.7.4.2 initially tied its default to the draft governance pack; 1.7.4.3 restores the open-by-default behaviour while retaining the switch.
- Added a PHP-level HTTPS 308 fallback and supplied server-level redirect examples. Server-level enforcement remains mandatory.
- Disabled full-page caching on forms, Story pages and Journal pages containing expiring nonces or personal form state.

## Privacy and security

- Cross-submission writing-style recognition is now disabled by default. Legacy writer hashes/link metadata and the year-long writer cookie are removed when disabled.
- Story email notifications no longer copy Story text into email; they contain only a content ID and protected admin link.
- Response edit tokens are stored as keyed hashes rather than plaintext. Legacy plaintext tokens migrate on first successful use.
- Rate-limit keys now use a keyed HMAC rather than unsalted MD5 values derived from IP addresses.
- Self-hosted Crimson Pro and Inter fonts; public pages no longer contact Google Fonts. SIL OFL licences are bundled.
- Tightened CSP to local font/style origins and added mixed-content upgrade directives.
- Added `/.well-known/security.txt` with the contact and policy routes.
- Updated Permissions-Policy.
- Fixed login lockout ordering so a locked request cannot bypass the check merely because WordPress has already returned a user or error.
- Added one-report-per-response/network guard so one visitor cannot trigger the two-report auto-hold alone.
- Added noindex handling for one-time confirmation and flash-state URLs.

## Moderation integrity

- A Response edit now returns the Response to `pending` moderation instead of changing approved public text immediately.
- Public Response counts are updated when an edit or reports hold a Response.
- Removed automatic rejection based solely on difficult words. Stories, Journals, Responses and comments remain pending for contextual human moderation; safety complaints are not rejected because they quote harmful language.
- Journal commenters can no longer impersonate an author simply by typing the byline name. The Author badge requires a moderator-verified flag.
- Fixed the Journal-comment Approve action, which previously returned immediately on every admin request.
- Added a moderator UI for verified Journal-author comments.
- Added age/moderation confirmations to Journal comments and nested Story replies.

## Functionality and discoverability

- Fixed semantic-search pagination by using `qt_page`; result pages no longer become WordPress 404s when the native lexical result count is smaller.
- Search now scores Stories, Posts and Journals; ordinary governance Pages appear only on an exact title/slug request.
- Fixed canonical and Open Graph URLs for Story archives, Journal archives, Room terms and paginated archives.
- Added archive meta descriptions and Journal `article` Open Graph type.
- Governance page generation now finds child pages correctly, retires old managed `-2`, `-3`, etc. duplicates, and preserves 301 redirects.
- Fixed House Rules URL lookup.
- Fixed duplicated Submit-a-Journal introduction.
- Replaced misleading Journal-upload controls with an honest writing-only notice. Future supporting files must use a separately designed private channel.
- Added a required Story classification: lived experience, fiction, or composite/details changed. Fiction and composite Stories receive public disclosures.
- Fixed doubled Response totals.
- Fixed Room vocabulary extraction counting WordPress markup such as `paragraph`, `strong` and `separator`.

## Accessibility

- Added the homepage H1 and an accessible label to the overlay search input.
- Darkened semantic colour tokens to WCAG AA contrast levels.
- Underlined in-text governance/form links so they do not rely on colour alone.
- Fixed placeholder contrast.

## Tests completed

- PHP 8.4 syntax check: 79 files passed.
- JavaScript syntax check: 4 files passed.
- WordPress 7.0.3 + Blocksy 2.1.52 integration environment.
- Room, Story, Journal, governance, search and pagination route checks.
- Story, Journal, Response, Contact and Journal-comment submission workflows.
- One-time flash-state isolation test with two independent sessions.
- Journal comment approval and author-impersonation test.
- Governance duplicate migration and redirect test.
- HTTPS 308 fallback test.
- Desktop and mobile browser audit across 18 page/viewport combinations: zero console errors, failed resources, horizontal overflow, external requests or automated WCAG A/AA violations.
