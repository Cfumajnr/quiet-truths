# Quiet Truths 1.7.5.2 — About-page release deployment checklist

## 1. Before deployment

1. Confirm the mandatory Unicode dependency before installing:

```bash
php -m | grep -i '^mbstring$'
php -r 'exit(extension_loaded("mbstring") ? 0 : 1);'
```

In cPanel this is normally under **Select PHP Version → Extensions → mbstring**. Quiet Truths deliberately returns HTTP 503 and refuses Story/AI processing if it is absent; WP Admin and the critical Site Health result remain available.

2. Back up the database and the current `quiet-truths` theme separately.
3. Test this release on staging with the same WordPress, Blocksy, PHP, LiteSpeed and Wordfence versions as production.
4. Add production constants:

```php
define('FORCE_SSL_ADMIN', true);
define('DISALLOW_FILE_EDIT', true);
define('WP_ENVIRONMENT_TYPE', 'production');
```

Publishable intake is initially paused because legal confirmation defaults to unchecked. After verifying the rendered documents, explicitly confirm legal review under **Tools → Quiet Truths Governance**; only then do governance pages publish and intake open. `QT_PUBLIC_INTAKE=false` remains an optional emergency pause.

5. Do not define `QT_WRITER_RECOGNITION`. It is deliberately disabled. Do not enable it without a documented purpose, DPIA/privacy assessment and updated notice.
6. If TLS terminates at a trusted reverse proxy, configure WordPress to recognise HTTPS at the server level. Only then, if required, define `QT_TRUST_PROXY_HTTPS` as `true`. Never trust a client-supplied forwarding header unless the proxy overwrites it.

## 2. Force HTTPS before PHP

The PHP 308 redirect is defence in depth; it cannot protect a request body that has already travelled to PHP over clear text. Put the following at the top of the document-root `.htaccess`, before WordPress/LiteSpeed rules:

```apache
RewriteEngine On

# Canonical HTTPS origin in one hop.
RewriteCond %{HTTPS} !=on [OR]
RewriteCond %{HTTP_HOST} !^quiettruths\.co\.ke$ [NC]
RewriteRule ^ https://quiettruths.co.ke%{REQUEST_URI} [R=308,L,NE]
```

For a LiteSpeed/Apache virtual host, also disable TRACE in server/vhost configuration:

```apache
TraceEnable off
```

For nginx, use a dedicated clear-text server:

```nginx
server {
    listen 80;
    listen [::]:80;
    server_name quiettruths.co.ke www.quiettruths.co.ke;
    return 308 https://quiettruths.co.ke$request_uri;
}

server {
    listen 443 ssl http2;
    server_name www.quiettruths.co.ke;
    return 308 https://quiettruths.co.ke$request_uri;
}
```

For nginx (which ignores `.htaccess`), also deny internal theme/tests and lifecycle tombstones:

```nginx
location ~ ^/wp-content/themes/quiet-truths/(app/(config|core|ai|cli|pages|presentation)|tests)/ { deny all; }
location ^~ /wp-content/qt-private/ { deny all; }
```

Test all host/scheme combinations, direct POST protection and both deny rules before inviting or promoting submissions.

## 3. Install and migrate

1. Install the ZIP as the active Blocksy child theme.
2. Load WP Admin once. The release will:
   - reuse `/about/` and replace the old generic blockquote with the reviewed, release-managed About page (without creating `about-2`);
   - set the About page author to `0`, install its deliberate search description and select the dedicated template;
   - resynchronise the draft governance pack;
   - correctly reuse the nested House Rules page;
   - draft extra theme-managed governance copies such as `terms-2` and `house-rules-3`;
   - retain 301 mappings for their old paths;
   - remove legacy cross-submission writer hashes when recognition is disabled;
   - clean the duplicated Journal-submission introduction.
3. Purge LiteSpeed page/object caches and any upstream CDN cache. Open `/about/` in a private window and confirm that it begins “A human archive for the truths we carry quietly,” contains exactly one H1, and contains none of the retired “Nothing is collected but your words” / “small team” copy.
4. In LiteSpeed, exclude these routes from full-page cache even though the theme defines `DONOTCACHEPAGE`:
   - `/leave-a-story/`
   - `/write-to-quiet-truths/`
   - `/submit-a-journal/`
   - `/story/*`
   - `/journal/*`
   - requests containing `qt_flash`, `qt_held`, `qt_ref`, `qt_contact_sent`, `qt_journal_submitted`, `qt_resp` or `qt_jc_held`

## 4. Founding Story chronology

WordPress core used the common 5 August 2026 migration/save timestamp as `<lastmod>` for the 32 carried Stories. Version 1.7.4.4 includes an operator-approved but **non-automatic** correction workflow:

1. Open **WP Admin → Quiet Stories → Founding Schedule**.
2. Review all 32 resolved titles, weekly dates and the Room arc.
3. Confirm the page reports no missing or ambiguous slugs.
4. Press **Apply the 32-Story founding schedule**.
5. Purge LiteSpeed/CDN caches.
6. Open `/wp-sitemap-posts-qt_story-1.xml` and confirm the founding dates run weekly from 1 January through 6 August, followed by “The Woman Who Went Back” on 9 August.
7. Inspect the Stories archive and several individual Stories before asking Search Console to recrawl the sitemap.

Application changes only publication dates and provenance metadata. It fills a Room only where a migrated Story currently has none; it preserves every non-empty Room, title, slug and Story body. A complete backup is captured before the first change. The same admin page offers **Restore the pre-schedule dates and Rooms**.

For migrated Stories, sitemap and Article `dateModified` use the house date until a substantive title, excerpt or body edit occurs. AI profile rebuilds and metadata-only changes do not reset the date. The first native Story remains outside the migrated schedule.

## 5. “From the House” provenance and labels

Quiet Truths records three independent facts:

- **Truth form:** lived experience, Fiction, or Composite/details changed
- **Editorial source:** anonymous submission, From the House, or editorial contribution
- **Chronology:** migrated founding collection or native Quiet Truths

A Story may therefore be both **Founding Collection** and **From the House**. For a Story created/editorially introduced by Quiet Truths, open its editor and set **Story source → From the House**. Public visitors cannot set this field. The single Story and discovery cards will show **From the House**, alongside **Fiction** or **Composite · details changed** where applicable.

House provenance suppresses automated near-duplicate and spam-origin suspicion because the editorial source is already known. It does **not** disable privacy scanning, safety review, content warnings, semantic discovery, copyright review or legitimate complaint routes. The founding-schedule tool marks “The Woman Who Went Back” as native Quiet Truths, which receives the same public House label.

## 6. Governance facts and publication

Open **Tools → Quiet Truths Governance** and verify the prefilled operator facts: Quiet Truths; admin@quiettruths.co.ke; Nairobi, Kenya; Shujaa Host/Roundcube in Kenya; Google Drive via UpdraftPlus Free on global Google infrastructure; provider-managed encryption; sole operator; and privacy-minimal retention. The **legal review checkbox is deliberately unchecked in every fresh installation**, regardless of developer or prior-build state. Check it only after reviewing the final rendered documents against the actual deployment.

Governance pages and publishable intake are code-gated: if any required fact or the explicit legal-review confirmation is absent, the pages remain drafts and intake pauses while Contact remains available. No unresolved token can enter a published document.

Keep the provider evidence, processor terms, ODPC registration/exemption decision and DPIA with the internal controller register. Public IP ownership previously pointed to a Contabo European network; the operator-confirmed Kenya hosting statement must be supported by Shujaa’s current written service/location record. A provider/location change requires governance review before activation.

## 7. Operational security gate

- Enforce Wordfence MFA on the sole administrator account; remove or demote every additional administrator. The Health page must report exactly one privacy-capable account.
- Add a cPanel/server cron at least every five minutes:

```bash
cd /absolute/path/to/wordpress && wp qt operations run --quiet
```

- Confirm **Tools → Quiet Truths Health** shows current runner/retention/reconciliation heartbeats, no overdue jobs, no forget-integrity violations and the expected Updraft policy.
- UpdraftPlus Free: Google Drive remote confirmed; Google 2-step verification enabled; database daily/retain 30; files weekly/retain 4. The governance pack explicitly discloses Google-managed encryption and the absence of client-side Updraft archive encryption.
- Keep `wp-content/qt-private` out of public serving and preserve its HMAC tombstone file across database restores. Run `wp qt operations run` before public/AI processing after any restoration.
- Verify WordPress, Blocksy, Wordfence, PHP and LiteSpeed updates on staging before production.
- Validate SPF and DKIM, then move DMARC from monitoring toward enforcement after legitimate mail is confirmed.
- Configure uptime checks for Home, all seven Rooms, search page 2, forms and `security.txt`; set server/WAF body-size limits and queue-spike alerts.

## 8. Smoke tests

Expected outcomes:

```text
http://quiettruths.co.ke/*                  308 → https://quiettruths.co.ke/*
http://www.quiettruths.co.ke/*              308 → https://quiettruths.co.ke/*
https://www.quiettruths.co.ke/*             308 → https://quiettruths.co.ke/*
/room/{each-room}/                           200, no “critical error”
/about/                                        200, canonical, one H1, reviewed copy
/stories/ and /stories/page/2/               200, self-canonical
/?s=test&qt_page=2                           200, not 404
/.well-known/security.txt                    200 text/plain
interactive pages                            Cache-Control: no-store/private
```

Before legal confirmation, Story, Journal, Response and Journal-comment forms should show pause notices while Contact remains available. After the operator explicitly completes **Tools → Quiet Truths Governance**, those forms should open without requiring a `QT_PUBLIC_INTAKE` constant. Also test the optional emergency switch: `QT_PUBLIC_INTAKE=false` must pause them again.

Run an invited closed beta before broad public promotion. Test submission, moderation, fiction/composite disclosure, correction re-moderation, reporting, withdrawal, deletion and backup restoration end to end.

## 9. Required deployment actions outside PHP

These are release requirements, not a future-feature bucket, and must be checked off before production promotion:

- retain Shujaa’s written hosting/location and processor terms with the controller register;
- retain the ODPC registration/exemption and DPIA decisions;
- enforce administrator MFA in Wordfence;
- verify Google-account 2-step recovery and perform an Updraft restore drill;
- verify SPF/DKIM and advance DMARC after mail observation;
- configure the server-level HTTPS/TRACE rules and five-minute WP-CLI cron;
- protect the HMAC tombstone directory in LiteSpeed/nginx as well as `.htaccess`;
- run `tests/production.sh` and the browser suite against staging and production;
- keep supporting-file intake disabled until a separately private, scanned storage channel exists.

Do not place private supporting files in the ordinary public WordPress Media Library.
