<?php
/**
 * Quiet Truths — Page
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main id="qt-main" class="reading-container reading-container--story" style="padding-top:var(--space-3xl);padding-bottom:var(--space-4xl)">
    <?php while (have_posts()) : the_post(); ?>
        <article class="story-panel">
            <h1 class="story-panel__title" style="font-size:var(--text-2xl)"><?php the_title(); ?></h1>
            <div style="margin-top:var(--space-lg)">
                <?php the_content(); ?>
            </div>
        </article>
    <?php endwhile; ?>
</main>

<?php get_footer(); ?>
