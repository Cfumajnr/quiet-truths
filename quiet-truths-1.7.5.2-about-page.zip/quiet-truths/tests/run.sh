#!/usr/bin/env bash
set -euo pipefail
THEME_DIR="$(cd "$(dirname "$0")/.." && pwd)"
WP_ROOT="${WP_ROOT:-}"
QT_BASE_URL="${QT_BASE_URL:-}"
WP_BIN="${WP_BIN:-wp}"
if [[ -z "$WP_ROOT" || ! -f "$WP_ROOT/wp-load.php" || -z "$QT_BASE_URL" ]]; then
  echo "Set WP_ROOT and QT_BASE_URL to a served clean WordPress installation with Quiet Truths active." >&2
  exit 2
fi
php "$THEME_DIR/tests/static.php"
php "$THEME_DIR/tests/unit.php"
"$WP_BIN" --path="$WP_ROOT" eval-file "$THEME_DIR/tests/integration.php"
QT_BASE_URL="$QT_BASE_URL" WP_ROOT="$WP_ROOT" WP_BIN="$WP_BIN" php "$THEME_DIR/tests/http.php"
echo "All Quiet Truths tests passed."
