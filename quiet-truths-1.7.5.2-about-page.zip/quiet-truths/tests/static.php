<?php
/** Dependency-independent source checks. */
$root = dirname(__DIR__);
$failures = [];
$phpFiles = [];

$iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)
);
foreach ($iterator as $file) {
    if ($file->isFile() && 'php' === $file->getExtension()) {
        $phpFiles[] = $file->getPathname();
    }
}

$report = static function (bool $ok, string $name, array $details = []) use (&$failures): void {
    echo ($ok ? '[PASS] ' : '[FAIL] ') . $name . PHP_EOL;
    if (!$ok) {
        $failures[] = $name;
        foreach ($details as $detail) {
            echo '  ' . $detail . PHP_EOL;
        }
    }
};

$checks = [
    'SSL verification bypass'            => 'sslverify\s*["\']?\s*=>\s*false',
    'Dynamic evaluation'                 => '\beval\s*\(',
    'Global visitor flash transient'     => 'qt_(?:contact|resp|jc)_state',
    'Remote Google font'                 => 'fonts\.(?:googleapis|gstatic)\.com',
    'Obsolete mbstring function fallback'=> 'function_exists\(["\']mb_',
];
foreach ($checks as $name => $pattern) {
    $hits = [];
    foreach ($phpFiles as $file) {
        $source = (string) file_get_contents($file);
        if (preg_match('/' . $pattern . '/i', $source)) {
            $hits[] = $file;
        }
    }
    $report(empty($hits), $name, $hits);
}

// Resolve every explicit internal namespace import to a declared class.
$classes = [];
foreach ($phpFiles as $file) {
    $source = (string) file_get_contents($file);
    preg_match('/namespace\s+([^;]+);/', $source, $namespace);
    preg_match_all('/\b(?:final\s+|abstract\s+)?class\s+(\w+)/', $source, $matches);
    foreach ($matches[1] as $class) {
        $classes[(isset($namespace[1]) ? trim($namespace[1]) . '\\' : '') . $class] = $file;
    }
}
$badImports = [];
foreach ($phpFiles as $file) {
    $source = (string) file_get_contents($file);
    preg_match_all('/use\s+(QuietTruths\\[^;\s]+)\s*;/', $source, $matches);
    foreach ($matches[1] as $class) {
        if (!isset($classes[$class])) {
            $badImports[] = $file . ': ' . $class;
        }
    }
}
$report(empty($badImports), 'Internal namespace imports resolve', $badImports);

// The About page is a public contract. Its canonical source must keep the
// architecture's core promises and must never regain the old false claims.
$aboutPath = $root . '/app/pages/content/about.html';
$about = is_file($aboutPath) ? (string) file_get_contents($aboutPath) : '';
$requiredAbout = [
    'A human archive for the truths we carry quietly.',
    'This is an archive, not a magazine',
    'AI assists the House. Humans govern the House.',
    'For AI processing, Story text does not leave the Quiet Truths server.',
    'The first 32 Stories were carried into this house',
    'one authorised operator',
];
$missingAbout = [];
foreach ($requiredAbout as $promise) {
    if (!str_contains($about, $promise)) {
        $missingAbout[] = 'Missing: ' . $promise;
    }
}
$forbiddenAbout = [
    'Nothing is collected but your words',
    'without your name, your email, or anything that could identify you',
    'The house is kept by a small team',
];
foreach ($forbiddenAbout as $claim) {
    if (str_contains($about, $claim)) {
        $missingAbout[] = 'Retired claim returned: ' . $claim;
    }
}
if (1 !== preg_match_all('/<h1\b/i', $about)) {
    $missingAbout[] = 'Canonical About content must contain exactly one H1.';
}
$report('' !== $about && empty($missingAbout), 'Canonical About copy is complete and truthful', $missingAbout);

$aboutFiles = [
    $root . '/app/core/About.php',
    $root . '/app/design-system/about.css',
    $root . '/page-about.php',
];
$missingFiles = array_values(array_filter($aboutFiles, static fn(string $path): bool => !is_file($path)));
$report(empty($missingFiles), 'Dedicated About architecture is present', $missingFiles);

$application = (string) file_get_contents($root . '/app/core/Application.php');
$manifest = (string) file_get_contents($root . '/app/design-system/manifest.php');
$aboutWired = str_contains($application, "require_once __DIR__ . '/About.php';")
    && str_contains($application, 'About::init();')
    && str_contains($manifest, "'about'             => ['file' => 'about.css']");
$report($aboutWired, 'About content and presentation are wired at boot');

$style = (string) file_get_contents($root . '/style.css');
$constants = (string) file_get_contents($root . '/app/config/constants.php');
preg_match('/^Version:\s*([^\s]+)/m', $style, $styleVersion);
preg_match("/QT_THEME_VERSION',\s*'([^']+)'/", $constants, $constantVersion);
$report(
    isset($styleVersion[1], $constantVersion[1]) && $styleVersion[1] === $constantVersion[1],
    'Theme version declarations agree'
);

exit($failures ? 1 : 0);
