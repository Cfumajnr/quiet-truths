#!/usr/bin/env bash
set -euo pipefail
BASE="${1%/}"
[[ "$BASE" == https://* ]] || { echo "HTTPS base URL required" >&2; exit 2; }
fail=0
UA="${QT_TEST_USER_AGENT:-Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/124 Safari/537.36 QuietTruths-Production-Test/1.0}"
qt_curl(){ command curl -A "$UA" "$@"; }
pass(){ echo "[PASS] $*"; }
bad(){ echo "[FAIL] $*"; fail=1; }
status(){ qt_curl -sS -o /dev/null -w '%{http_code}' "$1"; }
header(){ qt_curl -sS -D - -o /dev/null "$1" | tr -d '\r' | awk -v n="$2" 'BEGIN{IGNORECASE=1}$0~"^"n":"{sub(/^[^:]+:[ ]*/,"");print;exit}'; }

[[ "$(status "$BASE/")" == 200 ]] && pass "Home 200" || bad "Home"
for path in /about/ /stories/ /room/beginnings/ /room/heavy-hearts/ /room/crossroads/ /room/homecoming/ /room/mending/ /room/letters/ /room/small-mercies/ /privacy/ /terms/ /submission-terms/ /editorial-policy/ /safety-crisis-help/ /complaints-removals/ /wp-sitemap.xml /.well-known/security.txt; do
  [[ "$(status "$BASE$path")" == 200 ]] && pass "$path 200" || bad "$path"
done
code=$(qt_curl -sS -o /dev/null -w '%{http_code}' "${BASE/https:/http:}/leave-a-story/")
[[ "$code" == 301 || "$code" == 308 ]] && pass "HTTP redirects to HTTPS" || bad "HTTP redirect ($code)"

for h in Content-Security-Policy Strict-Transport-Security X-Content-Type-Options Referrer-Policy Permissions-Policy; do
  [[ -n "$(header "$BASE/" "$h")" ]] && pass "$h present" || bad "$h missing"
done
cache=$(header "$BASE/leave-a-story/" Cache-Control)
[[ "$cache" == *no-store* && "$cache" == *private* ]] && pass "Story form not cacheable" || bad "Story form cache policy: $cache"

for path in /wp-content/themes/quiet-truths/app/core/Application.php /wp-content/themes/quiet-truths/tests/unit.php /wp-content/qt-private/lifecycle-tombstones.jsonl /wp-content/debug.log /.env /.git/HEAD; do
  c=$(status "$BASE$path"); [[ "$c" == 403 || "$c" == 404 ]] && pass "$path denied" || bad "$path exposed ($c)"
done

xml=$(qt_curl -sS "$BASE/wp-sitemap-posts-qt_story-1.xml")
[[ "$xml" != *qt_withdrawn* && "$xml" != *qt_declined* ]] && pass "Sitemap excludes private lifecycle states" || bad "Sitemap lifecycle leak"
privacy=$(qt_curl -sS "$BASE/privacy/")
[[ "$privacy" != *'[insert]'* && "$privacy" != *'[Privacy Email]'* && "$privacy" != *'[TBD]'* && "$privacy" != *'qt-gov-placeholder'* ]] && pass "Governance placeholders absent" || bad "Governance placeholder exposed"

about=$(qt_curl -sS "$BASE/about/")
h1_count=$(printf '%s' "$about" | grep -Eoi '<h1([[:space:]>])' | wc -l || true)
[[ "$h1_count" == 1 ]] && pass "About has exactly one H1" || bad "About H1 count ($h1_count)"
[[ "$about" == *'A human archive for the truths we carry quietly.'* \
   && "$about" == *'AI assists the House. Humans govern the House.'* \
   && "$about" == *'"@type":"AboutPage"'* \
   && "$about" != *'Nothing is collected but your words'* \
   && "$about" != *'The house is kept by a small team'* ]] \
  && pass "About reviewed copy and schema present" || bad "About page is stale or incomplete"

# Conservative uncached network budgets; override QT_MAX_SECONDS if needed.
max="${QT_MAX_SECONDS:-5.0}"
for path in / /about/ /stories/ /room/beginnings/ /?s=hope /leave-a-story/ /submit-a-journal/; do
  metrics=$(qt_curl -sS -o /dev/null -w '%{time_total} %{size_download}' "$BASE$path")
  seconds=${metrics%% *}; bytes=${metrics##* }
  awk -v t="$seconds" -v m="$max" 'BEGIN{exit !(t<=m)}' && pass "$path response ${seconds}s" || bad "$path too slow: ${seconds}s"
  [[ "$bytes" -le 1048576 ]] && pass "$path HTML under 1 MiB" || bad "$path HTML too large: $bytes"
done

exit "$fail"
