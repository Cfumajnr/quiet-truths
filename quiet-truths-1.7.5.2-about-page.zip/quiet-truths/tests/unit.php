<?php
/**
 * Quiet Truths unit checks.
 *
 * Dependency-independent policy/structure tests always run. Unicode/privacy
 * tests run only on the supported production runtime with mbstring. The
 * missing-extension boot path is tested separately by requirements-case.php.
 */
$failures = [];
$assert = static function (bool $ok, string $name) use (&$failures): void {
    echo ($ok ? '[PASS] ' : '[FAIL] ') . $name . PHP_EOL;
    if (!$ok) $failures[] = $name;
};

if (!defined('ABSPATH')) define('ABSPATH', __DIR__);
require dirname(__DIR__) . '/app/core/Requirements.php';

// ── Dependency gate itself ──────────────────────────────────────────
$requirementsCase = __DIR__ . '/requirements-case.php';
$missingResult = trim((string) shell_exec(
    escapeshellarg(PHP_BINARY) . ' -n ' . escapeshellarg($requirementsCase)
));
$assert('missing' === $missingResult, 'Missing-extension requirement path fails closed');

$mbAvailable = \QuietTruths\Core\Requirements::satisfied();
if ($mbAvailable) {
    $assert(true, 'mbstring requirement passes on supported runtime');
} else {
    echo '[PASS] Current runtime correctly reports mandatory mbstring as unavailable' . PHP_EOL;
}

// ── Dependency-independent endpoint/policy/structure tests ─────────
$case = __DIR__ . '/ai-host-case.php';
$runHost = static function (string $host) use ($case): string {
    // Deliberately run with -n to prove endpoint policy itself has no
    // mbstring or php.ini dependency.
    $cmd = 'QT_TEST_HOST=' . escapeshellarg($host) . ' '
        . escapeshellarg(PHP_BINARY) . ' -n ' . escapeshellarg($case);
    return trim((string) shell_exec($cmd));
};
$assert('http://127.0.0.1:8765' === $runHost('127.0.0.1'), 'IPv4 loopback AI endpoint accepted without mbstring');
$assert('http://[::1]:8765' === $runHost('::1'), 'IPv6 loopback AI endpoint accepted without mbstring');
foreach (['localhost','10.0.0.5','192.168.1.5','8.8.8.8','ai.example.com','https://example.com'] as $bad) {
    $assert('' === $runHost($bad), 'Remote/non-literal AI endpoint rejected: ' . $bad);
}

require dirname(__DIR__) . '/app/ai/AiPolicy.php';
require dirname(__DIR__) . '/app/core/GovernanceSettings.php';

$profile = [
    'concepts' => ['grief' => 0.8],
    'personality_type' => 'introvert',
    'nested' => ['inferred_medical_condition' => 'x', 'safe' => 'story-signal'],
];
$clean = \QuietTruths\Ai\AiPolicy::enforce($profile);
$assert(!isset($clean['personality_type']), 'Personality profiling key removed');
$assert(!isset($clean['nested']['inferred_medical_condition']), 'Nested medical inference key removed');
$assert('story-signal' === $clean['nested']['safe'], 'Story-centred signal retained');
$assert(false === $clean['policy']['person_profiling'], 'Persisted policy declares no person profiling');

$defaults = \QuietTruths\Core\GovernanceSettings::defaults();
$assert(0 === (int) ($defaults['counsel_approved'] ?? 1), 'Legal approval defaults to explicit false');
$assert('Quiet Truths' === ($defaults['controller_legal_name'] ?? ''), 'Controller default is structurally defined');
$assert(str_contains((string) ($defaults['backup_provider'] ?? ''), 'UpdraftPlus Free'), 'Backup limitation is structurally disclosed');

// Stop successfully after the independent suite when the environment is
// intentionally unsupported. Do not enter PrivacyScanner mb_* paths.
if (!$mbAvailable) {
    if (empty($failures)) {
        echo '[SKIP] Runtime-dependent Unicode tests require mbstring' . PHP_EOL;
        exit(0);
    }
    exit(1);
}

// ── Runtime-dependent Unicode/privacy tests ─────────────────────────
if (!function_exists('__')) {
    function __($string, $domain = null) { return $string; }
}
if (!function_exists('wp_strip_all_tags')) {
    function wp_strip_all_tags($string) { return strip_tags($string); }
}
require dirname(__DIR__) . '/app/ai/AiKernel.php';
require dirname(__DIR__) . '/app/ai/PrivacyScanner.php';

$scan = \QuietTruths\Ai\PrivacyScanner::scan(
    'I am a 34 year old teacher in Nairobi at Safaricom. Call 0712 345 678 or me@example.com. My national ID 12345678.'
);
$kinds = array_column($scan['flags'], 'kind');
foreach (['phone','email','id_number','workplace'] as $kind) {
    $assert(in_array($kind, $kinds, true), 'Privacy scanner detects ' . $kind);
}
$constellation = array_values(array_filter(
    $scan['flags'],
    static fn($flag) => in_array($flag['kind'] ?? '', ['constellation','uniqueness'], true)
));
$assert(!empty($constellation), 'Privacy scanner emits identifying-constellation evidence');
$assert(!empty($constellation[0]['evidence'] ?? []), 'Constellation warning explains generic evidence');

exit(empty($failures) ? 0 : 1);
