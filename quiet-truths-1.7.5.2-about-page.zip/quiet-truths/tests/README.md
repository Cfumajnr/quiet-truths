# Quiet Truths reproducible tests

Serve a clean installation, then run:

```bash
WP_ROOT=/path/to/clean-wordpress \
QT_BASE_URL=http://127.0.0.1:8088 \
./wp-content/themes/quiet-truths/tests/run.sh
```

The suite fails non-zero on real failures. `unit.php` always runs dependency-independent endpoint, policy, structure and governance-default checks. When mbstring is absent it prints `[SKIP] Runtime-dependent Unicode tests require mbstring` and exits successfully after those independent checks; `requirements-case.php` separately proves that the application requirement gate fails closed. On the supported runtime, Unicode/privacy tests also run. WordPress integration checks cover the release-managed About contract, lifecycle eligibility, revision tickets, authoritative/idempotent forgetting, queue resurrection refusal, edit invalidation, withdrawal, REST isolation, sitemap isolation and retention selection.

For automated desktop/mobile accessibility, console, external-request, focus and overflow checks:

```bash
cd wp-content/themes/quiet-truths/tests
npm install
npx playwright install chromium
QT_BASE_URL=https://staging.example.com npm run test:browser
```

`production.sh` covers canonical redirects, cache/security headers, direct-file protection, sitemap/governance isolation and conservative response-time/HTML-size budgets.
