<?php
/** Run with: wp eval-file wp-content/themes/quiet-truths/tests/integration.php */
use QuietTruths\Ai\ProfileLifecycle;
use QuietTruths\Ai\ProfileStore;
use QuietTruths\Core\About;
use QuietTruths\Core\Audit;
use QuietTruths\Core\Retention;
use QuietTruths\Core\Requirements;
use QuietTruths\Core\Governance;
use QuietTruths\Core\GovernanceSettings;
use QuietTruths\Core\Health;
use QuietTruths\Core\Security;
use QuietTruths\Core\Seo;
use QuietTruths\Core\StoryLifecycle;
use QuietTruths\Core\Tombstones;

$failures = [];
$assert = static function (bool $ok, string $name) use (&$failures): void {
    WP_CLI::line(($ok ? '[PASS] ' : '[FAIL] ') . $name);
    if (!$ok) $failures[] = $name;
};

$admins = get_users(['role' => 'administrator', 'number' => 1]);
if (!empty($admins)) wp_set_current_user($admins[0]->ID);
\QuietTruths\Core\Capabilities::sync();
Audit::maybeInstall();
$assert('good' === (Requirements::siteHealthResult()['status'] ?? ''), 'Mandatory mbstring Site Health check is green');
$assert(0 === (int) (GovernanceSettings::defaults()['counsel_approved'] ?? 1), 'Legal approval defaults to explicit false');

About::ensurePage();
$about = get_page_by_path('about', OBJECT, 'page');
$aboutContent = $about instanceof WP_Post ? (string) $about->post_content : '';
$assert($about instanceof WP_Post
    && 'publish' === $about->post_status
    && 'About Quiet Truths' === $about->post_title
    && 0 === (int) $about->post_author,
    'Canonical About page is public without an administrator author');
$assert(1 === preg_match_all('/<h1\\b/i', $aboutContent)
    && str_contains($aboutContent, 'A human archive for the truths we carry quietly.')
    && str_contains($aboutContent, 'AI assists the House. Humans govern the House.')
    && !str_contains($aboutContent, 'Nothing is collected but your words')
    && !str_contains($aboutContent, 'small team'),
    'About copy contains one H1 and no retired false promises');
$aboutId = $about instanceof WP_Post ? (int) $about->ID : 0;
$assert($aboutId > 0
    && 'page-about.php' === (string) get_post_meta($aboutId, '_wp_page_template', true)
    && '' !== (string) get_post_meta($aboutId, '_qt_meta_description', true),
    'About page has its dedicated template and deliberate search description');

$incompleteGov = GovernanceSettings::defaults();
$incompleteGov['controller_legal_name'] = '';
$incompleteGov['counsel_approved'] = 0;
update_option('qt_governance_settings', $incompleteGov, false);
delete_option('qt_gov_pack_version');
Governance::ensurePages();
$privacyDraft = get_page_by_path('privacy', OBJECT, 'page');
$assert(!GovernanceSettings::complete() && !Security::intakeOpen('story'), 'Incomplete governance facts prevent publishable intake');
$assert(!$privacyDraft instanceof WP_Post || 'publish' !== $privacyDraft->post_status, 'Incomplete governance pages are not public');
$aboutClosingPaused = About::renderClosing();
$assert(!str_contains($aboutClosingPaused, 'Leave a Story')
    && str_contains($aboutClosingPaused, 'Write to Quiet Truths')
    && !str_contains($aboutClosingPaused, 'How the house is governed'),
    'About page does not advertise paused intake or unpublished governance');
$gov = GovernanceSettings::defaults();
$gov = array_merge($gov, [
    'controller_legal_name' => 'Integration Test Controller',
    'email_provider' => 'Integration Mail Provider',
    'email_location' => 'Kenya',
    'backup_provider' => 'Integration Backup Provider',
    'backup_location' => 'Kenya',
    'counsel_approved' => 1,
]);
update_option('qt_governance_settings', $gov, false);
delete_option('qt_gov_pack_version');
Governance::ensurePages();
$privacy = get_page_by_path('privacy');
$assert(GovernanceSettings::complete() && Security::intakeOpen('story'), 'Complete approved governance facts permit intake');
$assert($privacy instanceof WP_Post && 'publish' === $privacy->post_status
    && !preg_match('/\[[^\]]+\]/', (string) $privacy->post_content),
    'Published governance contains no unresolved placeholders');
$aboutClosingOpen = About::renderClosing();
$assert(str_contains($aboutClosingOpen, 'Leave a Story')
    && str_contains($aboutClosingOpen, 'How the house is governed')
    && str_contains($aboutClosingOpen, 'Privacy'),
    'About page reveals intake and governance routes only when available');

$id = wp_insert_post([
    'post_type' => 'qt_story', 'post_status' => 'pending',
    'post_title' => 'QT lifecycle test ' . wp_generate_password(6, false),
    'post_content' => 'A safe automated integration fixture containing enough words for lifecycle and privacy processing.',
    'post_author' => 0,
]);
$assert($id > 0, 'Fixture Story created');
$assert(ProfileLifecycle::isEligible($id), 'Pending Story is eligible for protective AI');

$ticket = ProfileLifecycle::issueTicket($id);
$assert(is_array($ticket) && ProfileLifecycle::isTicketCurrent($id, $ticket['generation'], $ticket['hash']), 'Revision ticket is current');

update_post_meta($id, '_qt_ai_profile', ['schema_version' => 99]);
update_post_meta($id, '_qt_embedding', [0.1, 0.2]);
update_post_meta($id, '_qt_concepts', [['slug' => 'test', 'score' => 1]]);
$assert(ProfileStore::hasDerived($id), 'Derived fixture data exists');
$removed = ProfileLifecycle::forget($id, 'test_forget');
$assert($removed >= 3 && !ProfileStore::hasDerived($id), 'Authoritative forget removes derived data');
$assert(!ProfileLifecycle::isTicketCurrent($id, $ticket['generation'], $ticket['hash']), 'Forgotten queue ticket cannot wake');
\QuietTruths\Ai\BackgroundWorker::runProfile($id, $ticket['generation'], $ticket['hash']);
$assert(!ProfileStore::hasDerived($id), 'Old worker invocation cannot resurrect forgotten data');
$assert(0 === ProfileLifecycle::forget($id, 'test_forget'), 'Forget is idempotent');
global $wpdb;
$auditCount = (int) $wpdb->get_var($wpdb->prepare(
    'SELECT COUNT(*) FROM ' . Audit::table() . ' WHERE content_id = %d AND event_type = %s',
    $id, 'ai_forgotten'
));
$assert(1 === $auditCount, 'Minimum audit records one idempotent AI-forget event');

wp_update_post(['ID' => $id, 'post_status' => 'pending']);
ProfileLifecycle::allow($id, 'test_restore');
$assert(ProfileLifecycle::isEligible($id), 'Restored pending Story becomes eligible');
$generation = ProfileLifecycle::generation($id);
wp_update_post(['ID' => $id, 'post_content' => get_post_field('post_content', $id) . ' Revised.']);
$assert(ProfileLifecycle::generation($id) > $generation, 'Substantive edit invalidates old revision ticket');

wp_update_post(['ID' => $id, 'post_status' => StoryLifecycle::WITHDRAWN]);
$assert(!ProfileLifecycle::isEligible($id) && !ProfileStore::hasDerived($id), 'Withdrawal blocks AI and leaves no derived data');
// Simulate an older database restoration that predates withdrawal.
$wpdb->update($wpdb->posts, ['post_status' => 'publish'], ['ID' => $id]);
clean_post_cache($id);
$reconciled = Tombstones::reconcile();
$assert(StoryLifecycle::WITHDRAWN === get_post_status($id)
    && (int) $reconciled['enforced'] >= 1
    && !ProfileStore::hasDerived($id),
    'File-backed tombstone prevents backup restoration from resurrecting withdrawn content');

$args = Seo::sitemapQueryArgs(['post_status' => 'any'], 'qt_story');
$assert(['publish'] === $args['post_status'], 'Story sitemap explicitly requires publish status');

// REST response for a separate published fixture must contain no internal AI keys.
$restId = wp_insert_post([
    'post_type' => 'qt_story', 'post_status' => 'publish',
    'post_title' => 'QT REST fixture', 'post_content' => 'Public REST isolation fixture.', 'post_author' => 0,
]);
update_post_meta($restId, '_qt_ai_risk_score', 0.9);
wp_set_current_user(0);
$request = new WP_REST_Request('GET', '/wp/v2/qt_story/' . $restId);
$response = rest_do_request($request);
$body = wp_json_encode($response->get_data());
$assert(false === strpos($body, '_qt_ai_') && false === strpos($body, '_qt_embedding'), 'Public REST excludes internal AI metadata');

// Retention dry-run sees an old pending fixture.
$old = wp_insert_post([
    'post_type' => 'qt_story', 'post_status' => 'pending',
    'post_title' => 'QT old pending fixture', 'post_content' => 'Old pending fixture content.', 'post_author' => 0,
]);
global $wpdb;
$oldDate = gmdate('Y-m-d H:i:s', time() - 40 * DAY_IN_SECONDS);
$wpdb->update($wpdb->posts, ['post_date' => $oldDate, 'post_date_gmt' => $oldDate], ['ID' => $old]);
clean_post_cache($old);
$retention = Retention::run(true);
$assert((int) $retention['candidates'] >= 1, 'Retention dry-run identifies old unreviewed content');
$retention = Retention::run(false);
$assert((int) $retention['deleted'] >= 1 && null === get_post($old), 'Retention job enforces unreviewed-content deletion');
Health::heartbeat('integration_test');
$checks = Health::checks();
$assert($checks['operations_runner']['ok'] && $checks['retention']['ok'], 'Private health checks observe runner and retention');

wp_delete_post($id, true);
wp_delete_post($restId, true);

if ($failures) {
    WP_CLI::error(count($failures) . ' Quiet Truths integration checks failed.');
}
WP_CLI::success('Quiet Truths integration checks passed.');
