<?php
define('ABSPATH', __DIR__);
require dirname(__DIR__) . '/app/core/Requirements.php';
echo \QuietTruths\Core\Requirements::satisfied() ? 'good' : 'missing';
