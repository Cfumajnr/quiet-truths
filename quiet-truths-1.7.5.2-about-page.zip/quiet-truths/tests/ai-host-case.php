<?php
$host = getenv('QT_TEST_HOST') ?: '127.0.0.1';
define('ABSPATH', __DIR__);
define('QT_AI_EMBED_HOST', $host);
define('QT_AI_EMBED_PORT', 8765);
require dirname(__DIR__) . '/app/ai/AiKernel.php';
echo \QuietTruths\Ai\AiKernel::serviceUrl();
