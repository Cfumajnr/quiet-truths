<?php
/** End-to-end public-form checks. Requires QT_BASE_URL, WP_ROOT and wp CLI. */
$base = rtrim(getenv('QT_BASE_URL') ?: '', '/');
$wpRoot = getenv('WP_ROOT') ?: '';
$wpBin = getenv('WP_BIN') ?: 'wp';
if (!$base || !is_file($wpRoot . '/wp-load.php')) { fwrite(STDERR, "QT_BASE_URL and WP_ROOT required\n"); exit(2); }
$fail=[];
$ok=function($v,$n)use(&$fail){echo($v?'[PASS] ':'[FAIL] ').$n.PHP_EOL;if(!$v)$fail[]=$n;};
$cookies=[];
$request=function($method,$path,$data=[],&$jar=[])use($base){
 $headers=['User-Agent: QuietTruths-Test/1.0'];
 if($jar)$headers[]='Cookie: '.implode('; ',array_map(fn($k,$v)=>$k.'='.$v,array_keys($jar),$jar));
 $opts=['http'=>['method'=>$method,'ignore_errors'=>true,'follow_location'=>0,'header'=>implode("\r\n",$headers)]];
 if('POST'===$method){$opts['http']['header'].="\r\nContent-Type: application/x-www-form-urlencoded";$opts['http']['content']=http_build_query($data);}
 $body=file_get_contents($base.$path,false,stream_context_create($opts));$hs=$http_response_header??[];$status=0;$location='';
 foreach($hs as $h){if(preg_match('#HTTP/\S+\s+(\d+)#',$h,$m))$status=(int)$m[1];if(stripos($h,'Location:')===0)$location=trim(substr($h,9));if(stripos($h,'Set-Cookie:')===0&&preg_match('/^Set-Cookie:\s*([^=]+)=([^;]*)/i',$h,$m))$jar[$m[1]]=$m[2];}
 return ['status'=>$status,'body'=>(string)$body,'location'=>$location,'headers'=>$hs];
};
$form=function($html,$classOrId){
 $d=new DOMDocument();@$d->loadHTML($html);$x=new DOMXPath($d);
 $query=$classOrId[0]==='#'?'//form[@id="'.substr($classOrId,1).'"]':'//form[contains(concat(" ",normalize-space(@class)," ")," '.$classOrId.' ")]';
 $f=$x->query($query)->item(0);if(!$f)return [];$out=[];
 foreach($x->query('.//input|.//textarea|.//select',$f)as$el){$name=$el->getAttribute('name');if(!$name)continue;if($el->nodeName==='select'){$o=$x->query('.//option[@selected]',$el)->item(0)?:$x->query('.//option',$el)->item(0);$out[$name]=$o?$o->getAttribute('value'):'';}elseif($el->nodeName==='textarea')$out[$name]=$el->textContent;elseif(!in_array($el->getAttribute('type'),['checkbox','radio'],true)||$el->hasAttribute('checked'))$out[$name]=$el->getAttribute('value');}
 foreach($x->query('.//button[@name]',$f)as$el)$out[$el->getAttribute('name')]=$el->getAttribute('value');
 return $out;
};
$wp=function($args)use($wpBin,$wpRoot){$cmd=escapeshellcmd($wpBin).' --path='.escapeshellarg($wpRoot).' '.$args;return trim((string)shell_exec($cmd));};
if ('' === $wp('post list --post_type=page --name=leave-a-story --field=ID')) {
    $wp('post create --post_type=page --post_status=publish --post_title="Leave a Story" --post_name=leave-a-story --post_content="[qt_leave_a_story]" --porcelain');
}
if ('' === $wp('post list --post_type=page --name=write-to-quiet-truths --field=ID')) {
    $wp('post create --post_type=page --post_status=publish --post_title="Write to Quiet Truths" --post_name=write-to-quiet-truths --post_content="[qt_contact]" --porcelain');
}
$intakeId=(int)$wp('post list --post_type=page --name=leave-a-story --field=ID');

// The release-managed About page renders the reviewed public contract.
$aboutJar=[];$r=$request('GET','/about/',[],$aboutJar);
$ok($r['status']===200
    && str_contains($r['body'],'A human archive for the truths we carry quietly.')
    && str_contains($r['body'],'AI assists the House. Humans govern the House.')
    && 1===preg_match_all('/<h1\\b/i',$r['body'])
    && !str_contains($r['body'],'Nothing is collected but your words'),
    'Canonical About page renders one H1 and reviewed copy');

// Story form and validation.
$r=$request('GET','/leave-a-story/',[],$cookies);$ok($r['status']===200&&str_contains($r['body'],'qt-form--journal'),'Story form available');
$fields=$form($r['body'],'qt-form--journal');
$valid=array_merge($fields,['qt_story_submit'=>'1','qt_story_text'=>'A harmless automated submission containing more than twenty words for nonce, consent, honeypot, rate limit, storage and confirmation testing on a clean installation.','qt_story_kind'=>'experience','qt_room'=>'mending','qt_consent_age_rules'=>'1','qt_consent_publish'=>'1','qt_website'=>'']);
$bad=$valid;$bad['_wpnonce']='invalid';$r=$request('POST','/leave-a-story/',$bad,$cookies);$ok($r['status']===200&&str_contains($r['body'],'session expired'),'Invalid nonce rejected calmly');
$missing=$valid;unset($missing['qt_consent_publish']);$r=$request('POST','/leave-a-story/',$missing,$cookies);$ok($r['status']===200&&str_contains($r['body'],'confirm consent'),'Missing consent rejected');
$before=(int)$wp('post list --post_type=qt_story --post_status=pending --format=count');$hp=$valid;$hp['qt_website']='bot';$r=$request('POST','/leave-a-story/',$hp,$cookies);$after=(int)$wp('post list --post_type=qt_story --post_status=pending --format=count');$ok($r['status']===302&&$before===$after,'Honeypot fakes success without storage');
// Fresh nonce, then valid submission.
$r=$request('GET','/leave-a-story/',[],$cookies);$fresh=$form($r['body'],'qt-form--journal');$valid['_wpnonce']=$fresh['_wpnonce']??'';$valid['_wp_http_referer']=$fresh['_wp_http_referer']??'/leave-a-story/';$r=$request('POST','/leave-a-story/',$valid,$cookies);$ok($r['status']===302&&str_contains($r['location'],'qt_held=1'),'Valid anonymous Story stored and redirected');
$id=(int)$wp('post list --post_type=qt_story --post_status=pending --orderby=ID --order=DESC --posts_per_page=1 --field=ID');$source=$wp('post meta get '.$id.' _qt_story_source');$ok($id>0&&$source==='anonymous_submission','Public Story has anonymous source and pending state');
$r=$request('GET','/leave-a-story/',[],$cookies);$fresh=$form($r['body'],'qt-form--journal');$limited=$valid;$limited['_wpnonce']=$fresh['_wpnonce']??'';$limited['_wp_http_referer']=$fresh['_wp_http_referer']??'/leave-a-story/';$r=$request('POST','/leave-a-story/',$limited,$cookies);$ok($r['status']===200&&str_contains($r['body'],'receives stories slowly'),'Story rate limit enforced');

// Response create, token protection and re-moderation.
$storyId=(int)$wp('post create --post_type=qt_story --post_status=publish --post_title="QT HTTP public fixture" --post_name=qt-http-public-fixture --post_content="Safe public fixture." --porcelain');
$r=$request('GET','/story/qt-http-public-fixture/',[],$cookies);$rf=$form($r['body'],'qt-response__form');$rf=array_merge($rf,['qt_resp_action'=>'create','qt_parent'=>'0','qt_response'=>'A kind automated response.','qt_consent_age_rules'=>'1','qt_consent_publish'=>'1','qt_website'=>'']);$r=$request('POST','/story/qt-http-public-fixture/',$rf,$cookies);$responseId=(int)$wp('post list --post_type=qt_response --post_status=pending --orderby=ID --order=DESC --posts_per_page=1 --field=ID');$ok($r['status']===302&&$responseId>0,'Anonymous Response enters pending moderation');
$wp('post update '.$responseId.' --post_status=publish >/dev/null');$r=$request('GET','/story/qt-http-public-fixture/',[],$cookies);$edit=$form($r['body'],'#qt-edit-'.$responseId);$edit['qt_response']='Corrected response requiring review.';$r=$request('POST','/story/qt-http-public-fixture/',$edit,$cookies);$ok($wp('post get '.$responseId.' --field=post_status')==='pending','Response edit returns to pending moderation');

// Contact validation does not leak state globally (one-time token tested by distinct jar).
$contact=[];$r=$request('GET','/write-to-quiet-truths/',[],$contact);$cf=$form($r['body'],'qt-form--contact');$cf=array_merge($cf,['qt_contact_submit'=>'1','qt_name'=>'Private Test','qt_email'=>'bad','qt_message'=>'Private draft marker','qt_website'=>'']);$r=$request('POST','/write-to-quiet-truths/',$cf,$contact);$other=[];$plain=$request('GET','/write-to-quiet-truths/',[],$other);$ok($r['status']===302&&!str_contains($plain['body'],'Private draft marker'),'Contact error state isolated between visitors');
$r=$request('GET','/write-to-quiet-truths/',[],$contact);$cf=$form($r['body'],'qt-form--contact');$cf=array_merge($cf,['qt_contact_submit'=>'1','qt_name'=>'Private Test','qt_email'=>'private@example.test','qt_subject'=>'Retention test','qt_message'=>'Private contact content stored only in the protected lifecycle-controlled record.','qt_website'=>'']);$beforeContact=(int)$wp('post list --post_type=qt_contact_message --post_status=private --format=count');$r=$request('POST','/write-to-quiet-truths/',$cf,$contact);$afterContact=(int)$wp('post list --post_type=qt_contact_message --post_status=private --format=count');$contactId=(int)$wp('post list --post_type=qt_contact_message --post_status=private --orderby=ID --order=DESC --posts_per_page=1 --field=ID');$ok($r['status']===302&&$afterContact===$beforeContact+1&&$contactId>0,'Valid contact is stored privately under enforceable retention');

$wp('post delete '.$storyId.' '.$id.' '.$contactId.' --force >/dev/null');
if($fail){fwrite(STDERR,count($fail)." HTTP checks failed\n");exit(1);}echo "HTTP integration checks passed.\n";
