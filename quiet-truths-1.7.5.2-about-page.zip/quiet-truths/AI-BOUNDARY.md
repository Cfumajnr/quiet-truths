# Quiet Truths AI boundary

## Purpose

AI assists the House. Humans govern the House.

The system answers **“What is this Story about, how can it be protected, and what other Stories may resonate?”** It does not answer **“What kind of person wrote this?”**

## Transport guarantee

Story text may be sent only to an embedding/inference service bound to literal loopback `127.0.0.1` or `::1`. Hostnames, public/private network addresses, arbitrary URLs and remote HTTPS endpoints are rejected in application code. No SSL-verification bypass exists because no remote TLS transport exists.

## Permitted Story-centred derivations

- public Room affinity;
- broad Concepts;
- cross-cutting Threads;
- life Domains;
- generic context and communication signals;
- privacy-risk evidence;
- content-warning suggestions;
- semantic embeddings and Story relationships;
- version, model, source revision and rebuild state.

## Prohibited person profiling

The profile store removes keys representing personality, psychological type/profile, political identity, inferred religion/ethnicity/sexual orientation/medical condition/criminal history, socioeconomic class, demographic profile, behavioural profile or writer identity. Future modules and filters pass through the same policy enforcement before persistence.

Sensitive words may be understood as part of a Story. They must not be converted into persistent assertions about the anonymous writer.

## Human authority

AI cannot publish, decline, withdraw, determine truthfulness, rewrite testimony, expose internal inferences publicly or assign materially characterising public labels. Moderators see evidence-based protective signals and make the decision.

## Revision and forgetting

Every processing job carries a lifecycle generation and content fingerprint. Workers re-check both before and after processing. A changed, withdrawn, declined or deleted Story invalidates the ticket. Authoritative forgetting blocks processing, cancels/invalidates queued jobs and deletes the profile, vectors, concepts, signals, retry/rebuild state and per-Story AI caches.
