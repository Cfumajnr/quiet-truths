<?php
/**
 * Quiet Truths — About the house
 *
 * A dedicated editorial surface for the canonical, release-managed About
 * copy. It intentionally avoids the generic Page/Story card: this is the
 * threshold and record of the house, not another item in the archive.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main id="qt-main" class="qt-about">
    <?php while (have_posts()) : the_post(); ?>
        <article class="qt-about__document" aria-label="<?php echo esc_attr__('About Quiet Truths', 'quiet-truths'); ?>">
            <?php the_content(); ?>
            <?php
            if (class_exists(\QuietTruths\Core\About::class)) {
                echo wp_kses_post(\QuietTruths\Core\About::renderClosing());
            }
            ?>
        </article>
    <?php endwhile; ?>
</main>

<?php get_footer(); ?>
