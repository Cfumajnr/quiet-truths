# Quiet Truths data lifecycle — authoritative production map

This map is operational policy for the deployed code. Story text is never copied into the audit trail.

| Stage | Submitted data | Operational data | Derived data | Public? | Access | Retention / exit |
|---|---|---|---|---|---|---|
| Form in progress | Browser memory only | Nonce; local UI state | Client-only privacy nudges | No | Visitor | Abandoned with page; no draft storage |
| Submitted / pending | Story text, title, Room, warnings, consent version | Keyed rate limit; queue ticket; moderation status | Protective privacy evidence; concepts/profile/embedding when eligible | No | Sole authorised operator | Unreviewed content deleted at 30 days |
| Human review | Same | Moderation status; minimum audit event | Versioned Story-centred AI profile | No | Sole authorised operator with `view_qt_privacy` | Approve, decline or withdraw |
| Published | Approved Story and public labels | Publication/provenance state | Search/profile/relations while eligible | Yes, approved fields only | Public text; internal data operator-only | While editorially useful; review every 2 years |
| Declined | Story temporarily retained for deletion | Decline time/reason category; minimum audit | Immediately forgotten; jobs invalidated | No | Sole operator during deletion window | Active text permanently deleted within 7 days |
| Withdrawn | Story temporarily retained for deletion | Withdrawal time/reason category; minimum audit | Immediately forgotten; jobs invalidated | No | Sole operator during deletion window | Active text permanently deleted within 7 days |
| Deleted | No active Story text | Minimum content-ID lifecycle audit only | None; repeated forget remains idempotent | No | Audit: sole operator | Audit expires at 3 years |
| Backup expiry | Provider-encrypted isolated copy may remain | Provider backup catalogue + HMAC file tombstone | No active AI processing | No | Provider + sole operator | Backup ages out within 30 days; database restore is reconciled against the protected file tombstone before jobs run |

## Four non-interchangeable information layers

1. **Submitted information** — what a writer deliberately provides.
2. **Operational information** — minimum state needed for security, moderation and delivery.
3. **Derived information** — Story-centred concepts, Threads, Domains, privacy evidence, warnings, embeddings and relationships.
4. **Public information** — only fields deliberately approved for publication.

## Lifecycle invariants

- A queue row is not permission to process.
- AI eligibility is checked from the current post type, status, block state, job generation and content hash.
- Decline, withdrawal, trash and deletion invoke authoritative AI forgetting.
- Repeated forgetting has the same final state: no active per-Story derived representation.
- Public search and sitemaps require `publish` state explicitly.
- A substantive revision produces a new content hash and invalidates old derived data.
- Metadata-only, provenance and AI housekeeping changes do not pretend the Story text changed.
- The audit trail stores no Story words, visitor IP, privacy match or embedding.
