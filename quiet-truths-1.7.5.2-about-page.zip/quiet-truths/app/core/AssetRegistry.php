<?php
/**
 * Quiet Truths — Asset Registry
 *
 * Reads the design-system manifest (app/design-system/manifest.php) and
 * enqueues the CSS token files in cascade order, then the theme script.
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class AssetRegistry
{
    public static function init(): void
    {
        add_action('wp_enqueue_scripts', [self::class, 'registerDesignSystem'], 20);
        add_action('wp_enqueue_scripts', [self::class, 'registerThemeAssets'], 21);
    }

    /**
     * Enqueue every stylesheet listed in the design-system manifest.
     * Handles are prefixed with "qt-" so they can be filtered by other code.
     */
    public static function registerDesignSystem(): void
    {
        $manifest = require QT_DESIGN_SYSTEM_DIR . '/manifest.php';

        if (!is_array($manifest) || empty($manifest)) {
            error_log('Quiet Truths: design-system manifest is empty or missing at ' . QT_DESIGN_SYSTEM_DIR . '/manifest.php');
            return;
        }

        // Child CSS cascades over the Blocksy parent stylesheet.
        $deps = ['blocksy-parent'];

        foreach ($manifest as $handle => $entry) {
            if (!is_array($entry) || empty($entry['file'])) {
                continue;
            }

            $file    = $entry['file'];
            $path    = QT_DESIGN_SYSTEM_DIR . '/' . $file;
            $assetId = 'qt-' . $handle;

            if (!file_exists($path)) {
                error_log('Quiet Truths: design asset missing at ' . $path);
                continue;
            }

            wp_enqueue_style($assetId, QT_DESIGN_SYSTEM_URI . '/' . $file, $deps, QT_THEME_VERSION);
            $deps[] = $assetId;
        }
    }

    public static function registerThemeAssets(): void
    {
        // Reading & interface fonts are bundled locally so opening a
        // sensitive submission page does not disclose the visitor's IP to
        // a third-party font host. Disable with QT_ENABLE_FONTS=false.
        if (apply_filters('quiet_truths_load_fonts', !defined('QT_ENABLE_FONTS') || QT_ENABLE_FONTS)) {
            wp_enqueue_style(
                'qt-fonts',
                QT_ASSETS_URI . '/fonts/fonts.css',
                [],
                QT_THEME_VERSION
            );
        }

        wp_enqueue_script('qt-theme', QT_ASSETS_URI . '/js/theme.js', [], QT_THEME_VERSION, true);
        wp_enqueue_script('qt-live-search', QT_ASSETS_URI . '/js/live-search.js', [], QT_THEME_VERSION, true);

        // Silent reader reactions — only on single story pages.
        if (is_singular('qt_story') && class_exists(\QuietTruths\Core\Reactions::class)) {
            wp_enqueue_script('qt-reactions', QT_ASSETS_URI . '/js/reactions.js', [], QT_THEME_VERSION, true);

            $storyId = get_queried_object_id();

            wp_localize_script('qt-reactions', 'QTReactions', [
                'ajaxUrl' => admin_url('admin-ajax.php'),
                'nonce'   => \QuietTruths\Core\Reactions::nonce($storyId),
                'thanks'  => __('The house has heard you. Thank you for being here.', 'quiet-truths'),
            ]);
        }

        // The invisible layer, slimmed for the browser: each concept's
        // name and a few of its words, so typing suggests concepts.
        if (class_exists(\QuietTruths\Core\Concepts::class)) {
            $slim = [];

            foreach (\QuietTruths\Core\Concepts::concepts() as $slug => $concept) {
                $slim[] = [
                    'slug'  => (string) $slug,
                    'name'  => (string) ($concept['name'] ?? $slug),
                    'words' => array_slice(array_values((array) ($concept['words'] ?? [])), 0, 15),
                ];
            }

            wp_localize_script('qt-live-search', 'QTLiveSearch', ['concepts' => $slim]);
        }
    }
}
