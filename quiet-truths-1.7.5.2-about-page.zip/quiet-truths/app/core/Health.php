<?php
/** Quiet Truths — private operational health without Story content. */
namespace QuietTruths\Core;

use QuietTruths\Ai\AiKernel;
use QuietTruths\Ai\BackgroundWorker;
use QuietTruths\Ai\Embeddings;
use QuietTruths\Ai\ProfileLifecycle;
use QuietTruths\Ai\ProfileStore;

if (!defined('ABSPATH')) { exit; }

final class Health
{
    public static function init(): void
    {
        add_action('admin_menu', [self::class, 'registerPage']);
    }

    public static function heartbeat(string $runner = 'wp_cli'): void
    {
        update_option('qt_operations_heartbeat', [
            'at_gmt' => current_time('mysql', true),
            'runner' => sanitize_key($runner),
        ], false);
    }

    /** @return array<string,array{ok:bool,value:string}> */
    public static function checks(): array
    {
        $heartbeat = get_option('qt_operations_heartbeat', []);
        $heartbeat = is_array($heartbeat) ? $heartbeat : [];
        $heartbeatTs = !empty($heartbeat['at_gmt']) ? strtotime($heartbeat['at_gmt'] . ' UTC') : 0;
        $retention = get_option('qt_retention_last_run', []);
        $retention = is_array($retention) ? $retention : [];
        $retentionTs = !empty($retention['checked_at_gmt']) ? strtotime($retention['checked_at_gmt'] . ' UTC') : 0;
        $reconcile = get_option('qt_tombstone_last_reconcile', []);
        $reconcile = is_array($reconcile) ? $reconcile : [];
        $reconcileTs = !empty($reconcile['at_gmt']) ? strtotime($reconcile['at_gmt'] . ' UTC') : 0;

        [$queued, $overdue] = self::queueCounts();
        $violations = self::forgottenViolations();
        $service = Embeddings::serviceMeta();
        $backup = self::backupPolicy();
        $moderators = 0;
        foreach (get_users(['fields' => 'ids']) as $userId) {
            if (user_can((int) $userId, 'view_qt_privacy')) $moderators++;
        }

        return [
            'mbstring' => [
                'ok' => Requirements::satisfied(),
                'value' => Requirements::satisfied() ? 'mandatory extension loaded' : 'missing — application must not run',
            ],
            'ai_policy' => [
                'ok' => AiKernel::isLocalOnly(),
                'value' => AiKernel::isLocalOnly() ? 'loopback-only' : 'invalid endpoint rejected',
            ],
            'ai_service' => [
                'ok' => !$service['ok'] || AiKernel::isLocalOnly(),
                'value' => $service['ok'] ? ('ready: ' . $service['model']) : 'offline; lexical fallback safe',
            ],
            'operations_runner' => [
                'ok' => $heartbeatTs > time() - 15 * MINUTE_IN_SECONDS,
                'value' => $heartbeatTs ? gmdate('c', $heartbeatTs) . ' via ' . ($heartbeat['runner'] ?? '?') : 'never',
            ],
            'retention' => [
                'ok' => $retentionTs > time() - 2 * DAY_IN_SECONDS,
                'value' => $retentionTs ? gmdate('c', $retentionTs) : 'never',
            ],
            'restore_reconciliation' => [
                'ok' => $reconcileTs > time() - 15 * MINUTE_IN_SECONDS && 0 === (int) ($reconcile['invalid'] ?? 0),
                'value' => $reconcileTs ? gmdate('c', $reconcileTs) . '; enforced=' . (int) ($reconcile['enforced'] ?? 0) : 'never',
            ],
            'ai_queue' => [
                'ok' => 0 === $overdue,
                'value' => $queued . ' queued; ' . $overdue . ' overdue',
            ],
            'forget_integrity' => [
                'ok' => 0 === $violations,
                'value' => $violations . ' blocked Stories retain derived data',
            ],
            'moderator_access' => [
                'ok' => 1 === $moderators,
                'value' => $moderators . ' account(s) can view pending AI/privacy evidence',
            ],
            'backup_policy' => $backup,
            'debug_display' => [
                'ok' => !(defined('WP_DEBUG_DISPLAY') && WP_DEBUG_DISPLAY),
                'value' => (defined('WP_DEBUG_DISPLAY') && WP_DEBUG_DISPLAY) ? 'enabled' : 'disabled',
            ],
        ];
    }

    public static function registerPage(): void
    {
        add_management_page(
            __('Quiet Truths Health', 'quiet-truths'),
            __('Quiet Truths Health', 'quiet-truths'),
            'manage_qt_health',
            'qt-health',
            [self::class, 'renderPage']
        );
    }

    public static function renderPage(): void
    {
        if (!current_user_can('manage_qt_health')) {
            wp_die(esc_html__('You are not allowed to view operational health.', 'quiet-truths'));
        }
        echo '<div class="wrap"><h1>' . esc_html__('Quiet Truths Health', 'quiet-truths') . '</h1>';
        echo '<p>' . esc_html__('Operational status only. No Story words, privacy evidence or inferred labels are displayed here.', 'quiet-truths') . '</p>';
        echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Check', 'quiet-truths') . '</th><th>' . esc_html__('State', 'quiet-truths') . '</th><th>' . esc_html__('Detail', 'quiet-truths') . '</th></tr></thead><tbody>';
        foreach (self::checks() as $name => $check) {
            echo '<tr><td>' . esc_html(str_replace('_', ' ', $name)) . '</td><td><strong style="color:' . ($check['ok'] ? '#2e7d32' : '#b32d2e') . '">' . esc_html($check['ok'] ? __('OK', 'quiet-truths') : __('Attention', 'quiet-truths')) . '</strong></td><td>' . esc_html($check['value']) . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    /** @return array{ok:bool,value:string} */
    private static function backupPolicy(): array
    {
        $service = get_option('updraft_service', '');
        $services = is_array($service) ? $service : preg_split('/[,\s]+/', (string) $service);
        $remote = in_array('googledrive', array_map('strtolower', array_filter((array) $services)), true);
        $fileInterval = (string) get_option('updraft_interval', '');
        $dbInterval   = (string) get_option('updraft_interval_database', '');
        $fileRetain   = (int) get_option('updraft_retain', 0);
        $dbRetain     = (int) get_option('updraft_retain_db', 0);
        $ok = $remote && 'weekly' === $fileInterval && 'daily' === $dbInterval
            && $fileRetain > 0 && $fileRetain <= 4
            && $dbRetain > 0 && $dbRetain <= 30;
        return [
            'ok' => $ok,
            'value' => sprintf(
                'remote=%s; files=%s/%d; database=%s/%d; archive encryption=provider-managed only',
                $remote ? 'Google Drive' : 'not verified',
                $fileInterval ?: 'unset', $fileRetain,
                $dbInterval ?: 'unset', $dbRetain
            ),
        ];
    }

    /** @return array{0:int,1:int} */
    private static function queueCounts(): array
    {
        $queued = 0; $overdue = 0; $now = time();
        $cron = function_exists('_get_cron_array') ? _get_cron_array() : [];
        foreach ((array) $cron as $timestamp => $hooks) {
            if (empty($hooks[BackgroundWorker::HOOK_PROFILE])) continue;
            foreach ((array) $hooks[BackgroundWorker::HOOK_PROFILE] as $event) {
                $queued++;
                if ((int) $timestamp < $now - HOUR_IN_SECONDS) $overdue++;
            }
        }
        return [$queued, $overdue];
    }

    private static function forgottenViolations(): int
    {
        $ids = get_posts([
            'post_type' => ['qt_story','qt_journal'], 'post_status' => 'any',
            'posts_per_page' => -1, 'fields' => 'ids', 'no_found_rows' => true,
            'meta_query' => [['key' => ProfileLifecycle::BLOCKED_META, 'value' => '1']],
        ]);
        $count = 0;
        foreach ($ids as $id) if (ProfileStore::hasDerived((int) $id)) $count++;
        return $count;
    }
}
