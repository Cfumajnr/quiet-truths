<?php
/**
 * Quiet Truths — Story provenance and founding-collection schedule.
 *
 * WordPress core uses post_modified for sitemap <lastmod>. The 32 Stories
 * carried from the previous site were all technically migrated on the same
 * day, so core correctly—but unhelpfully—reported one common migration date.
 *
 * This layer distinguishes technical migration from meaningful editorial
 * chronology. It provides an explicit, reversible admin tool that:
 *   - applies the operator-approved weekly founding schedule;
 *   - marks those 32 Stories as a migrated founding collection;
 *   - fills only missing Room assignments from the approved Room arc;
 *   - leaves Story words, titles, slugs and existing non-empty Rooms alone;
 *   - keeps the first native Story outside the legacy schedule;
 *   - backs up dates/Rooms/provenance before changing anything.
 *
 * Sitemaps and Article schema then use the house release date until a later
 * substantive title/excerpt/body edit occurs. AI profile rebuilds, taxonomy
 * changes and metadata-only edits do not manufacture a fresh <lastmod>.
 *
 * @package QuietTruths\Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Provenance
{
    public const ORIGIN_META           = '_qt_origin';
    public const SOURCE_META           = '_qt_story_source';
    public const HOUSE_DATE_META       = '_qt_house_published_at_gmt';
    public const CONTENT_UPDATED_META  = '_qt_content_modified_at_gmt';
    public const SCHEDULE_META         = '_qt_founding_schedule';

    // Chronology/provenance: where the Story sits in the site's history.
    public const ORIGIN_FOUNDING = 'migrated_founding_collection';
    public const ORIGIN_NATIVE   = 'native_quiet_truths';

    // Editorial source: who brought the Story into the system. Kept
    // separate so a Story may be both Founding Collection and From the House.
    public const SOURCE_ANONYMOUS = 'anonymous_submission';
    public const SOURCE_HOUSE     = 'house_original';
    public const SOURCE_EDITORIAL = 'editorial_contribution';

    // Temporary 1.7.4.5 values, read only for seamless compatibility.
    private const LEGACY_ORIGIN_ANONYMOUS = 'anonymous_submission';
    private const LEGACY_ORIGIN_HOUSE     = 'house_original';
    private const LEGACY_ORIGIN_EDITORIAL = 'editorial_contribution';
    private const APPLIED_OPTION  = 'qt_founding_schedule_applied';
    private const BACKUP_OPTION   = 'qt_founding_schedule_backup';

    /** @var array<string,mixed>|null */
    private static ?array $config = null;

    public static function init(): void
    {
        add_filter('wp_sitemaps_posts_entry', [self::class, 'sitemapEntry'], 10, 3);
        add_action('post_updated', [self::class, 'recordSubstantiveUpdate'], 20, 3);
        add_action('admin_menu', [self::class, 'registerAdminPage']);
        add_action('add_meta_boxes_qt_story', [self::class, 'registerSourceMetaBox']);
        add_action('save_post_qt_story', [self::class, 'saveSourceMeta'], 15, 2);
        add_action('admin_post_qt_apply_founding_schedule', [self::class, 'handleApply']);
        add_action('admin_post_qt_restore_founding_schedule', [self::class, 'handleRestore']);
    }

    /** @return array<string,mixed> */
    public static function config(): array
    {
        if (null !== self::$config) {
            return self::$config;
        }

        $path = dirname(__DIR__) . '/config/founding-schedule.php';
        $data = is_file($path) ? require $path : [];
        self::$config = is_array($data) ? $data : [];

        return self::$config;
    }

    /** @return list<array{date:string,room:string,slug:string}> */
    public static function entries(): array
    {
        $entries = (array) (self::config()['entries'] ?? []);

        return array_values(array_filter($entries, static function ($entry): bool {
            return is_array($entry)
                && !empty($entry['date'])
                && !empty($entry['room'])
                && !empty($entry['slug']);
        }));
    }

    public static function isFoundingStory($post): bool
    {
        $post = get_post($post);

        return $post instanceof \WP_Post
            && 'qt_story' === $post->post_type
            && self::ORIGIN_FOUNDING === (string) get_post_meta($post->ID, self::ORIGIN_META, true);
    }

    public static function origin($post): string
    {
        $post = get_post($post);

        return $post instanceof \WP_Post
            ? (string) get_post_meta($post->ID, self::ORIGIN_META, true)
            : '';
    }

    /** Editorial source, independent of founding/native chronology. */
    public static function source($post): string
    {
        $post = get_post($post);
        if (!$post instanceof \WP_Post) {
            return '';
        }

        $source = (string) get_post_meta($post->ID, self::SOURCE_META, true);
        if ('' !== $source) {
            return $source;
        }

        // Seamlessly read the short-lived 1.7.4.5 representation where
        // source values were written into _qt_origin.
        return match (self::origin($post)) {
            self::LEGACY_ORIGIN_ANONYMOUS => self::SOURCE_ANONYMOUS,
            self::LEGACY_ORIGIN_HOUSE     => self::SOURCE_HOUSE,
            self::LEGACY_ORIGIN_EDITORIAL => self::SOURCE_EDITORIAL,
            default                       => '',
        };
    }

    /**
     * A Story made/editorially introduced by Quiet Truths itself. A native
     * Story with no source recorded is treated as House material for
     * backwards compatibility; new native schedules record both fields.
     */
    public static function isHouseStory($post): bool
    {
        $source = self::source($post);
        if (self::SOURCE_HOUSE === $source) {
            return true;
        }

        return '' === $source && self::ORIGIN_NATIVE === self::origin($post);
    }

    public static function sourceLabel($post): string
    {
        return match (self::source($post)) {
            self::SOURCE_HOUSE     => __('From the House', 'quiet-truths'),
            self::SOURCE_ANONYMOUS => __('Left anonymously', 'quiet-truths'),
            self::SOURCE_EDITORIAL => __('Editorial Contribution', 'quiet-truths'),
            default                => '',
        };
    }

    /** @return array<string,string> */
    public static function sourceOptions(): array
    {
        return [
            ''                     => __('Not recorded', 'quiet-truths'),
            self::SOURCE_ANONYMOUS => __('Anonymous submission', 'quiet-truths'),
            self::SOURCE_HOUSE     => __('From the House', 'quiet-truths'),
            self::SOURCE_EDITORIAL => __('Editorial contribution', 'quiet-truths'),
        ];
    }

    /**
     * Meaningful modified time in UTC MySQL format.
     */
    public static function meaningfulModifiedGmt(\WP_Post $post): string
    {
        if (!self::isFoundingStory($post)) {
            return self::validGmt((string) $post->post_modified_gmt)
                ? (string) $post->post_modified_gmt
                : (string) $post->post_date_gmt;
        }

        $house = (string) get_post_meta($post->ID, self::HOUSE_DATE_META, true);
        if (!self::validGmt($house)) {
            $house = (string) $post->post_date_gmt;
        }

        $content = (string) get_post_meta($post->ID, self::CONTENT_UPDATED_META, true);
        if (self::validGmt($content) && strtotime($content . ' UTC') > strtotime($house . ' UTC')) {
            return $content;
        }

        return $house;
    }

    public static function modifiedIso(\WP_Post $post): string
    {
        $gmt = self::meaningfulModifiedGmt($post);
        $ts  = strtotime($gmt . ' UTC');

        return false !== $ts ? wp_date(DATE_W3C, $ts) : get_the_modified_date('c', $post);
    }

    /**
     * @param array<string,string> $entry
     * @return array<string,string>
     */
    public static function sitemapEntry(array $entry, \WP_Post $post, string $postType): array
    {
        if ('qt_story' !== $postType || !self::isFoundingStory($post)) {
            return $entry;
        }

        $entry['lastmod'] = self::modifiedIso($post);

        return $entry;
    }

    /**
     * Record only a meaningful title/excerpt/body edit. WordPress's generic
     * post_modified changes on many editorial saves and was the cause of the
     * common migration timestamp in the first place.
     */
    public static function recordSubstantiveUpdate(int $postId, \WP_Post $after, \WP_Post $before): void
    {
        if ('qt_story' !== $after->post_type || !self::isFoundingStory($after)) {
            return;
        }

        $changed = (string) $after->post_title !== (string) $before->post_title
            || (string) $after->post_excerpt !== (string) $before->post_excerpt
            || (string) $after->post_content !== (string) $before->post_content;

        if ($changed && self::validGmt((string) $after->post_modified_gmt)) {
            update_post_meta($postId, self::CONTENT_UPDATED_META, (string) $after->post_modified_gmt);
        }
    }

    public static function registerSourceMetaBox(\WP_Post $post): void
    {
        add_meta_box(
            'qt_story_source',
            __('Story source', 'quiet-truths'),
            static function (\WP_Post $story): void {
                wp_nonce_field('qt_story_source_' . $story->ID, 'qt_story_source_nonce');
                $current = self::source($story);
                echo '<select name="qt_story_source" style="width:100%">';
                foreach (self::sourceOptions() as $value => $label) {
                    echo '<option value="' . esc_attr($value) . '"'
                        . selected($current, $value, false) . '>'
                        . esc_html($label) . '</option>';
                }
                echo '</select>';
                echo '<p class="description">'
                    . esc_html__('“From the House” is public editorial source. It is separate from truth form (fiction/composite/experience) and from chronology (founding/native). It suppresses automated duplicate/spam-origin suspicion, but privacy and safety review remain active.', 'quiet-truths')
                    . '</p>';
            },
            'qt_story',
            'side',
            'high'
        );
    }

    public static function saveSourceMeta(int $postId, \WP_Post $post): void
    {
        if ('qt_story' !== $post->post_type
            || !isset($_POST['qt_story_source_nonce'])
            || !wp_verify_nonce(
                sanitize_key(wp_unslash((string) $_POST['qt_story_source_nonce'])),
                'qt_story_source_' . $postId
            )
            || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
            || wp_is_post_revision($postId)
            || !current_user_can('edit_post', $postId)) {
            return;
        }

        $source  = sanitize_key(wp_unslash((string) ($_POST['qt_story_source'] ?? '')));
        $allowed = array_keys(self::sourceOptions());
        if ('' !== $source && in_array($source, $allowed, true)) {
            update_post_meta($postId, self::SOURCE_META, $source);
        } else {
            delete_post_meta($postId, self::SOURCE_META);
        }

        $legacyOrigin = (string) get_post_meta($postId, self::ORIGIN_META, true);
        if (in_array($legacyOrigin, [
            self::LEGACY_ORIGIN_ANONYMOUS,
            self::LEGACY_ORIGIN_HOUSE,
            self::LEGACY_ORIGIN_EDITORIAL,
        ], true)) {
            delete_post_meta($postId, self::ORIGIN_META);
        }
    }

    public static function registerAdminPage(): void
    {
        add_submenu_page(
            'edit.php?post_type=qt_story',
            __('Founding Story Schedule', 'quiet-truths'),
            __('Founding Schedule', 'quiet-truths'),
            'manage_options',
            'qt-founding-schedule',
            [self::class, 'renderAdminPage']
        );
    }

    public static function renderAdminPage(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to manage the founding schedule.', 'quiet-truths'));
        }

        $config  = self::config();
        $entries = self::entries();
        $rows    = self::resolveEntries($entries);
        $missing = array_values(array_filter($rows, static fn (array $row): bool => !$row['post']));
        $applied = get_option(self::APPLIED_OPTION, []);
        $applied = is_array($applied) ? $applied : [];
        $notice  = sanitize_key(wp_unslash((string) ($_GET['qt_schedule_notice'] ?? '')));

        echo '<div class="wrap">';
        echo '<h1>' . esc_html__('Founding Story Schedule', 'quiet-truths') . '</h1>';
        echo '<p>' . esc_html__('Preview the operator-approved weekly journey for the 32 Stories carried from the previous site. Nothing changes until Apply is pressed. Story words, titles and slugs are never changed.', 'quiet-truths') . '</p>';
        echo '<p><strong>' . esc_html__('Schedule:', 'quiet-truths') . '</strong> '
            . esc_html((string) ($config['version'] ?? '—')) . ' · '
            . esc_html__('one Story each Thursday, 1 January–6 August 2026, followed by the first native Story on 9 August.', 'quiet-truths') . '</p>';

        if ('applied' === $notice) {
            echo '<div class="notice notice-success"><p>' . esc_html__('The founding schedule was applied. Purge page caches, then inspect the Story sitemap.', 'quiet-truths') . '</p></div>';
        } elseif ('restored' === $notice) {
            echo '<div class="notice notice-success"><p>' . esc_html__('The previous dates, Rooms and provenance values were restored from the backup.', 'quiet-truths') . '</p></div>';
        } elseif ('missing' === $notice) {
            echo '<div class="notice notice-error"><p>' . esc_html__('Nothing was changed because one or more scheduled Story slugs could not be resolved uniquely.', 'quiet-truths') . '</p></div>';
        } elseif ('already' === $notice) {
            echo '<div class="notice notice-warning"><p>' . esc_html__('This schedule has already been applied. Restore it before applying again.', 'quiet-truths') . '</p></div>';
        }

        if (!empty($missing)) {
            echo '<div class="notice notice-error"><p>' . esc_html(sprintf(
                _n('%d scheduled Story is missing or ambiguous. Apply is disabled.', '%d scheduled Stories are missing or ambiguous. Apply is disabled.', count($missing), 'quiet-truths'),
                count($missing)
            )) . '</p></div>';
        }

        echo '<table class="widefat striped"><thead><tr>';
        foreach ([__('Week', 'quiet-truths'), __('House date', 'quiet-truths'), __('Story', 'quiet-truths'), __('Room arc', 'quiet-truths'), __('Current state', 'quiet-truths')] as $heading) {
            echo '<th>' . esc_html($heading) . '</th>';
        }
        echo '</tr></thead><tbody>';

        foreach ($rows as $index => $row) {
            $post = $row['post'];
            echo '<tr>';
            echo '<td>' . (int) ($index + 1) . '</td>';
            echo '<td><code>' . esc_html((string) $row['entry']['date']) . '</code></td>';
            echo '<td>';
            if ($post instanceof \WP_Post) {
                echo '<a href="' . esc_url(get_edit_post_link($post->ID)) . '">' . esc_html((string) $post->post_title) . '</a>';
                echo '<br><code>' . esc_html((string) $post->post_name) . '</code>';
            } else {
                echo '<strong style="color:#b32d2e">' . esc_html__('Missing or ambiguous', 'quiet-truths') . '</strong><br><code>'
                    . esc_html((string) $row['entry']['slug']) . '</code>';
            }
            echo '</td>';
            echo '<td>' . esc_html(self::roomName((string) $row['entry']['room'])) . '</td>';
            echo '<td>' . esc_html((string) $row['state']) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';

        echo '<p style="margin-top:18px"><strong>' . esc_html__('Important:', 'quiet-truths') . '</strong> '
            . esc_html__('Existing non-empty Room assignments are preserved. The approved Room arc fills only the 11 migrated Stories that currently have no Room. A complete backup is stored before application.', 'quiet-truths') . '</p>';

        if (empty($applied)) {
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
            wp_nonce_field('qt_apply_founding_schedule');
            echo '<input type="hidden" name="action" value="qt_apply_founding_schedule">';
            submit_button(
                __('Apply the 32-Story founding schedule', 'quiet-truths'),
                'primary',
                'submit',
                false,
                !empty($missing) ? ['disabled' => 'disabled'] : []
            );
            echo '</form>';
        } else {
            echo '<div class="notice notice-info inline"><p>' . esc_html(sprintf(
                /* translators: %s schedule version. */
                __('Applied schedule: %s. Sitemaps now use house dates rather than the technical migration timestamp.', 'quiet-truths'),
                (string) ($applied['version'] ?? '—')
            )) . '</p></div>';

            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(' . esc_attr(wp_json_encode(__('Restore the dates and Rooms saved before the schedule was applied?', 'quiet-truths'))) . ')">';
            wp_nonce_field('qt_restore_founding_schedule');
            echo '<input type="hidden" name="action" value="qt_restore_founding_schedule">';
            submit_button(__('Restore the pre-schedule dates and Rooms', 'quiet-truths'), 'secondary', 'submit', false);
            echo '</form>';
        }

        echo '</div>';
    }

    public static function handleApply(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to apply this schedule.', 'quiet-truths'));
        }
        check_admin_referer('qt_apply_founding_schedule');

        if (get_option(self::APPLIED_OPTION)) {
            self::redirectWithNotice('already');
        }

        $entries = self::entries();
        $rows    = self::resolveEntries($entries);
        foreach ($rows as $row) {
            if (!$row['post'] instanceof \WP_Post) {
                self::redirectWithNotice('missing');
            }
        }

        $backup = [
            'created_at_gmt' => current_time('mysql', true),
            'version'        => (string) (self::config()['version'] ?? ''),
            'stories'        => [],
            'native'         => null,
        ];

        // Capture every value before making the first change.
        foreach ($rows as $row) {
            /** @var \WP_Post $post */
            $post = $row['post'];
            $backup['stories'][$post->ID] = self::snapshot($post);
        }

        $native = self::findUniqueStory((string) (self::config()['native_slug'] ?? ''));
        if ($native instanceof \WP_Post) {
            $backup['native'] = [
                'id'     => $native->ID,
                'origin' => get_post_meta($native->ID, self::ORIGIN_META, true),
                'source' => get_post_meta($native->ID, self::SOURCE_META, true),
            ];
        }

        update_option(self::BACKUP_OPTION, $backup, false);

        foreach ($rows as $row) {
            /** @var \WP_Post $post */
            $post  = $row['post'];
            $entry = $row['entry'];
            $local = (string) $entry['date'];
            $gmt   = self::localToGmt($local);

            wp_update_post([
                'ID'            => $post->ID,
                'post_date'     => $local,
                'post_date_gmt' => $gmt,
            ]);

            $rooms = wp_get_object_terms($post->ID, 'qt_room', ['fields' => 'slugs']);
            $rooms = is_wp_error($rooms) ? [] : array_values(array_map('strval', $rooms));
            if (empty($rooms)) {
                wp_set_object_terms($post->ID, [(string) $entry['room']], 'qt_room', false);
            }

            // Preserve any 1.7.4.5 source value before chronology replaces
            // the overloaded _qt_origin field with Founding Collection.
            $existingSource = self::source($post);
            if ('' !== $existingSource
                && '' === (string) get_post_meta($post->ID, self::SOURCE_META, true)) {
                update_post_meta($post->ID, self::SOURCE_META, $existingSource);
            }
            update_post_meta($post->ID, self::ORIGIN_META, self::ORIGIN_FOUNDING);
            update_post_meta($post->ID, self::HOUSE_DATE_META, $gmt);
            update_post_meta($post->ID, self::SCHEDULE_META, (string) (self::config()['version'] ?? ''));
            // The migration/save timestamp is not a substantive content edit.
            delete_post_meta($post->ID, self::CONTENT_UPDATED_META);
            clean_post_cache($post->ID);
        }

        if ($native instanceof \WP_Post) {
            if ('' === (string) get_post_meta($native->ID, self::ORIGIN_META, true)) {
                update_post_meta($native->ID, self::ORIGIN_META, self::ORIGIN_NATIVE);
            }
            if ('' === (string) get_post_meta($native->ID, self::SOURCE_META, true)) {
                update_post_meta($native->ID, self::SOURCE_META, self::SOURCE_HOUSE);
            }
        }

        update_option(self::APPLIED_OPTION, [
            'version'        => (string) (self::config()['version'] ?? ''),
            'applied_at_gmt' => current_time('mysql', true),
            'count'          => count($rows),
        ], false);

        self::purgeCaches();
        self::redirectWithNotice('applied');
    }

    public static function handleRestore(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('You are not allowed to restore this schedule.', 'quiet-truths'));
        }
        check_admin_referer('qt_restore_founding_schedule');

        $backup = get_option(self::BACKUP_OPTION, []);
        if (!is_array($backup) || empty($backup['stories']) || !is_array($backup['stories'])) {
            self::redirectWithNotice('missing');
        }

        global $wpdb;

        foreach ($backup['stories'] as $postId => $saved) {
            $postId = (int) $postId;
            $post   = get_post($postId);
            if (!$post instanceof \WP_Post || 'qt_story' !== $post->post_type || !is_array($saved)) {
                continue;
            }

            wp_update_post([
                'ID'            => $postId,
                'post_date'     => (string) ($saved['post_date'] ?? $post->post_date),
                'post_date_gmt' => (string) ($saved['post_date_gmt'] ?? $post->post_date_gmt),
            ]);
            // wp_update_post intentionally stamps "modified now". Restore
            // the exact pre-schedule technical values unless the Story was
            // substantively edited after application; a real later edit must
            // never be hidden by rollback.
            $modifiedLocal = (string) ($saved['post_modified'] ?? '');
            $modifiedGmt   = (string) ($saved['post_modified_gmt'] ?? '');
            $laterContent  = (string) get_post_meta($postId, self::CONTENT_UPDATED_META, true);
            if (self::validGmt($laterContent)
                && (!self::validGmt($modifiedGmt)
                    || strtotime($laterContent . ' UTC') > strtotime($modifiedGmt . ' UTC'))) {
                $modifiedGmt   = $laterContent;
                $modifiedLocal = get_date_from_gmt($laterContent, 'Y-m-d H:i:s');
            }

            if (self::validGmt($modifiedGmt) && '' !== $modifiedLocal) {
                $wpdb->update(
                    $wpdb->posts,
                    [
                        'post_modified'     => $modifiedLocal,
                        'post_modified_gmt' => $modifiedGmt,
                    ],
                    ['ID' => $postId],
                    ['%s', '%s'],
                    ['%d']
                );
            }

            wp_set_object_terms($postId, array_values((array) ($saved['rooms'] ?? [])), 'qt_room', false);
            self::restoreMeta($postId, self::ORIGIN_META, $saved['origin'] ?? '');
            self::restoreMeta($postId, self::SOURCE_META, $saved['source'] ?? '');
            self::restoreMeta($postId, self::HOUSE_DATE_META, $saved['house_date'] ?? '');
            self::restoreMeta($postId, self::CONTENT_UPDATED_META, $saved['content_updated'] ?? '');
            self::restoreMeta($postId, self::SCHEDULE_META, $saved['schedule'] ?? '');
            clean_post_cache($postId);
        }

        if (!empty($backup['native']['id'])) {
            self::restoreMeta(
                (int) $backup['native']['id'],
                self::ORIGIN_META,
                $backup['native']['origin'] ?? ''
            );
            self::restoreMeta(
                (int) $backup['native']['id'],
                self::SOURCE_META,
                $backup['native']['source'] ?? ''
            );
        }

        delete_option(self::APPLIED_OPTION);
        delete_option(self::BACKUP_OPTION);
        self::purgeCaches();
        self::redirectWithNotice('restored');
    }

    /**
     * @param list<array{date:string,room:string,slug:string}> $entries
     * @return list<array{entry:array,post:?\WP_Post,state:string}>
     */
    private static function resolveEntries(array $entries): array
    {
        $rows = [];
        foreach ($entries as $entry) {
            $post  = self::findUniqueStory((string) $entry['slug']);
            $state = __('Missing or ambiguous', 'quiet-truths');

            if ($post instanceof \WP_Post) {
                $rooms = wp_get_object_terms($post->ID, 'qt_room', ['fields' => 'slugs']);
                $rooms = is_wp_error($rooms) ? [] : array_values(array_map('strval', $rooms));
                if (empty($rooms)) {
                    $state = sprintf(
                        /* translators: %s expected Room. */
                        __('Ready; missing Room will become %s', 'quiet-truths'),
                        self::roomName((string) $entry['room'])
                    );
                } elseif (in_array((string) $entry['room'], $rooms, true)) {
                    $state = __('Ready; existing Room agrees', 'quiet-truths');
                } else {
                    $state = sprintf(
                        /* translators: %s comma-separated current Rooms. */
                        __('Ready; existing Room preserved: %s', 'quiet-truths'),
                        implode(', ', array_map([self::class, 'roomName'], $rooms))
                    );
                }
            }

            $rows[] = ['entry' => $entry, 'post' => $post, 'state' => $state];
        }

        return $rows;
    }

    private static function findUniqueStory(string $slug): ?\WP_Post
    {
        if ('' === $slug) {
            return null;
        }

        $posts = get_posts([
            'name'           => sanitize_title($slug),
            'post_type'      => 'qt_story',
            'post_status'    => ['publish', 'pending', 'draft', 'private', 'future'],
            'posts_per_page' => 2,
            'no_found_rows'  => true,
            'orderby'        => 'ID',
            'order'          => 'ASC',
        ]);

        return 1 === count($posts) && $posts[0] instanceof \WP_Post ? $posts[0] : null;
    }

    /** @return array<string,mixed> */
    private static function snapshot(\WP_Post $post): array
    {
        $rooms = wp_get_object_terms($post->ID, 'qt_room', ['fields' => 'slugs']);

        return [
            'post_date'       => (string) $post->post_date,
            'post_date_gmt'   => (string) $post->post_date_gmt,
            'post_modified'   => (string) $post->post_modified,
            'post_modified_gmt' => (string) $post->post_modified_gmt,
            'rooms'           => is_wp_error($rooms) ? [] : array_values(array_map('strval', $rooms)),
            'origin'          => get_post_meta($post->ID, self::ORIGIN_META, true),
            'source'          => get_post_meta($post->ID, self::SOURCE_META, true),
            'house_date'      => get_post_meta($post->ID, self::HOUSE_DATE_META, true),
            'content_updated' => get_post_meta($post->ID, self::CONTENT_UPDATED_META, true),
            'schedule'        => get_post_meta($post->ID, self::SCHEDULE_META, true),
        ];
    }

    private static function restoreMeta(int $postId, string $key, $value): void
    {
        if ('' === (string) $value) {
            delete_post_meta($postId, $key);
        } else {
            update_post_meta($postId, $key, $value);
        }
    }

    private static function localToGmt(string $local): string
    {
        $tzName = (string) (self::config()['timezone'] ?? 'Africa/Nairobi');
        try {
            $date = new \DateTimeImmutable($local, new \DateTimeZone($tzName));
            return $date->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s');
        } catch (\Throwable $e) {
            return get_gmt_from_date($local, 'Y-m-d H:i:s');
        }
    }

    private static function validGmt(string $value): bool
    {
        if (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $value)) {
            return false;
        }

        return false !== strtotime($value . ' UTC');
    }

    public static function roomName(string $slug): string
    {
        $rooms = defined('QT_ROOMS') ? QT_ROOMS : [];

        return (string) ($rooms[$slug]['name'] ?? ucwords(str_replace('-', ' ', $slug)));
    }

    private static function purgeCaches(): void
    {
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
        do_action('litespeed_purge_all');
    }

    private static function redirectWithNotice(string $notice): void
    {
        $url = add_query_arg([
            'post_type'          => 'qt_story',
            'page'               => 'qt-founding-schedule',
            'qt_schedule_notice' => sanitize_key($notice),
        ], admin_url('edit.php'));

        wp_safe_redirect($url);
        exit;
    }
}
