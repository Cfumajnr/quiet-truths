<?php
/** Quiet Truths — enforceable privacy-minimal retention. */
namespace QuietTruths\Core;

if (!defined('ABSPATH')) { exit; }

final class Retention
{
    public const HOOK = 'qt_retention_cleanup';
    public const UNREVIEWED_DAYS = 30;
    public const DECLINED_DAYS   = 7;
    public const AUDIT_DAYS      = 1095; // 3 years

    public static function init(): void
    {
        add_action('init', [self::class, 'schedule'], 50);
        add_action(self::HOOK, [self::class, 'run']);
    }

    public static function schedule(): void
    {
        if (false === wp_next_scheduled(self::HOOK)) {
            wp_schedule_event(time() + HOUR_IN_SECONDS, 'daily', self::HOOK, [], true);
        }
    }

    /** @return array<string,int|string> */
    public static function run(bool $dryRun = false): array
    {
        $unreviewed = self::idsOlderThan(
            ['qt_story', 'qt_journal', 'qt_response', 'qt_journal_comment'],
            ['pending'],
            self::UNREVIEWED_DAYS
        );
        $inactive = self::inactiveIdsOlderThan(self::DECLINED_DAYS);
        $contacts = self::idsOlderThan(['qt_contact_message'], ['private'], 180);
        $ids = array_values(array_unique(array_merge($unreviewed, $inactive, $contacts)));
        $deleted = 0;

        if (!$dryRun) {
            foreach ($ids as $id) {
                if (wp_delete_post((int) $id, true)) {
                    $deleted++;
                }
            }
        }
        $auditDeleted = (!$dryRun && class_exists(Audit::class))
            ? Audit::purgeOlderThanDays(self::AUDIT_DAYS)
            : 0;
        $result = [
            'checked_at_gmt' => current_time('mysql', true),
            'candidates'     => count($ids),
            'deleted'        => $deleted,
            'audit_deleted'  => $auditDeleted,
            'dry_run'        => $dryRun ? 1 : 0,
        ];
        if (!$dryRun) {
            update_option('qt_retention_last_run', $result, false);
            if (class_exists(Audit::class)) {
                Audit::record('retention_completed', 0, 'scheduled', [
                    'deleted' => $deleted,
                    'audit_deleted' => $auditDeleted,
                ]);
            }
        }
        return $result;
    }

    /** @return list<int> */
    private static function idsOlderThan(array $types, array $statuses, int $days): array
    {
        $q = new \WP_Query([
            'post_type'      => $types,
            'post_status'    => $statuses,
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'date_query'     => [[
                'column'    => 'post_date_gmt',
                'before'    => gmdate('Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS),
                'inclusive' => true,
            ]],
        ]);
        return array_map('intval', (array) $q->posts);
    }

    /** @return list<int> */
    private static function inactiveIdsOlderThan(int $days): array
    {
        $q = new \WP_Query([
            'post_type'      => ['qt_story', 'qt_journal'],
            'post_status'    => [StoryLifecycle::DECLINED, StoryLifecycle::WITHDRAWN],
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'meta_query'     => [[
                'key'     => StoryLifecycle::AT_META,
                'value'   => gmdate('Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS),
                'compare' => '<=',
                'type'    => 'DATETIME',
            ]],
        ]);
        return array_map('intval', (array) $q->posts);
    }
}
