<?php
/**
 * Quiet Truths — Contact
 *
 * A quiet, theme-native contact form. No plugin. Name and email are
 * required for a reply; the message is delivered to the configured
 * mailbox and retained according to the published Privacy Notice. It is
 * never added to a marketing list.
 *
 * Guards match the house: honeypot, nonce, validation and rate limit.
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Contact
{
    private const NONCE = 'qt_contact';

    /** @var string[] */
    private static array $errors = [];

    /** @var array<string,string> */
    private static array $old = [];

    public static function init(): void
    {
        add_action('init', [self::class, 'registerPostType'], 6);
        add_action('add_meta_boxes_qt_contact_message', [self::class, 'addDetailsBox']);
        add_action('template_redirect', [self::class, 'maybeHandle']);
    }

    public static function registerPostType(): void
    {
        register_post_type('qt_contact_message', [
            'labels' => [
                'name' => __('Contact Messages', 'quiet-truths'),
                'singular_name' => __('Contact Message', 'quiet-truths'),
                'menu_name' => __('Contact Messages', 'quiet-truths'),
            ],
            'public' => false, 'publicly_queryable' => false,
            'exclude_from_search' => true, 'show_ui' => true,
            'show_in_menu' => 'tools.php', 'show_in_rest' => false,
            'supports' => ['editor'], 'rewrite' => false,
            'capability_type' => ['qt_contact_message', 'qt_contact_messages'],
            'map_meta_cap' => true,
        ]);
    }

    public static function addDetailsBox(\WP_Post $post): void
    {
        if (!current_user_can('edit_post', $post->ID)) return;
        add_meta_box('qt_contact_details', __('Private contact details', 'quiet-truths'), static function (\WP_Post $message): void {
            $name = (string) get_post_meta($message->ID, '_qt_contact_name', true);
            $email = (string) get_post_meta($message->ID, '_qt_contact_email', true);
            $phone = (string) get_post_meta($message->ID, '_qt_contact_phone', true);
            $subject = (string) get_post_meta($message->ID, '_qt_contact_subject', true);
            echo '<p><strong>' . esc_html__('Name:', 'quiet-truths') . '</strong> ' . esc_html($name) . '</p>';
            echo '<p><strong>' . esc_html__('Email:', 'quiet-truths') . '</strong> <a href="mailto:' . esc_attr($email) . '">' . esc_html($email) . '</a></p>';
            if ('' !== $phone) echo '<p><strong>' . esc_html__('Phone:', 'quiet-truths') . '</strong> ' . esc_html($phone) . '</p>';
            if ('' !== $subject) echo '<p><strong>' . esc_html__('Subject:', 'quiet-truths') . '</strong> ' . esc_html($subject) . '</p>';
            echo '<p class="description">' . esc_html__('Private. Automatically deleted after six months unless a lawful complaint or claim requires a separately governed record.', 'quiet-truths') . '</p>';
        }, 'qt_contact_message', 'side', 'high');
    }

    /* ─────────────── view state ─────────────── */

    /** @return string[] */
    public static function errors(): array
    {
        return self::$errors;
    }

    public static function old(string $key, string $default = ''): string
    {
        return self::$old[$key] ?? $default;
    }

    public static function sent(): bool
    {
        return isset($_GET['qt_contact_sent']);
    }

    /* ─────────────── handling ─────────────── */

    public static function maybeHandle(): void
    {
        if (is_admin() || (defined('REST_REQUEST') && REST_REQUEST)) {
            return;
        }
        if (empty($_POST['qt_contact_submit']) || !isset($_POST['_wpnonce'])) {
            return;
        }

        $back = is_singular()
            ? (get_permalink(get_queried_object_id()) ?: home_url('/write-to-quiet-truths/'))
            : home_url('/write-to-quiet-truths/');
        $back = remove_query_arg(['qt_contact_sent', Flash::QUERY_ARG], $back);

        if (!wp_verify_nonce(sanitize_key(wp_unslash((string) $_POST['_wpnonce'])), self::NONCE)) {
            self::$errors[] = 'session';
            self::redirect($back);
        }

        // Honeypot: bots fill this hidden field.
        if (!empty($_POST['qt_website'])) {
            wp_safe_redirect(add_query_arg('qt_contact_sent', '1', $back));
            exit;
        }

        // Gentle rate limit: a handful of messages per visitor per hour.
        // Incremented BEFORE validation so that garbage submissions
        // cannot hammer wp_mail() indefinitely.
        $key   = Security::rateKey('qt_contact_rate_');
        $count = (int) get_transient($key);
        if ($count >= (int) apply_filters('quiet_truths_contact_rate_limit', 3)) {
            self::$errors[] = 'rate';
            self::redirect($back);
        }
        set_transient($key, $count + 1, HOUR_IN_SECONDS);

        // Contact is the house's front desk — it needs a reply address.
        // Always detailed: name + email required, phone optional.
        $name    = isset($_POST['qt_name']) ? sanitize_text_field(wp_unslash((string) $_POST['qt_name'])) : '';
        $email   = isset($_POST['qt_email']) ? sanitize_email(wp_unslash((string) $_POST['qt_email'])) : '';
        $subject = isset($_POST['qt_subject']) ? sanitize_text_field(wp_unslash((string) $_POST['qt_subject'])) : '';
        $phone   = isset($_POST['qt_phone']) ? sanitize_text_field(wp_unslash((string) $_POST['qt_phone'])) : '';

        self::$old = [
            'name'    => $name,
            'email'   => $email,
            'subject' => $subject,
            'phone'   => $phone,
        ];

        if ('' === trim($name)) {
            self::$errors[] = 'name_req';
        }
        if ('' === $email || !is_email($email)) {
            self::$errors[] = 'email_req';
        }
        if ('' !== $phone && !preg_match('/^[0-9+()\-\s]{6,20}$/', $phone)) {
            self::$errors[] = 'phone';
        }
        if ('' !== $name && mb_strlen($name, 'UTF-8') > 100) {
            self::$errors[] = 'name';
        }
        if ('' !== $email && mb_strlen($email, 'UTF-8') > 100) {
            self::$errors[] = 'email';
        }
        if ('' !== $subject && mb_strlen($subject, 'UTF-8') > 150) {
            self::$errors[] = 'subject';
        }
        if ('' !== $phone && mb_strlen($phone, 'UTF-8') > 20) {
            self::$errors[] = 'phone';
        }

        $message = isset($_POST['qt_message']) ? sanitize_textarea_field(wp_unslash((string) $_POST['qt_message'])) : '';
        self::$old['message'] = $message;

        if ('' === trim($message)) {
            self::$errors[] = 'empty';
        }
        if (mb_strlen($message, 'UTF-8') > 2000) {
            self::$errors[] = 'long';
        }

        // Do not reject safety reports or complaints because they quote
        // difficult language. Contact messages are delivered as plain text.
        if (!empty(self::$errors)) {
            self::redirect($back);
        }

        // Store in a private, retention-controlled record. Email receives
        // only a content ID and protected admin URL, never the message or
        // contact details, so mailbox retention cannot silently become the
        // primary personal-data store.
        $messageId = wp_insert_post([
            'post_type' => 'qt_contact_message',
            'post_status' => 'private',
            'post_title' => sprintf(__('Contact message received %s', 'quiet-truths'), current_time('mysql')),
            'post_content' => $message,
            'post_author' => 0,
        ], true);
        if (is_wp_error($messageId)) {
            error_log('Quiet Truths: contact message storage failed.');
            self::$errors[] = 'store';
            self::redirect($back);
        }
        update_post_meta($messageId, '_qt_contact_name', $name);
        update_post_meta($messageId, '_qt_contact_email', $email);
        update_post_meta($messageId, '_qt_contact_phone', $phone);
        update_post_meta($messageId, '_qt_contact_subject', $subject);
        update_post_meta($messageId, '_qt_contact_received_gmt', current_time('mysql', true));
        if (class_exists(Audit::class)) Audit::record('contact_received', (int) $messageId, 'contact_form');

        $to = get_option('admin_email');
        $mailSubject = sprintf('[%s] %s', get_bloginfo('name'), __('A private contact message is waiting', 'quiet-truths'));
        $body = sprintf(
            __("Private contact message ID: %1\$d\n\nFor privacy, its words and contact details are not copied into email.\n\nOpen it in the protected dashboard:\n%2\$s", 'quiet-truths'),
            $messageId,
            admin_url('post.php?post=' . $messageId . '&action=edit')
        );
        if (!wp_mail($to, $mailSubject, $body, ['Content-Type: text/plain; charset=UTF-8'])) {
            error_log('Quiet Truths: contact notification could not be sent; message remains in the protected dashboard.');
        }

        self::$old = [];
        wp_safe_redirect(add_query_arg('qt_contact_sent', '1', $back));
        exit;
    }

    private static function redirect(string $back): void
    {
        $url = Flash::url($back, 'contact', [
            'errors' => self::$errors,
            'old'    => self::$old,
        ]);

        wp_safe_redirect($url);
        exit;
    }
}
