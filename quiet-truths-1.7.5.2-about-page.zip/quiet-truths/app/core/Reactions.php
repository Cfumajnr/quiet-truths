<?php
/**
 * Quiet Truths — Silent Reader Reactions
 *
 * A quiet way for readers who do not want to write to still be heard.
 * One gentle click on a feeling — no words, no accounts, no moderation
 * queue. Unlike Responses (which are written and held), a reaction is a
 * simple count: it cannot contain abuse, so it appears immediately and
 * needs no approval.
 *
 *  - a curated, filterable set of feeling buttons (Wow, That is painful…)
 *  - one reaction per visitor per story (tracked by a cookie + rate limit)
 *  - counts stored as post meta `_qt_reactions` (kind => count)
 *  - anonymous, private, non-identifying
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Reactions
{
    private const NONCE_REACT = 'qt_react_story_';
    private const COOKIE      = 'qt_reactions';

    public static function init(): void
    {
        add_action('template_redirect', [self::class, 'maybeHandleReact']);
        add_action('wp_ajax_qt_react', [self::class, 'handleReactAjax']);
        add_action('wp_ajax_nopriv_qt_react', [self::class, 'handleReactAjax']);
        // Show total reaction count on the story admin list for the house.
        add_filter('manage_qt_story_posts_columns', [self::class, 'adminColumns']);
        add_action('manage_qt_story_posts_custom_column', [self::class, 'adminColumnValue'], 10, 2);
    }

    /**
     * The curated set of reader reactions. Filterable so the house can
     * tune them without code changes. Human sentences, not social-media
     * reaction terminology.
     *
     * @return array<string,string> slug => label
     */
    public static function reactions(): array
    {
        return (array) apply_filters('quiet_truths_reactions', [
            'moved'      => __('This moved me', 'quiet-truths'),
            'painful'    => __('That is painful', 'quiet-truths'),
            'seen'       => __('I felt seen', 'quiet-truths'),
            'hope'       => __('It gave me hope', 'quiet-truths'),
            'understand' => __('I understand this', 'quiet-truths'),
            'thanks'     => __('Thank you', 'quiet-truths'),
        ]);
    }

    /**
     * A gentle emoji for each reaction. Keyed by the same slug as
     * reactions(). Filterable alongside the labels. The emoji stays
     * visually hidden until the reader interacts with the phrase.
     *
     * @return array<string,string> slug => emoji
     */
    public static function emojis(): array
    {
        return (array) apply_filters('quiet_truths_reaction_emojis', [
            'moved'      => '🫂',
            'painful'    => '💔',
            'seen'       => '🫶',
            'hope'       => '🌤',
            'understand' => '🤝',
            'thanks'     => '🙏',
        ]);
    }

    /**
     * Nonce for a story's reaction form / AJAX request.
     */
    public static function nonce(int $storyId): string
    {
        return wp_create_nonce(self::NONCE_REACT . $storyId);
    }

    /**
     * Counts for a story, keyed by reaction slug.
     *
     * @return array<string,int>
     */
    public static function counts(int $storyId): array
    {
        $raw = get_post_meta($storyId, '_qt_reactions', true);
        $raw = is_array($raw) ? $raw : [];

        $out = [];
        foreach (self::reactions() as $slug => $label) {
            $out[$slug] = (int) ($raw[$slug] ?? 0);
        }

        return $out;
    }

    /**
     * Has this visitor already reacted to this story (from their cookie)?
     */
    public static function hasReacted(int $storyId): bool
    {
        $data = self::cookie();
        return isset($data[$storyId]);
    }

    /**
     * Which reaction slug this visitor chose for this story, if any.
     */
    public static function myReaction(int $storyId): string
    {
        $data = self::cookie();

        return isset($data[$storyId]) ? (string) $data[$storyId] : '';
    }

    /* ─────────────── handling ─────────────── */

    public static function maybeHandleReact(): void
    {
        if (!is_singular('qt_story')) {
            return;
        }
        if (empty($_POST['qt_react_action']) || 'react' !== $_POST['qt_react_action']) {
            return;
        }

        $storyId = get_queried_object_id();
        $back    = get_permalink($storyId) . '#qt-reactions';

        if (!isset($_POST['_wpnonce'])
            || !wp_verify_nonce(sanitize_key(wp_unslash((string) $_POST['_wpnonce'])), self::NONCE_REACT . $storyId)) {
            self::redirect($back);
        }

        if ('publish' !== get_post_status($storyId)) {
            self::redirect($back);
        }

        $slug = isset($_POST['qt_react']) ? sanitize_key(wp_unslash((string) $_POST['qt_react'])) : '';
        if (!array_key_exists($slug, self::reactions())) {
            self::redirect($back);
        }

        // One reaction per visitor per story.
        if (self::hasReacted($storyId)) {
            self::redirect($back);
        }

        if (!self::passesRateLimit()) {
            self::redirect($back);
        }

        $counts = self::counts($storyId);
        $counts[$slug]++;
        update_post_meta($storyId, '_qt_reactions', $counts);

        self::remember($storyId, $slug);

        self::redirect($back);
    }

    /**
     * AJAX handler for the gentle, no-reload reaction reveal. Returns the
     * reaction outcome as JSON so the page can reveal the emoji softly
     * without navigating away. Falls back to the server-side cookie guard
     * exactly like the non-JS POST path.
     */
    public static function handleReactAjax(): void
    {
        check_ajax_referer('qt_react_story_' . absint($_POST['story_id'] ?? 0), '_wpnonce');

        $storyId = absint($_POST['story_id'] ?? 0);
        $slug    = sanitize_key(wp_unslash((string) ($_POST['qt_react'] ?? '')));
        $post    = $storyId ? get_post($storyId) : null;

        if (!$post || 'qt_story' !== $post->post_type || 'publish' !== $post->post_status) {
            wp_send_json_error(['message' => 'invalid'], 400);
        }
        if (!array_key_exists($slug, self::reactions())) {
            wp_send_json_error(['message' => 'invalid'], 400);
        }
        if (self::hasReacted($storyId)) {
            wp_send_json_success(['already' => true, 'counts' => self::counts($storyId)]);
        }
        if (!self::passesRateLimit()) {
            wp_send_json_error(['message' => 'rate'], 429);
        }

        $counts = self::counts($storyId);
        $counts[$slug]++;
        update_post_meta($storyId, '_qt_reactions', $counts);

        self::remember($storyId, $slug);

        wp_send_json_success([
            'already' => false,
            'mine'    => $slug,
            'counts'  => $counts,
        ]);
    }

    /* ─────────────── helpers ─────────────── */

    private static function redirect(string $back): void
    {
        wp_safe_redirect($back);
        exit;
    }

    /**
     * A modest per-visitor cap so a single visitor cannot flood the
     * counts. The hard guard against reacting to everything at once is
     * the per-story cookie (one reaction per visitor per story) enforced
     * in maybeHandleReact() — this IP-level cap is only a secondary
     * backstop against automation.
     */
    private static function passesRateLimit(): bool
    {
        $key   = Security::rateKey('qt_react_rate_');
        $limit = (int) apply_filters('quiet_truths_reaction_rate_limit', 10);

        $count = (int) get_transient($key);

        if ($count >= $limit) {
            return false;
        }

        set_transient($key, $count + 1, HOUR_IN_SECONDS);

        return true;
    }

    /** @return array<int,string> */
    private static function cookie(): array
    {
        if (empty($_COOKIE[self::COOKIE])) {
            return [];
        }

        $data = json_decode(stripslashes((string) $_COOKIE[self::COOKIE]), true);

        return is_array($data) ? $data : [];
    }

    private static function remember(int $storyId, string $slug): void
    {
        $data = self::cookie();
        $data[$storyId] = $slug;
        $data = array_slice($data, -50, 50, true);

        if (PHP_VERSION_ID >= 70300) {
            setcookie(self::COOKIE, wp_json_encode($data), [
                'expires'  => time() + 60 * DAY_IN_SECONDS,
                'path'     => (string) COOKIEPATH,
                'domain'   => (string) (COOKIE_DOMAIN ?: ''),
                'secure'   => 'https' === wp_parse_url(home_url('/'), PHP_URL_SCHEME),
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        } else {
            setcookie(
                self::COOKIE,
                wp_json_encode($data),
                time() + 60 * DAY_IN_SECONDS,
                COOKIEPATH . '; SameSite=Lax',
                (string) (COOKIE_DOMAIN ?: ''),
                'https' === wp_parse_url(home_url('/'), PHP_URL_SCHEME),
                true
            );
        }
    }

    /* ─────────────── admin ─────────────── */

    /** @param array<string,string> $columns */
    public static function adminColumns(array $columns): array
    {
        $columns['qt_reactions'] = __('Feelings', 'quiet-truths');

        return $columns;
    }

    public static function adminColumnValue(string $column, int $postId): void
    {
        if ('qt_reactions' !== $column) {
            return;
        }

        $counts = self::counts($postId);
        $total  = array_sum($counts);

        if ($total < 1) {
            echo '<span class="qt-muted">—</span>';

            return;
        }

        // A compact, kind summary: "wow 12 · painful 7".
        $parts = [];
        foreach ($counts as $slug => $n) {
            if ($n > 0) {
                $parts[] = esc_html($slug) . ' ' . (int) $n;
            }
        }

        echo implode(' · ', $parts);
    }
}
