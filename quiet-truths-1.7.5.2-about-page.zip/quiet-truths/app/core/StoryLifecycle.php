<?php
/**
 * Quiet Truths — first-class decline, withdrawal, restore and deletion.
 */
namespace QuietTruths\Core;

use QuietTruths\Ai\ProfileLifecycle;

if (!defined('ABSPATH')) { exit; }

final class StoryLifecycle
{
    public const DECLINED  = 'qt_declined';
    public const WITHDRAWN = 'qt_withdrawn';
    public const AT_META   = '_qt_lifecycle_at_gmt';
    public const WHY_META  = '_qt_lifecycle_reason';

    public static function init(): void
    {
        add_action('init', [self::class, 'registerStatuses'], 4);
        add_filter('post_row_actions', [self::class, 'rowActions'], 20, 2);
        add_action('admin_post_qt_decline_content', [self::class, 'decline']);
        add_action('admin_post_qt_withdraw_content', [self::class, 'withdraw']);
        add_action('admin_post_qt_restore_content', [self::class, 'restore']);
        add_action('transition_post_status', [self::class, 'auditTransition'], 40, 3);
        add_action('before_delete_post', [self::class, 'beforeDelete'], 40, 2);
    }

    public static function registerStatuses(): void
    {
        register_post_status(self::DECLINED, [
            'label' => _x('Declined', 'post status', 'quiet-truths'),
            'public' => false, 'internal' => false, 'protected' => true,
            'exclude_from_search' => true, 'show_in_admin_all_list' => true,
            'show_in_admin_status_list' => true,
            'label_count' => _n_noop('Declined <span class="count">(%s)</span>', 'Declined <span class="count">(%s)</span>', 'quiet-truths'),
        ]);
        register_post_status(self::WITHDRAWN, [
            'label' => _x('Withdrawn', 'post status', 'quiet-truths'),
            'public' => false, 'internal' => false, 'protected' => true,
            'exclude_from_search' => true, 'show_in_admin_all_list' => true,
            'show_in_admin_status_list' => true,
            'label_count' => _n_noop('Withdrawn <span class="count">(%s)</span>', 'Withdrawn <span class="count">(%s)</span>', 'quiet-truths'),
        ]);
    }

    /** @param array<string,string> $actions */
    public static function rowActions(array $actions, \WP_Post $post): array
    {
        if (!in_array($post->post_type, ['qt_story', 'qt_journal'], true)
            || !current_user_can('manage_qt_lifecycle')) {
            return $actions;
        }
        if ('pending' === $post->post_status) {
            $actions['qt_decline'] = self::actionLink('qt_decline_content', $post, __('Decline', 'quiet-truths'));
        } elseif ('publish' === $post->post_status) {
            $actions['qt_withdraw'] = self::actionLink('qt_withdraw_content', $post, __('Withdraw', 'quiet-truths'));
        } elseif (in_array($post->post_status, [self::DECLINED, self::WITHDRAWN], true)) {
            $actions['qt_restore'] = self::actionLink('qt_restore_content', $post, __('Restore to review', 'quiet-truths'));
        }
        return $actions;
    }

    private static function actionLink(string $action, \WP_Post $post, string $label): string
    {
        $url = wp_nonce_url(
            admin_url('admin-post.php?action=' . $action . '&post_id=' . $post->ID),
            $action . '_' . $post->ID
        );
        return '<a href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
    }

    public static function decline(): void { self::change(self::DECLINED, 'declined'); }
    public static function withdraw(): void { self::change(self::WITHDRAWN, 'withdrawn'); }
    public static function restore(): void { self::change('pending', 'restored'); }

    private static function change(string $status, string $event): void
    {
        $postId = absint($_GET['post_id'] ?? 0);
        if (!$postId || !current_user_can('manage_qt_lifecycle')
            || !current_user_can('edit_post', $postId)) {
            wp_die(esc_html__('You are not allowed to change this content lifecycle.', 'quiet-truths'));
        }
        $nonceAction = match ($status) {
            self::DECLINED  => 'qt_decline_content',
            self::WITHDRAWN => 'qt_withdraw_content',
            default         => 'qt_restore_content',
        };
        check_admin_referer($nonceAction . '_' . $postId);
        $post = get_post($postId);
        if (!$post instanceof \WP_Post || !in_array($post->post_type, ['qt_story', 'qt_journal'], true)) {
            wp_die(esc_html__('That content cannot use this lifecycle action.', 'quiet-truths'));
        }

        if ('pending' === $status) {
            delete_post_meta($postId, self::AT_META);
            delete_post_meta($postId, self::WHY_META);
        } else {
            update_post_meta($postId, self::AT_META, current_time('mysql', true));
            update_post_meta($postId, self::WHY_META, $event);
        }
        wp_update_post(['ID' => $postId, 'post_status' => $status]);
        self::purgePublicCaches($postId);

        $url = admin_url('edit.php?post_type=' . $post->post_type);
        wp_safe_redirect($url);
        exit;
    }

    public static function auditTransition(string $new, string $old, \WP_Post $post): void
    {
        if ($new === $old || !in_array($post->post_type, ['qt_story', 'qt_journal'], true)) {
            return;
        }
        if (in_array($new, [self::DECLINED, self::WITHDRAWN], true)
            && '' === (string) get_post_meta($post->ID, self::AT_META, true)) {
            update_post_meta($post->ID, self::AT_META, current_time('mysql', true));
            update_post_meta($post->ID, self::WHY_META, $new);
        } elseif (in_array($new, ['pending','publish'], true)) {
            delete_post_meta($post->ID, self::AT_META);
            delete_post_meta($post->ID, self::WHY_META);
        }
        if (in_array($new, [self::DECLINED, self::WITHDRAWN], true) && class_exists(Tombstones::class)) {
            Tombstones::append($post->ID, self::DECLINED === $new ? 'declined' : 'withdrawn');
        }
        if (class_exists(Audit::class)) {
            Audit::record('content_status_changed', $post->ID, $old . '_to_' . $new, [
                'post_type' => $post->post_type,
            ]);
        }
    }

    public static function beforeDelete(int $postId, \WP_Post $post): void
    {
        if (!in_array($post->post_type, ['qt_story', 'qt_journal'], true)) {
            return;
        }
        if (class_exists(Tombstones::class)) {
            Tombstones::append($postId, 'deleted');
        }
        // Associated private conversation content has no independent
        // purpose once its parent is permanently deleted.
        $childType = 'qt_story' === $post->post_type ? 'qt_response' : 'qt_journal_comment';
        $metaKey   = 'qt_story' === $post->post_type ? '_qt_story_id' : '_qt_journal_id';
        $children  = get_posts([
            'post_type' => $childType, 'post_status' => 'any',
            'posts_per_page' => -1, 'fields' => 'ids', 'no_found_rows' => true,
            'meta_query' => [['key' => $metaKey, 'value' => $postId, 'compare' => '=']],
        ]);
        foreach ($children as $childId) {
            wp_delete_post((int) $childId, true);
        }
        if (class_exists(Audit::class)) {
            Audit::record('content_deleted', $postId, 'permanent_delete', [
                'post_type' => $post->post_type,
                'children_deleted' => count($children),
            ]);
        }
    }

    private static function purgePublicCaches(int $postId): void
    {
        clean_post_cache($postId);
        do_action('litespeed_purge_post', $postId);
        do_action('litespeed_purge_all');
    }
}
