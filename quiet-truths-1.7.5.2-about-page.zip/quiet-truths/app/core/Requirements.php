<?php
/**
 * Quiet Truths — mandatory runtime dependency gate.
 *
 * Loaded before the application. It deliberately uses no mb_* functions so
 * an administrator can still reach WP Admin and Site Health when mbstring is
 * missing, while public/application processing fails closed with HTTP 503.
 *
 * @package QuietTruths\Core
 */
namespace QuietTruths\Core;

if (!defined('ABSPATH')) { exit; }

final class Requirements
{
    /** @return list<string> */
    public static function missing(): array
    {
        $missing = [];
        if (!extension_loaded('mbstring')) {
            $missing[] = 'mbstring extension';
        }
        foreach (['mb_strlen','mb_substr','mb_strtolower','mb_strpos','mb_strimwidth'] as $function) {
            if (!function_exists($function)) $missing[] = $function . '()';
        }
        return array_values(array_unique($missing));
    }

    public static function satisfied(): bool
    {
        return [] === self::missing();
    }

    /** Register the fail-closed diagnostics; returns whether boot may continue. */
    public static function enforce(): bool
    {
        add_filter('site_status_tests', [self::class, 'siteHealthTests']);
        if (self::satisfied()) return true;

        add_action('admin_notices', [self::class, 'adminNotice']);
        add_action('template_redirect', [self::class, 'blockPublicRequest'], -1000);
        add_filter('rest_authentication_errors', [self::class, 'blockRestRequest'], -1000);

        if (defined('WP_CLI') && WP_CLI && class_exists('WP_CLI')) {
            \WP_CLI::error('Quiet Truths requires the PHP mbstring extension. Enable/install mbstring before running the application.');
        }
        error_log('Quiet Truths boot refused: missing mandatory PHP dependency — ' . implode(', ', self::missing()));
        return false;
    }

    public static function adminNotice(): void
    {
        if (!current_user_can('manage_options')) return;
        echo '<div class="notice notice-error"><p><strong>'
            . esc_html__('Quiet Truths is not running: PHP mbstring is mandatory.', 'quiet-truths')
            . '</strong> ' . esc_html__('Ask the host to enable the mbstring extension, then reload this page. Missing:', 'quiet-truths')
            . ' <code>' . esc_html(implode(', ', self::missing())) . '</code></p></div>';
    }

    public static function blockPublicRequest(): void
    {
        if (is_admin()) return;
        status_header(503);
        nocache_headers();
        wp_die(
            esc_html__('Quiet Truths is temporarily unavailable while a required server component is restored.', 'quiet-truths'),
            esc_html__('Service temporarily unavailable', 'quiet-truths'),
            ['response' => 503]
        );
    }

    public static function blockRestRequest($result)
    {
        if (self::satisfied() || is_user_logged_in()) return $result;
        return new \WP_Error(
            'quiet_truths_requirements_missing',
            __('Service temporarily unavailable.', 'quiet-truths'),
            ['status' => 503]
        );
    }

    /** @param array<string,mixed> $tests */
    public static function siteHealthTests(array $tests): array
    {
        $tests['direct']['quiet_truths_mbstring'] = [
            'label' => __('Quiet Truths mbstring dependency', 'quiet-truths'),
            'test'  => [self::class, 'siteHealthResult'],
        ];
        return $tests;
    }

    /** @return array<string,mixed> */
    public static function siteHealthResult(): array
    {
        $ok = self::satisfied();
        return [
            'label' => $ok
                ? __('PHP mbstring is available', 'quiet-truths')
                : __('PHP mbstring is missing', 'quiet-truths'),
            'status' => $ok ? 'good' : 'critical',
            'badge' => ['label' => 'Quiet Truths', 'color' => $ok ? 'blue' : 'red'],
            'description' => '<p>' . esc_html($ok
                ? __('Unicode-aware Story, search, privacy and AI processing is available.', 'quiet-truths')
                : __('Quiet Truths refuses to process Stories without the mandatory Unicode-safe mbstring extension.', 'quiet-truths')) . '</p>',
            'actions' => '',
            'test' => 'quiet_truths_mbstring',
        ];
    }
}
