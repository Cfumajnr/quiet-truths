<?php
/**
 * Quiet Truths — About page
 *
 * The About page contains public promises about anonymity, moderation,
 * AI and forgetting. Those promises are release-managed rather than left
 * as an old editable page that can drift away from the application and
 * governance documents.
 *
 * On boot this class reuses the canonical /about/ page, synchronises the
 * version-controlled copy in app/pages/content/about.html, removes the
 * WordPress author association, and keeps the page public. The dedicated
 * page-about.php template provides the presentation; this class provides
 * only canonical content and state-aware closing links.
 *
 * @package QuietTruths\Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class About
{
    public const CONTENT_VERSION = '1.0.0';

    private const META_MANAGED = '_qt_about_page';
    private const META_VERSION = '_qt_about_content_version';
    private const META_SOURCE_HASH = '_qt_about_source_hash';
    private const META_STORED_HASH = '_qt_about_stored_hash';
    private const OPTION_SYNCED = 'qt_about_content_synced';

    private static bool $syncing = false;

    private const META_DESCRIPTION = 'Quiet Truths is an independent human archive in Nairobi for anonymous Stories and signed Journals, held with human care, privacy and local-only AI.';

    public static function init(): void
    {
        add_action('init', [self::class, 'ensurePage'], 31);
        add_action('save_post_page', [self::class, 'invalidateOnSave'], 100, 3);
        add_action('before_delete_post', [self::class, 'invalidateOnDelete'], 10, 2);
        add_action('wp_trash_post', [self::class, 'invalidateOnTrash'], 10, 1);
        add_action('untrashed_post', [self::class, 'invalidateOnTrash'], 10, 1);
        add_filter('display_post_states', [self::class, 'postState'], 10, 2);
        add_action('admin_notices', [self::class, 'editorNotice']);
    }

    /**
     * Create or reconcile the one canonical About page.
     *
     * The comparison prevents a write on ordinary requests. If an editor
     * changes a public promise in WordPress, the next request restores the
     * reviewed release copy instead of allowing silent policy drift.
     */
    public static function ensurePage(): void
    {
        if (self::$syncing || self::CONTENT_VERSION === (string) get_option(self::OPTION_SYNCED, '')) {
            return;
        }

        $content = self::canonicalContent();
        if ('' === $content) {
            error_log('Quiet Truths: canonical About content is missing or contains an unresolved token.');
            return;
        }

        $page = get_page_by_path('about', OBJECT, 'page');
        if (!$page instanceof \WP_Post) {
            $managed = get_posts([
                'post_type'      => 'page',
                'post_status'    => ['publish', 'draft', 'private', 'pending', 'future', 'trash'],
                'posts_per_page' => 1,
                'orderby'        => 'ID',
                'order'          => 'ASC',
                'meta_key'       => self::META_MANAGED,
                'meta_value'     => '1',
                'no_found_rows'  => true,
            ]);
            $page = !empty($managed) && $managed[0] instanceof \WP_Post ? $managed[0] : null;
        }

        $postarr = [
            'post_title'     => __('About Quiet Truths', 'quiet-truths'),
            'post_name'      => 'about',
            'post_content'   => $content,
            'post_excerpt'   => self::META_DESCRIPTION,
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'post_parent'    => 0,
            'menu_order'     => 20,
            'post_author'    => 0,
            'comment_status' => 'closed',
            'ping_status'    => 'closed',
        ];

        $sourceHash = hash('sha256', $content);
        $needsWrite = !($page instanceof \WP_Post);
        if ($page instanceof \WP_Post) {
            $postarr['ID'] = $page->ID;
            $recordedSource = (string) get_post_meta($page->ID, self::META_SOURCE_HASH, true);
            $recordedStored = (string) get_post_meta($page->ID, self::META_STORED_HASH, true);
            $currentStored  = hash('sha256', (string) $page->post_content);
            $needsWrite = self::pageDiffers($page, $postarr)
                || self::CONTENT_VERSION !== (string) get_post_meta($page->ID, self::META_VERSION, true)
                || $sourceHash !== $recordedSource
                || $currentStored !== $recordedStored;
        }

        self::$syncing = true;
        try {
            if ($needsWrite) {
                $result = isset($postarr['ID'])
                    ? wp_update_post($postarr, true)
                    : wp_insert_post($postarr, true);
            } else {
                $result = $page->ID;
            }
        } finally {
            self::$syncing = false;
        }

        if (is_wp_error($result) || (int) $result < 1) {
            $message = is_wp_error($result) ? $result->get_error_message() : 'unknown write failure';
            error_log('Quiet Truths: About page could not be synchronised: ' . $message);
            return;
        }

        $pageId = (int) $result;
        $savedPage = get_post($pageId);
        $storedHash = $savedPage instanceof \WP_Post
            ? hash('sha256', (string) $savedPage->post_content)
            : hash('sha256', $content);

        update_post_meta($pageId, self::META_MANAGED, '1');
        update_post_meta($pageId, self::META_VERSION, self::CONTENT_VERSION);
        update_post_meta($pageId, self::META_SOURCE_HASH, $sourceHash);
        update_post_meta($pageId, self::META_STORED_HASH, $storedHash);
        update_post_meta($pageId, '_qt_meta_description', self::META_DESCRIPTION);
        update_post_meta($pageId, '_wp_page_template', 'page-about.php');
        update_option(self::OPTION_SYNCED, self::CONTENT_VERSION, false);
    }

    /**
     * Return the reviewed HTML after replacing only internal site URLs.
     */
    public static function canonicalContent(): string
    {
        $path = dirname(__DIR__) . '/pages/content/about.html';
        if (!is_file($path)) {
            return '';
        }

        $content = (string) file_get_contents($path);
        $replace = [
            '{{stories_url}}'             => esc_url(home_url('/stories/')),
            '{{leave_story_url}}'         => esc_url(home_url('/leave-a-story/')),
            '{{contact_url}}'             => esc_url(home_url('/write-to-quiet-truths/')),
            '{{woman_went_back_url}}'     => esc_url(home_url('/story/the-woman-who-went-back/')),
            '{{room_beginnings_url}}'     => esc_url(home_url('/room/beginnings/')),
            '{{room_heavy_hearts_url}}'   => esc_url(home_url('/room/heavy-hearts/')),
            '{{room_crossroads_url}}'     => esc_url(home_url('/room/crossroads/')),
            '{{room_homecoming_url}}'     => esc_url(home_url('/room/homecoming/')),
            '{{room_mending_url}}'        => esc_url(home_url('/room/mending/')),
            '{{room_letters_url}}'        => esc_url(home_url('/room/letters/')),
            '{{room_small_mercies_url}}'  => esc_url(home_url('/room/small-mercies/')),
        ];
        $content = strtr($content, $replace);

        if (preg_match('/\{\{[^}]+\}\}/', $content)) {
            return '';
        }

        return trim($content);
    }

    /**
     * State-aware end of the page. Governance links appear only when the
     * corresponding reviewed documents are genuinely public; intake is
     * never advertised as open while the application has paused it.
     */
    public static function renderClosing(): string
    {
        $html = self::renderGovernanceLinks();
        $intakeOpen = class_exists(Security::class) && Security::intakeOpen('story');

        $html .= '<section class="qt-about__closing" aria-labelledby="qt-about-begin">'
            . '<p class="qt-about__eyebrow">' . esc_html__('Where to begin', 'quiet-truths') . '</p>'
            . '<h2 id="qt-about-begin">' . esc_html__('Come in slowly.', 'quiet-truths') . '</h2>'
            . '<p>' . esc_html__('Read what has already been left here, or write to the house with a question, correction or concern.', 'quiet-truths') . '</p>'
            . '<div class="qt-about__actions">'
            . '<a class="qt-about__action qt-about__action--primary" href="' . esc_url(home_url('/stories/')) . '">'
            . esc_html__('Read the Stories', 'quiet-truths') . '</a>';

        if ($intakeOpen) {
            $html .= '<a class="qt-about__action" href="' . esc_url(home_url('/leave-a-story/')) . '">'
                . esc_html__('Leave a Story', 'quiet-truths') . '</a>';
        }

        $html .= '<a class="qt-about__action" href="' . esc_url(home_url('/write-to-quiet-truths/')) . '">'
            . esc_html__('Write to Quiet Truths', 'quiet-truths') . '</a>'
            . '</div></section>';

        return $html;
    }

    /** @param array<string,string> $postarr */
    private static function pageDiffers(\WP_Post $page, array $postarr): bool
    {
        // Content drift is checked against the stored/source hashes above.
        // WordPress may normalise trusted HTML during insertion, so comparing
        // the stored value directly with the source file would cause a write
        // on every request on hosts with stricter KSES filters.
        $fields = [
            'post_title', 'post_name', 'post_excerpt', 'post_type',
            'post_status', 'comment_status', 'ping_status',
        ];
        foreach ($fields as $field) {
            if ((string) $page->{$field} !== (string) $postarr[$field]) {
                return true;
            }
        }

        return (int) $page->post_parent !== (int) $postarr['post_parent']
            || (int) $page->menu_order !== (int) $postarr['menu_order']
            || (int) $page->post_author !== (int) $postarr['post_author'];
    }

    private static function renderGovernanceLinks(): string
    {
        if (!class_exists(Governance::class)) {
            return '';
        }

        $wanted = [
            'privacy'             => __('Privacy', 'quiet-truths'),
            'submission-terms'    => __('Submission Terms', 'quiet-truths'),
            'editorial-policy'    => __('Editorial Policy', 'quiet-truths'),
            'safety-crisis-help'  => __('Safety & Crisis Help', 'quiet-truths'),
            'complaints-removals' => __('Complaints & Removals', 'quiet-truths'),
        ];
        $links = [];

        foreach ($wanted as $slug => $label) {
            $page = get_page_by_path($slug, OBJECT, 'page');
            if (!$page instanceof \WP_Post || 'publish' !== $page->post_status) {
                continue;
            }
            $url = get_permalink($page);
            if ($url) {
                $links[] = '<li><a href="' . esc_url($url) . '">' . esc_html($label) . '</a></li>';
            }
        }

        if (empty($links)) {
            return '';
        }

        return '<section class="qt-about__documents" aria-labelledby="qt-about-governance">'
            . '<div class="qt-about__section-grid">'
            . '<div><p class="qt-about__eyebrow">' . esc_html__('The careful details', 'quiet-truths') . '</p></div>'
            . '<div><h2 id="qt-about-governance">' . esc_html__('How the house is governed', 'quiet-truths') . '</h2>'
            . '<p>' . esc_html__('The promises on this page are carried into public documents that set out the exact rules, limits and routes for redress.', 'quiet-truths') . '</p>'
            . '<ul class="qt-about__document-links">' . implode('', $links) . '</ul>'
            . '</div></div></section>';
    }

    /** A WordPress edit invalidates the fast sync marker. */
    public static function invalidateOnSave(int $postId, \WP_Post $post, bool $update): void
    {
        if (self::$syncing || wp_is_post_revision($postId) || wp_is_post_autosave($postId)) {
            return;
        }
        if ('about' === $post->post_name || (bool) get_post_meta($postId, self::META_MANAGED, true)) {
            delete_option(self::OPTION_SYNCED);
        }
    }

    /** @param \WP_Post|mixed $post */
    public static function invalidateOnDelete(int $postId, $post): void
    {
        if ($post instanceof \WP_Post
            && ('about' === $post->post_name || (bool) get_post_meta($postId, self::META_MANAGED, true))) {
            delete_option(self::OPTION_SYNCED);
        }
    }

    public static function invalidateOnTrash(int $postId): void
    {
        $post = get_post($postId);
        if ($post instanceof \WP_Post
            && ('about' === $post->post_name || (bool) get_post_meta($postId, self::META_MANAGED, true))) {
            delete_option(self::OPTION_SYNCED);
        }
    }

    /** @param array<string,string> $states @return array<string,string> */
    public static function postState(array $states, \WP_Post $post): array
    {
        if ('page' === $post->post_type && (bool) get_post_meta($post->ID, self::META_MANAGED, true)) {
            $states['qt_about_managed'] = __('Quiet Truths managed', 'quiet-truths');
        }
        return $states;
    }

    /** Tell an editor why the canonical words return after a manual edit. */
    public static function editorNotice(): void
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        $postId = isset($_GET['post']) ? absint($_GET['post']) : 0;
        if ($postId < 1 || !(bool) get_post_meta($postId, self::META_MANAGED, true)) {
            return;
        }

        echo '<div class="notice notice-info"><p>'
            . esc_html__('The About page is release-managed because it contains public privacy, AI and moderation promises. Edit app/pages/content/about.html and ship a reviewed release rather than changing those promises only in WordPress.', 'quiet-truths')
            . '</p></div>';
    }
}
