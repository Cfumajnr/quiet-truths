<?php
/**
 * Quiet Truths — Rooms Intelligence
 *
 * The house's sense of its seven Rooms. Everything here is computed
 * live from the stories' AI PROFILES (concepts, threads, signals,
 * emotional valence, communication modes) — Layer 2 of the canonical
 * ten-layer AI architecture (v1.7.4 Correction 34). As the house
 * grows, each room's atmosphere shifts honestly with what is actually
 * being held.
 *
 * The principle: profile.concepts and profile.threads carry weighted
 * scores from the semantic layer (prototype 0.30 → concept 0.18 →
 * signal 0.12 → lexical capped 0.40). We aggregate those WEIGHTS
 * rather than counting tag occurrences, so a story the AI is
 * confident is about grief counts more than a story that merely
 * mentions the word.
 *
 * Stories without a FRESH profile yet (pre-v6, pending first build,
 * or lexical fallback) fall back to concepts via conceptsOf() —
 * which reads canonical _qt_concepts first, then the legacy
 * _qt_themes READ-ONLY fallback (v1.7.3 Clause 9, Correction 9) — at
 * a flat floor weight of 0.25 so they still contribute to the room
 * shape without drowning out the calibrated signal. Legacy keys are
 * NEVER written by current AI, NEVER used to recreate Door/Theme
 * taxonomy, and can be retired once every story has a canonical
 * profile.
 *
 *  - atmosphere():    what a room has been made of (concepts, threads,
 *                     emotional tone, communication texture, the
 *                     story currently held) and a generated note
 *  - houseMap():      the whole house at a glance — aggregated concept
 *                     weights across all rooms
 *  - suggestedFrom(): stories in OTHER rooms that resonate, scored by
 *                     concept overlap + thread overlap + a soft lexical
 *                     cross-pollination signal — the librarian leading
 *                     you onward
 *
 * @package QuietTruths\Core
 */

namespace QuietTruths\Core;

use QuietTruths\Ai\Profile;
use QuietTruths\Ai\ThreadInference;

if (!defined('ABSPATH')) {
    exit;
}

final class Rooms
{
    /**
     * Floor weight for a story that contributes via the legacy
     * _qt_themes keyword list (no v6 profile). 0.25 keeps these
     * stories visible in the room but prevents them from overwhelming
     * calibrated semantic scores (which run 0.0–1.0).
     */
    private const LEGACY_FLOOR_WEIGHT = 0.25;

    /**
     * Minimum concept score to count a concept as present in a story
     * during aggregation. Anything below this is noise.
     */
    private const CONCEPT_FLOOR = 0.20;

    /**
     * Minimum thread score to count an active thread during aggregation.
     * Matches ThreadInference::THREAD_THRESHOLD.
     */
    private const THREAD_FLOOR = 0.35;

    /**
     * Published story IDs in a room, newest first.
     *
     * @return list<int>
     */
    public static function storyIds(string $roomSlug): array
    {
        $query = new \WP_Query([
            'post_type'      => 'qt_story',
            'post_status'    => 'publish',
            'posts_per_page' => 500,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'tax_query'      => [
                [
                    'taxonomy' => 'qt_room',
                    'field'    => 'slug',
                    'terms'    => $roomSlug,
                ],
            ],
        ]);

        return array_map('intval', (array) $query->posts);
    }

    /**
     * Fetch a story's AI profile and return the concept-weight array
     * (slug → weight, 0..1) plus the thread/signal/emotion slices.
     * Falls back to legacy _qt_themes when no FRESH profile exists.
     *
     * @return array{concepts:array<string,float>,threads:array<string,float>,
     *               signals:array<string,array<string,float>>,emotion:array,
     *               comm:array<string,float>,valence:float,is_dense:bool}
     */
    private static function storyContribution(int $postId): array
    {
        $empty = [
            'concepts' => [], 'threads' => [], 'signals' => [],
            'emotion' => [], 'comm' => [], 'valence' => 0.0, 'is_dense' => false,
        ];

        $post = get_post($postId);
        if (!$post) {
            return $empty;
        }

        // Use the READ path — this is reader-facing room architecture,
        // never triggers a fresh embed. Returns stored profile or the
        // cheap lexical fallback.
        $raw = get_post_meta($postId, Profile::META_KEY, true);
        $hasProfile = is_array($raw)
            && (int) ($raw['schema_version'] ?? 0) >= Profile::SCHEMA_VERSION
            && ($raw['_status'] ?? Profile::FRESH) === Profile::FRESH;

        if ($hasProfile) {
            $semMode     = (string) ($raw['semantic']['mode'] ?? 'lexical');
            $conceptsIn  = (array) ($raw['concepts'] ?? []);
            $threadsIn   = (array) ($raw['threads']['scores'] ?? []);
            $signalsIn   = (array) ($raw['signals'] ?? []);
            $emotion     = (array) ($raw['emotional']['labels'] ?? []);
            $valence     = (float) ($raw['emotional']['valence'] ?? 0.0);
            $comm        = (array) ($signalsIn['communication'] ?? []);

            $concepts = [];
            foreach ($conceptsIn as $slug => $score) {
                $s = (float) $score;
                if ($s >= self::CONCEPT_FLOOR) {
                    $concepts[(string) $slug] = $s;
                }
            }
            $threads = [];
            foreach ($threadsIn as $slug => $score) {
                $s = (float) $score;
                if ($s >= self::THREAD_FLOOR) {
                    // Canonicalise retired thread slugs so v6/v7 profiles
                    // aggregate into the same bucket in atmosphere().
                    $canon = ThreadInference::canonicalSlug((string) $slug);
                    // If multiple legacy keys collapse to the same canonical,
                    // take the strongest weight.
                    if (!isset($threads[$canon]) || $s > $threads[$canon]) {
                        $threads[$canon] = $s;
                    }
                }
            }

            return [
                'concepts' => $concepts,
                'threads'  => $threads,
                'signals'  => [
                    'emotional'    => (array) ($signalsIn['emotional'] ?? []),
                    'relationship' => (array) ($signalsIn['relationship'] ?? []),
                    'time'         => (array) ($signalsIn['time'] ?? []),
                    'context'      => (array) ($signalsIn['context'] ?? []),
                    'communication'=> $comm,
                ],
                'emotion'  => $emotion,
                'comm'     => $comm,
                'valence'  => $valence,
                'is_dense' => $semMode === 'dense',
            ];
        }

        // LEGACY READ-ONLY FALLBACK (Correction 9): stories that
        // predate v6 profiles, or whose first build hasn't landed
        // yet. Contribute concept slugs via conceptsOf() (which
        // reads canonical _qt_concepts first, falls back to legacy
        // _qt_themes for older stories) at a flat floor weight so
        // they appear in rooms without dominating calibrated scores.
        //
        // IMPORTANT: the Room is a public classification, not derived
        // from Themes. Legacy concept information contributes soft
        // affinity — it does NOT recreate the old Door/Theme
        // taxonomy (v1.7.3 Clause 9).
        $legacyConcepts = Concepts::conceptsOf($postId);
        $concepts = [];
        foreach ($legacyConcepts as $slug) {
            if (is_string($slug) && '' !== $slug) {
                $concepts[$slug] = self::LEGACY_FLOOR_WEIGHT;
            }
        }
        return $empty + ['concepts' => $concepts];
    }

    /**
     * What a room has been made of, computed from its stories' AI
     * profiles.
     *
     * @return array{
     *   count:int, words:list<string>,
     *   concepts:list<array{slug:string,name:string,weight:float,pct:int,stories:int}>,
     *   threads:list<array{slug:string,name:string,weight:float,pct:int,stories:int}>,
     *   emotions:list<array{label:string,stories:int}>,
     *   tone:string, comm_modes:list<string>,
     *   dense_share:int, newest:?\WP_Post, note:string
     * }
     */
    public static function atmosphere(string $roomSlug): array
    {
        $ids = self::storyIds($roomSlug);

        $out = [
            'count'       => count($ids),
            'words'       => [],
            'concepts'    => [],
            'threads'     => [],
            'emotions'    => [],
            'tone'        => 'quiet',
            'comm_modes'  => [],
            'dense_share' => 0,
            'newest'      => null,
            'note'        => '',
        ];

        if (empty($ids)) {
            return $out;
        }

        $out['newest'] = get_post($ids[0]);

        // ── Aggregate over all stories in the room ──────────────────
        $conceptW   = []; // slug → cumulative weight
        $conceptN   = []; // slug → number of stories that carried it
        $threadW    = [];
        $threadN    = [];
        $emotionN   = [];
        $commW      = [];
        $text       = '';
        $denseCount = 0;
        $sumValence = 0.0;
        $valenceN   = 0;

        foreach ($ids as $id) {
            $post = get_post($id);
            if (!$post) continue;

            // Text is kept only for a stop-word-filtered top-words list
            // (preserves the "words most kept here" texture). Semantic
            // weight for concepts/threads comes from profiles above.
            $text .= ' ' . (string) $post->post_title . ' ' . (string) $post->post_content;

            $c = self::storyContribution($id);
            if ($c['is_dense']) $denseCount++;

            foreach ($c['concepts'] as $slug => $w) {
                $conceptW[$slug] = ($conceptW[$slug] ?? 0.0) + (float) $w;
                $conceptN[$slug] = ($conceptN[$slug] ?? 0)   + 1;
            }
            foreach ($c['threads'] as $slug => $w) {
                // Canonicalise retired thread slugs so v6 and v7
                // profiles aggregate into the same bucket.
                $canon = ThreadInference::canonicalSlug((string) $slug);
                $threadW[$canon] = ($threadW[$canon] ?? 0.0) + (float) $w;
                $threadN[$canon] = ($threadN[$canon] ?? 0)   + 1;
            }
            foreach ((array) $c['emotion'] as $lab) {
                if (is_string($lab) && '' !== $lab) {
                    $emotionN[$lab] = ($emotionN[$lab] ?? 0) + 1;
                }
            }
            foreach ($c['comm'] as $mode => $w) {
                if ((float) $w >= 0.45) {
                    $commW[(string) $mode] = ($commW[(string) $mode] ?? 0.0) + (float) $w;
                }
            }
            if (isset($c['valence'])) {
                $sumValence += (float) $c['valence'];
                $valenceN++;
            }
        }

        $total = max(1, count($ids));

        // Top words (stop-word filtered, lexical texture only).
        $out['words'] = Concepts::topWords($text, 3);

        // ── Concepts: sort by cumulative weight, keep top 5 ─────────
        arsort($conceptW);
        $concepts = [];
        $maxCW    = (float) (reset($conceptW) ?: 1.0);
        foreach (array_slice($conceptW, 0, 5, true) as $slug => $w) {
            $cMeta = Concepts::concepts()[$slug] ?? null;
            $concepts[] = [
                'slug'    => (string) $slug,
                'name'    => (string) ($cMeta['name'] ?? ucwords(str_replace('-', ' ', (string) $slug))),
                'weight'  => round((float) $w, 2),
                'pct'     => (int) round(((float) $w / $maxCW) * 100),
                'stories' => (int) ($conceptN[$slug] ?? 0),
            ];
        }
        $out['concepts'] = $concepts;

        // ── Threads: invisible cross-cutting textures, top 4 ────────
        arsort($threadW);
        $threads = [];
        $maxTW = (float) (reset($threadW) ?: 1.0);
        $threadDefs = ThreadInference::definitions();
        // Slug → human label overrides for retired slugs so that v6
        // profiles, which may still carry deprecated thread keys, still
        // render a friendly name while the librarian rebuilds to the
        // v1.7 ontology. Current threads carry their own 'name' key.
        static $retiredThreadNames = [
            'family'            => 'Family',
            'faith'             => 'Faith & Belief',
            'work-money'        => 'Work, Money & The Hustle',
            'work-money-hustle' => 'Work, Money & The Hustle',
            'the-body'          => 'Vulnerability',
            'body'              => 'Vulnerability',
            'violence-survival' => 'Survival & Resilience',
            'place-belonging'   => 'Belonging',
            'time-memory'       => 'Memory',
            'silence-secrets'   => 'Silence & The Unsaid',
        ];
        $fallbackName = static function (string $slug) use ($threadDefs, $retiredThreadNames): string {
            if (isset($retiredThreadNames[$slug])) return $retiredThreadNames[$slug];
            $canon = ThreadInference::canonicalSlug($slug);
            if (isset($threadDefs[$canon]['name'])) return (string) $threadDefs[$canon]['name'];
            return ucwords(str_replace(['-', '_'], ' ', $slug));
        };
        foreach (array_slice($threadW, 0, 4, true) as $slug => $w) {
            $canon  = ThreadInference::canonicalSlug((string) $slug);
            $tMeta  = $threadDefs[$canon] ?? [];
            $threads[] = [
                'slug'    => $canon,
                'name'    => (string) ($tMeta['name'] ?? $fallbackName((string) $slug)),
                'weight'  => round((float) $w, 2),
                'pct'     => (int) round(((float) $w / $maxTW) * 100),
                'stories' => (int) ($threadN[$canon] ?? $threadN[$slug] ?? 0),
            ];
        }
        $out['threads'] = $threads;

        // ── Emotional tone ──────────────────────────────────────────
        arsort($emotionN);
        $emotions = [];
        foreach (array_slice($emotionN, 0, 3, true) as $lab => $n) {
            $emotions[] = ['label' => (string) $lab, 'stories' => (int) $n];
        }
        $out['emotions'] = $emotions;

        $avgValence = $valenceN > 0 ? ($sumValence / $valenceN) : 0.0;
        if ($avgValence <= -0.25)      $out['tone'] = 'heavy';
        elseif ($avgValence <= -0.05)  $out['tone'] = 'weighted';
        elseif ($avgValence >= 0.25)   $out['tone'] = 'hopeful';
        elseif ($avgValence >= 0.05)   $out['tone'] = 'light';
        else                            $out['tone'] = 'quiet';

        // ── Communication modes present (narrative, unsent_letter,
        //    apology, confession, address_to_*) ──────────────────────
        arsort($commW);
        $commLabels = [
            'narrative'           => __('stories told straight', 'quiet-truths'),
            'unsent_letter'       => __('letters never sent', 'quiet-truths'),
            'apology'             => __('apologies offered', 'quiet-truths'),
            'confession'          => __('confessions made', 'quiet-truths'),
            'address_to_deceased' => __('words to those gone', 'quiet-truths'),
            'address_to_younger_self' => __('words to a younger self', 'quiet-truths'),
        ];
        $commModes = [];
        foreach (array_keys(array_slice($commW, 0, 2, true)) as $mode) {
            if (isset($commLabels[$mode])) {
                $commModes[] = $commLabels[$mode];
            }
        }
        $out['comm_modes'] = $commModes;

        // Share of stories with a dense profile (for the mwenye nyumba
        // to see how much of the room is currently on calibrated signal).
        $out['dense_share'] = (int) round(($denseCount / $total) * 100);

        // ── Room note ───────────────────────────────────────────────
        $out['note'] = self::buildRoomNote($roomSlug, $out);

        return $out;
    }

    /**
     * The whole house at a glance: aggregated concept weights across
     * every room, strongest first.
     *
     * @return list<array{slug:string,name:string,weight:float,pct:int,stories:int}>
     */
    public static function houseMap(int $limit = 10): array
    {
        $query = new \WP_Query([
            'post_type'      => 'qt_story',
            'post_status'    => 'publish',
            'posts_per_page' => 500,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ]);

        $conceptW = [];
        $conceptN = [];

        foreach ((array) $query->posts as $id) {
            $c = self::storyContribution((int) $id);
            foreach ($c['concepts'] as $slug => $w) {
                $conceptW[$slug] = ($conceptW[$slug] ?? 0.0) + (float) $w;
                $conceptN[$slug] = ($conceptN[$slug] ?? 0) + 1;
            }
        }

        arsort($conceptW);
        $max = (float) (reset($conceptW) ?: 1.0);

        $map = [];
        foreach (array_slice($conceptW, 0, $limit, true) as $slug => $w) {
            $meta = Concepts::concepts()[$slug] ?? null;
            $map[] = [
                'slug'    => (string) $slug,
                'name'    => (string) ($meta['name'] ?? ucwords(str_replace('-', ' ', (string) $slug))),
                'weight'  => round((float) $w, 2),
                'pct'     => (int) round(((float) $w / $max) * 100),
                'stories' => (int) ($conceptN[$slug] ?? 0),
            ];
        }

        return $map;
    }

    /**
     * Stories in OTHER rooms that resonate with this room — the
     * librarian leading the reader onward. Scored by:
     *   - concept weight overlap (semantic prototype-aware)  → largest term
     *   - thread overlap (silent cross-cutting textures)     → smaller term
     *   - soft token-cosine between averaged room profile
     *     and candidate story text                           → small polish
     *
     * @return list<\WP_Post>
     */
    public static function suggestedFrom(string $roomSlug, int $limit = 3): array
    {
        $ids = self::storyIds($roomSlug);
        if (empty($ids)) return [];

        // Build a "room profile" of aggregated concept/thread weights.
        $roomConceptW = [];
        $roomThreadW  = [];
        $roomVec      = [];
        $roomVecN     = 0;

        foreach ($ids as $sid) {
            $c = self::storyContribution((int) $sid);
            foreach ($c['concepts'] as $slug => $w) {
                $roomConceptW[$slug] = ($roomConceptW[$slug] ?? 0.0) + (float) $w;
            }
            foreach ($c['threads'] as $slug => $w) {
                $roomThreadW[$slug] = ($roomThreadW[$slug] ?? 0.0) + (float) $w;
            }
            // Soft cross-pollination vector — token vectors of up to 5
            // recent stories averaged together (same approach as before,
            // still an honest lexical signal, not a replacement for the
            // semantic layer above).
            if ($roomVecN < 5 && Ai::enabled()) {
                $sp = get_post($sid);
                if ($sp) {
                    $tv = Ai::tokenVector((string) $sp->post_title . ' ' . (string) $sp->post_content);
                    foreach ($tv as $t => $w) {
                        $roomVec[$t] = ($roomVec[$t] ?? 0.0) + $w;
                    }
                    $roomVecN++;
                }
            }
        }
        if ($roomVecN > 0) {
            foreach ($roomVec as &$w) $w /= $roomVecN;
            unset($w);
        }

        if (empty($roomConceptW)) return [];

        $query = new \WP_Query([
            'post_type'      => 'qt_story',
            'post_status'    => 'publish',
            'posts_per_page' => 500,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ]);

        $scored = [];
        foreach ((array) $query->posts as $id) {
            $id = (int) $id;
            if (in_array($id, $ids, true)) continue;

            $terms = get_the_terms($id, 'qt_room');
            if (is_wp_error($terms) || empty($terms)) continue;
            if (($terms[0]->slug ?? '') === $roomSlug) continue;

            $c = self::storyContribution($id);
            $score = 0.0;

            // Concept overlap — weighted (semantic gravity: a concept
            // with 0.82 confidence counts for 0.82, not 1).
            foreach ($c['concepts'] as $slug => $w) {
                if (isset($roomConceptW[$slug])) {
                    $score += (float) $w * min(1.0, (float) $roomConceptW[$slug]);
                }
            }
            // Thread overlap — cross-cutting threads (family, grief,
            // faith...) are invisible to the reader but make two
            // stories feel like they belong near each other. Weighted
            // lower than concepts per evidence hierarchy.
            foreach ($c['threads'] as $slug => $w) {
                if (isset($roomThreadW[$slug])) {
                    $score += 0.5 * (float) $w * min(1.0, (float) $roomThreadW[$slug]);
                }
            }
            // Soft lexical cross-pollination (cosine against the
            // averaged token-vector profile), small polish.
            if (!empty($roomVec) && Ai::enabled()) {
                $candidate = get_post($id);
                if ($candidate) {
                    $cv = Ai::tokenVector((string) $candidate->post_title . ' ' . (string) $candidate->post_content);
                    $dot = 0.0;
                    foreach ($cv as $t => $w) {
                        if (isset($roomVec[$t])) $dot += $w * $roomVec[$t];
                    }
                    $score += $dot * 2.0;
                }
            }

            if ($score > 0) {
                $scored[$id] = $score;
            }
        }

        arsort($scored);
        $posts = [];
        foreach (array_slice(array_keys($scored), 0, $limit, true) as $id) {
            $post = get_post($id);
            if ($post) $posts[] = $post;
        }
        return $posts;
    }

    /* ──────────────────── room note composition ──────────────────── */

    /**
     * Compose a short, honest note describing the room. Uses tones,
     * top concepts/threads/comm-modes rather than the old "X% concept"
     * mechanical phrasing — feels like a librarian who has been
     * reading what is held, not a statistician.
     *
     * @param array<string,mixed> $atmo
     */
    private static function buildRoomNote(string $roomSlug, array $atmo): string
    {
        $count  = (int) ($atmo['count'] ?? 0);
        $names  = array_slice(array_column((array) ($atmo['concepts'] ?? []), 'name'), 0, 2);
        $threadNames = array_slice(array_column((array) ($atmo['threads'] ?? []), 'name'), 0, 1);
        $words  = array_slice((array) ($atmo['words'] ?? []), 0, 3);
        $tone   = (string) ($atmo['tone'] ?? 'quiet');
        $comms  = (array) ($atmo['comm_modes'] ?? []);
        $dense  = (int) ($atmo['dense_share'] ?? 0);

        if (1 === $count) {
            $what = !empty($names) ? implode(' ' . __('and', 'quiet-truths') . ' ', $names) : __('quiet things', 'quiet-truths');
            // Translators: %s = the concepts this single story speaks of.
            return sprintf(
                __('One story rests here so far, and it speaks of %s.', 'quiet-truths'),
                $what
            );
        }

        // Translators: %1$s = top concepts, %2$s = top held words, %3$s = tone word.
        $fmt = __('This room holds %1$d stories. Lately it has been about %2$s — %3$s. The words kept here most often: %4$s.', 'quiet-truths');

        $conceptPhrase = !empty($names)
            ? implode(' ' . __('and', 'quiet-truths') . ' ', $names)
            : __('the quiet things of the house', 'quiet-truths');

        $tonePhrases = [
            'heavy'   => __('weight carried quietly', 'quiet-truths'),
            'weighted'=> __('the air a little thick with memory', 'quiet-truths'),
            'quiet'   => __('held softly', 'quiet-truths'),
            'light'   => __('something lifting', 'quiet-truths'),
            'hopeful'=> __('the shape of hope appearing', 'quiet-truths'),
        ];
        $tonePhrase = $tonePhrases[$tone] ?? $tonePhrases['quiet'];

        if (!empty($threadNames)) {
            // Translators: appended to concept phrase to mention a quiet thread.
            $tonePhrase = sprintf(__('%s, often in the territory of %s', 'quiet-truths'),
                $tonePhrase,
                $threadNames[0]
            );
        }

        if (!empty($comms)) {
            $tonePhrase .= ' — ' . implode(', ', $comms);
        }

        $wordPhrase = !empty($words) ? implode(', ', $words) : '—';

        $note = sprintf($fmt, (int) $count, $conceptPhrase, $tonePhrase, $wordPhrase);

        return $note;
    }
}
