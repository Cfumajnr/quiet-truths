<?php
/**
 * Quiet Truths — Config
 *
 * Loads the configuration constants and exposes a small typed accessor.
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Config
{
    private static ?self $instance = null;

    /** @var array<string, mixed> */
    private array $data = [];

    /**
     * Full canonical room specifications (name, description, purpose,
     * concepts, signals, lexical, bias, prototypes). Keyed by slug.
     * @var array<string,array<string,mixed>>
     */
    private array $roomSpecs = [];

    /**
     * Background Intelligence Domains (twenty broad areas of human
     * life, per AI Bible XVIII). These are private organising
     * umbrellas over the concept vocabulary; they are NOT scored
     * directly and never appear as public categories.
     * @var array<string,array<string,mixed>>
     */
    private array $domains = [];

    private function __construct()
    {
        require_once dirname(__DIR__) . '/config/constants.php';

        // Threads (cross-cutting AI layer) — loaded lazily via self::threads().
        $threadsPath = dirname(__DIR__) . '/config/threads.php';
        $threads     = is_file($threadsPath) ? (array) require $threadsPath : [];

        // Background Intelligence Domains (twenty private areas of life).
        $domainsPath = dirname(__DIR__) . '/config/domains.php';
        $domains     = is_file($domainsPath) ? (array) require $domainsPath : [];

        // Canonical room definitions (the seven rooms). Loaded once at boot
        // so constants.php, RoomAffinity, Submission, and reader archives
        // all read from ONE source. See app/config/rooms.php for the full
        // canonical spec. AI components may SCORE rooms but never redefine
        // them.
        $roomsPath   = dirname(__DIR__) . '/config/rooms.php';
        $roomsSpec   = is_file($roomsPath) ? (array) require $roomsPath : [];

        // Build the public-facing QT_ROOMS map (slug => name+description)
        // from the canonical source. constants.php only provides defaults
        // if this map is empty (defensive for broken installs).
        $roomsPublic = [];
        foreach ($roomsSpec as $slug => $spec) {
            if (!is_array($spec)) continue;
            $roomsPublic[(string) $slug] = [
                'slug'        => (string) ($spec['slug'] ?? $slug),
                'name'        => (string) ($spec['name'] ?? ucfirst((string) $slug)),
                'description' => (string) ($spec['description'] ?? ''),
            ];
        }
        if (!defined('QT_ROOMS')) {
            define('QT_ROOMS', $roomsPublic);
        }

        $this->roomSpecs = $roomsSpec;
        $this->domains   = $domains;

        $this->data = [
            'identity' => [
                'name'        => 'Quiet Truths',
                'version'     => QT_THEME_VERSION,
                'text_domain' => QT_TEXT_DOMAIN,
            ],
            'paths' => [
                'theme'            => QT_THEME_DIR,
                'theme_uri'        => QT_THEME_URI,
                'app'              => QT_APP_DIR,
                'app_uri'          => QT_APP_URI,
                'design_system'    => QT_DESIGN_SYSTEM_DIR,
                'design_system_uri'=> QT_DESIGN_SYSTEM_URI,
                'assets_uri'       => QT_ASSETS_URI,
            ],
            'content' => [
                'story_post_type' => QT_STORY_POST_TYPE,
                'room_taxonomy'   => QT_ROOM_TAXONOMY,
                'rooms'           => QT_ROOMS,
                'threads'         => $threads,
                'domains'         => $domains,
                'room_redirects'  => defined('QT_ROOM_REDIRECTS') ? QT_ROOM_REDIRECTS : [],
            ],
        ];
    }

    public static function init(): self
    {
        return self::$instance ??= new self();
    }

    public static function instance(): self
    {
        return self::$instance ?? self::init();
    }

    /**
     * @param mixed $default
     * @return mixed
     */
    public function get(string $key, $default = null)
    {
        return $this->data[$key] ?? $default;
    }

    /** @return array<string, mixed> */
    public function all(): array
    {
        return $this->data;
    }

    /**
     * Canonical room specifications (full AI-ready definitions: concepts,
     * signals, lexical, bias, prototypes). Callers that just need public
     * name/description should continue to use content.rooms (QT_ROOMS).
     *
     * @return array<string,array<string,mixed>>
     */
    public function roomSpecs(): array
    {
        return $this->roomSpecs;
    }

    /**
     * Single canonical room spec by slug, or null if not defined.
     *
     * @return array<string,mixed>|null
     */
    public function roomSpec(string $slug): ?array
    {
        return $this->roomSpecs[$slug] ?? null;
    }

    /**
     * Background Intelligence Domains (AI Bible XVIII) — twenty
     * broad areas of human life that organise the concept library.
     * Not scored directly; not public.
     *
     * @return array<string,array<string,mixed>>
     */
    public function domains(): array
    {
        return $this->domains;
    }

    /**
     * Single domain spec by slug, or null if not defined.
     *
     * @return array<string,mixed>|null
     */
    public function domain(string $slug): ?array
    {
        return $this->domains[$slug] ?? null;
    }
}
