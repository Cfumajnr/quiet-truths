<?php
/** Quiet Truths — factual governance configuration, never secrets. */
namespace QuietTruths\Core;

if (!defined('ABSPATH')) { exit; }

final class GovernanceSettings
{
    private const OPTION = 'qt_governance_settings';

    public static function init(): void
    {
        add_action('admin_menu', [self::class, 'registerPage']);
        add_action('admin_post_qt_save_governance_settings', [self::class, 'save']);
        add_action('admin_notices', [self::class, 'notice']);
    }

    /** @return array<string,string|int> */
    public static function defaults(): array
    {
        return [
            'controller_legal_name' => 'Quiet Truths',
            'controller_public_name' => 'Quiet Truths',
            'privacy_email' => 'admin@quiettruths.co.ke',
            'contact_address' => 'Nairobi, Kenya',
            'host_provider' => 'Shujaa Host',
            'host_location' => 'Kenya',
            'email_provider' => 'Shujaa Host (Roundcube webmail)',
            'email_location' => 'Kenya',
            'backup_provider' => 'Google LLC (Google Drive via UpdraftPlus Free)',
            'backup_location' => 'International / global Google infrastructure',
            'backup_security' => 'Google-managed encryption in transit and at rest; UpdraftPlus Free archives are not client-side encrypted',
            'support_provider' => 'Sole authorised operator in Kenya',
            'effective_date' => '11 August 2026',
            'last_reviewed_date' => '11 August 2026',
            'counsel_approved' => 0,
        ];
    }

    /** @return array<string,string|int> */
    public static function all(): array
    {
        $saved = get_option(self::OPTION, []);
        return array_merge(self::defaults(), is_array($saved) ? $saved : []);
    }

    public static function get(string $key): string
    {
        $all = self::all();
        return isset($all[$key]) ? (string) $all[$key] : '';
    }

    /** @return list<string> */
    public static function missing(): array
    {
        $required = [
            'controller_legal_name', 'privacy_email', 'contact_address',
            'host_provider', 'host_location', 'email_provider', 'email_location',
            'backup_provider', 'backup_location', 'backup_security', 'support_provider',
            'effective_date', 'last_reviewed_date',
        ];
        $missing = [];
        foreach ($required as $key) {
            if ('' === trim(self::get($key))) $missing[] = $key;
        }
        if ('1' !== self::get('counsel_approved')) $missing[] = 'counsel_approved';
        return $missing;
    }

    public static function complete(): bool
    {
        return [] === self::missing();
    }

    public static function registerPage(): void
    {
        add_management_page(
            __('Quiet Truths Governance', 'quiet-truths'),
            __('Quiet Truths Governance', 'quiet-truths'),
            'manage_qt_governance',
            'qt-governance-settings',
            [self::class, 'renderPage']
        );
    }

    public static function renderPage(): void
    {
        if (!current_user_can('manage_qt_governance')) {
            wp_die(esc_html__('You are not allowed to configure governance.', 'quiet-truths'));
        }
        $values = self::all();
        $fields = [
            'controller_legal_name' => __('Individual controller’s exact legal name', 'quiet-truths'),
            'controller_public_name' => __('Public operating name', 'quiet-truths'),
            'privacy_email' => __('Privacy/security email', 'quiet-truths'),
            'contact_address' => __('Contact/postal address', 'quiet-truths'),
            'host_provider' => __('Hosting provider legal/public name', 'quiet-truths'),
            'host_location' => __('Hosting/database/log processing country', 'quiet-truths'),
            'email_provider' => __('External email provider', 'quiet-truths'),
            'email_location' => __('Email processing country/countries', 'quiet-truths'),
            'backup_provider' => __('External backup provider', 'quiet-truths'),
            'backup_location' => __('Backup storage country/countries', 'quiet-truths'),
            'backup_security' => __('Backup encryption/control statement', 'quiet-truths'),
            'support_provider' => __('Technical support/security access', 'quiet-truths'),
            'effective_date' => __('Effective date', 'quiet-truths'),
            'last_reviewed_date' => __('Last reviewed date', 'quiet-truths'),
        ];

        echo '<div class="wrap"><h1>' . esc_html__('Quiet Truths Governance Facts', 'quiet-truths') . '</h1>';
        echo '<p>' . esc_html__('These are factual public/operational details—not credentials. Governance pages remain unpublished until every required fact and legal-review confirmation is present.', 'quiet-truths') . '</p>';
        if (!self::complete()) {
            echo '<div class="notice notice-error inline"><p>' . esc_html__('Missing: ', 'quiet-truths') . esc_html(implode(', ', self::missing())) . '</p></div>';
        }
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('qt_save_governance_settings');
        echo '<input type="hidden" name="action" value="qt_save_governance_settings"><table class="form-table">';
        foreach ($fields as $key => $label) {
            echo '<tr><th><label for="' . esc_attr($key) . '">' . esc_html($label) . '</label></th><td><input class="regular-text" id="' . esc_attr($key) . '" name="' . esc_attr($key) . '" value="' . esc_attr((string) ($values[$key] ?? '')) . '" required></td></tr>';
        }
        echo '<tr><th>' . esc_html__('Legal review', 'quiet-truths') . '</th><td><label><input type="checkbox" name="counsel_approved" value="1" ' . checked((int) ($values['counsel_approved'] ?? 0), 1, false) . '> ' . esc_html__('Kenyan counsel has approved the deployed governance pack and these facts.', 'quiet-truths') . '</label></td></tr>';
        echo '</table>';
        submit_button(__('Save governance facts', 'quiet-truths'));
        echo '</form></div>';
    }

    public static function save(): void
    {
        if (!current_user_can('manage_qt_governance')) {
            wp_die(esc_html__('You are not allowed to save governance facts.', 'quiet-truths'));
        }
        check_admin_referer('qt_save_governance_settings');
        $values = [];
        foreach (array_keys(self::defaults()) as $key) {
            if ('counsel_approved' === $key) {
                $values[$key] = empty($_POST[$key]) ? 0 : 1;
            } elseif ('privacy_email' === $key) {
                $values[$key] = sanitize_email(wp_unslash((string) ($_POST[$key] ?? '')));
            } else {
                $values[$key] = sanitize_text_field(wp_unslash((string) ($_POST[$key] ?? '')));
            }
        }
        update_option(self::OPTION, $values, false);
        delete_option('qt_gov_pack_version'); // force factual re-render
        if (class_exists(Audit::class)) Audit::record('governance_changed', 0, 'facts_updated');
        wp_safe_redirect(admin_url('tools.php?page=qt-governance-settings&updated=1'));
        exit;
    }

    public static function notice(): void
    {
        if (!current_user_can('manage_qt_governance') || self::complete()) return;
        echo '<div class="notice notice-error"><p><strong>' . esc_html__('Quiet Truths governance is incomplete.', 'quiet-truths') . '</strong> '
            . '<a href="' . esc_url(admin_url('tools.php?page=qt-governance-settings')) . '">' . esc_html__('Supply the missing controller/provider facts and legal-review confirmation.', 'quiet-truths') . '</a></p></div>';
    }
}
