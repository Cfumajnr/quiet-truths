<?php
/**
 * Quiet Truths — short-lived, visitor-specific form state.
 *
 * Form errors sometimes need to survive a POST/Redirect/GET cycle. A
 * single global transient would allow one visitor to receive another
 * visitor's name, email or draft text. This helper stores each state under
 * an unguessable one-time token and deletes it as soon as it is read.
 *
 * The token contains no personal data. Cross-origin referrers are already
 * reduced to the origin by the site's Referrer-Policy, and a consumed token
 * is useless even if it remains in browser history.
 *
 * @package QuietTruths\Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Flash
{
    public const QUERY_ARG = 'qt_flash';

    /**
     * Store a one-time state and return its opaque token.
     *
     * @param array<string,mixed> $state
     */
    public static function put(string $scope, array $state, int $ttl = 120): string
    {
        $scope = sanitize_key($scope);
        $token = wp_generate_password(32, false, false);

        set_transient(self::key($scope, $token), $state, max(30, min($ttl, 300)));

        return $token;
    }

    /**
     * Read and immediately delete the state for the current request.
     *
     * @return array<string,mixed>
     */
    public static function pull(string $scope): array
    {
        if (empty($_GET[self::QUERY_ARG])) {
            return [];
        }

        $token = sanitize_text_field(wp_unslash((string) $_GET[self::QUERY_ARG]));

        if (!preg_match('/^[A-Za-z0-9]{20,64}$/', $token)) {
            return [];
        }

        $key   = self::key(sanitize_key($scope), $token);
        $state = get_transient($key);
        delete_transient($key);

        return is_array($state) ? $state : [];
    }

    /**
     * Add a newly stored state token to a safe return URL.
     *
     * @param array<string,mixed> $state
     */
    public static function url(string $url, string $scope, array $state): string
    {
        $url   = remove_query_arg(self::QUERY_ARG, $url);
        $token = self::put($scope, $state);

        return add_query_arg(self::QUERY_ARG, rawurlencode($token), $url);
    }

    private static function key(string $scope, string $token): string
    {
        $digest = hash_hmac('sha256', $token, (string) wp_salt('nonce'));

        return 'qt_flash_' . $scope . '_' . $digest;
    }
}
