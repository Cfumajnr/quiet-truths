<?php
/**
 * Quiet Truths — Journal Comments (conversation, not engagement)
 *
 * The Journal invites thought, not quick emotional measurement (Journal
 * Bible §19–§25). Unlike Stories (which have silent reactions), a Journal
 * has comments ONLY:
 *
 *   - attributable: a real name, a private email (used for moderation,
 *     never displayed), and the comment itself.
 *   - replies supported, kept visually subordinate and shallow so the
 *     Journal stays the centre.
 *   - the Journal author can participate, and is clearly flagged as the
 *     author.
 *   - moderation is accountable but disagreement is allowed.
 *   - NO comment counts are displayed (§25), and no reactions exist (§26).
 *
 * Comments are stored as `qt_journal_comment` posts; each carries the
 * journal's ID, the public commenter name and a private email address for
 * moderation. The email is never rendered publicly, but it remains
 * personal data at rest and must follow the published retention schedule.
 *
 * @package QuietTruths
 * @subpackage Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class JournalComments
{
    private const NONCE_ADD   = 'qt_journal_comment_';
    private const COOKIE      = 'qt_journal_edit_tokens';
    private const COMMENT_CPT = 'qt_journal_comment';

    /** @var list<string> */
    private static array $errors = [];

    /** @var array<string,string> */
    private static array $old = [];

    public static function init(): void
    {
        add_action('init', [self::class, 'registerPostType']);
        add_action('template_redirect', [self::class, 'maybeHandleAdd']);
        add_action('admin_init', [self::class, 'maybeHandleApprove']);
        add_action('admin_notices', [self::class, 'adminNotice']);
        add_filter('post_row_actions', [self::class, 'rowActions'], 10, 2);
        add_filter('manage_qt_journal_comment_posts_columns', [self::class, 'adminColumns']);
        add_action('manage_qt_journal_comment_posts_custom_column', [self::class, 'adminColumnValue'], 10, 2);
        add_action('add_meta_boxes_qt_journal_comment', [self::class, 'addAuthorVerificationBox']);
        add_action('save_post_qt_journal_comment', [self::class, 'saveAuthorVerification'], 10, 2);
    }

    /* ─────────────── admin ─────────────── */

    public static function adminNotice(): void
    {
        if (!current_user_can('edit_posts')) {
            return;
        }
        $counts  = wp_count_posts(self::COMMENT_CPT);
        $pending = (int) ($counts->pending ?? 0);
        if ($pending < 1) {
            return;
        }
        $url = admin_url('edit.php?post_type=qt_journal_comment&post_status=pending');
        echo '<div class="notice notice-info"><p>' . wp_kses_post(sprintf(
            /* translators: %1$d count, %2$s URL */
            __('%1$d Journal comment waiting to be read, and — if they are kind — held. <a href="%2$s">Open the comments queue</a>.', 'quiet-truths'),
            $pending,
            esc_url($url)
        )) . '</p></div>';
    }

    /** @param array<string,string> $actions */
    public static function rowActions(array $actions, $post): array
    {
        if (self::COMMENT_CPT !== $post->post_type || 'pending' !== $post->post_status) {
            return $actions;
        }
        if (!current_user_can('edit_post', $post->ID)) {
            return $actions;
        }
        $url = wp_nonce_url(
            admin_url('admin.php?qt_approve_jc=' . $post->ID),
            'qt_approve_jc_' . $post->ID
        );
        $actions['qt_approve'] = sprintf(
            '<a href="%s" aria-label="%s">%s</a>',
            esc_url($url),
            esc_attr__('Approve this Journal comment', 'quiet-truths'),
            esc_html__('Approve', 'quiet-truths')
        );
        return $actions;
    }

    /** @param array<string,string> $columns */
    public static function adminColumns(array $columns): array
    {
        $new = [];
        foreach ($columns as $key => $label) {
            $new[$key] = $label;
            if ('title' === $key) {
                $new['qt_journal'] = __('Journal', 'quiet-truths');
            }
        }
        $new['qt_commenter'] = __('Commenter', 'quiet-truths');
        return $new;
    }

    public static function adminColumnValue(string $column, int $postId): void
    {
        if ('qt_journal' === $column) {
            $journalId = (int) get_post_meta($postId, '_qt_journal_id', true);
            $journal   = $journalId ? get_post($journalId) : null;
            if ($journal) {
                echo '<a href="' . esc_url(get_edit_post_link($journal->ID)) . '">' . esc_html($journal->post_title) . '</a>';
            } else {
                echo '<span class="qt-muted">—</span>';
            }
        }
        if ('qt_commenter' === $column) {
            $name = (string) get_post_meta($postId, '_qt_comment_name', true);
            echo esc_html('' !== $name ? $name : __('Anonymous', 'quiet-truths'));
        }
    }

    public static function registerPostType(): void
    {
        register_post_type(self::COMMENT_CPT, [
            'labels' => [
                'name'          => __('Journal Comments', 'quiet-truths'),
                'singular_name' => __('Journal Comment', 'quiet-truths'),
                'menu_name'     => __('Journal Comments', 'quiet-truths'),
            ],
            'public'             => false,
            'publicly_queryable' => false,
            'exclude_from_search'=> true,
            'show_ui'            => true,
            'show_in_menu'       => 'edit.php?post_type=qt_journal',
            'show_in_rest'       => false,
            'rewrite'            => false,
            'supports'           => ['editor'],
            'capability_type'    => ['qt_journal_comment', 'qt_journal_comments'],
            'map_meta_cap'       => true,
        ]);
    }

    /** Moderator-only verification; a matching public name is never enough. */
    public static function addAuthorVerificationBox(\WP_Post $post): void
    {
        add_meta_box(
            'qt_journal_comment_author',
            __('Journal author verification', 'quiet-truths'),
            static function (\WP_Post $comment): void {
                wp_nonce_field('qt_jc_author_' . $comment->ID, 'qt_jc_author_nonce');
                $checked = '1' === (string) get_post_meta($comment->ID, '_qt_comment_is_author', true);
                echo '<label><input type="checkbox" name="qt_jc_is_author" value="1" '
                    . checked($checked, true, false) . '> '
                    . esc_html__('Verified as the author of this Journal', 'quiet-truths') . '</label>';
                echo '<p class="description">' . esc_html__('Set this only after verifying the commenter through the private author contact route. A matching display name is not proof.', 'quiet-truths') . '</p>';
            },
            self::COMMENT_CPT,
            'side',
            'high'
        );
    }

    public static function saveAuthorVerification(int $postId, \WP_Post $post): void
    {
        if (self::COMMENT_CPT !== $post->post_type
            || !isset($_POST['qt_jc_author_nonce'])
            || !wp_verify_nonce(
                sanitize_key(wp_unslash((string) $_POST['qt_jc_author_nonce'])),
                'qt_jc_author_' . $postId
            )
            || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
            || wp_is_post_revision($postId)
            || !current_user_can('edit_post', $postId)) {
            return;
        }

        if (!empty($_POST['qt_jc_is_author'])) {
            update_post_meta($postId, '_qt_comment_is_author', '1');
        } else {
            delete_post_meta($postId, '_qt_comment_is_author');
        }
    }

    /* ─────────────── view state ─────────────── */

    /** @return list<string> */
    public static function errors(): array
    {
        return self::$errors;
    }

    /** @return array<string,string> */
    public static function old(): array
    {
        return self::$old;
    }

    public static function nonce(int $journalId): string
    {
        return wp_create_nonce(self::NONCE_ADD . $journalId);
    }

    /* ─────────────── retrieval ─────────────── */

    /**
     * Approved top-level comments for a journal, oldest first (flow).
     *
     * @return list<\WP_Post>
     */
    public static function forJournal(int $journalId, int $parentId = 0): array
    {
        $q = new \WP_Query([
            'post_type'      => self::COMMENT_CPT,
            'post_status'    => 'publish',
            'post_parent'    => $parentId,
            'posts_per_page' => 200,
            'orderby'        => 'date',
            'order'          => 'ASC',
            'no_found_rows'  => true,
            'meta_query'     => $parentId ? [] : [
                ['key' => '_qt_journal_id', 'value' => $journalId, 'compare' => '='],
            ],
        ]);

        return array_values(array_filter($q->posts, static fn ($p) => $p instanceof \WP_Post));
    }

    /**
     * The public name of a comment (or "Author" for the journal author).
     */
    public static function publicName(\WP_Post $comment): string
    {
        $name = (string) get_post_meta($comment->ID, '_qt_comment_name', true);

        return '' !== $name ? $name : __('A reader', 'quiet-truths');
    }

    public static function isAuthor(\WP_Post $comment): bool
    {
        // A matching display name is not proof: any visitor can type the
        // Journal byline into the public form. Only a moderator-verified
        // flag may display the Author badge.
        return '1' === (string) get_post_meta($comment->ID, '_qt_comment_is_author', true);
    }

    /* ─────────────── adding ─────────────── */

    public static function maybeHandleAdd(): void
    {
        if (!is_singular('qt_journal')) {
            return;
        }
        if (empty($_POST['qt_jc_action']) || 'add' !== $_POST['qt_jc_action']) {
            return;
        }

        $journalId = get_queried_object_id();
        $back      = get_permalink($journalId) . '#qt-journal-conversation';

        if (!Security::intakeOpen('journal_comment')) {
            self::fail('closed', $back);
        }

        if (!isset($_POST['_wpnonce'])
            || !wp_verify_nonce(sanitize_key(wp_unslash((string) $_POST['_wpnonce'])), self::NONCE_ADD . $journalId)) {
            self::fail('session', $back);
        }

        // Honeypot.
        if (!empty($_POST['qt_website'])) {
            wp_safe_redirect($back);
            exit;
        }

        if ('publish' !== get_post_status($journalId)) {
            self::fail('invalid', $back);
        }

        $parentId = absint($_POST['qt_parent'] ?? 0);
        if ($parentId > 0) {
            $parent = get_post($parentId);
            if (!$parent || self::COMMENT_CPT !== $parent->post_type || 'publish' !== $parent->post_status
                || (int) get_post_meta($parentId, '_qt_journal_id', true) !== $journalId) {
                self::fail('invalid', $back);
            }
        }

        if (!self::passesRate()) {
            self::fail('rate', $back);
        }

        $name    = isset($_POST['qt_jc_name']) ? sanitize_text_field(wp_unslash((string) $_POST['qt_jc_name'])) : '';
        $email   = isset($_POST['qt_jc_email']) ? sanitize_email(wp_unslash((string) $_POST['qt_jc_email'])) : '';
        $comment = isset($_POST['qt_jc_comment']) ? sanitize_textarea_field(wp_unslash((string) $_POST['qt_jc_comment'])) : '';

        self::$old = ['name' => $name, 'email' => $email, 'comment' => $comment];

        if ('' === trim($name) || mb_strlen($name) > 80) {
            self::fail('name', $back);
        }
        if ('' === $email || !is_email($email) || mb_strlen($email) > 254) {
            self::fail('email', $back);
        }
        $len = mb_strlen($comment);
        if ($len < 3) {
            self::fail('short', $back);
        }
        if ($len > 2000) {
            self::fail('long', $back);
        }
        // Language alone never decides publication. The item remains
        // pending for human moderation, where context can be understood.
        if (empty($_POST['qt_jc_age_rules'])) {
            self::fail('consent', $back);
        }

        $commentId = wp_insert_post([
            'post_type'    => self::COMMENT_CPT,
            'post_status'  => 'pending',
            'post_title'   => '',
            'post_content' => $comment,
            'post_author'  => 0,
            'post_parent'  => $parentId,
        ], true);

        if (is_wp_error($commentId)) {
            error_log('Quiet Truths: could not store a Journal comment — ' . $commentId->get_error_message());
            self::fail('store', $back);
        }

        update_post_meta($commentId, '_qt_journal_id', $journalId);
        update_post_meta($commentId, '_qt_comment_name', $name);
        update_post_meta($commentId, '_qt_comment_email_hash', wp_hash($email));
        // Private moderation/contact data. Never expose this meta through
        // REST, templates, feeds or public search.
        update_post_meta($commentId, '_qt_comment_email', $email);
        update_post_meta($commentId, '_qt_consent_at', current_time('mysql', true));
        update_post_meta($commentId, '_qt_consent_version', defined('QT_THEME_VERSION') ? QT_THEME_VERSION : '1.0');
        update_post_meta($commentId, '_qt_consent_age_rules', '1');

        self::notifyAdmin($commentId, $name, $comment, $journalId);

        wp_safe_redirect(add_query_arg('qt_jc_held', '1', $back));
        exit;
    }

    /* ─────────────── moderation ─────────────── */

    public static function maybeHandleApprove(): void
    {
        if (!is_admin() || !current_user_can('edit_posts')) {
            return;
        }
        if (empty($_GET['qt_approve_jc'])) {
            return;
        }

        $commentId = absint($_GET['qt_approve_jc']);
        if (!$commentId || !wp_verify_nonce(sanitize_key(wp_unslash((string) $_GET['_wpnonce'] ?? '')), 'qt_approve_jc_' . $commentId)) {
            return;
        }

        $comment = get_post($commentId);
        if (!$comment || self::COMMENT_CPT !== $comment->post_type
            || !current_user_can('edit_post', $commentId)) {
            return;
        }

        wp_update_post(['ID' => $commentId, 'post_status' => 'publish']);
        if (class_exists(Audit::class)) {
            Audit::record('journal_comment_approved', $commentId, 'human_moderation');
        }

        wp_safe_redirect(wp_get_referer() ?: admin_url('edit.php?post_type=qt_journal_comment'));
        exit;
    }

    /* ─────────────── helpers ─────────────── */

    private static function fail(string $code, string $back): void
    {
        self::$errors[] = $code;
        $url = Flash::url($back, 'journal_comment', [
            'errors' => self::$errors,
            'old'    => self::$old,
        ]);
        wp_safe_redirect($url);
        exit;
    }

    private static function passesRate(): bool
    {
        $key = Security::rateKey('qt_jc_rate_');
        $lim = (int) apply_filters('quiet_truths_journal_comment_rate_limit', 8);
        $cnt = (int) get_transient($key);

        if ($cnt >= $lim) {
            return false;
        }
        set_transient($key, $cnt + 1, 10 * MINUTE_IN_SECONDS);
        return true;
    }

    private static function notifyAdmin(int $commentId, string $name, string $comment, int $journalId): void
    {
        $admin = get_option('admin_email');
        if (!$admin) {
            return;
        }

        $journal = get_post($journalId);

        wp_mail(
            $admin,
            __('[Quiet Truths] New Journal comment awaiting moderation', 'quiet-truths'),
            sprintf(
                "A comment has been submitted on a Journal.\n\nName: %s\nJournal: %s\n\nFor privacy, the comment text is not copied into email.\n\nModerate: %s",
                $name,
                $journal ? $journal->post_title : '#',
                admin_url('post.php?post=' . $commentId . '&action=edit')
            ),
            ['Content-Type: text/plain; charset=UTF-8']
        );
    }
}
