<?php
/** Quiet Truths least-privilege capability model. */
namespace QuietTruths\Core;

if (!defined('ABSPATH')) { exit; }

final class Capabilities
{
    private const VERSION = '2';

    public static function init(): void
    {
        add_action('admin_init', [self::class, 'sync']);
        add_action('after_switch_theme', [self::class, 'sync']);
    }

    /** @return list<string> */
    public static function all(): array
    {
        $caps = [
            'view_qt_privacy', 'manage_qt_lifecycle', 'manage_qt_audit',
            'manage_qt_health', 'manage_qt_governance',
        ];
        foreach ([
            ['qt_story', 'qt_stories'],
            ['qt_journal', 'qt_journals'],
            ['qt_response', 'qt_responses'],
            ['qt_journal_comment', 'qt_journal_comments'],
            ['qt_contact_message', 'qt_contact_messages'],
        ] as [$singular, $plural]) {
            foreach ([
                "edit_{$singular}", "read_{$singular}", "delete_{$singular}",
                "edit_{$plural}", "edit_others_{$plural}", "publish_{$plural}",
                "read_private_{$plural}", "delete_{$plural}",
                "delete_private_{$plural}", "delete_published_{$plural}",
                "delete_others_{$plural}", "edit_private_{$plural}",
                "edit_published_{$plural}", "create_{$plural}",
            ] as $cap) {
                $caps[] = $cap;
            }
        }
        return array_values(array_unique($caps));
    }

    public static function sync(): void
    {
        if ((string) get_option('qt_capabilities_version') === self::VERSION) {
            return;
        }
        $admin = get_role('administrator');
        if (!$admin) {
            return;
        }
        foreach (self::all() as $cap) {
            $admin->add_cap($cap);
        }
        update_option('qt_capabilities_version', self::VERSION, false);
    }
}
