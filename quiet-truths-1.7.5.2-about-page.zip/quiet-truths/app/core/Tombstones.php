<?php
/**
 * Quiet Truths — file-backed withdrawal/deletion tombstones.
 *
 * Kept outside the database so a database-only backup restoration cannot
 * silently resurrect content withdrawn after that backup. Contains only
 * content ID, event, UTC time and HMAC—never Story text or visitor data.
 */
namespace QuietTruths\Core;

use QuietTruths\Ai\ProfileLifecycle;

if (!defined('ABSPATH')) { exit; }

final class Tombstones
{
    public static function path(): string
    {
        return WP_CONTENT_DIR . '/qt-private/lifecycle-tombstones.jsonl';
    }

    public static function append(int $contentId, string $event): bool
    {
        if ($contentId < 1 || !in_array($event, ['withdrawn','declined','deleted'], true)) return false;
        $path = self::path(); $dir = dirname($path);
        if (!is_dir($dir) && !wp_mkdir_p($dir)) return false;
        if (!file_exists($dir . '/.htaccess')) {
            @file_put_contents($dir . '/.htaccess', "Require all denied\nDeny from all\n");
            @file_put_contents($dir . '/index.php', "<?php http_response_code(404); exit;\n");
        }
        $row = ['content_id'=>$contentId,'event'=>$event,'at_gmt'=>current_time('mysql',true)];
        $row['hmac'] = hash_hmac('sha256', implode('|',$row), (string) wp_salt('auth'));
        $written = @file_put_contents($path, wp_json_encode($row) . "\n", FILE_APPEND | LOCK_EX);
        @chmod($dir, 0700); @chmod($path, 0600);
        return false !== $written;
    }

    /** @return array{checked:int,enforced:int,invalid:int} */
    public static function reconcile(): array
    {
        $result=['checked'=>0,'enforced'=>0,'invalid'=>0];$path=self::path();
        if (!is_file($path)) return $result;
        $latest=[];
        foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
            $row=json_decode($line,true);$result['checked']++;
            if (!is_array($row)) {$result['invalid']++;continue;}
            $base=[(int)($row['content_id']??0),(string)($row['event']??''),(string)($row['at_gmt']??'')];
            $expected=hash_hmac('sha256',implode('|',$base),(string)wp_salt('auth'));
            if (empty($row['hmac'])||!hash_equals($expected,(string)$row['hmac'])) {$result['invalid']++;continue;}
            $id=$base[0];if($id<1)continue;
            if (!isset($latest[$id])||strcmp($base[2],$latest[$id]['at_gmt'])>0)$latest[$id]=['event'=>$base[1],'at_gmt'=>$base[2]];
        }
        foreach($latest as$id=>$row){$post=get_post($id);if(!$post)continue;
            if('deleted'===$row['event']){ProfileLifecycle::forget($id,'tombstone_deleted');wp_delete_post($id,true);$result['enforced']++;}
            elseif(in_array($row['event'],['withdrawn','declined'],true)&&!in_array($post->post_status,[StoryLifecycle::WITHDRAWN,StoryLifecycle::DECLINED],true)){
                update_post_meta($id,StoryLifecycle::AT_META,$row['at_gmt']);
                wp_update_post(['ID'=>$id,'post_status'=>'withdrawn'===$row['event']?StoryLifecycle::WITHDRAWN:StoryLifecycle::DECLINED]);
                ProfileLifecycle::forget($id,'tombstone_'.$row['event']);$result['enforced']++;
            }
        }
        update_option('qt_tombstone_last_reconcile',array_merge($result,['at_gmt'=>current_time('mysql',true)]),false);
        return $result;
    }
}
