<?php
/**
 * Quiet Truths — minimal administrative audit trail.
 *
 * Records accountable content-lifecycle events, never visitor IP addresses,
 * Story text, AI profiles or privacy evidence. Records expire after the
 * configured three-year audit period.
 *
 * @package QuietTruths\Core
 */

namespace QuietTruths\Core;

if (!defined('ABSPATH')) {
    exit;
}

final class Audit
{
    private const DB_VERSION = '1';
    private const DB_OPTION  = 'qt_audit_db_version';

    public static function init(): void
    {
        add_action('init', [self::class, 'maybeInstall'], 5);
        add_action('admin_menu', [self::class, 'registerPage']);
    }

    public static function table(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'qt_audit';
    }

    public static function maybeInstall(): void
    {
        if ((string) get_option(self::DB_OPTION) === self::DB_VERSION) {
            return;
        }
        if (!current_user_can('manage_options') && !wp_doing_cron()
            && !(defined('WP_CLI') && WP_CLI)) {
            return;
        }

        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $table   = self::table();
        dbDelta("CREATE TABLE {$table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            event_key varchar(191) DEFAULT NULL,
            occurred_gmt datetime NOT NULL,
            actor_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            content_id bigint(20) unsigned NOT NULL DEFAULT 0,
            event_type varchar(80) NOT NULL,
            reason varchar(120) NOT NULL DEFAULT '',
            data_json text NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY event_key (event_key),
            KEY content_id (content_id),
            KEY event_type (event_type),
            KEY occurred_gmt (occurred_gmt)
        ) {$charset};");
        update_option(self::DB_OPTION, self::DB_VERSION, false);
    }

    /**
     * @param array<string,scalar|null> $data Strictly non-content metadata.
     */
    public static function record(
        string $eventType,
        int $contentId = 0,
        string $reason = '',
        array $data = [],
        string $eventKey = ''
    ): bool {
        self::maybeInstall();
        global $wpdb;

        $safe = [];
        $allowedData = array_fill_keys([
            'post_type', 'removed_rows', 'children_deleted', 'consent_version',
            'deleted', 'audit_deleted', 'count', 'status', 'from', 'to',
        ], true);
        foreach ($data as $key => $value) {
            $key = sanitize_key((string) $key);
            if (!isset($allowedData[$key]) || (!is_scalar($value) && null !== $value)) {
                continue;
            }
            $safe[$key] = is_string($value)
                ? substr(sanitize_text_field($value), 0, 120)
                : $value;
        }

        $row = [
            'event_key'     => '' !== $eventKey ? substr(hash('sha256', $eventKey), 0, 64) : null,
            'occurred_gmt'  => current_time('mysql', true),
            'actor_user_id' => get_current_user_id(),
            'content_id'    => max(0, $contentId),
            'event_type'    => substr(sanitize_key($eventType), 0, 80),
            'reason'        => substr(sanitize_text_field($reason), 0, 120),
            'data_json'     => empty($safe) ? null : wp_json_encode($safe),
        ];

        $ok = $wpdb->insert(self::table(), $row, ['%s','%s','%d','%d','%s','%s','%s']);
        if (false === $ok && '' !== $eventKey) {
            // Idempotency-key collision means the event is already recorded.
            return true;
        }
        return false !== $ok;
    }

    public static function purgeOlderThanDays(int $days): int
    {
        global $wpdb;
        $days = max(1, $days);
        $cutoff = gmdate('Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS);

        return (int) $wpdb->query($wpdb->prepare(
            'DELETE FROM ' . self::table() . ' WHERE occurred_gmt < %s',
            $cutoff
        ));
    }

    public static function registerPage(): void
    {
        add_management_page(
            __('Quiet Truths Audit', 'quiet-truths'),
            __('Quiet Truths Audit', 'quiet-truths'),
            'manage_qt_audit',
            'qt-audit',
            [self::class, 'renderPage']
        );
    }

    public static function renderPage(): void
    {
        if (!current_user_can('manage_qt_audit')) {
            wp_die(esc_html__('You are not allowed to view the audit trail.', 'quiet-truths'));
        }
        global $wpdb;
        $rows = $wpdb->get_results('SELECT * FROM ' . self::table() . ' ORDER BY id DESC LIMIT 200', ARRAY_A);

        echo '<div class="wrap"><h1>' . esc_html__('Quiet Truths Audit', 'quiet-truths') . '</h1>';
        echo '<p>' . esc_html__('Minimum administrative events only. Story text, visitor IP addresses and AI/privacy findings are never copied here.', 'quiet-truths') . '</p>';
        echo '<table class="widefat striped"><thead><tr><th>' . esc_html__('Time (UTC)', 'quiet-truths') . '</th><th>' . esc_html__('Event', 'quiet-truths') . '</th><th>' . esc_html__('Content ID', 'quiet-truths') . '</th><th>' . esc_html__('Actor', 'quiet-truths') . '</th><th>' . esc_html__('Reason', 'quiet-truths') . '</th></tr></thead><tbody>';
        foreach ((array) $rows as $row) {
            echo '<tr><td>' . esc_html((string) $row['occurred_gmt']) . '</td><td>' . esc_html((string) $row['event_type']) . '</td><td>' . (int) $row['content_id'] . '</td><td>' . (int) $row['actor_user_id'] . '</td><td>' . esc_html((string) $row['reason']) . '</td></tr>';
        }
        if (empty($rows)) {
            echo '<tr><td colspan="5">' . esc_html__('No audited lifecycle events yet.', 'quiet-truths') . '</td></tr>';
        }
        echo '</tbody></table></div>';
    }
}
