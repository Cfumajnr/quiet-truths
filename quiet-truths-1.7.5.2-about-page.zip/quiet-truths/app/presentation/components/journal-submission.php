<?php
/**
 * Quiet Truths — Journal Submission (view layer)
 *
 * The formal editorial submission form for a Journal. Refined per the
 * Submit-a-Journal corrections: the form is unmistakably an EDITORIAL
 * submission, not instant publishing (§2, §29). Author information is
 * separated from publication information (§4), declarations are kept
 * separate (§17–§20), and copyright/privacy are made explicit (§21–§22).
 *
 * Processing lives in QuietTruths\Core\JournalSubmission.
 *
 * @package QuietTruths
 * @subpackage Presentation
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!shortcode_exists('qt_journal_submission')) {
    add_shortcode('qt_journal_submission', 'qt_journal_submission_shortcode');
}

if (!function_exists('qt_journal_submission_shortcode')) {
    function qt_journal_submission_shortcode(): string
    {
        ob_start();
        qt_journal_submission_form();
        return (string) ob_get_clean();
    }
}

if (!function_exists('qt_journal_submission_form')) {
    function qt_journal_submission_form(): void
    {
        if (!class_exists(\QuietTruths\Core\JournalSubmission::class)) {
            return;
        }

        if (\QuietTruths\Core\JournalSubmission::held()) {
            qt_journal_submission_confirmation();
            return;
        }
        if (class_exists(\QuietTruths\Core\Security::class)
            && !\QuietTruths\Core\Security::intakeOpen('journal')) {
            qt_gentle_notice('attention', __('Journal submissions are temporarily paused while the editorial and privacy arrangements are being completed.', 'quiet-truths'));
            return;
        }

        $errors = \QuietTruths\Core\JournalSubmission::errors();
        $old    = \QuietTruths\Core\JournalSubmission::old();
        $label  = \QuietTruths\Core\JournalSubmission::submitLabel();

        echo '<div class="qt-jsub">';

        if (!empty($errors)) {
            echo '<div class="qt-form__errors">';
            foreach ($errors as $code) {
                echo '<p>' . esc_html(qt_journal_submission_error($code)) . '</p>';
            }
            echo '</div>';
        }

        /* ── What the form is — the editorial nature is unmistakable ── */
        echo '<p class="qt-jsub__statement">' . esc_html__('Journals enter editorial review. Submitting does not publish — the house decides.', 'quiet-truths') . '</p>';
        echo '<p class="qt-jsub__note">' . esc_html__(
            'Submitting a Journal does not publish it. It enters editorial review: the house reads it, may seek clarification, and considers the writing, supporting material, permissions and other relevant details before deciding whether and how to publish it. A submission may be accepted, returned for clarification or editing, or declined.',
            'quiet-truths'
        ) . '</p>';

        echo '<form method="post" class="qt-form">';

        /* ── Author information — separated from publication (§4) ── */
        echo '<h2 class="qt-jsub__section">' . esc_html__('About you', 'quiet-truths') . '</h2>';
        echo '<p class="qt-form__hint qt-jsub__section-hint">' . esc_html__(
            'These details help us identify your submission, communicate with you and understand the context of your work. Not everything you provide here will necessarily appear publicly.',
            'quiet-truths'
        ) . '</p>';

        echo '<label class="qt-form__label" for="qt_j_name">' . esc_html__('Full name', 'quiet-truths') . ' <span aria-hidden="true">*</span></label>';
        echo '<input class="qt-form__input" id="qt_j_name" name="qt_j_name" type="text" required maxlength="100" autocomplete="name" value="' . esc_attr($old['name'] ?? '') . '">';
        echo '<p class="qt-form__hint">' . esc_html__(
            'Required for authorship and editorial communication. The author\'s name may appear publicly if the Journal is accepted, according to the publication and privacy framework of Quiet Truths.',
            'quiet-truths'
        ) . '</p>';

        echo '<label class="qt-form__label" for="qt_j_email">' . esc_html__('Email address', 'quiet-truths') . ' <span aria-hidden="true">*</span></label>';
        echo '<input class="qt-form__input" id="qt_j_email" name="qt_j_email" type="email" required maxlength="254" autocomplete="email" value="' . esc_attr($old['email'] ?? '') . '">';
        echo '<p class="qt-form__hint">' . esc_html__('Used for editorial communication, submission confirmation, and publication matters. It will not be published with your Journal.', 'quiet-truths') . '</p>';

        echo '<label class="qt-form__label" for="qt_j_whatsapp">' . esc_html__('WhatsApp number (optional)', 'quiet-truths') . '</label>';
        echo '<input class="qt-form__input" id="qt_j_whatsapp" name="qt_j_whatsapp" type="tel" maxlength="30" autocomplete="tel" value="' . esc_attr($old['whatsapp'] ?? '') . '">';
        echo '<p class="qt-form__hint">' . esc_html__(
            'You may provide a WhatsApp number if you would like Quiet Truths to have an additional way of contacting you about your submission. This will not be published with your Journal.',
            'quiet-truths'
        ) . '</p>';

        echo '<label class="qt-form__label" for="qt_j_profession">' . esc_html__('Profession / area of work (optional)', 'quiet-truths') . '</label>';
        echo '<input class="qt-form__input" id="qt_j_profession" name="qt_j_profession" type="text" maxlength="100" placeholder="' . esc_attr__('e.g. Teacher, Researcher, Journalist, Farmer…', 'quiet-truths') . '" value="' . esc_attr($old['profession'] ?? '') . '">';
        echo '<p class="qt-form__hint">' . esc_html__('Context about your perspective — not a declaration of expertise.', 'quiet-truths') . '</p>';

        echo '<label class="qt-form__label" for="qt_j_interests">' . esc_html__('Areas of interest (optional)', 'quiet-truths') . '</label>';
        echo '<textarea class="qt-form__textarea" id="qt_j_interests" name="qt_j_interests" rows="2" maxlength="500">' . esc_textarea($old['interests'] ?? '') . '</textarea>';
        echo '<p class="qt-form__hint">' . esc_html__(
            'Tell us about the subjects, questions or areas you commonly write, study, work with or think about. For example: Family, education, work and the changing experience of young adults in Kenya.',
            'quiet-truths'
        ) . '</p>';

        echo '<label class="qt-form__label" for="qt_j_bio">' . esc_html__('Author bio', 'quiet-truths') . ' <span aria-hidden="true">*</span></label>';
        echo '<textarea class="qt-form__textarea" id="qt_j_bio" name="qt_j_bio" rows="3" maxlength="800" required>' . esc_textarea($old['bio'] ?? '') . '</textarea>';
        echo '<p class="qt-form__hint">' . esc_html__(
            'A concise biography to accompany the Journal if accepted. Tell readers briefly who you are and what informs your perspective. The editorial team may edit it for clarity, length and presentation.',
            'quiet-truths'
        ) . '</p>';

        /* ── The Journal itself (§7, §12, §13) ── */
        echo '<h2 class="qt-jsub__section">' . esc_html__('The Journal', 'quiet-truths') . '</h2>';

        echo '<label class="qt-form__label" for="qt_j_title">' . esc_html__('Journal title', 'quiet-truths') . ' <span aria-hidden="true">*</span></label>';
        echo '<input class="qt-form__input" id="qt_j_title" name="qt_j_title" type="text" required maxlength="140" value="' . esc_attr($old['title'] ?? '') . '">';
        echo '<p class="qt-form__hint">' . esc_html__('Give your Journal a clear title that reflects what you are exploring.', 'quiet-truths') . '</p>';

        echo '<label class="qt-form__label" for="qt_j_content">' . esc_html__('Journal content', 'quiet-truths') . ' <span aria-hidden="true">*</span></label>';
        echo '<p class="qt-form__hint">' . esc_html__(
            'A considered piece exploring a subject, question, pattern or idea more deeply. Headings, paragraphs, quotations and links are welcome.',
            'quiet-truths'
        ) . '</p>';
        echo '<textarea class="qt-form__textarea qt-form__textarea--large" id="qt_j_content" name="qt_j_content" rows="14" maxlength="40000" required>' . esc_textarea($old['content'] ?? '') . '</textarea>';

        /* ── Supporting material ── */
        echo '<h2 class="qt-jsub__section">' . esc_html__('Supporting material', 'quiet-truths') . '</h2>';
        echo '<p class="qt-form__hint qt-jsub__warn"><strong>'
            . esc_html__('Files are not accepted through this form yet.', 'quiet-truths') . '</strong> '
            . esc_html__('If the editorial team needs a photograph, screenshot, chart or document, it will request it through a separate secure channel after reviewing the writing. Please do not paste private messages, phone numbers, account details or other identifying material into the Journal text.', 'quiet-truths')
            . '</p>';
        echo '<input type="hidden" name="qt_j_material" value="self">';

        /* ── Declarations — each kept separate (§16–§19) ── */
        echo '<h2 class="qt-jsub__section">' . esc_html__('Declarations', 'quiet-truths') . '</h2>';

        // Age (§16) — a separate, mandatory declaration.
        echo '<label class="qt-form__checkbox"><input type="checkbox" name="qt_j_age" value="1" required> '
            . esc_html__('I confirm that I am 18 years of age or older.', 'quiet-truths') . '</label>';

        // Authorship & permissions (§17) — a separate, mandatory declaration.
        echo '<label class="qt-form__checkbox"><input type="checkbox" name="qt_j_copyright" value="1" required> '
            . esc_html__('I confirm that the material I have submitted is my own work or that I have the necessary rights and permissions to submit and publish it.', 'quiet-truths') . '</label>';

        // Journal Terms (§18) — separate from Copyright.
        echo '<label class="qt-form__checkbox"><input type="checkbox" name="qt_j_terms" value="1" required> '
            . esc_html__('I have read and agree to the Quiet Truths Journal Terms.', 'quiet-truths')
            . ' <a href="' . esc_url(\QuietTruths\Core\Governance::pageUrl('journal-terms')) . '" target="_blank" rel="noopener">' . esc_html__('Read the Journal Terms', 'quiet-truths') . '</a></label>';

        // Copyright (§18) — a separate acknowledgement linking to its own
        // document, so copyright is not buried inside the Journal Terms.
        echo '<label class="qt-form__checkbox"><input type="checkbox" name="qt_j_copyright_terms" value="1" required> '
            . esc_html__('I have read and agree to the Quiet Truths Journal Copyright Policy.', 'quiet-truths')
            . ' <a href="' . esc_url(\QuietTruths\Core\Governance::pageUrl('journal-copyright')) . '" target="_blank" rel="noopener">' . esc_html__('Read the Copyright Policy', 'quiet-truths') . '</a></label>';

        /* ── Privacy reference (§20) ── */
        echo '<p class="qt-form__hint qt-jsub__links">';
        echo '<a href="' . esc_url(\QuietTruths\Core\Governance::pageUrl('privacy')) . '" target="_blank" rel="noopener">' . esc_html__('Read the Privacy information', 'quiet-truths') . '</a>';
        echo '</p>';

        /* ── What happens after you submit (§3) ── */
        echo '<div class="qt-jsub__after">';
        echo '<h3 class="qt-jsub__after-title">' . esc_html__('What happens after you submit', 'quiet-truths') . '</h3>';
        echo '<p class="qt-form__hint">' . esc_html__(
            'The house reads your Journal and may contact you if clarification or additional information is needed. We may review the writing, supporting material, copyright and permissions, and other details provided with the submission before deciding whether and how to publish it. A Journal may be accepted, returned for clarification or editing, or declined. Submitting a Journal does not guarantee publication.',
            'quiet-truths'
        ) . '</p>';
        echo '</div>';

        /* ── Editorial-review acknowledgement, immediately before submit (§19) ── */
        echo '<label class="qt-form__checkbox qt-jsub__editorial-ack"><input type="checkbox" name="qt_j_editorial" value="1" required> '
            . esc_html__('I understand that submitting a Journal does not guarantee publication and that Quiet Truths may review, edit, request clarification, accept, return or decline a submission before publication.', 'quiet-truths') . '</label>';

        /* ── Submit (§22) ── */
        echo '<div class="qt-form__row">';
        echo '<input type="hidden" name="_wpnonce" value="' . esc_attr(\QuietTruths\Core\JournalSubmission::nonce()) . '">';
        echo '<input type="hidden" name="qt_website" value="">';
        echo '<input type="hidden" name="qt_journal_submit" value="1">';
        echo '<button class="qt-button qt-button--primary" type="submit">' . esc_html($label) . '</button>';
        echo '</div>';

        echo '</form>';
        echo '</div>';
    }
}

if (!function_exists('qt_journal_submission_confirmation')) {
    function qt_journal_submission_confirmation(): void
    {
        echo '<div class="qt-jsub qt-jsub--done">';
        echo '<p class="qt-jsub__done-title">' . esc_html__('Your Journal has been submitted for editorial review.', 'quiet-truths') . '</p>';
        echo '<p>' . esc_html__(
            'Thank you for trusting Quiet Truths with your work. Your submission has been received and will be considered by our editorial team. Submission does not guarantee publication. If we need clarification or additional information, we will contact you using the details you provided.',
            'quiet-truths'
        ) . '</p>';
        echo '<p><a class="qt-button qt-button--quiet" href="' . esc_url(home_url('/journals/')) . '">' . esc_html__('Return to the Journals', 'quiet-truths') . '</a></p>';
        echo '</div>';
    }
}

if (!function_exists('qt_journal_submission_error')) {
    function qt_journal_submission_error(string $code): string
    {
        $map = [
            'closed'      => __('Journal submissions are temporarily paused.', 'quiet-truths'),
            'session'     => __('Your session expired — please try again.', 'quiet-truths'),
            'rate'        => __('You have submitted too recently. Please wait a little and try again.', 'quiet-truths'),
            'name'        => __('Please provide your full name.', 'quiet-truths'),
            'email'       => __('Please provide a valid email address.', 'quiet-truths'),
            'whatsapp'    => __('Please keep the optional WhatsApp number under 30 characters.', 'quiet-truths'),
            'bio'         => __('Please provide an author bio.', 'quiet-truths'),
            'bio_long'    => __('Your author bio is too long.', 'quiet-truths'),
            'profession'  => __('Your profession entry is too long.', 'quiet-truths'),
            'interests'   => __('Your areas of interest entry is too long.', 'quiet-truths'),
            'title'       => __('Please provide a Journal title.', 'quiet-truths'),
            'short'       => __('Your Journal is too short — a considered piece needs more depth.', 'quiet-truths'),
            'long'        => __('Your Journal is too long.', 'quiet-truths'),
            'profanity'   => __('That contains language the house cannot accept.', 'quiet-truths'),
            'age'         => __('You must confirm that you are 18 or older.', 'quiet-truths'),
            'copyright'   => __('You must confirm your rights or permissions to the material.', 'quiet-truths'),
            'terms'       => __('You must agree to the Journal Terms.', 'quiet-truths'),
            'copyright_terms' => __('You must agree to the Journal Copyright Policy.', 'quiet-truths'),
            'editorial'   => __('You must acknowledge that submission does not guarantee publication.', 'quiet-truths'),
            'material'    => __('Please choose your relationship to the supporting material.', 'quiet-truths'),
            'store'       => __('Your submission could not be stored. Please try again later.', 'quiet-truths'),
        ];

        return $map[$code] ?? __('There was a problem with your submission.', 'quiet-truths');
    }
}
