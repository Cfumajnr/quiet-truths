<?php
/**
 * Quiet Truths — Public Story Form (view layer)
 *
 * The journal. Leave what you've been carrying: an optional title,
 * a room, the story itself, optional content warnings. The form does not
 * ask for identity details; limited technical security data still exists.
 * The writing assistant rides
 * along (word count, repeated words, room suggestions).
 *
 * Processing lives in QuietTruths\Core\Submission.
 *
 * @package QuietTruths
 * @subpackage Presentation
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!shortcode_exists('qt_leave_a_story')) {
    add_shortcode('qt_leave_a_story', 'qt_story_form_shortcode');
}

if (!function_exists('qt_story_form_shortcode')) {
    function qt_story_form_shortcode(): string
    {
        if (class_exists(\QuietTruths\Core\Submission::class)) {
            $handle = 'qt-writer';

            wp_register_script($handle, QT_ASSETS_URI . '/js/writer.js', [], QT_THEME_VERSION, true);
            wp_enqueue_script($handle);
            wp_localize_script($handle, 'QTWriter', \QuietTruths\Core\Submission::writerAssistantData());
        }

        ob_start();
        qt_story_form();
        return (string) ob_get_clean();
    }
}

if (!function_exists('qt_story_form')) {
    function qt_story_form(): void
    {
        if (!class_exists(\QuietTruths\Core\Submission::class)) {
            return;
        }

        if (\QuietTruths\Core\Submission::held()) {
            qt_story_form_confirmation();
            return;
        }
        if (class_exists(\QuietTruths\Core\Security::class)
            && !\QuietTruths\Core\Security::intakeOpen('story')) {
            qt_gentle_notice('attention', __('Story submissions are temporarily paused while the house is being prepared. The reading rooms and contact route remain open.', 'quiet-truths'));
            return;
        }

        $errors   = \QuietTruths\Core\Submission::errors();
        $maxLen   = (int) apply_filters('quiet_truths_story_max_length', 4000);
        $minWords = (int) apply_filters('quiet_truths_story_min_words', 20);
        $rooms    = defined('QT_ROOMS') ? QT_ROOMS : [];

        $qt_visits = \QuietTruths\Core\Submission::writerCount();
        if ($qt_visits >= 2) {
            echo '<p class="qt-writer__welcome">' . esc_html(sprintf(
                /* translators: %d number of stories this voice has left */
                __('Welcome back — this is your %dth story. The house remembers your voice, if not your name.', 'quiet-truths'),
                $qt_visits
            )) . '</p>';
        }

        if (!empty($errors)) {
            echo '<ul class="qt-form__error" role="alert">';
            foreach ($errors as $code) {
                echo '<li>' . esc_html(qt_story_form_error_message($code)) . '</li>';
            }
            echo '</ul>';
        }

        /* ── The journal ── */
        echo '<form class="qt-form qt-form--journal" method="post">';

        /* Story title (optional) */
        echo '<div class="qt-form__field">';
        echo '<label class="qt-form__label" for="qt_heading">' . esc_html__('Story title', 'quiet-truths')
            . ' <span class="u-text-subtle">(' . esc_html__('optional — the house can find one for you', 'quiet-truths') . ')</span></label>';
        echo '<input class="qt-form__input" type="text" id="qt_heading" name="qt_heading" maxlength="120" value="'
            . esc_attr(\QuietTruths\Core\Submission::old('heading')) . '">';
        echo '</div>';

        /* How the piece should be read — fiction must never be presented as fact. */
        echo '<div class="qt-form__field">';
        echo '<label class="qt-form__label" for="qt_story_kind">' . esc_html__('How should this be read?', 'quiet-truths') . '</label>';
        echo '<select class="qt-form__select" id="qt_story_kind" name="qt_story_kind" required>';
        echo '<option value="">' . esc_html__('Choose one…', 'quiet-truths') . '</option>';
        echo '<option value="experience"' . selected(\QuietTruths\Core\Submission::old('kind'), 'experience', false) . '>' . esc_html__('My lived experience', 'quiet-truths') . '</option>';
        echo '<option value="fiction"' . selected(\QuietTruths\Core\Submission::old('kind'), 'fiction', false) . '>' . esc_html__('Fiction', 'quiet-truths') . '</option>';
        echo '<option value="composite"' . selected(\QuietTruths\Core\Submission::old('kind'), 'composite', false) . '>' . esc_html__('A composite, or details changed for privacy', 'quiet-truths') . '</option>';
        echo '</select>';
        echo '<span class="qt-form__hint">' . esc_html__('This helps the house avoid presenting fiction or changed details as a verified factual account.', 'quiet-truths') . '</span>';
        echo '</div>';

        /* Room */
        echo '<div class="qt-form__field">';
        echo '<label class="qt-form__label" for="qt_room">' . esc_html__('A room', 'quiet-truths') . '</label>';
        echo '<select class="qt-form__select" id="qt_room" name="qt_room" required>';
        echo '<option value="">' . esc_html__('Choose where this story belongs…', 'quiet-truths') . '</option>';
        foreach ($rooms as $slug => $room) {
            echo '<option value="' . esc_attr($slug) . '"' . selected(\QuietTruths\Core\Submission::old('room'), $slug, false) . '>'
                . esc_html($room['name']) . '</option>';
        }
        echo '</select>';
        echo '</div>';

        /* The story body */
        echo '<div class="qt-form__field">';
        echo '<label class="qt-form__label" for="qt_story">' . esc_html__('Your story', 'quiet-truths') . '</label>';
        echo '<textarea class="qt-form__textarea" id="qt_story" name="qt_story_text" rows="12" maxlength="' . esc_attr((string) $maxLen) . '" placeholder="' . esc_attr__('Write as you would speak it — plainly, and without hurry.', 'quiet-truths') . '" data-qt-writer required>'
            . esc_textarea(\QuietTruths\Core\Submission::old('story')) . '</textarea>';

        /* Live writing assistant */
        echo '<div class="qt-writer">';
        echo '<span class="qt-writer__counter" id="qt-writer-count" aria-live="polite"></span>';
        echo '<div class="qt-writer__chips" id="qt-writer-repeats"></div>';
        echo '<p class="qt-writer__warn" id="qt-writer-warn" role="alert"></p>';
        echo '</div>';

        echo '<span class="qt-form__hint">' . esc_html(sprintf(
            /* translators: %1$d minimum words, %2$d maximum characters */
            __('At least %1$d words — a few lines at least — and up to %2$s characters. As you write, the house will suggest rooms this story could belong to.', 'quiet-truths'),
            $minWords,
            number_format_i18n($maxLen)
        )) . '</span>';
        echo '</div>';

        /* Optional content warnings */
        echo '<div class="qt-form__field">';
        echo '<label class="qt-form__label" for="qt_warnings">' . esc_html__('Content warnings', 'quiet-truths')
            . ' <span class="u-text-subtle">(' . esc_html__('optional — so readers can prepare', 'quiet-truths') . ')</span></label>';
        echo '<input class="qt-form__input" type="text" id="qt_warnings" name="qt_warnings" maxlength="200" value="'
            . esc_attr(\QuietTruths\Core\Submission::old('warnings')) . '" placeholder="' . esc_attr__('e.g. grief, illness, loss', 'quiet-truths') . '">';
        echo '</div>';

        /* ── Room suggestions (filled live by writer.js) ── */
        echo '<div class="qt-suggest" id="qt-suggest" hidden>';
        echo '<p class="qt-suggest__label">' . esc_html__('The house suggests these rooms', 'quiet-truths') . '</p>';
        echo '<div class="qt-suggest__chips" id="qt-suggest-chips"></div>';
        echo '<p class="qt-suggest__note">' . esc_html__('You suggest where it belongs. An editor may move it if another room holds it more safely or clearly.', 'quiet-truths') . '</p>';
        echo '</div>';

        /* ── Anonymous notice + consent ── */
        echo '<div class="qt-anon-note">';
        echo '<span class="qt-anon-note__mark" aria-hidden="true">✦</span>';
        echo '<p>' . esc_html__('For adults 18+. Do not name or identify another person. Your submission is held privately for human moderation and may be edited and published anonymously if accepted. Technical security data is processed. Read the Privacy Notice, House Rules and Submission Terms.', 'quiet-truths') . '</p>';
        if (class_exists(\QuietTruths\Core\Governance::class)) {
            $privacy_url  = \QuietTruths\Core\Governance::pageUrl('privacy');
            $rules_url    = \QuietTruths\Core\Governance::pageUrl('house-rules') ?: \QuietTruths\Core\Governance::pageUrl('editorial-policy');
            $terms_url    = \QuietTruths\Core\Governance::pageUrl('submission-terms');
            $links = [];
            if ($privacy_url)  $links[] = '<a href="' . esc_url($privacy_url) . '" target="_blank" rel="noopener">' . esc_html__('Privacy Notice', 'quiet-truths') . '</a>';
            if ($rules_url)    $links[] = '<a href="' . esc_url($rules_url) . '" target="_blank" rel="noopener">' . esc_html__('House Rules', 'quiet-truths') . '</a>';
            if ($terms_url)    $links[] = '<a href="' . esc_url($terms_url) . '" target="_blank" rel="noopener">' . esc_html__('Submission Terms', 'quiet-truths') . '</a>';
            if ($links) {
                echo '<p class="qt-form__legal-links">' . implode(' · ', $links) . '</p>';
            }
        }
        echo '</div>';

        echo '<div class="qt-form__consent">';
        echo '<label class="qt-form__check"><input type="checkbox" name="qt_consent_age_rules" value="1" required> '
            . esc_html__('I am 18 or older, this is my own work or I have permission to submit it, I have not named or knowingly identified another person, and I accept the House Rules and Submission Terms.', 'quiet-truths') . '</label>';
        echo '<label class="qt-form__check"><input type="checkbox" name="qt_consent_publish" value="1" required> '
            . esc_html__('I consent to Quiet Truths receiving, reviewing, gently editing, and — if accepted — publishing this submission anonymously, including any sensitive personal details I choose to include.', 'quiet-truths') . '</label>';
        echo '</div>';

        echo '<input type="text" name="qt_website" class="qt-hp" tabindex="-1" autocomplete="off" aria-hidden="true">';
        wp_nonce_field('qt_leave_story');
        echo '<div class="qt-form__submit">';
        echo '<button class="qt-button qt-button--primary" type="submit" name="qt_story_submit" value="1">'
            . esc_html__('Leave my story', 'quiet-truths') . '</button>';
        echo '</div>';

        echo '</form>';
    }
}

if (!function_exists('qt_story_form_confirmation')) {
    function qt_story_form_confirmation(): void
    {
        $again = remove_query_arg(['qt_held', 'qt_ref'], home_url(add_query_arg([])));
        $data  = \QuietTruths\Core\Submission::confirmationData();
        $visits = (int) $data['visits'];
        ?>
        <div class="qt-held">
            <?php qt_hope_marker(__('Held', 'quiet-truths')); ?>
            <p class="qt-held__line"><?php echo esc_html__('Your story is being held.', 'quiet-truths'); ?></p>
            <p class="qt-held__detail">
                <?php echo esc_html__('It rests now in the private queue, where it will be read slowly. If it is given a place, it will appear in its room — anonymous, kept whole, and never used against the one who shared it.', 'quiet-truths'); ?>
            </p>

            <?php if ($visits >= 2) : ?>
                <p class="qt-writer__welcome" style="margin-bottom:var(--space-xl)">
                    <?php echo esc_html(sprintf(
                        /* translators: %d number of stories this voice has left */
                        __('This is your %dth story in the house. Welcome home.', 'quiet-truths'),
                        $visits
                    )); ?>
                </p>
            <?php endif; ?>

            <?php if (!empty($data['related'])) : ?>
                <div class="qt-related">
                    <p class="rooms-section__label"><?php echo esc_html__('While you wait — stories like yours', 'quiet-truths'); ?></p>
                    <div class="story-feed" style="padding:0">
                        <?php foreach ($data['related'] as $qt_related) : ?>
                            <?php qt_story_panel($qt_related); ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>

            <a class="qt-button qt-button--quiet" style="margin-top:var(--space-xl)" href="<?php echo esc_url($again); ?>">
                <?php echo esc_html__('Leave another story', 'quiet-truths'); ?>
            </a>
        </div>
        <?php
    }
}

if (!function_exists('qt_story_form_error_message')) {
    function qt_story_form_error_message(string $code): string
    {
        $minWords = (int) apply_filters('quiet_truths_story_min_words', 20);

        $messages = [
            'closed'     => __('Story submissions are temporarily paused.', 'quiet-truths'),
            'session'    => __('Your session expired — please try again.', 'quiet-truths'),
            'rate'       => __('The house receives stories slowly, so that each one is held properly. Please try again in a few minutes.', 'quiet-truths'),
            'rate_hour'  => __('You have already shared a story this hour. The house keeps a limited number each hour — please come back a little later.', 'quiet-truths'),
            'rate_day'   => __('You have shared several stories today — the house is grateful. Please return tomorrow with the next one.', 'quiet-truths'),
            'short'      => sprintf(
                /* translators: %d minimum number of words */
                __('A story needs at least %d words — a blank or one-word note cannot be held. Give it a little more room to breathe.', 'quiet-truths'),
                $minWords
            ),
            'long'       => __('This story is longer than one note can hold — please share up to 4,000 characters, or continue in a second story.', 'quiet-truths'),
            'heading'    => __('The title is a little long — please keep it under 120 characters.', 'quiet-truths'),
            'warnings'   => __('The content warnings are a little long — please keep them under 200 characters.', 'quiet-truths'),
            'room'       => __('Please choose a room for this story.', 'quiet-truths'),
            'kind'       => __('Please say whether this is lived experience, fiction, or a composite with details changed.', 'quiet-truths'),
            'profanity'  => __('This wording needs human review; please check that it does not direct abuse at another person.', 'quiet-truths'),
            'consent_age'   => __('Please confirm you are 18 or older and accept the House Rules and Submission Terms before leaving a story.', 'quiet-truths'),
            'consent_publish' => __('Please confirm consent to review and — if accepted — publish your submission anonymously.', 'quiet-truths'),
            'store'      => __('Something went wrong while the story was being kept. Please try again.', 'quiet-truths'),
        ];

        return $messages[$code] ?? __('Something went wrong. Please try again.', 'quiet-truths');
    }
}
