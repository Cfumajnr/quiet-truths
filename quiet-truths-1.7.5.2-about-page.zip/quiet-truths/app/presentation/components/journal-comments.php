<?php
/**
 * Quiet Truths — Journal Comments (view layer)
 *
 * The conversation beneath a Journal — attributable, moderated, shallow
 * nesting, no counts, no reactions (Journal Bible §19–§25). Processing
 * lives in QuietTruths\Core\JournalComments.
 *
 * @package QuietTruths
 * @subpackage Presentation
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('qt_journal_conversation')) {
    /**
     * The conversation section for a single Journal.
     */
    function qt_journal_conversation(int $journalId): void
    {
        if (!class_exists(\QuietTruths\Core\JournalComments::class)) {
            return;
        }

        $state  = class_exists(\QuietTruths\Core\Flash::class)
            ? \QuietTruths\Core\Flash::pull('journal_comment')
            : [];
        $errors = !empty($state['errors']) && is_array($state['errors'])
            ? $state['errors']
            : \QuietTruths\Core\JournalComments::errors();
        $old    = !empty($state['old']) && is_array($state['old']) ? $state['old'] : [];

        $message = '';
        if (isset($_GET['qt_jc_held'])) {
            $message = __('Your comment is held before it appears — the house reads the conversation too.', 'quiet-truths');
        }

        $comments = \QuietTruths\Core\JournalComments::forJournal($journalId);

        echo '<section class="qt-jconversation" id="qt-journal-conversation">';
        echo '<p class="qt-jconversation__heading">' . esc_html__('Conversation', 'quiet-truths') . '</p>';
        echo '<p class="qt-jconversation__invite">' . esc_html__('What do you think?', 'quiet-truths') . '</p>';

        if ('' !== $message) {
            echo '<p class="qt-jconversation__message">' . esc_html($message) . '</p>';
        }
        if (!empty($errors)) {
            echo '<div class="qt-form__errors">';
            foreach ($errors as $code) {
                echo '<p>' . esc_html(qt_journal_comment_error($code)) . '</p>';
            }
            echo '</div>';
        }

        // No comment count is ever shown (§25) — the conversation just is.
        echo '<div class="qt-jconversation__flow">';
        if (empty($comments)) {
            echo '<p class="qt-jconversation__empty">' . esc_html__('The conversation is open. Your thoughts would be the first.', 'quiet-truths') . '</p>';
        } else {
            foreach ($comments as $comment) {
                qt_journal_comment_thread($journalId, $comment, 0);
            }
        }
        echo '</div>';

        $intakeOpen = !class_exists(\QuietTruths\Core\Security::class)
            || \QuietTruths\Core\Security::intakeOpen('journal_comment');
        if (!$intakeOpen) {
            echo '<p class="qt-jconversation__message">' . esc_html__('New Journal comments are temporarily paused.', 'quiet-truths') . '</p>';
            echo '</section>';
            return;
        }

        echo '<div class="qt-jconversation__formwrap">';
        echo '<p class="qt-jconversation__form-label">' . esc_html__('Join the conversation', 'quiet-truths') . '</p>';

        // Name / email / comment (§20).
        echo '<form method="post" class="qt-form" novalidate>';

        echo '<div class="qt-form__grid2">';
        echo '<div><label class="qt-form__label" for="qt_jc_name">' . esc_html__('Name', 'quiet-truths') . ' <span aria-hidden="true">*</span></label>';
        echo '<input class="qt-form__input" id="qt_jc_name" name="qt_jc_name" type="text" required maxlength="80" autocomplete="name" value="' . esc_attr($old['name'] ?? '') . '"></div>';
        echo '<div><label class="qt-form__label" for="qt_jc_email">' . esc_html__('Email address', 'quiet-truths') . ' <span aria-hidden="true">*</span></label>';
        echo '<input class="qt-form__input" id="qt_jc_email" name="qt_jc_email" type="email" required maxlength="254" autocomplete="email" value="' . esc_attr($old['email'] ?? '') . '"></div>';
        echo '</div>';
        echo '<p class="qt-form__hint">' . esc_html__('Your email address is kept private. It is used by Quiet Truths for moderation and will not be displayed with your comment.', 'quiet-truths') . '</p>';

        echo '<label class="qt-form__label" for="qt_jc_comment">' . esc_html__('Comment', 'quiet-truths') . ' <span aria-hidden="true">*</span></label>';
        echo '<textarea class="qt-form__textarea" id="qt_jc_comment" name="qt_jc_comment" rows="4" maxlength="2000" required>' . esc_textarea($old['comment'] ?? '') . '</textarea>';
        echo '<label class="qt-form__checkbox"><input type="checkbox" name="qt_jc_age_rules" value="1" required> '
            . esc_html__('I am 18 or older and understand that this comment is held for moderation before publication.', 'quiet-truths') . '</label>';

        echo '<div class="qt-form__row">';
        echo '<input type="hidden" name="_wpnonce" value="' . esc_attr(\QuietTruths\Core\JournalComments::nonce($journalId)) . '">';
        echo '<input type="hidden" name="qt_website" value="">';
        echo '<input type="hidden" name="qt_parent" value="0">';
        echo '<input type="hidden" name="qt_jc_action" value="add">';
        echo '<button class="qt-button qt-button--primary" type="submit">' . esc_html__('Share my thought', 'quiet-truths') . '</button>';
        echo '</div>';

        echo '</form>';
        echo '</div>';

        echo '</section>';
    }
}

if (!function_exists('qt_journal_comment_thread')) {
    /**
     * One comment and, nested beneath it, its replies — shallow and
     * subordinate so the Journal stays the centre (§22).
     */
    function qt_journal_comment_thread(int $journalId, \WP_Post $comment, int $depth = 0): void
    {
        $depthClass = min($depth, 2);
        $isAuthor   = \QuietTruths\Core\JournalComments::isAuthor($comment);
        $intakeOpen = !class_exists(\QuietTruths\Core\Security::class)
            || \QuietTruths\Core\Security::intakeOpen('journal_comment');
        $replies    = \QuietTruths\Core\JournalComments::forJournal($journalId, $comment->ID);

        echo '<div class="qt-jcomment" id="jc-' . (int) $comment->ID . '" data-depth="' . (int) $depthClass . '">';
        echo '<div class="qt-jcomment__meta">';
        echo '<span class="qt-jcomment__name">' . esc_html(\QuietTruths\Core\JournalComments::publicName($comment)) . '</span>';
        if ($isAuthor) {
            echo '<span class="qt-jcomment__author-tag">' . esc_html__('Author', 'quiet-truths') . '</span>';
        }
        echo '<span aria-hidden="true">·</span><span>' . esc_html(qt_relative_time(get_post_time('U', true, $comment))) . '</span>';
        echo '</div>';
        echo '<div class="qt-jcomment__body">' . wp_kses_post(wpautop(esc_html((string) $comment->post_content))) . '</div>';

        if ($intakeOpen) {
            echo '<div class="qt-jcomment__actions">';
            echo '<button type="button" class="qt-jcomment__reply-toggle" data-qt-jreply="qt-jreply-' . (int) $comment->ID . '">' . esc_html__('Reply', 'quiet-truths') . '</button>';
            echo '</div>';

            /* Reply form — hidden until toggled */
            echo '<form method="post" class="qt-form qt-jcomment__reply" id="qt-jreply-' . (int) $comment->ID . '" hidden>';
        echo '<div class="qt-form__grid2">';
        echo '<div><label class="qt-form__label" for="qt_jc_name_r' . (int) $comment->ID . '">' . esc_html__('Name', 'quiet-truths') . ' <span aria-hidden="true">*</span></label>';
        echo '<input class="qt-form__input" id="qt_jc_name_r' . (int) $comment->ID . '" name="qt_jc_name" type="text" required maxlength="80" autocomplete="name"></div>';
        echo '<div><label class="qt-form__label" for="qt_jc_email_r' . (int) $comment->ID . '">' . esc_html__('Email address', 'quiet-truths') . ' <span aria-hidden="true">*</span></label>';
        echo '<input class="qt-form__input" id="qt_jc_email_r' . (int) $comment->ID . '" name="qt_jc_email" type="email" required maxlength="254" autocomplete="email"></div>';
        echo '</div>';
        echo '<label class="qt-form__label" for="qt_jc_comment_r' . (int) $comment->ID . '">' . esc_html__('Reply', 'quiet-truths') . ' <span aria-hidden="true">*</span></label>';
        echo '<textarea class="qt-form__textarea" id="qt_jc_comment_r' . (int) $comment->ID . '" name="qt_jc_comment" rows="3" maxlength="2000" required></textarea>';
        echo '<label class="qt-form__checkbox"><input type="checkbox" name="qt_jc_age_rules" value="1" required> '
            . esc_html__('I am 18 or older and understand that this reply is held for moderation before publication.', 'quiet-truths') . '</label>';
        echo '<div class="qt-form__row">';
        echo '<input type="hidden" name="_wpnonce" value="' . esc_attr(\QuietTruths\Core\JournalComments::nonce($journalId)) . '">';
        echo '<input type="hidden" name="qt_website" value="">';
        echo '<input type="hidden" name="qt_parent" value="' . (int) $comment->ID . '">';
        echo '<input type="hidden" name="qt_jc_action" value="add">';
        echo '<button class="qt-button qt-button--quiet" type="submit">' . esc_html__('Send reply', 'quiet-truths') . '</button>';
        echo '</div>';
            echo '</form>';
        }

        /* Nested replies — subordinate (§22) */
        if (!empty($replies)) {
            echo '<div class="qt-jcomment__replies">';
            foreach ($replies as $reply) {
                qt_journal_comment_thread($journalId, $reply, $depth + 1);
            }
            echo '</div>';
        }

        echo '</div>';
    }
}

if (!function_exists('qt_journal_comment_error')) {
    function qt_journal_comment_error(string $code): string
    {
        $map = [
            'closed'    => __('New Journal comments are temporarily paused.', 'quiet-truths'),
            'session'   => __('Your session expired — please try again.', 'quiet-truths'),
            'invalid'   => __('That conversation is not open.', 'quiet-truths'),
            'rate'      => __('You are commenting too often. Please wait a moment.', 'quiet-truths'),
            'name'      => __('Please provide your name.', 'quiet-truths'),
            'email'     => __('Please provide a valid email address.', 'quiet-truths'),
            'short'     => __('Your comment is too short.', 'quiet-truths'),
            'long'      => __('Your comment is too long.', 'quiet-truths'),
            'profanity' => __('That contains language the house cannot accept.', 'quiet-truths'),
            'consent'   => __('Please confirm that you are 18 or older and accept pre-publication moderation.', 'quiet-truths'),
            'store'     => __('Your comment could not be stored. Please try again later.', 'quiet-truths'),
        ];

        return $map[$code] ?? __('There was a problem submitting your comment.', 'quiet-truths');
    }
}
