<?php
/**
 * Quiet Truths — Contact Form (view layer)
 *
 * The house's front desk. Contact is NOT anonymous: messages,
 * questions and journal enquiries need replies, so name and email are
 * required (phone optional). Use [qt_contact] anywhere.
 *
 * Processing lives in QuietTruths\Core\Contact.
 *
 * @package QuietTruths
 * @subpackage Presentation
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!shortcode_exists('qt_contact')) {
    add_shortcode('qt_contact', 'qt_contact_form_shortcode');
}

if (!function_exists('qt_contact_form_shortcode')) {
    function qt_contact_form_shortcode(): string
    {
        ob_start();
        qt_contact_form();
        return (string) ob_get_clean();
    }
}

if (!function_exists('qt_contact_form')) {
    function qt_contact_form(): void
    {
        if (!class_exists(\QuietTruths\Core\Contact::class)) {
            return;
        }

        if (\QuietTruths\Core\Contact::sent()) {
            qt_contact_form_confirmation();
            return;
        }

        $state  = class_exists(\QuietTruths\Core\Flash::class)
            ? \QuietTruths\Core\Flash::pull('contact')
            : [];
        $errors = !empty($state['errors']) && is_array($state['errors']) ? $state['errors'] : [];
        $old    = !empty($state['old']) && is_array($state['old']) ? $state['old'] : [];

        /* ── Clarifying paragraph — what this form is for ── */
        echo '<p class="qt-form__intro">'
            . esc_html__('Write to Quiet Truths. Questions, feedback, corrections, collaborations, or anything you would like us to read. Because these need a reply, please leave your name and email. They are used to handle and answer your enquiry, retained only under the Privacy Notice, and never added to a marketing list.', 'quiet-truths')
            . '</p>';

        if (class_exists(\QuietTruths\Core\Governance::class)) {
            $privacy_url = \QuietTruths\Core\Governance::pageUrl('privacy');
            if ($privacy_url) {
                echo '<p class="qt-form__legal-notice">';
                echo wp_kses(
                    sprintf(
                        /* translators: %s privacy notice link */
                        __('We use your name, email, optional phone and message only to handle and reply to this enquiry, protect the service, and meet legal obligations. We do not add you to a marketing list. Read the %s.', 'quiet-truths'),
                        '<a href="' . esc_url($privacy_url) . '" target="_blank" rel="noopener">' . esc_html__('Privacy Notice', 'quiet-truths') . '</a>'
                    ),
                    ['a' => ['href' => [], 'target' => [], 'rel' => []]]
                );
                echo '</p>';
            }
        }

        if (!empty($errors)) {
            echo '<ul class="qt-form__error" role="alert">';
            foreach ($errors as $code) {
                echo '<li>' . esc_html(qt_contact_error_message($code)) . '</li>';
            }
            echo '</ul>';
        }

        echo '<form class="qt-form qt-form--contact" method="post">';

        /* ── Name (required) ── */
        echo '<div class="qt-form__field">';
        echo '<label class="qt-form__label" for="qt_name">' . esc_html__('Name', 'quiet-truths') . ' <span class="u-text-subtle">*</span></label>';
        echo '<input class="qt-form__input" type="text" id="qt_name" name="qt_name" maxlength="100" required value="'
            . esc_attr($old['name'] ?? '') . '">';
        echo '</div>';

        /* ── Email (required) ── */
        echo '<div class="qt-form__field">';
        echo '<label class="qt-form__label" for="qt_email">' . esc_html__('Email', 'quiet-truths') . ' <span class="u-text-subtle">*</span></label>';
        echo '<input class="qt-form__input" type="email" id="qt_email" name="qt_email" maxlength="100" required value="'
            . esc_attr($old['email'] ?? '') . '">';
        echo '</div>';

        /* ── Subject ── */
        echo '<div class="qt-form__field">';
        echo '<label class="qt-form__label" for="qt_subject">' . esc_html__('Subject', 'quiet-truths') . '</label>';
        echo '<input class="qt-form__input" type="text" id="qt_subject" name="qt_subject" maxlength="150" value="'
            . esc_attr($old['subject'] ?? '') . '">';
        echo '</div>';

        /* ── Phone (optional) ── */
        echo '<div class="qt-form__field">';
        echo '<label class="qt-form__label" for="qt_phone">' . esc_html__('Phone', 'quiet-truths')
            . ' <span class="u-text-subtle">(' . esc_html__('optional', 'quiet-truths') . ')</span></label>';
        echo '<input class="qt-form__input" type="tel" id="qt_phone" name="qt_phone" maxlength="20" value="'
            . esc_attr($old['phone'] ?? '') . '">';
        echo '</div>';

        /* ── Message ── */
        echo '<div class="qt-form__field">';
        echo '<label class="qt-form__label" for="qt_message">' . esc_html__('Message', 'quiet-truths') . '</label>';
        echo '<textarea class="qt-form__textarea" id="qt_message" name="qt_message" rows="6" maxlength="2000" required>'
            . esc_textarea($old['message'] ?? '') . '</textarea>';
        echo '</div>';

        /* ── Honeypot + nonce + submit ── */
        echo '<input type="text" name="qt_website" class="qt-hp" tabindex="-1" autocomplete="off" aria-hidden="true">';
        wp_nonce_field('qt_contact');
        echo '<div class="qt-form__submit">';
        echo '<button class="qt-button qt-button--primary" type="submit" name="qt_contact_submit" value="1">'
            . esc_html__('Send message', 'quiet-truths') . '</button>';
        echo '</div>';

        echo '</form>';
    }
}

if (!function_exists('qt_contact_form_confirmation')) {
    function qt_contact_form_confirmation(): void
    {
        $again = remove_query_arg('qt_contact_sent', home_url(add_query_arg([])));
        ?>
        <div class="qt-held">
            <?php qt_hope_marker(__('Received', 'quiet-truths')); ?>
            <p class="qt-held__line"><?php echo esc_html__('Your message has been received.', 'quiet-truths'); ?></p>
            <p class="qt-held__detail">
                <?php echo esc_html__('The house reads slowly, but it does read. If you left a way to reply, expect to hear from us in a few days.', 'quiet-truths'); ?>
            </p>
            <a class="qt-button qt-button--quiet" href="<?php echo esc_url($again); ?>">
                <?php echo esc_html__('Write again', 'quiet-truths'); ?>
            </a>
        </div>
        <?php
    }
}

if (!function_exists('qt_contact_error_message')) {
    function qt_contact_error_message(string $code): string
    {
        $messages = [
            'session'    => __('Your session expired — please try again.', 'quiet-truths'),
            'rate'       => __('The house receives messages slowly. Please try again in an hour.', 'quiet-truths'),
            'empty'      => __('Please write a message before sending.', 'quiet-truths'),
            'long'       => __('Please keep messages under 2,000 characters.', 'quiet-truths'),
            'name_req'   => __('Please give your name — the house needs it to reply.', 'quiet-truths'),
            'email_req'  => __('Please give a valid email — the house needs it to reply.', 'quiet-truths'),
            'phone'      => __('That phone number does not look quite right.', 'quiet-truths'),
            'email'      => __('That email address does not look quite right.', 'quiet-truths'),
            'name'       => __('The name is a little long — please keep it under 100 characters.', 'quiet-truths'),
            'profanity'  => __('Please check that the message does not direct abuse at another person.', 'quiet-truths'),
            'store'      => __('Something went wrong while your message was being sent. Please try again.', 'quiet-truths'),
        ];

        return $messages[$code] ?? __('Something went wrong. Please try again.', 'quiet-truths');
    }
}
