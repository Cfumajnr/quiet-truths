<?php
/**
 * Quiet Truths — Journal Patterns (emerging knowledge)
 *
 * The archive can reveal questions worth exploring (Journal Bible
 * §45–§47). Many Stories may cluster around a recurring human current;
 * that clustering can suggest a potential Journal subject.
 *
 * CRITICAL GUARDRAILS:
 *   - The AI identifies patterns; it never manufactures authority (§46).
 *     "Many stories concern this" is not "this is objectively true."
 *   - The output is CANDIDATE / suggestion only. It never publishes
 *     anything and never auto-creates a Journal or category (§48).
 *   - It is evidence-aware (§47): it reports which concepts/threads/
 *     domains recur and how many stories evidence them, but does not
 *     claim the subject is true or universal.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

use QuietTruths\Core\Concepts;

final class JournalPatterns
{
    /**
     * Discover recurring patterns across the published story archive that
     * might merit a Journal, without asserting truth.
     *
     * @param int $minEvidence minimum stories to consider a pattern
     * @param int $limit       max suggestions
     * @return list<array{
     *   subject:string, evidence_count:int,
     *   concepts:list<string>, threads:list<string>, domains:list<string>,
     *   confidence:float, candidate_only:bool, authority_note:string
     * }>
     */
    public static function suggest(int $minEvidence = 4, int $limit = 6): array
    {
        $ids = self::publishedStoryIds();

        // Aggregate concept / thread / domain frequency across stories.
        $conceptFreq = [];
        $threadFreq  = [];
        $domainFreq  = [];

        foreach ($ids as $id) {
            $profile = Profile::get((int) $id);
            if (empty($profile)) {
                continue;
            }

            foreach (array_keys((array) ($profile['concepts'] ?? [])) as $c) {
                $conceptFreq[$c] = ($conceptFreq[$c] ?? 0) + 1;
            }

            $threadBlock = (array) ($profile['threads'] ?? []);
            $threads = array_keys((array) ($threadBlock['active'] ?? $threadBlock['scores'] ?? $threadBlock));
            foreach ($threads as $t) {
                $threadFreq[$t] = ($threadFreq[$t] ?? 0) + 1;
            }

            foreach (array_keys((array) (($profile['domains']['scores'] ?? []))) as $d) {
                $domainFreq[$d] = ($domainFreq[$d] ?? 0) + 1;
            }
        }

        arsort($conceptFreq);
        arsort($threadFreq);
        arsort($domainFreq);

        $suggestions = [];
        $total = count($ids);

        // Recurring threads are the strongest signal of a human current
        // that a Journal could examine.
        foreach ($threadFreq as $thread => $count) {
            if ($count < $minEvidence || count($suggestions) >= $limit) {
                continue;
            }
            if ($total > 0 && ($count / $total) < 0.15) {
                continue; // not yet a meaningful concentration
            }

            $name = ThreadInference::definitions()[$thread]['name']
                ?? str_replace('-', ' ', $thread);

            $suggestions[] = self::makeSuggestion($name, $count, $conceptFreq, $threadFreq, $domainFreq, $thread);
        }

        // If threads gave little, fall back to recurring concepts.
        if (empty($suggestions)) {
            foreach ($conceptFreq as $concept => $count) {
                if ($count < $minEvidence || count($suggestions) >= $limit) {
                    continue;
                }

                $name = (Concepts::concepts()[$concept]['name'] ?? str_replace('-', ' ', $concept));
                $suggestions[] = self::makeSuggestion($name, $count, $conceptFreq, $threadFreq, $domainFreq, $concept);
            }
        }

        return array_slice($suggestions, 0, $limit);
    }

    /**
     * @return list<int>
     */
    private static function publishedStoryIds(): array
    {
        $q = new \WP_Query([
            'post_type'      => 'qt_story',
            'post_status'    => 'publish',
            'posts_per_page' => 500,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ]);

        return array_map('intval', (array) ($q->posts ?: []));
    }

    /**
     * Build one candidate suggestion with evidence + the authority note.
     *
     * @param array<string,int> $conceptFreq
     * @param array<string,int> $threadFreq
     * @param array<string,int> $domainFreq
     * @return array<string,mixed>
     */
    private static function makeSuggestion(string $name, int $count, array $conceptFreq, array $threadFreq, array $domainFreq, string $focus): array
    {
        $topConcepts = array_slice(array_keys($conceptFreq), 0, 3);
        $topThreads  = array_slice(array_keys($threadFreq), 0, 3);
        $topDomains  = array_slice(array_keys($domainFreq), 0, 3);

        return [
            'subject'         => $name,
            'evidence_count'  => $count,
            'concepts'        => $topConcepts,
            'threads'         => $topThreads,
            'domains'         => $topDomains,
            'confidence'      => round(min(0.85, 0.3 + 0.1 * $count), 2),
            'candidate_only'  => true,
            // The honest, non-authoritative framing (Journal Bible §46).
            'authority_note'  => 'Pattern observed across the archive; this suggests a question worth exploring, not a claim of universal truth.',
        ];
    }
}
