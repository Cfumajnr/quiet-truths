<?php
/**
 * Quiet Truths — Thread Inference
 *
 * Threads are recurring human currents (AI Bible XV; Correction 6/7/8)
 * — ideas, experiences or tensions that can run through many stories
 * and many Rooms. They answer "What human current runs through the
 * experience?" They are NOT categories, NOT Rooms, NOT Domains
 * (Non-Collapse Principle; Bible XIX). Readers never see threads as
 * navigation. A single story can participate in many threads at once.
 *
 * Threads are an OPEN list (no arbitrary cap — Bible XV–XVI;
 * Correction 5). They are grouped internally into families
 * (Connection / Change / Responsibility / Loss / Inner Life / Agency /
 * Meaning / Struggle / Time / Silence) for organisation. This
 * inference engine scores whatever definitions are returned by
 * self::definitions() and does not assume a fixed count.
 *
 * LIFECYCLE (Correction Nine):
 *   candidate  — proposed by the AI or editor, visible in corpus
 *                diagnostics but held back from discovery fan-out
 *                until promoted.
 *   active     — part of the established ontology; participates in
 *                scoring and discovery. (Formerly 'established' in
 *                v1.7.0; normalised automatically.)
 *   refining   — active but under review; meaning may shift.
 *   merged     — collapsed into another thread; scores forwarded
 *                through canonicalSlug().
 *   deprecated — retired but kept for alias lookups.
 *   archived   — no longer scored; kept for historical profile reads.
 *
 * A thread satisfies the Thread Test (Correction 8) when it:
 *   1. recurs across multiple stories,
 *   2. crosses Rooms,
 *   3. names a meaningful human current rather than a subject,
 *   4. does not merely duplicate a Domain or Concept,
 *   5. provides discovery value,
 *   6. is supported by evidence,
 *   7. remains useful as vocabulary changes.
 *
 * A thread is scored 0..1 for a story. Scoring combines:
 *   - concept evidence (concepts mapped to this thread)
 *   - direct lexical cues from the thread's own word list
 *   - signal evidence (relationship, context, time, emotional signals
 *     that imply the thread)
 *   - semantic prototype similarity (when BGE-M3 is available) against
 *     the thread's prototype phrases. Prototypes are vectorised once
 *     via PrototypeCache and reused across every story.
 *
 * Prototype-cosine thresholds are PROVISIONAL — the raw best-cosine is
 * recorded per thread in $raw['proto_best'] so future calibration can
 * tune THREAD_THRESHOLD against real corpus judgments without rewriting
 * the pipeline.
 *
 * HIERARCHY OF EVIDENCE (strongest first):
 *     semantic prototype (0.30)
 *        -> concepts (0.18)
 *        -> signals (0.12)
 *        -> lexical cues (capped at 0.40 via diminishing returns)
 *
 * Lexical word lists are supporting evidence, not the intelligence.
 * When a thread is being missed, add prototype phrases before expanding
 * lexical lists.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

use QuietTruths\Core\Config;

final class ThreadInference
{
    /**
     * Thread detection threshold. Below this, a thread is not considered
     * present in the story.
     */
    public const THREAD_THRESHOLD = 0.35;

    public const PROTO_FLOOR = 0.25;
    public const PROTO_RANGE = 0.40;

    /* ──────────────────── lifecycle ──────────────────── */

    // Lifecycle states (Correction Nine).
    public const STATE_CANDIDATE  = 'candidate';
    public const STATE_ACTIVE     = 'active';
    public const STATE_REFINING   = 'refining';
    public const STATE_MERGED     = 'merged';
    public const STATE_DEPRECATED = 'deprecated';
    public const STATE_ARCHIVED   = 'archived';

    /**
     * Normalise a status value to one of the lifecycle states. Accepts
     * legacy aliases ('established' → 'active').
     */
    public static function normaliseStatus(?string $status): string
    {
        $s = strtolower(trim((string) $status));
        return match ($s) {
            '', 'established' => self::STATE_ACTIVE, // back-compat with v1.7.0
            'candidate', 'active', 'refining',
            'merged', 'deprecated', 'archived' => $s,
            default => self::STATE_CANDIDATE,
        };
    }

    /**
     * Can this thread participate in scoring and discovery?
     * Only active/refining threads score; candidate threads are held
     * back from discovery surfaces but still recorded for corpus
     * diagnostics.
     */
    public static function isActive(array $def): bool
    {
        $s = self::normaliseStatus((string) ($def['status'] ?? ''));
        return in_array($s, [self::STATE_ACTIVE, self::STATE_REFINING], true);
    }

    /**
     * Flatten all thread prototype phrases (for batched embedding).
     *
     * @return list<string>
     */
    public static function allPrototypes(): array
    {
        $out = [];
        foreach (self::threadDefinitions() as $def) {
            foreach ((array) ($def['prototypes'] ?? []) as $p) {
                $out[] = $p;
            }
        }
        return array_values(array_unique($out));
    }

    /**
     * Score every thread for a text.
     *
     * @param string              $text       Full text (title + content).
     * @param array<string,float> $concepts   Concept slug => score.
     * @param array<string,mixed> $signals    Signals from Signals::forText().
     * @param array<float>|array<string,float>|null $storyVec   Precomputed story vector.
     * @param array<string,array<float>|array<string,float>>|null $protoVecs  Prototype phrase→vec cache.
     *
     * @return array{scores:array<string,float>,raw:array<string,mixed>}
     */
    public static function scoreThreads(
        string $text,
        array $concepts = [],
        array $signals = [],
        $storyVec = null,
        ?array $protoVecs = null
    ): array {
        $t = AiKernel::normalise($text);
        $threads = self::threadDefinitions();
        $scores  = [];
        $raw     = ['proto_best' => [], 'mode' => 'lexical'];

        // If precomputed vectors not supplied, pull from PrototypeCache so
        // the function is still safe to call standalone (CLI/tests).
        if (null === $storyVec || null === $protoVecs) {
            $protoVecs = PrototypeCache::vectors('threads', self::allPrototypes());
            $storyVecs = Embeddings::embed([$t]);
            $storyVec  = $storyVecs[0] ?? [];
            $raw['mode'] = Embeddings::canWriteDense() && !empty($storyVec) ? 'dense' : 'lexical';
        } else {
            $raw['mode'] = (!empty($storyVec) && is_array($storyVec) && isset($storyVec[0])) ? 'dense' : 'lexical';
        }

        foreach ($threads as $slug => $def) {
            $score = 0.0;
            $bestCos = 0.0;

            // 1) Concept evidence.
            foreach ((array) ($def['concepts'] ?? []) as $c) {
                if (isset($concepts[$c])) {
                    $score += 0.18 * (float) $concepts[$c];
                }
            }

            // 2) Direct lexical cues.
            $lexHits = 0;
            foreach ((array) ($def['words'] ?? []) as $w) {
                if (str_contains($t, mb_strtolower($w, 'UTF-8'))) {
                    $lexHits++;
                }
            }
            if ($lexHits > 0) {
                $score += min(0.40, 0.15 + 0.08 * ($lexHits - 1));
            }

            // 3) Signal evidence.
            foreach ((array) ($def['signals'] ?? []) as $sigRef) {
                [$group, $name] = explode(':', $sigRef . ':');
                $groupArr = (array) ($signals[$group] ?? []);
                if (isset($groupArr[$name])) {
                    $score += 0.12 * (float) $groupArr[$name];
                }
            }

            // 4) Semantic prototype similarity.
            if (!empty($storyVec) && !empty($protoVecs)) {
                foreach ((array) ($def['prototypes'] ?? []) as $p) {
                    $pv = $protoVecs[$p] ?? [];
                    if (empty($pv)) continue;
                    $sim = Embeddings::vectorSimilarity($storyVec, $pv);
                    if ($sim > $bestCos) $bestCos = $sim;
                }
            }
            $protoMapped = max(0.0, min(1.0,
                ($bestCos - self::PROTO_FLOOR) / max(0.01, self::PROTO_RANGE)
            ));
            $score += 0.30 * $protoMapped;

            $scores[$slug] = min(0.99, round($score, 2));
            $raw['proto_best'][$slug] = round($bestCos, 3);
        }

        arsort($scores);
        return ['scores' => $scores, 'raw' => $raw];
    }

    /**
     * Map of deprecated/retired thread slugs → current slug. Old profile
     * data is readable through this map (v6 → v7 back-compat per AI
     * Bible §XL — the AI layer is reconstructible, not permanent).
     *
     * @var array<string,string>
     */
    private const DEPRECATED_SLUGS = [
        // v1.7.0 ontology revision (audit §V, plan §1):
        'family'            => 'love-intimacy',  // family-as-bond absorbed by love-intimacy; family-as-duty by responsibility/care
        'faith'             => 'faith-belief',
        'work-money-hustle' => 'responsibility', // area of life split into work + money domains; current = responsibility for provision
        'work-money'        => 'responsibility',
        'body'              => 'vulnerability', // physical health moves to Health-Vulnerability domain; the human current = vulnerability
        'violence-survival' => 'survival-resilience',
        'silence-secrets'   => 'silence-unsaid',
        'place-belonging'   => 'belonging',
        'time-memory'       => 'memory',
        // Safety net in case of prior aliases:
        'love'              => 'love-intimacy',
    ];

    /**
     * Resolve a thread slug to its canonical current slug, handling
     * deprecated aliases. Unknown slugs are returned unchanged (so
     * future or candidate slugs do not get mangled).
     */
    public static function canonicalSlug(string $slug): string
    {
        return self::DEPRECATED_SLUGS[$slug] ?? $slug;
    }

    /**
     * Thread definitions.
     *
     * Returns the open thread map defined in config/threads.php
     * (AI Bible XV–XVI, audit §V: no arbitrary cap). Public so the
     * Rooms/Core layer can aggregate thread distributions for
     * atmosphere/houseMap. Loaded via Config::init() which reads
     * from the canonical config; falls back to a direct require
     * when Config has not booted (CLI, tests).
     *
     * @return array<string,array{name?:string,description?:string,family?:string,status?:string,domains?:list<string>,concepts?:list<string>,words?:list<string>,signals?:list<string>,prototypes?:list<string>,aliases?:list<string>}>
     */
    public static function definitions(): array
    {
        $cfg = null;
        if (class_exists(Config::class)) {
            try {
                $cfg = Config::instance()->get('content');
            } catch (\Throwable $e) {
                $cfg = null;
            }
        }
        $threads = (is_array($cfg) && isset($cfg['threads']) && is_array($cfg['threads']))
            ? $cfg['threads']
            : null;

        if (null === $threads) {
            $f = dirname(__DIR__) . '/config/threads.php';
            if (is_file($f)) {
                $threads = (array) require $f;
            }
        }

        return is_array($threads) ? $threads : [];
    }

    /**
     * Alias kept for any internal callers that still reference the
     * private helper name. New code should call definitions() directly.
     *
     * @return array<string,array<string,mixed>>
     */
    private static function threadDefinitions(): array
    {
        return self::definitions();
    }
}
