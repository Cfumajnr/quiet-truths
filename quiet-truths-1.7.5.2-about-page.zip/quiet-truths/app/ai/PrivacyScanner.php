<?php
/**
 * Quiet Truths — Privacy Scanner (Layers 4 + 6)
 *
 * Combinatorial identifying-detail detection. Instead of flagging
 * "age" or "city" alone (which are rarely identifying), the scanner
 * looks for *constellations* of details that together narrow who a
 * writer could be. It also returns a soft 0..1 risk score and a list
 * of concerns for the moderation panel and a writer-facing warning
 * chip.
 *
 *   - Pattern PII: phones, IDs, M-Pesa, emails — always flagged.
 *   - Place PII: named estates, landmarks, matatu routes.
 *   - Workplace PII: named employers, specific institutions.
 *   - School PII: named schools/colleges.
 *   - Bio constellation: weighted combination of age + gender +
 *     profession + city/town + family role + named workplace.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

final class PrivacyScanner
{
    public static function init(): void
    {
        // Pure functions — consumed by Submission + ModerationSignals.
    }

    /**
     * Run a full scan. Returns an array shaped:
     *
     *   'flags'      => list of { kind, match, severity, note }
     *   'risk_score' => 0..1 (a *writer* risk, not a moral judgment)
     *   'writer_warnings' => list<string> gentle chips for the form
     *
     * Severity: 'low' | 'medium' | 'high' | 'critical'
     *
     * @return array{flags:list<array>,risk_score:float,writer_warnings:list<string>}
     */
    public static function scan(string $text): array
    {
        $normal = AiKernel::normalise($text);
        $flags  = [];
        $score  = 0.0;

        // ── Pattern PII (high/critical) ──
        $flags = array_merge($flags, self::patternPii($text, $normal));
        // ── Place PII ──
        $flags = array_merge($flags, self::placePii($normal));
        // ── Workplace/institution PII ──
        $flags = array_merge($flags, self::workplacePii($normal));
        // ── School PII ──
        $flags = array_merge($flags, self::schoolPii($normal));
        // ── Constellation PII ──
        $flags = array_merge($flags, self::constellationPii($normal, $score));

        // Recompute score from severities (so pattern hits contribute).
        foreach ($flags as $f) {
            $score += self::severityWeight($f['severity'] ?? 'low');
        }
        $score = min(1.0, $score);

        // Writer-facing chips (non-blocking, gentle, in the same voice).
        $writerWarnings = self::writerWarnings($flags, $score);

        return [
            'flags'           => $flags,
            'risk_score'      => $score,
            'writer_warnings' => $writerWarnings,
        ];
    }

    /* ──────────────────── pattern PII ──────────────────── */

    /**
     * @return list<array>
     */
    private static function patternPii(string $raw, string $normal): array
    {
        $flags = [];

        // Kenyan phones: 07xx, 01xx, +254xx, 254xx, 07xx xxx xxx.
        if (preg_match_all('/\b(?:\+?254[\s-]?|0)[17]\d{2}[\s-]?\d{3}[\s-]?\d{3}\b/u', $raw, $m)) {
            foreach (array_unique($m[0]) as $hit) {
                $flags[] = [
                    'kind' => 'phone',
                    'match' => trim($hit),
                    'severity' => 'critical',
                    'note' => __('Phone number — please remove before publishing.', 'quiet-truths'),
                ];
            }
        }

        // National ID / KRA PIN — require a nearby "id"/"pin" word so
        // random 7–9 digit strings aren't flagged.
        if (preg_match_all('/\b(?:id|i\.d\.?|national\s+id|kra\s*pin|pin\s*(?:no|number)?)\s*[:#-]?\s*\d{6,9}\b/iu', $raw, $m)) {
            foreach (array_unique($m[0]) as $hit) {
                $flags[] = [
                    'kind' => 'id_number',
                    'match' => trim($hit),
                    'severity' => 'critical',
                    'note' => __('ID / KRA PIN reference — please remove.', 'quiet-truths'),
                ];
            }
        }

        // M-Pesa codes.
        if (preg_match_all('/\bm-?pesa\b[^\w]{0,20}(?:reference|code|confirmation|receipt|msg|message)?[^\w]{0,10}[a-z0-9]{6,12}\b/iu', $raw, $m)) {
            foreach (array_unique($m[0]) as $hit) {
                $flags[] = [
                    'kind' => 'mpesa',
                    'match' => trim($hit),
                    'severity' => 'high',
                    'note' => __('M-Pesa reference — can be traced; please remove.', 'quiet-truths'),
                ];
            }
        }

        // Emails.
        if (preg_match_all('/\b[\w.+-]+@[\w-]+\.[\w.-]+\b/u', $raw, $m)) {
            foreach (array_unique($m[0]) as $hit) {
                $flags[] = [
                    'kind' => 'email',
                    'match' => $hit,
                    'severity' => 'critical',
                    'note' => __('Email address — please remove.', 'quiet-truths'),
                ];
            }
        }

        // URLs / social handles pointing at the writer.
        if (preg_match_all('/\b(?:facebook|instagram|twitter|x|tiktok|linkedin)\.com\/[^\s<>"]+/iu', $raw, $m)) {
            foreach (array_unique($m[0]) as $hit) {
                $flags[] = [
                    'kind' => 'social',
                    'match' => $hit,
                    'severity' => 'high',
                    'note' => __('Social-media link — please remove.', 'quiet-truths'),
                ];
            }
        }

        return $flags;
    }

    /* ──────────────────── place PII ──────────────────── */

    /**
     * @return list<array>
     */
    private static function placePii(string $normal): array
    {
        $flags  = [];
        $places = [
            // Nairobi estates
            'runda','karen','muthaiga','lavington','kilimani','kileleshwa','westlands',
            'parklands','south b','south c','eastleigh','pangani','ngara',
            'kibera','mathare','kariobangi','dandora','kayole','ruaka','ruai',
            'embakasi','donholm','buruburu','jericho','makadara','huruma',
            'kawangware','dagoretti','langata',"lang'ata",'syokimau','kitengela',
            'rongai','roysambu','kasarani','kahawa west','kahawa sukari',
            'githurai 45','githurai 44','utawala','imara daima',
            // Coast
            'nyali','bamburi','likoni','diani','malindi town','kongowea','kizingo',
            'shanzu','mkomani','changamwe',
            // Kisumu
            'milimani kisumu','dunga','kondele','nyamasaria','manyatta','obunga',
            // Nakuru
            'milimani nakuru','kaptembwa','pipeline nakuru','bahati',
            // Eldoret
            'langas','elgon view','kapsoya',
        ];
        foreach ($places as $p) {
            if (str_contains($normal, $p)) {
                $flags[] = [
                    'kind' => 'place',
                    'match' => $p,
                    'severity' => 'medium',
                    'note' => sprintf(
                        __('Specific estate/place (%s) — consider whether a reader could locate the writer from it.', 'quiet-truths'),
                        $p
                    ),
                ];
            }
        }
        return $flags;
    }

    /* ──────────────────── workplace PII ──────────────────── */

    /**
     * @return list<array>
     */
    private static function workplacePii(string $normal): array
    {
        $workplaces = [
            'safaricom','airtel kenya','telkom kenya','kcb','equity bank',
            'co-operative bank','coop bank','family bank','absa','ncba','dtb',
            'stanbic','kra','nssf','nhif','kenya power','kengen','kplc',
            'kenya pipeline','central bank','state house','parliament',
            'jkia','wilson airport','strathmore','university of nairobi',
            'uon','kenyatta university','nairobi hospital','knh',
            'naivas','quickmart','carrefour','google kenya','microsoft kenya',
            'unep','world bank kenya',
        ];
        $flags = [];
        foreach ($workplaces as $w) {
            if (str_contains($normal, $w)) {
                $flags[] = [
                    'kind' => 'workplace',
                    'match' => $w,
                    'severity' => 'medium',
                    'note' => sprintf(
                        __('Workplace/institution (%s) — combined with other details, this can identify a writer.', 'quiet-truths'),
                        $w
                    ),
                ];
            }
        }
        return $flags;
    }

    /* ──────────────────── school PII ──────────────────── */

    /**
     * @return list<array>
     */
    private static function schoolPii(string $normal): array
    {
        $flags = [];
        if (preg_match_all('/\b(?:school|secondary|high school|primary|academy|university|college|chuo)\s+(?:of\s+)?(?:[a-z][a-z\']+\s*){1,4}/u', $normal, $m)) {
            foreach (array_unique($m[0]) as $hit) {
                $hit = trim($hit);
                if (mb_strlen($hit) < 25) {
                    continue;
                }
                $flags[] = [
                    'kind' => 'school',
                    'match' => $hit,
                    'severity' => 'medium',
                    'note' => __('Named school/college — small cohorts can identify the writer.', 'quiet-truths'),
                ];
            }
        }
        return $flags;
    }

    /* ──────────────────── constellation PII ──────────────────── */

    /**
     * Bio constellations are weighted — the more of {age, gender, job,
     * city, workplace} that appear together, the higher the score.
     *
     * @return list<array>
     */
    private static function constellationPii(string $normal, float &$score): array
    {
        $signals = [
            'age'       => (bool) preg_match('/\b(?:i(?:\'m| am)|age(?:d)?\s*)?(?:twenty|thirty|forty|fifty|twenty[- ]?five|thirty[- ]?two|miaka|umri|[- ]?[2-5][0-9])\b/u', $normal),
            'gender'    => (bool) preg_match('/\b(?:female|male|woman|man|mother|father|wife|husband|mwanamke|mwanamume|mama|baba)\b/u', $normal),
            'job'       => (bool) preg_match('/\b(?:doctor|nurse|teacher|engineer|accountant|lawyer|police|soldier|farmer|driver|matatu|pastor|priest|nun|journalist|reporter|waiter|barman|cashier|receptionist|mjengo|fundi|daktari|mwalimu)\b/u', $normal),
            'city'      => (bool) preg_match('/\b(nairobi|mombasa|kisumu|nakuru|eldoret|thika|kitale|nyeri|kakamega|kisii|kericho|machakos|garissa|malindi|diani)\b/u', $normal),
            'workplace' => false, // computed below
            'school'    => false, // computed below
        ];

        // Place/workplace/school presence — quick presence checks.
        foreach (self::PLACE_HINTS as $w) {
            if (str_contains($normal, $w)) {
                $signals['city'] = true;
                break;
            }
        }
        foreach (self::WORKPLACE_HINTS as $w) {
            if (str_contains($normal, $w)) {
                $signals['workplace'] = true;
                break;
            }
        }
        if (preg_match('/\b(?:school|secondary|high school|primary|academy|university|college|chuo)\b/u', $normal)) {
            $signals['school'] = true;
        }

        // Stronger quasi-identifiers: named children, specific form/class
        // level, pregnancy/marriage/life-event markers — these narrow the
        // pool faster than plain demographics.
        if (preg_match('/\b(?:form\s*[1-6]|class\s*[1-8]|grade\s*\d|standard\s*\d|year\s*[1-4])\b/u', $normal)) {
            $signals['class_level'] = true;
        }
        $namedChild = false;
        if (preg_match('/\b(?:my\s+(?:daughter|son|child|baby|kid)\s+(?:called|named)\s+[a-z][a-z]+)\b/u', $normal)) {
            $signals['named_child'] = 2; // weight x2
            $namedChild = true;
        } elseif (preg_match('/\b(?:my\s+(?:daughter|son|child|baby|kid)(?:\s+who|\'s|\s+is)?)\b/u', $normal)) {
            $signals['named_child'] = 1;
        }
        if (preg_match('/\b(?:pregnant|miscarriage|abortion|gave birth|ndoa|harusi)\b/u', $normal)) {
            $signals['life_event'] = true;
        }
        if (preg_match('/\b(?:matatu\s*(?:route|no\.?|number)?\s*\d+|sacco\s+[a-z]+|stage\s+[a-z]+)\b/u', $normal)) {
            $signals['route'] = true;
        }

        // Weighted combination risk. Direct identifiers (phone/email/...)
        // are already scored in scan() via severity weights. Here we add
        // risk from quasi-identifier clusters.
        $weights = [
            'age'         => 0.08,
            'gender'      => 0.04,
            'job'         => 0.12,
            'city'        => 0.10,
            'workplace'   => 0.20,
            'school'      => 0.20,
            'class_level' => 0.12,
            'named_child' => 0.18,
            'life_event'  => 0.08,
            'route'       => 0.12,
        ];
        foreach ($signals as $k => $v) {
            if (!isset($weights[$k])) {
                continue;
            }
            if (is_numeric($v)) {
                $score += $weights[$k] * ((float) $v);
            } elseif ($v) {
                $score += $weights[$k];
            }
        }

        // Count narrowers vs total soft hits to tier the flag.
        $strongHits = 0;
        foreach (['workplace','school','named_child','class_level','route'] as $n) {
            if (!empty($signals[$n])) {
                $strongHits++;
            }
        }
        $softHits = 0;
        foreach ($signals as $v) {
            if ($v) { $softHits++; }
        }

        $evidence = [];
        foreach ($signals as $name => $present) {
            if ($present) $evidence[] = (string) $name;
        }

        $flags = [];
        if ($strongHits >= 1 && $softHits >= 2) {
            $flags[] = [
                'kind' => 'uniqueness',
                'match' => '',
                'severity' => $strongHits >= 2 ? 'high' : 'medium',
                'evidence' => $evidence,
                'note' => __(
                    'Specific details combined with demographic signals could identify the writer within a small circle — consider softening a workplace, school, matatu route, or named-child reference.',
                    'quiet-truths'
                ),
            ];
        } elseif ($softHits >= 3) {
            $severity = $softHits >= 5 ? 'high' : 'medium';
            $flags[] = [
                'kind' => 'constellation',
                'match' => '',
                'severity' => $severity,
                'evidence' => $evidence,
                'note' => __(
                    'Several demographic details appear together — someone who knows the writer could recognise them. Consider softening one or two.',
                    'quiet-truths'
                ),
            ];
        }

        return $flags;
    }

    /* ──────────────────── writer warning chips ──────────────────── */

    /**
     * Turn the machine-readable flags into a small number of gentle
     * writer-facing chips. Never alarmist; in the house voice.
     *
     * @param  list<array> $flags
     * @return list<string>
     */
    private static function writerWarnings(array $flags, float $score): array
    {
        $warnings = [];
        $kinds    = array_unique(array_map(fn($f) => $f['kind'] ?? '', $flags));

        if (in_array('phone', $kinds, true) || in_array('email', $kinds, true) || in_array('id_number', $kinds, true)) {
            $warnings[] = __('a phone, email or ID number is visible — please remove it', 'quiet-truths');
        }
        if (in_array('mpesa', $kinds, true)) {
            $warnings[] = __('an M-Pesa reference is visible — please remove it', 'quiet-truths');
        }
        if (in_array('social', $kinds, true)) {
            $warnings[] = __('a social-media link is visible — please remove it', 'quiet-truths');
        }
        if ($score >= 0.45) {
            $warnings[] = __('several details together could make you identifiable — consider softening one', 'quiet-truths');
        } elseif ($score >= 0.30) {
            $warnings[] = __('a few specific details — worth reading once more with anonymity in mind', 'quiet-truths');
        }

        return array_values(array_unique($warnings));
    }

    /* ──────────────────── utilities ──────────────────── */

    private static function severityWeight(string $sev): float
    {
        return match ($sev) {
            'critical' => 0.45,
            'high'     => 0.25,
            'medium'   => 0.12,
            'low'      => 0.05,
            default    => 0.02,
        };
    }

    // Shortlists used by constellationPii() for quick presence checks.
    private const PLACE_HINTS = [
        'nairobi','mombasa','kisumu','nakuru','eldoret','thika','kitale',
        'nyeri','kakamega','kisii','kericho','machakos','garissa','malindi','diani',
    ];
    private const WORKPLACE_HINTS = [
        'safaricom','airtel','kcb','equity bank','co-op','family bank','absa',
        'ncba','dtb','stanbic','kra','nssf','nhif','kenya power','kplc',
        'state house','parliament','jkia','strathmore','uon','kenyatta university',
        'nairobi hospital','knh','naivas','quickmart','carrefour',
    ];
}
