<?php
/**
 * Quiet Truths — Moderation Signals (Layer 7)
 *
 * Editorial dashboard for moderators. Reads from the AI Profile (read-
 * only — never causes HTTP calls or recomputation on render). Only
 * near-duplicate detection is computed afresh (for pending stories
 * that don't yet have a profile), and that uses the batched
 * /similarities endpoint.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

final class ModerationSignals
{
    public static function init(): void
    {
        add_action('add_meta_boxes', [self::class, 'addBox']);
    }

    public static function addBox(): void
    {
        if (!current_user_can('view_qt_privacy')) {
            return;
        }
        add_meta_box(
            'qt_ai_review',
            __('The house noticed — review before publishing', 'quiet-truths'),
            [self::class, 'render'],
            'qt_story',
            'side',
            'high'
        );
    }

    public static function render(\WP_Post $post): void
    {
        // Read-only. This returns either a fully built profile or a
        // fast lexical fallback — never triggers embedding work.
        $profile = Profile::get($post->ID);
        $text    = (string) $post->post_title . "\n\n" . (string) $post->post_content;

        $isFallback   = !empty($profile['_fallback']);
        $isStale      = ($profile['_status'] ?? 'fresh') === 'stale';
        $rebuildPending = Profile::rebuildPending($post->ID);
        $embedStatus  = (string) ($profile['semantic']['status'] ?? 'pending');

        $risk    = (float) ($profile['privacy']['risk_score'] ?? 0.0);
        $conceptScores = (array) ($profile['concepts'] ?? []);
        // Editor-only diagnostic: show top concepts and active threads.
        // Legacy v7 profiles may still carry a top-level 'themes' key
        // (pre-v1.7.3 door groupings). We surface those ONLY as
        // legacy diagnostic labels so an editor can see what older
        // inference attached to the story — they DO NOT influence
        // current concept/thread/domain inference, search ranking,
        // public Room assignment, or semantic discovery (Correction
        // 11, v1.7.4). New profiles carry _legacy.doors instead.
        $broadConcepts = array_slice(array_keys($conceptScores), 0, 6);
        $activeThreads = array_keys((array) ($profile['threads']['active'] ?? []));
        $legacyThemeData = array_values(array_filter(array_map(
            'strval',
            (array) ($profile['themes'] ?? [])
        )));
        $legacyDoorData  = array_values(array_filter(array_map(
            'strval',
            (array) ($profile['_legacy']['doors'] ?? [])
        )));
        $legacyDiagnostic = array_values(array_unique(array_merge(
            $legacyThemeData,
            $legacyDoorData
        )));
        $diagnosticLabels = array_values(array_unique(array_merge(
            $broadConcepts,
            array_slice($activeThreads, 0, 3),
            $legacyDiagnostic
        )));
        $warnings = (array) ($profile['content']['warnings'] ?? []);
        $confidence = (float) ($profile['confidence'] ?? 0.0);
        $language   = (string) ($profile['identity']['language'] ?? 'en');
        $model      = (string) ($profile['model'] ?? '');
        $threads    = (array) ($profile['threads']['active'] ?? []);
        $comm       = (array) ($profile['signals']['communication'] ?? []);
        $directFlags = array_merge(
            (array) ($profile['privacy']['direct_identifiers'] ?? []),
            (array) ($profile['privacy']['contextual_identifiers'] ?? [])
        );

        // A House-origin Story is known editorial material, not an
        // unknown public submission. Suppress pattern-based duplicate and
        // spam-origin suspicion for it, while retaining privacy, safety,
        // content-warning and semantic understanding signals.
        $fromHouse = class_exists('\\QuietTruths\\Core\\Provenance')
            && \QuietTruths\Core\Provenance::isHouseStory($post);
        $dupes = $fromHouse ? [] : self::nearDuplicates($post->ID, $text);
        $spam  = $fromHouse ? 0.0 : self::spamScore($text);

        $riskLabel = $risk >= 0.65 ? __('High identifiability risk', 'quiet-truths')
                  : ($risk >= 0.35 ? __('Moderate identifiability risk', 'quiet-truths')
                  :                   __('Low identifiability risk', 'quiet-truths'));
        $riskColor = $risk >= 0.65 ? '#c62828'
                  : ($risk >= 0.35 ? '#ef6c00'
                  :                   '#2e7d32');

        $usingSemantic = Embeddings::canWriteDense()
            || Embeddings::isDenseModel((string) ($profile['semantic']['embedding_model'] ?? ''));

        echo '<div class="qt-ai-panel" style="font-size:13px;line-height:1.5;color:#333">';

        // Intro.
        echo '<p style="color:#757575;font-size:12px;margin:0 0 10px">';
        if ($isFallback) {
            echo esc_html__('The full profile is still being built in the background. What you see now is a quick lexical reading — it will refresh shortly.', 'quiet-truths');
        } elseif ($isStale) {
            // Stale means this profile is KNOWN to be provisional (e.g.
            // lexical fallback for a brand-new post with service down).
            echo esc_html__('This is a provisional lexical profile (dense build pending). Once the embedding service responds the profile will be upgraded.', 'quiet-truths');
        } elseif ($rebuildPending) {
            // Profile is FRESH, a rebuild is queued because content
            // changed. Do NOT call this "stale" — it is the current
            // good profile being refreshed in the background.
            echo esc_html__('These are suggestions from the house. A refreshed profile is being built in the background after a recent edit; what you see is still the current good reading. Stories are never sent to any third party.', 'quiet-truths');
        } elseif ($usingSemantic) {
            echo esc_html__('These are suggestions from the house. They are generated from patterns and semantic signals; a human eye still decides. Stories are never sent to any third party.', 'quiet-truths');
        } else {
            echo esc_html__('These are suggestions from the house — patterns the house noticed in the words. A human eye still decides.', 'quiet-truths');
        }
        if ($embedStatus === Embeddings::STATUS_PENDING && !$isFallback) {
            echo ' <em style="color:#ef6c00">' . esc_html__('A dense embedding has not yet been computed for this story.', 'quiet-truths') . '</em>';
        }
        echo '</p>';

        if ($fromHouse) {
            echo '<div style="margin-bottom:12px;padding:8px 10px;background:#f3f6f8;border-left:3px solid #526b7f">';
            echo '<strong style="display:block;color:#3f596d">' . esc_html__('From the House', 'quiet-truths') . '</strong>';
            echo '<span style="font-size:12px;color:#52606a">'
                . esc_html__('Editorial provenance is known, so automated duplicate/spam-origin pattern flags are suppressed. Privacy, safety and content review remain active.', 'quiet-truths')
                . '</span></div>';
        }

        // Risk.
        echo '<div style="margin-bottom:12px;padding:8px 10px;background:#fafafa;border-left:3px solid ' . esc_attr($riskColor) . '">';
        echo '<strong style="display:block;color:' . esc_attr($riskColor) . '">' . esc_html($riskLabel) . '</strong>';
        if (!empty($directFlags)) {
            echo '<ul style="margin:6px 0 0;padding-left:18px;font-size:12px">';
            foreach (array_slice($directFlags, 0, 8) as $f) {
                $match    = (string) ($f['match'] ?? '');
                $evidence = array_values(array_filter(array_map('sanitize_key', (array) ($f['evidence'] ?? []))));
                echo '<li><strong>' . esc_html((string) ($f['kind'] ?? 'note')) . '</strong>';
                if ('' !== $match) {
                    echo ' (<code>' . esc_html($match) . '</code>)';
                }
                echo ' — ' . esc_html((string) ($f['note'] ?? ''));
                if (!empty($evidence)) {
                    echo '<br><small>' . esc_html__('Evidence:', 'quiet-truths') . ' '
                        . esc_html(implode(' + ', $evidence)) . '</small>';
                }
                echo '</li>';
            }
            echo '</ul>';
        }
        echo '</div>';

        // Concepts.
        if (!empty($conceptScores)) {
            echo '<p style="margin:0 0 6px"><strong>' . esc_html__('Suggested concepts', 'quiet-truths') . '</strong> ';
            $labels = [];
            foreach (array_slice(array_keys($conceptScores), 0, 6) as $c) {
                $score = $conceptScores[$c] ?? 1.0;
                $labels[] = sprintf('%s%s', str_replace('-', ' ', $c), $score < 0.95 ? sprintf(' (%d%%)', (int) round($score * 100)) : '');
            }
            echo esc_html(implode(' · ', $labels));
            echo ' <span style="color:#9e9e9e">(' . esc_html(sprintf(__('confidence %d%%', 'quiet-truths'), (int) round($confidence * 100))) . ')</span>';
            echo '</p>';
        }
        if (!empty($threads)) {
            echo '<p style="margin:0 0 6px"><strong>' . esc_html__('Threads', 'quiet-truths') . '</strong> ';
            $tlabels = [];
            foreach ($threads as $slug => $score) {
                $name = str_replace('-', ' ', (string) $slug);
                $tlabels[] = sprintf('%s (%d%%)', $name, (int) round((float) $score * 100));
            }
            echo '<span style="color:#6a6a6a">' . esc_html(implode(' · ', $tlabels)) . '</span>';
            echo '</p>';
        }
        if (!empty($comm)) {
            $commLabels = [];
            foreach ($comm as $mode => $sc) {
                if ((float) $sc >= 0.55) {
                    $commLabels[] = str_replace('_', ' ', (string) $mode);
                }
            }
            if (!empty($commLabels)) {
                echo '<p style="margin:0 0 6px"><strong>' . esc_html__('Form', 'quiet-truths') . '</strong> '
                    . '<em style="color:#6a6a6a">' . esc_html(implode(' · ', array_slice($commLabels, 0, 3))) . '</em></p>';
            }
        }
        // Rooms: human-assigned + AI affinity.
        $assignedRoom = $profile['rooms']['assigned'] ?? null;
        $primaryRoom  = $profile['rooms']['primary'] ?? null;
        $secondaries  = (array) ($profile['rooms']['secondary'] ?? []);
        $roomParts = [];
        if (!empty($assignedRoom)) {
            $roomParts[] = str_replace('-', ' ', (string) $assignedRoom) . ' (' . esc_html__('placed', 'quiet-truths') . ')';
        }
        if (!empty($primaryRoom) && $primaryRoom !== $assignedRoom) {
            $roomParts[] = str_replace('-', ' ', (string) $primaryRoom) . ' (' . esc_html__('suggested', 'quiet-truths') . ')';
        }
        foreach ($secondaries as $sec) {
            $slug = $sec['slug'] ?? null;
            $sc   = isset($sec['score']) ? (int) round(((float) $sec['score']) * 100) : 0;
            if ($slug && $slug !== $assignedRoom && $slug !== $primaryRoom) {
                $roomParts[] = str_replace('-', ' ', (string) $slug) . ($sc ? sprintf(' (%d%%)', $sc) : '');
            }
        }
        // Fallback for legacy flat room arrays (profiles built before v1.5).
        if (empty($roomParts)) {
            $legacyRooms = (array) ($profile['rooms'] ?? []);
            foreach ($legacyRooms as $r) {
                if (is_string($r) && '' !== $r) {
                    $roomParts[] = str_replace('-', ' ', $r);
                }
            }
        }
        if (!empty($roomParts)) {
            echo '<p style="margin:0 0 6px"><strong>' . esc_html__('Room', 'quiet-truths') . '</strong> '
                . esc_html(implode(' · ', $roomParts)) . '</p>';
        }
        if (!empty($diagnosticLabels)) {
            // Editor-only diagnostic: a combined view of concepts,
            // active threads and (transitionally) any retired legacy
            // door groupings from older profiles. Not public.
            echo '<p style="margin:0 0 6px"><strong>' . esc_html__('Concepts & threads (internal)', 'quiet-truths') . '</strong> '
                . '<span style="color:#9e9e9e">' . esc_html(implode(' · ', array_slice($diagnosticLabels, 0, 9))) . '</span></p>';
        }
        if (!empty($warnings)) {
            echo '<p style="margin:0 0 6px"><strong>' . esc_html__('Content warnings', 'quiet-truths') . '</strong> '
                . esc_html(implode(' · ', $warnings)) . '</p>';
        }
        if (!empty($language) && 'en' !== $language) {
            echo '<p style="margin:0 0 6px"><strong>' . esc_html__('Language', 'quiet-truths') . '</strong> '
                . esc_html($language) . '</p>';
        }
        if (!empty($profile['emotional']['labels'] ?? null)) {
            echo '<p style="margin:0 0 6px"><strong>' . esc_html__('Emotional tone', 'quiet-truths') . '</strong> '
                . esc_html(implode(' · ', (array) $profile['emotional']['labels'])) . '</p>';
        }

        // Near-duplicates.
        if (!empty($dupes)) {
            echo '<p style="margin:10px 0 4px"><strong>' . esc_html__('Similar to existing stories', 'quiet-truths') . '</strong></p>';
            echo '<ul style="margin:0;padding-left:18px;font-size:12px">';
            foreach ($dupes as $d) {
                $title = get_the_title($d['id']);
                $link  = get_edit_post_link($d['id']);
                $lbl   = StoryRelations::labelFor('', (string) ($d['primary'] ?? ''));
                printf(
                    '<li><a href="%s">%s</a> <span style="color:#9e9e9e">(%.0f%%%s)</span></li>',
                    esc_url($link ?: '#'),
                    esc_html($title ?: '(untitled)'),
                    round(($d['score'] ?? 0) * 100),
                    '' !== $lbl ? ' · ' . esc_html($lbl) : ''
                );
            }
            echo '</ul>';
        }

        if ($spam >= 0.4) {
            echo '<p style="margin:10px 0 0;color:#c62828"><strong>' . esc_html__('Possible spam / promotion', 'quiet-truths') . '</strong> ';
            echo esc_html(sprintf(__('(signal %.0f%%) — review for external links or repeated phrases.', 'quiet-truths'), $spam * 100));
            echo '</p>';
        }

        if ('' !== $model && 'fallback' !== $model && 'tokens-v1' !== $model && 'none' !== $model) {
            echo '<p style="margin:10px 0 0;font-size:11px;color:#bdbdbd">' . esc_html(
                sprintf(__('Profiled with %s.', 'quiet-truths'), $model)
            ) . '</p>';
        }

        echo '</div>';
    }

    /**
     * Near-duplicates via batched /similarities (one HTTP call total).
     * @return list<array{id:int,score:float,primary:string}>
     */
    private static function nearDuplicates(int $postId, string $text): array
    {
        $q = new \WP_Query([
            'post_type' => 'qt_story',
            'post_status' => ['publish','pending'],
            'posts_per_page' => 40,
            'post__not_in' => [$postId],
            'no_found_rows' => true,
            'fields' => 'ids',
        ]);
        $candidateIds = array_map('intval', (array) ($q->posts ?: []));
        if (empty($candidateIds)) return [];
        $texts = [];
        foreach ($candidateIds as $cid) {
            $p = get_post($cid);
            $texts[] = $p ? ((string) $p->post_title . '. ' . (string) $p->post_content) : '';
        }
        $scores = Embeddings::textSimilarities($text, $texts);
        $hits = [];
        foreach ($candidateIds as $i => $cid) {
            $s = (float) ($scores[$i] ?? 0.0);
            if ($s < 0.55) continue;
            $rel = StoryRelations::classify($postId, $cid);
            $hits[] = ['id' => $cid, 'score' => $s, 'primary' => $rel['primary'] ?: 'similar'];
        }
        usort($hits, fn($a,$b) => $b['score'] <=> $a['score']);
        return array_slice($hits, 0, 3);
    }

    private static function spamScore(string $text): float
    {
        $score = 0.0;
        $t = AiKernel::normalise($text);
        $urlHits = preg_match_all('~https?://|www\.~u', $t);
        $score += min(0.5, $urlHits * 0.15);
        if (preg_match('/(contact|whatsapp|call|text|dm|telegram)\s*(me|us|on|us on)\b/u', $t)) $score += 0.3;
        foreach (['buy now','click here','subscribe','join my','follow me','dm me','whatsapp me','join our telegram','for sale','hire me','cheap'] as $p) {
            if (str_contains($t, $p)) $score += 0.2;
        }
        $words = preg_split('/\s+/u', $t) ?: [];
        if (count($words) > 20) {
            $freq = array_count_values($words);
            arsort($freq);
            $top = reset($freq);
            if ($top && count($words) > 0 && $top / count($words) > 0.08) $score += 0.2;
        }
        return max(0.0, min(1.0, $score));
    }
}
