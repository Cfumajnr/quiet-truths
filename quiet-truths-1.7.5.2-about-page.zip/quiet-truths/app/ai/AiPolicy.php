<?php
/** Quiet Truths — non-negotiable Story-not-person inference boundary. */
namespace QuietTruths\Ai;

if (!defined('ABSPATH')) { exit; }

final class AiPolicy
{
    public const VERSION = 1;

    /** @return list<string> */
    public static function prohibitedPersonKeys(): array
    {
        return [
            'personality', 'personality_type', 'psychological_profile',
            'psychological_type', 'political_identity', 'inferred_religion',
            'inferred_ethnicity', 'inferred_sexual_orientation',
            'inferred_medical_condition', 'inferred_criminal_history',
            'socioeconomic_class', 'demographic_profile', 'behavioural_profile',
            'behavioral_profile', 'writer_profile', 'writer_identity',
        ];
    }

    /**
     * Remove prohibited identity/personality structures even if a plugin or
     * future filter tries to append them to a profile.
     *
     * @param array<string,mixed> $profile
     * @return array<string,mixed>
     */
    public static function enforce(array $profile): array
    {
        $blocked = array_fill_keys(self::prohibitedPersonKeys(), true);
        $walk = static function ($value) use (&$walk, $blocked) {
            if (!is_array($value)) return $value;
            $out = [];
            foreach ($value as $key => $child) {
                $normal = strtolower(str_replace(['-', ' '], '_', (string) $key));
                if (isset($blocked[$normal])) continue;
                $out[$key] = $walk($child);
            }
            return $out;
        };
        $profile = $walk($profile);
        $profile['policy'] = [
            'version' => self::VERSION,
            'subject' => 'story_not_person',
            'person_profiling' => false,
        ];
        return $profile;
    }

    public static function containsProhibited(array $profile): bool
    {
        $clean = self::enforce($profile);
        unset($clean['policy']);
        $original = $profile;
        unset($original['policy']);
        return $clean !== $original;
    }
}
