<?php
/**
 * Quiet Truths — AI eligibility, revision tickets and authoritative forget.
 *
 * A queued job is never permission. Every worker must present the current
 * generation and source fingerprint and re-check lifecycle eligibility.
 *
 * @package QuietTruths\Ai
 */
namespace QuietTruths\Ai;

use QuietTruths\Core\Audit;

if (!defined('ABSPATH')) { exit; }

final class ProfileLifecycle
{
    public const BLOCKED_META       = '_qt_lifecycle_ai_blocked';
    public const BLOCKED_REASON     = '_qt_lifecycle_ai_block_reason';
    public const BLOCKED_AT         = '_qt_lifecycle_ai_blocked_at_gmt';
    public const GENERATION_META    = '_qt_lifecycle_ai_generation';
    public const QUEUED_HASH_META   = '_qt_lifecycle_ai_queued_hash';
    public const FORGOTTEN_AT_META  = '_qt_lifecycle_ai_forgotten_at_gmt';

    public static function init(): void
    {
        add_action('transition_post_status', [self::class, 'onStatusTransition'], 5, 3);
        add_action('post_updated', [self::class, 'onPostUpdated'], 5, 3);
        add_action('before_delete_post', [self::class, 'beforeDelete'], 5, 2);
    }

    public static function isEligible($post): bool
    {
        $post = get_post($post);
        if (!$post instanceof \WP_Post
            || !in_array($post->post_type, ['qt_story', 'qt_journal'], true)
            || !in_array($post->post_status, ['pending', 'publish'], true)
            || '1' === (string) get_post_meta($post->ID, self::BLOCKED_META, true)) {
            return false;
        }

        return '' !== trim((string) $post->post_title . (string) $post->post_content);
    }

    public static function contentHash($post): string
    {
        $post = get_post($post);
        if (!$post instanceof \WP_Post) {
            return '';
        }
        return hash('sha256', wp_json_encode([
            'type'    => (string) $post->post_type,
            'title'   => (string) $post->post_title,
            'excerpt' => (string) $post->post_excerpt,
            'content' => (string) $post->post_content,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    public static function generation(int $postId): int
    {
        return max(0, (int) get_post_meta($postId, self::GENERATION_META, true));
    }

    /** @return array{generation:int,hash:string}|null */
    public static function issueTicket(int $postId): ?array
    {
        $post = get_post($postId);
        if (!self::isEligible($post)) {
            return null;
        }
        $hash = self::contentHash($post);
        $generation = self::generation($postId) + 1;
        update_post_meta($postId, self::GENERATION_META, $generation);
        update_post_meta($postId, self::QUEUED_HASH_META, $hash);

        return ['generation' => $generation, 'hash' => $hash];
    }

    public static function isTicketCurrent(int $postId, int $generation, string $hash): bool
    {
        $post = get_post($postId);
        return self::isEligible($post)
            && $generation > 0
            && $generation === self::generation($postId)
            && '' !== $hash
            && hash_equals($hash, self::contentHash($post));
    }

    public static function completeTicket(int $postId, int $generation): void
    {
        if ($generation === self::generation($postId)) {
            delete_post_meta($postId, self::QUEUED_HASH_META);
        }
    }

    /**
     * Idempotent final state: blocked, jobs invalid, no active derived data.
     */
    public static function forget(int $postId, string $reason = 'lifecycle'): int
    {
        if ($postId < 1) {
            return 0;
        }
        $alreadyBlocked = '1' === (string) get_post_meta($postId, self::BLOCKED_META, true);
        if ($alreadyBlocked && !ProfileStore::hasDerived($postId)) {
            BackgroundWorker::cancelProfiling($postId);
            return 0;
        }

        update_post_meta($postId, self::BLOCKED_META, '1');
        update_post_meta($postId, self::BLOCKED_REASON, sanitize_key($reason));
        update_post_meta($postId, self::BLOCKED_AT, current_time('mysql', true));
        update_post_meta($postId, self::FORGOTTEN_AT_META, current_time('mysql', true));
        update_post_meta($postId, self::GENERATION_META, self::generation($postId) + 1);
        delete_post_meta($postId, self::QUEUED_HASH_META);

        BackgroundWorker::cancelProfiling($postId);
        $removed = ProfileStore::forgetDerived($postId);

        if (class_exists(Audit::class)) {
            Audit::record(
                'ai_forgotten',
                $postId,
                $reason,
                ['removed_rows' => $removed],
                'ai-forgotten:' . $postId . ':' . (string) get_post_meta($postId, self::FORGOTTEN_AT_META, true)
            );
        }
        do_action('quiet_truths_ai_forgotten', $postId, $reason, $removed);
        clean_post_cache($postId);

        return $removed;
    }

    public static function allow(int $postId, string $reason = 'eligible'): bool
    {
        $post = get_post($postId);
        if (!$post instanceof \WP_Post
            || !in_array($post->post_status, ['pending', 'publish'], true)) {
            return false;
        }
        delete_post_meta($postId, self::BLOCKED_META);
        delete_post_meta($postId, self::BLOCKED_REASON);
        delete_post_meta($postId, self::BLOCKED_AT);
        delete_post_meta($postId, self::FORGOTTEN_AT_META);
        Profile::queueWarm($postId);

        if (class_exists(Audit::class)) {
            Audit::record('ai_eligible', $postId, $reason);
        }
        return true;
    }

    public static function onPostUpdated(int $postId, \WP_Post $after, \WP_Post $before): void
    {
        if (!in_array($after->post_type, ['qt_story', 'qt_journal'], true)
            || !self::isEligible($after)) {
            return;
        }
        if (!hash_equals(self::contentHash($before), self::contentHash($after))) {
            Embeddings::clearRuntimeCache($postId);
            Profile::queueWarm($postId);
            if (class_exists(Audit::class)) {
                Audit::record('ai_revision_invalidated', $postId, 'content_changed', [],
                    'ai-revision:' . $postId . ':' . self::contentHash($after));
            }
        }
    }

    public static function onStatusTransition(string $new, string $old, \WP_Post $post): void
    {
        if (!in_array($post->post_type, ['qt_story', 'qt_journal'], true) || $new === $old) {
            return;
        }
        if (in_array($new, ['pending', 'publish'], true)) {
            self::allow($post->ID, 'status_' . $new);
        } else {
            self::forget($post->ID, 'status_' . sanitize_key($new));
        }
    }

    public static function beforeDelete(int $postId, \WP_Post $post): void
    {
        if (in_array($post->post_type, ['qt_story', 'qt_journal'], true)) {
            self::forget($postId, 'deleted');
        }
    }
}
