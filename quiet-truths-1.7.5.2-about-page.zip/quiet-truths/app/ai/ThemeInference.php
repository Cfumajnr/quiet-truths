<?php
/**
 * Quiet Truths — Theme Inference (back-compat shim ONLY)
 *
 * The class historically named ThemeInference was renamed to
 * ConceptInference to match the canonical Quiet Truths vocabulary
 * (v1.7.3 Clauses 11, 14, 15; v1.7.4 Correction 14):
 *
 *   - "Themes" and "Doors" are retired ontology. The layer understands
 *     Concepts (what a story is about), Threads (recurring currents),
 *     and Domains (broad areas of life) — not Themes, not Doors.
 *   - The eight former Door groupings (family, work, tradition,
 *     faith, love, loss, growth, healing) were retired as a public
 *     taxonomy in v1.7.1; conceptToDoor() and doorsFor() were removed
 *     in v1.7.3. NO concept-to-group map survives in current code.
 *   - This file exists ONLY so that external code (plugins, child
 *     snippets, cached class maps) that still type-hints or calls
 *     `\QuietTruths\Ai\ThemeInference` resolves transparently to the
 *     canonical ConceptInference class.
 *
 * NO CURRENT QUIET TRUTHS SUBSYSTEM depends on this shim.
 * The current architecture is: AiKernel → ConceptInference →
 * ThreadInference → Domain intelligence → Semantic/Relationship/
 * Discovery layers (Correction 16).
 *
 * This is LEGACY COMPATIBILITY, isolated and read-only. It is never
 * used for current AI inference and is kept solely so external callers
 * that still reference the old class name keep resolving. It is not
 * part of the current intelligence architecture (Correction 40).
 *
 * @package QuietTruths\Ai
 * @deprecated 1.7.3 Use ConceptInference. ThemeInference is a retired
 *             ontology term; compatibility shim only.
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

// Load the new class if it is not already available.
if (!class_exists(ConceptInference::class, false)) {
    require_once __DIR__ . '/ConceptInference.php';
}

// Alias the old name to the new one so existing references keep working.
if (!class_exists(ThemeInference::class, false)) {
    class_alias(ConceptInference::class, 'QuietTruths\\Ai\\ThemeInference');
}
