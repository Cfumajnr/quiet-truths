<?php
/**
 * Quiet Truths — authoritative storage boundary for AI-derived Story data.
 *
 * Submitted content and operational/audit records do not belong here. This
 * service owns only machine-derived representations and can remove them
 * idempotently without deleting the underlying Story or its consent record.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

final class ProfileStore
{
    /** @return list<string> */
    public static function derivedMetaKeys(): array
    {
        return [
            Profile::META_KEY,
            Profile::REBUILD_PENDING_KEY,
            Profile::CONCEPTS_META_KEY,
            Profile::LEGACY_THEMES_META_KEY,
            Profile::LEGACY_DOORS_META_KEY,
            Embeddings::META_KEY,
            Embeddings::MODEL_KEY,
            Embeddings::DIM_KEY,
            Embeddings::AI_VERSION_KEY,
            Embeddings::PROFILE_VERSION_KEY,
            Embeddings::STATUS_KEY,
            '_qt_ai_retry_attempts',
            '_qt_ai_version',
            '_qt_ai_profile_version',
            '_qt_ai_risk_score',
            '_qt_ai_pii_flags',
            // Legacy cross-submission inference; disabled in hardened builds.
            '_qt_writer_hash',
            '_qt_writer_returning',
            '_qt_writer_prev',
        ];
    }

    /** @return array<string,mixed> */
    public static function readProfile(int $postId): array
    {
        $value = get_post_meta($postId, Profile::META_KEY, true);

        return is_array($value) ? $value : [];
    }

    /** @param array<string,mixed> $profile */
    public static function writeProfile(int $postId, array $profile): bool
    {
        $profile = AiPolicy::enforce($profile);
        return false !== update_post_meta($postId, Profile::META_KEY, $profile);
    }

    /**
     * Idempotently remove every active per-Story AI representation.
     * Returns the number of rows removed where the database can report it.
     */
    public static function forgetDerived(int $postId): int
    {
        if ($postId < 1) {
            return 0;
        }

        global $wpdb;
        $keys = array_values(array_unique(self::derivedMetaKeys()));
        $removed = 0;

        foreach ($keys as $key) {
            $removed += (int) $wpdb->delete(
                $wpdb->postmeta,
                ['post_id' => $postId, 'meta_key' => $key],
                ['%d', '%s']
            );
        }

        // Defensive cleanup for a newer derived key added under the
        // controlled prefixes but not yet listed above. Lifecycle/audit
        // keys deliberately use `_qt_lifecycle_` and are not matched.
        $removed += (int) $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->postmeta}
              WHERE post_id = %d
                AND (meta_key LIKE %s OR meta_key LIKE %s)",
            $postId,
            $wpdb->esc_like('_qt_ai_') . '%',
            $wpdb->esc_like('_qt_embedding') . '%'
        ));

        Embeddings::clearRuntimeCache($postId);
        clean_post_cache($postId);

        return $removed;
    }

    public static function hasDerived(int $postId): bool
    {
        global $wpdb;
        $keys = self::derivedMetaKeys();
        if (empty($keys)) {
            return false;
        }
        $placeholders = implode(',', array_fill(0, count($keys), '%s'));
        $args = array_merge([$postId], $keys);
        $sql = $wpdb->prepare(
            "SELECT 1 FROM {$wpdb->postmeta}
              WHERE post_id = %d AND meta_key IN ($placeholders) LIMIT 1",
            $args
        );

        return (bool) $wpdb->get_var($sql);
    }
}
