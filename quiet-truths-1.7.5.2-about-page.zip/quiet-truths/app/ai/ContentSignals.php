<?php
/**
 * Quiet Truths — Content Signals (Layer 0)
 *
 * Content-warning detection and writer-assistance chips. These are
 * the quiet, non-blocking chips that appear *for the writer* as they
 * type ("grief · a father · money · suicide"), giving them a chance
 * to tag or reconsider. Never blocks submission; never rewrites.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

final class ContentSignals
{
    public static function init(): void
    {
        // Nothing to hook — pure functions consumed by Submission and writer.js.
    }

    /**
     * Human-readable label map for content-warning tags (English first,
     * one or two Swahili entries for warmth). The writer.js chip uses
     * the label directly.
     *
     * @return array<string,string>
     */
    public static function warningLabels(): array
    {
        return [
            'grief'    => __('grief', 'quiet-truths'),
            'illness'  => __('illness', 'quiet-truths'),
            'violence' => __('violence', 'quiet-truths'),
            'suicide'  => __('suicide', 'quiet-truths'),
            'abuse'    => __('abuse', 'quiet-truths'),
            'money'    => __('money', 'quiet-truths'),
            'loss'     => __('loss', 'quiet-truths'),
            'faith'    => __('faith', 'quiet-truths'),
            'sex'      => __('intimacy', 'quiet-truths'),
            'family'   => __('family', 'quiet-truths'),
            'children' => __('children', 'quiet-truths'),
            'addiction' => __('addiction', 'quiet-truths'),
        ];
    }

    /**
     * Suggested content-warning tags for a piece of text. Considers
     * English + Swahili/Sheng cues. Returns tag slugs.
     *
     * @return list<string>
     */
    public static function warningsFor(string $text): array
    {
        $normal = AiKernel::normalise($text);
        if ('' === $normal) {
            return [];
        }

        $map = [
            'grief' => [
                'died','passed away','burial','funeral','lost him','lost her',
                'kufariki','kufa','mazishi','marehemu','aliaga dunia',
                'never came back','coffin','graveside','grave','tears for him',
                'still dial her number',
            ],
            'illness' => [
                'hospital','sick','cancer','hiv','diagnosed','ward','admitted',
                'surgery','chemotherapy','diabetes','ulcers','depression',
                'hospitali','mgonjwa','daktari','matibabu',
            ],
            'violence' => [
                'beat me','beat her','beat him','hit me','hit her','hit him',
                'choked','slapped','kicked','blood','punch','kicked me',
                'alinipiga','akapiga','alipiga',
            ],
            'suicide' => [
                'end my life','kill myself','wanted to die','suicide',
                'no reason to live','take my life','overdose','kills herself',
                'kujiua',
            ],
            'abuse' => [
                'abused','abusive','touched me','molested','raped','rape',
                'forced himself on me','groped','alininajisi','alinibaka',
            ],
            'money' => [
                'debt','rent','evicted','no money','broke','loan','400k',
                '200k','100k','50k','denied me','zero in my account',
                'denied rent','mkopo','deni','kulipa rent','nimekosa kodi',
            ],
            'loss' => [
                'left me','divorce','separated','broke up','said goodbye',
                'talaka','tenga','aliacha','aliniacha',
            ],
            'faith' => [
                'prayed','church','mosque','pastor','imam','sheikh',
                'bible','quran','knees and prayed','on my knees',
                'niliomba','kuomba','kanisa','msikiti',
            ],
            'sex' => [
                'slept with','sex','cheated','cheating','mistress',
                'mpango','side chick','mpango wa kando','tukalala',
                'alinitongoza',
            ],
            'family' => [
                'my father','my mother','my son','my daughter','my parents',
                'my brother','my sister','baba yangu','mama yangu',
            ],
            'children' => [
                'my child','my baby','my kid','became a mother','became a father',
                'firstborn','lastborn','mtoto wangu','watoto wangu',
            ],
            'addiction' => [
                'alcohol','drunk','drugs','cocaine','bhang','weed','heroin',
                'gambling','betting','placed a bet','pombe','sigara','bang',
            ],
        ];

        $out = [];
        foreach ($map as $tag => $phrases) {
            foreach ($phrases as $p) {
                if (str_contains($normal, $p)) {
                    $out[] = $tag;
                    break;
                }
            }
        }
        return array_values(array_unique($out));
    }

    /**
     * Chip data for writer.js — same shape as the old warnMap (tag =>
     * label) so the JS doesn't need changes beyond pointing at this.
     *
     * @return array<string,string>
     */
    public static function chipMap(): array
    {
        return self::warningLabels();
    }
}
