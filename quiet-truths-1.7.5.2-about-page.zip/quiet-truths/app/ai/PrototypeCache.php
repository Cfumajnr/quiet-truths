<?php
/**
 * Quiet Truths — Prototype Vector Cache
 *
 * Persists the embedding vectors for room and thread prototype phrases
 * so that profile builds do NOT re-embed the same 56 room prototypes
 * and ~80 thread prototypes for every story.
 *
 * IMPORTANT — embedding-call budget per Profile::build():
 *
 *   Cold system: ONE HTTP call ([story] + all missing room/thread protos).
 *   Warm system: ONE HTTP call ([story] only, protos from wp_options).
 *
 * DENSE-ONLY RULE:
 *   We ONLY persist vectors produced by embedDense() — validated as
 *   sequential numeric arrays of length = expected model dimension.
 *   If the dense request fails, we do NOT fall back to token vectors
 *   and we do NOT write anything to the cache; the profile runs in
 *   lexical mode and the next background build retries. This prevents
 *   the "poisoned cache" bug where sparse token vectors are saved as
 *   if they were BGE-M3 dense vectors.
 *
 * HIERARCHY: semantic prototype > Concept > Signal > Lexical.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

final class PrototypeCache
{
    private const OPTION_PREFIX = 'qt_proto_vecs_';

    /** @var array<string,array<string,array<float>>> */
    private static array $warm = [];

    /**
     * Standalone convenience for CLI/tests; Profile::build() uses
     * embedStoryAndPrototypes() for the single-batch path.
     *
     * @param  string       $group   'rooms' or 'threads'.
     * @param  list<string> $phrases Ordered prototype phrases.
     * @return array<string,array<float>> phrase => dense vector.
     */
    public static function vectors(string $group, array $phrases): array
    {
        $phrases = array_values(array_filter($phrases, fn($p) => '' !== trim((string) $p)));
        if (empty($phrases)) {
            return [];
        }

        $meta  = self::serviceMeta();
        $cache = self::loadGroup($group, $phrases, $meta);

        $missing = [];
        foreach ($phrases as $p) {
            if (empty($cache['vecs'][$p])) {
                $missing[] = $p;
            }
        }

        if (!empty($missing) && $meta['ok']) {
            $vecs = Embeddings::embedDense($missing, (int) $meta['dim']);
            if (null !== $vecs && count($vecs) === count($missing)) {
                foreach ($missing as $i => $p) {
                    $cache['vecs'][$p] = $vecs[$i];
                }
                self::saveGroup($group, $cache, $meta);
            }
        }

        self::$warm[self::memKey($group, $meta)] = $cache['vecs'];
        return $cache['vecs'];
    }

    /**
     * Single-shot: one HTTP call on cold (story + missing protos), one
     * HTTP call on warm (story only). Returns story vec, room vecs,
     * thread vecs, and effective mode ('dense'|'lexical').
     *
     * @return array{0:array,1:array<string,array>,2:array<string,array>,3:string}
     */
    public static function embedStoryAndPrototypes(
        string $storyText,
        array $roomProtos,
        array $threadProtos
    ): array {
        $meta  = self::serviceMeta();
        $dense = $meta['ok'] && $meta['dim'] > 0;

        $roomCache   = self::loadGroup('rooms', $roomProtos, $meta);
        $threadCache = self::loadGroup('threads', $threadProtos, $meta);

        $batch      = [$storyText];
        $roomMissing   = [];
        $threadMissing = [];

        foreach ($roomProtos as $p) {
            if (empty($roomCache['vecs'][$p])) {
                $roomMissing[$p] = count($batch);
                $batch[] = $p;
            }
        }
        foreach ($threadProtos as $p) {
            if (empty($threadCache['vecs'][$p])) {
                $threadMissing[$p] = count($batch);
                $batch[] = $p;
            }
        }

        $mode     = 'lexical';
        $storyVec = [];

        if ($dense) {
            $vecs = Embeddings::embedDense($batch, (int) $meta['dim']);
            if (null !== $vecs && count($vecs) === count($batch)) {
                $storyVec = $vecs[0];
                foreach ($roomMissing as $p => $idx)   $roomCache['vecs'][$p]   = $vecs[$idx];
                foreach ($threadMissing as $p => $idx) $threadCache['vecs'][$p] = $vecs[$idx];
                if (!empty($roomMissing))   self::saveGroup('rooms', $roomCache, $meta);
                if (!empty($threadMissing)) self::saveGroup('threads', $threadCache, $meta);
                $mode = 'dense';
            }
        }

        if ('lexical' === $mode) {
            // Lexical fallback for the story; do NOT write sparse vectors
            // into proto caches.
            $storyVec = Embeddings::tokenVector($storyText);
        }

        self::$warm[self::memKey('rooms', $meta)]   = $roomCache['vecs'];
        self::$warm[self::memKey('threads', $meta)] = $threadCache['vecs'];

        return [$storyVec, $roomCache['vecs'], $threadCache['vecs'], $mode];
    }

    public static function flush(string $group = ''): void
    {
        if ('' !== $group) {
            delete_option(self::OPTION_PREFIX . $group);
            foreach (array_keys(self::$warm) as $k) {
                if (strpos($k, $group . '|') === 0) {
                    unset(self::$warm[$k]);
                }
            }
            return;
        }
        foreach (['rooms', 'threads'] as $g) {
            delete_option(self::OPTION_PREFIX . $g);
        }
        self::$warm = [];
    }

    /* ──────────────────── internal ──────────────────── */

    /** @return array{ok:bool,model:string,dim:int} */
    private static function serviceMeta(): array
    {
        $ok    = Embeddings::canWriteDense();
        $model = $ok ? Embeddings::activeModel() : 'tokens-v1';
        $dim   = $ok ? Embeddings::activeDim() : 0;
        return ['ok' => $ok, 'model' => $model, 'dim' => $dim];
    }

    private static function memKey(string $group, array $meta): string
    {
        return $group . '|' . ($meta['model'] ?? 'tokens-v1');
    }

    /** @param list<string> $phrases */
    private static function signature(array $phrases, array $meta): string
    {
        $sorted = $phrases;
        sort($sorted, SORT_STRING);
        $concat = ($meta['model'] ?? '') . '|' . (int) ($meta['dim'] ?? 0) . '|'
                . QT_THEME_VERSION . '|'
                . implode("\x1f", $sorted);
        return substr(md5($concat), 0, 16);
    }

    /**
     * @param  list<string> $phrases
     * @return array{vecs:array<string,array<float>>,sig:string}
     */
    private static function loadGroup(string $group, array $phrases, array $meta): array
    {
        $key = self::memKey($group, $meta);
        if (isset(self::$warm[$key])) {
            return ['vecs' => self::$warm[$key], 'sig' => ''];
        }
        $sig = self::signature($phrases, $meta);
        $opt = get_option(self::OPTION_PREFIX . $group);
        $opt = is_array($opt) ? $opt : [];
        $vecs = [];
        $expectedDim = (int) ($meta['dim'] ?? 0);
        if (($opt['sig'] ?? '') === $sig && is_array($opt['vecs'] ?? null)) {
            foreach ($phrases as $p) {
                $v = $opt['vecs'][$p] ?? null;
                if (!is_array($v)) continue;
                if (array_keys($v) !== range(0, count($v) - 1)) continue;
                if ($expectedDim > 0 && count($v) !== $expectedDim) continue;
                $allNumeric = true;
                foreach ($v as $x) { if (!is_numeric($x)) { $allNumeric = false; break; } }
                if (!$allNumeric) continue;
                $vecs[$p] = array_map('floatval', $v);
            }
        }
        return ['vecs' => $vecs, 'sig' => $sig];
    }

    private static function saveGroup(string $group, array $cache, array $meta): void
    {
        if (!$meta['ok'] || (int) ($meta['dim'] ?? 0) < 1) {
            return;
        }
        update_option(self::OPTION_PREFIX . $group, [
            'sig'   => $cache['sig'],
            'vecs'  => $cache['vecs'],
            'model' => $meta['model'],
            'dim'   => (int) $meta['dim'],
            'built' => gmdate('c'),
        ], false);
    }
}
