<?php
/**
 * Quiet Truths — Journal Understanding
 *
 * The deeper layer of the house (Journal Bible).
 *
 * A Story answers "what happened?" A Journal asks "what does it mean?",
 * "why does it happen?", "what surrounds it?", "what can we understand?".
 *
 * This is NOT a duplicate of StoryUnderstanding. It builds on the SAME
 * shared ontology (Concepts / Threads / Domains / Signals / Context /
 * semantics) — the connective tissue of the house (§5, §18) — and adds the
 * journal-specific inference layer (§15–§17, §26, §30–§32, §47):
 *
 *   - subject           — what the writer is examining
 *   - questions         — the "why / what does it mean" opened up
 *   - argument          — what is being argued / claimed
 *   - observation       — what is being observed
 *   - evidence          — sourced / researched / statistical cues
 *   - claims            — classification of each claim's nature
 *   - author            — perspective/role context (never automatic authority)
 *   - depth             — how far past the immediate the writing reaches
 *   - content_identity  — a machine fingerprint of the piece
 *
 * The profile is machine-facing and reconstructible (§27, §50). It never
 * becomes public taxonomy (§3), never flattens the author's voice (§32),
 * and never manufactures authority (§46). Author expertise is treated as
 * context, not proof (§30–§31).
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

use QuietTruths\Core\Concepts;

final class JournalUnderstanding
{
    private const QUESTION_CUES = [
        'why', 'what does', 'what does it mean', 'what happens', 'how does',
        'why do', 'why are', 'why is', 'what lies', 'what surrounds',
        'what we', 'what have', 'what can', 'what it means', 'does it mean',
        'the question', 'underneath', 'beneath', 'kwa nini', 'maana',
    ];

    private const ARGUMENT_CUES = [
        'argue', 'argues', 'claim', 'claims', 'contend', 'maintain', 'suggest',
        'suggests', 'in fact', 'the truth is', 'what i believe', 'what this shows',
        'the point', 'my argument', 'the reality is', 'rather than', 'in reality',
        'the real question', 'what matters', 'the deeper issue', 'in my view',
    ];

    private const OBSERVATION_CUES = [
        'we see', 'you see', 'in kenya', 'across the country', 'among',
        'in many', 'time and again', 'again and again', 'more often than not',
        'i have noticed', 'what i observe', 'the pattern', 'there is a',
        'there are', 'families', 'many of us', 'so many', 'i have watched',
        'over the years', 'in my work', 'in practice',
    ];

    private const EVIDENCE_CUES = [
        'research', 'studies', 'study', 'data', 'statistics', 'survey',
        'according to', 'report', 'evidence', 'found that', 'shows that',
        'the numbers', 'by the time', 'percent', '%,', 'researchers',
        'the data', 'measured', 'documented',
    ];

    /**
     * Personal-experience markers — distinguish a journal that is
     * experiential (grounded in the writer's life) from one that is
     * primarily analytical or sourced.
     */
    private const EXPERIENCE_CUES = [
        'i remember', 'i lived', 'when i', 'my own', 'i saw', 'i watched',
        'i felt', 'i became', 'i watched my', 'in my life', 'my family',
        'i grew up', 'i moved', 'i worked', 'i was', 'i am',
    ];

    /**
     * Claim-nature classification (Journal Bible §47): how the writing
     * presents its statements. The AI must understand whether a claim is
     * experiential, interpretive, observational, sourced, analytical, or
     * speculative — never flattening them into one undifferentiated truth.
     */
    private const CLAIM_CUES = [
        'experiential' => ['i remember', 'i lived', 'when i', 'my own', 'i felt', 'i became', 'i was', 'i am', 'i watched my', 'my family'],
        'interpretive' => ['i believe', 'in my view', 'the truth is', 'what this means', 'i think', 'it seems to me', 'to me', 'what i understand'],
        'observational' => ['i have noticed', 'what i observe', 'you see', 'we see', 'time and again', 'more often than not', 'i have watched'],
        'sourced'      => ['research', 'studies', 'data', 'statistics', 'according to', 'the numbers', 'measured', 'survey', 'report', 'evidence'],
        'analytical'   => ['the pattern', 'the structure', 'in reality', 'rather than', 'the cause', 'the result', 'because', 'therefore', 'this is why', 'what this shows'],
        'speculative'  => ['perhaps', 'maybe', 'could be', 'might be', 'what if', 'one wonders', 'it is possible', 'i wonder'],
    ];

    /**
     * Author-perspective classification from the byline role/bio (Journal
     * Bible §30). A professional title is context, never automatic proof
     * (§31). Multiple perspectives may coexist.
     *
     * @return list<string>
     */
    public static function authorPerspectives(string $role, string $bio): array
    {
        $text = mb_strtolower($role . ' ' . $bio, 'UTF-8');
        $out  = [];

        $map = [
            'professional'    => ['professor', 'lecturer', 'doctor', 'psychologist', 'counsellor', 'therapist', 'lawyer', 'engineer', 'accountant', 'economist', 'researcher', 'consultant', 'ceo', 'founder', 'manager', 'expert'],
            'journalism'      => ['journalist', 'reporter', 'editor', 'correspondent', 'writer for', 'columnist'],
            'academic'        => ['university', 'academic', 'researcher', 'scholar', 'phd', 'study'],
            'lived'           => ['i am a', 'i am an', 'i was a', 'my own', 'lived', 'survivor', 'mother', 'father', 'parent'],
            'cultural'        => ['culture', 'community', 'kenyan', 'tradition', 'elder'],
            'community'       => ['community', 'organiser', 'leader', 'village', 'neighbourhood'],
            'research'        => ['research', 'studied', 'data', 'field'],
        ];

        foreach ($map as $perspective => $cues) {
            foreach ($cues as $cue) {
                if (str_contains($text, $cue)) {
                    $out[] = $perspective;
                    break;
                }
            }
        }

        // A journal always carries the writer's own perspective implicitly.
        $out[] = 'writer';

        return array_values(array_unique($out));
    }

    /**
     * Build the full journal understanding envelope.
     *
     * @param string   $text  the journal title + body
     * @param string   $role  byline role/title (may be empty)
     * @param string   $bio   byline bio (may be empty)
     * @return array<string,mixed>
     */
    public static function understand(string $text, string $role = '', string $bio = ''): array
    {
        $normal = AiKernel::normalise($text);

        $concepts = ConceptInference::conceptsFromText($text);
        $sem      = ConceptInference::semanticConcepts($text);

        $scores = [];
        foreach ($concepts as $slug) {
            $scores[$slug] = 1.0;
        }
        foreach ($sem as $slug => $s) {
            if (!isset($scores[$slug]) || $s > $scores[$slug]) {
                $scores[$slug] = $s;
            }
        }
        arsort($scores);

        $allSlugs   = array_keys($scores);
        $primary    = array_slice($allSlugs, 0, 5);
        $secondary  = array_slice($allSlugs, 5, 8);

        return [
            'subject'           => self::subject($normal, $allSlugs),
            'questions'         => self::questions($normal),
            'argument'          => self::arguments($normal),
            'observation'       => self::hasCue($normal, self::OBSERVATION_CUES),
            'evidence'          => self::evidence($normal),
            'claims'            => self::claims($normal),
            'experiential'      => self::hasCue($normal, self::EXPERIENCE_CUES),
            'author'            => [
                'perspectives' => self::authorPerspectives($role, $bio),
                // Professional identity is context, not authority (§31).
                'expertise_context' => ('' !== trim($role)) ? trim($role) : '',
            ],
            'depth'             => round(self::depth($normal), 2),
            'concepts'          => $allSlugs,
            'primary_concepts'  => $primary,
            'secondary_concepts'=> $secondary,
            'concept_scores'    => array_slice($scores, 0, 14),
            'language'          => self::language($text),
            'content_identity'  => md5($normal),
            'confidence'        => round(min(0.90, 0.35 + 0.06 * count($scores)), 2),
            'provenance'        => [
                'inference' => 'journal-understanding-v1',
                'built_at'  => gmdate('c'),
            ],
        ];
    }

    /**
     * Guess the journal's central subject: the strongest concept name, or
     * a cleaned fragment of the title if none is recognised.
     *
     * @param list<string> $concepts
     */
    private static function subject(string $normal, array $concepts): string
    {
        if (!empty($concepts)) {
            $slug    = $concepts[0];
            $concept = Concepts::concepts()[$slug] ?? null;

            if ($concept) {
                return (string) ($concept['name'] ?? $slug);
            }

            return str_replace('-', ' ', $slug);
        }

        $first = preg_split('/[.!?\n]/u', $normal, 2)[0] ?? '';
        $words = preg_split('/\s+/u', trim($first)) ?: [];

        return implode(' ', array_slice($words, 0, 6));
    }

    /**
     * @return list<string>
     */
    private static function questions(string $normal): array
    {
        $out = [];

        if (preg_match_all('/[^.!?\n]+[?]/u', $normal, $m)) {
            foreach ($m[0] as $q) {
                $q = trim(preg_replace('/\s+/u', ' ', $q));
                if ('' !== $q) {
                    $out[] = $q;
                }
            }
        }

        foreach (self::QUESTION_CUES as $cue) {
            if (str_contains($normal, $cue) && count($out) < 6) {
                $out[] = $cue;
            }
        }

        return array_values(array_unique(array_slice($out, 0, 6)));
    }

    /**
     * @return list<string>
     */
    private static function arguments(string $normal): array
    {
        $out = [];
        foreach (self::ARGUMENT_CUES as $cue) {
            if (str_contains($normal, $cue)) {
                $out[] = $cue;
            }
        }

        return array_values(array_unique($out));
    }

    /**
     * @return list<string>
     */
    private static function evidence(string $normal): array
    {
        $out = [];
        foreach (self::EVIDENCE_CUES as $cue) {
            if (str_contains($normal, $cue)) {
                $out[] = $cue;
            }
        }

        return array_values(array_unique(array_slice($out, 0, 8)));
    }

    /**
     * Classify the nature of the claims in the writing (Journal Bible §47).
     * Returns slugs for each present claim-nature; the writing may exhibit
     * several at once. This keeps experience, interpretation, observation,
     * sourced support, analysis and speculation distinct.
     *
     * @return list<string>
     */
    private static function claims(string $normal): array
    {
        $out = [];
        foreach (self::CLAIM_CUES as $nature => $cues) {
            if (self::hasCue($normal, $cues)) {
                $out[] = $nature;
            }
        }

        return $out;
    }

    private static function hasCue(string $normal, array $cues): bool
    {
        foreach ($cues as $cue) {
            if (str_contains($normal, $cue)) {
                return true;
            }
        }

        return false;
    }

    /**
     * A 0..1 depth heuristic: how far past the immediate the writing
     * reaches. Combines question, argument, observation, evidence and
     * claim-nature cues. Depth is measured by the reach of the thinking,
     * not by vocabulary or length (§34).
     */
    private static function depth(string $normal): float
    {
        $score = 0.0;

        if (self::hasCue($normal, self::QUESTION_CUES))  $score += 0.25;
        if (self::hasCue($normal, self::ARGUMENT_CUES))  $score += 0.20;
        if (self::hasCue($normal, self::OBSERVATION_CUES)) $score += 0.15;
        if (self::hasCue($normal, self::EVIDENCE_CUES))  $score += 0.12;

        $claims = self::claims($normal);
        if (count($claims) >= 3)  $score += 0.18;
        elseif (count($claims) >= 2) $score += 0.10;

        $words = count(preg_split('/\s+/u', trim($normal)) ?: []);
        if ($words >= 600)  $score += 0.15;
        elseif ($words >= 300) $score += 0.08;

        return min(1.0, $score);
    }

    private static function language(string $text): string
    {
        $sw = preg_match('/\b(kwa|ya|na|ni|sasa|kila|baada|kabla|hii|ile|watu|familia)\b/u', AiKernel::normalise($text));

        return $sw ? 'sw-en' : 'en';
    }
}
