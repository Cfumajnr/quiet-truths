<?php
/**
 * Quiet Truths — AI Kernel (the quiet librarian, central desk)
 *
 * Boots the AI subsystem. Houses the feature flag and the loopback
 * HTTP client shared by every ai/* module.
 *
 * The four non-negotiable rules:
 *   1. AI never writes words a reader sees as content.
 *   2. AI works behind the curtain — readers experience it as better
 *      search, better suggestions, better protection for writers.
 *   3. Stories never leave the server. The embedding service listens
 *      on 127.0.0.1 only; no third-party APIs.
 *   4. AI flags are always suggestions. A human moderator decides.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

final class AiKernel
{
    /* ──────────────────── boot ──────────────────── */

    public static function boot(): void
    {
        if (!self::enabled()) {
            return;
        }

        // Subsystems. Order matters: Embeddings must be registered first
        // because everything else may ask for vectors; Profile before
        // Moderation (which reads it); BackgroundWorker early so other
        // subsystems can enqueue jobs.
        Embeddings::init();
        ProfileLifecycle::init();
        BackgroundWorker::init();
        ContentSignals::init();
        PrivacyScanner::init();
        // ConceptInference is the canonical concept-intelligence layer.
        // The former ThemeInference name is a retired compatibility
        // shim (v1.7.3, v1.7.4 Corrections 14–16) — current code never
        // references it.
        ConceptInference::init();
        StoryUnderstanding::init();
        StoryRelations::init();
        SemanticSearch::init();
        Profile::class; // registered via autoload
        ModerationSignals::init();
    }

    /* ──────────────────── feature flag ──────────────────── */

    public static function enabled(): bool
    {
        return !defined('QT_AI_ENABLED') || QT_AI_ENABLED;
    }

    /* ──────────────────── service connectivity ──────────────────── */

    /**
     * Literal loopback address only. Hostnames and arbitrary IPs are
     * rejected before the WordPress HTTP layer sees any Story text.
     */
    public static function host(): string
    {
        $host = trim((string) (defined('QT_AI_EMBED_HOST') ? QT_AI_EMBED_HOST : '127.0.0.1'));
        $host = trim($host, '[]');

        return in_array($host, ['127.0.0.1', '::1'], true) ? $host : '';
    }

    public static function port(): int
    {
        $port = defined('QT_AI_EMBED_PORT') ? (int) QT_AI_EMBED_PORT : 0;

        return $port >= 1 && $port <= 65535 ? $port : 0;
    }

    public static function isLocalOnly(): bool
    {
        return '' !== self::host();
    }

    public static function serviceUrl(): string
    {
        $host = self::host();
        $port = self::port();
        if ('' === $host || $port < 1) {
            return '';
        }

        // HTTP over kernel loopback is intentional. No remote TLS mode is
        // implemented, so certificate-verification bypasses cannot arise.
        $authority = '::1' === $host ? '[::1]' : $host;
        return 'http://' . $authority . ':' . $port;
    }

    /**
     * Is the local embedding service reachable and ready? Cached per
     * request — delegates to Embeddings::serviceMeta() which hits
     * /health (not a port probe) so we know the model is loaded.
     */
    public static function serviceReady(): bool
    {
        return self::serviceUrl() !== '' && Embeddings::serviceMeta()['ok'];
    }

    /**
     * Issue a POST to the local embedding service. Returns decoded
     * JSON or null if anything went wrong. Never raises.
     *
     * @return array<string,mixed>|null
     */
    public static function postJson(string $path, array $payload): ?array
    {
        $allowed = ['/embed', '/similarity', '/similarities', '/classify'];
        if (!self::serviceReady() || !in_array($path, $allowed, true)) {
            return null;
        }
        $url = self::serviceUrl();
        // Re-assert the policy immediately before transmission. A mutable
        // filter or malformed path can never turn this into an SSRF client.
        $parts = wp_parse_url($url);
        $host  = trim((string) ($parts['host'] ?? ''), '[]');
        if (!in_array($host, ['127.0.0.1', '::1'], true)
            || 'http' !== (string) ($parts['scheme'] ?? '')) {
            return null;
        }

        $resp = wp_remote_post($url . $path, [
            'timeout'  => 3.0,
            'blocking' => true,
            'headers'  => ['Content-Type' => 'application/json'],
            'body'     => wp_json_encode($payload),
        ]);
        if (is_wp_error($resp) || 200 !== (int) wp_remote_retrieve_response_code($resp)) {
            return null;
        }
        $decoded = json_decode((string) wp_remote_retrieve_body($resp), true);
        return is_array($decoded) ? $decoded : null;
    }

    /* ──────────────────── text helpers ──────────────────── */

    public static function normalise(string $text): string
    {
        $text = wp_strip_all_tags($text);
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = mb_strtolower($text, 'UTF-8');
        $text = preg_replace('/\s+/u', ' ', $text) ?: '';
        return trim($text);
    }
}
