<?php
/**
 * Quiet Truths — Semantic Search (Layers 2 + 5)
 *
 * Adds a vector similarity bonus to search and similar-story scoring.
 * Read-only: uses Profile::get() and Embeddings::forPostRead() so it
 * never triggers HTTP calls or profile rebuilds on a reader page.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

final class SemanticSearch
{
    public static function init(): void
    {
        add_filter('quiet_truths_search_extra_score', [self::class, 'searchBoost'], 10, 3);
        add_filter('quiet_truths_similar_extra_score', [self::class, 'similarBoost'], 10, 3);
    }

    public static function searchBoost(float $current, int $postId, string $query): float
    {
        $post = get_post($postId);
        if (!$post || '' === trim($query)) {
            return $current;
        }

        // Embed query once per request. If the service is down, this falls
        // back to a token vector (cheap, local, no network).
        static $qvec = null;
        static $qkey = '';
        if ($qkey !== $query) {
            $qvecs = Embeddings::embed([$query]);
            $qvec  = $qvecs[0] ?? [];
            $qkey  = $query;
        }
        if (empty($qvec)) {
            return $current;
        }

        $dvec = self::vectorForPost($postId);
        if (empty($dvec)) {
            return $current;
        }
        $sim = Embeddings::vectorSimilarity($qvec, $dvec);
        return $current + $sim * 3.5;
    }

    public static function similarBoost(float $current, int $a, int $b): float
    {
        if ($a === $b) return $current;
        $va = self::vectorForPost($a);
        $vb = self::vectorForPost($b);
        if (empty($va) || empty($vb)) return $current;
        $sim = Embeddings::vectorSimilarity($va, $vb);
        return $current + $sim * 3.0;
    }

    /** @var array<int,array<float>|array<string,float>|null> per-request cache */
    private static array $vecCache = [];

    /**
     * Read-only access to a post's vector.
     * @return array<float>|array<string,float>
     */
    private static function vectorForPost(int $postId): array
    {
        if (array_key_exists($postId, self::$vecCache)) {
            return self::$vecCache[$postId] ?? [];
        }
        // Try stored embedding (dense or sparse) first; fall back to a
        // transient token vector if nothing is stored yet.
        $v = Embeddings::forPostRead($postId);
        self::$vecCache[$postId] = $v ?: null;
        return $v;
    }
}
