<?php
/**
 * Quiet Truths — Concept Inference
 *
 * The Concept Intelligence layer (AI Bible §XX; Correction 12 / 13):
 * maps language onto Quiet Truths concept slugs. Concepts name what a
 * story is ABOUT (grief, money, religion, parenthood, …). They are
 * background ontology — never a public taxonomy, never a landing page.
 *
 * This file also carries the eight retired "Door" concept groupings
 * (family, work, tradition, faith, love, loss, growth, healing) as an
 * INTERNAL convenience for search fan-out and editor diagnostics. As
 * of v1.7.1 these groupings are NOT a public navigation surface, they
 * have no public routes, and their meaning is being absorbed into
 * Concepts + Threads + Domains (Correction One / Twenty-Three).
 *
 * Provides two routes to concepts:
 *
 *   1. Deterministic phrase signatures — always available, no service
 *      needed, curated in English + Kiswahili + a little Sheng.
 *
 *   2. A *semantic* route — when the embedding service is up, each
 *      concept has a small set of prototypical anchor phrases
 *      (the beginning of an ontology, not a flat tag list); we ask
 *      the model to score the text against every anchor and take the
 *      best hit per concept. This is what lets
 *        "I kept dialling her number after she died"
 *      pull in grief/ritual/absence even though no exact phrase fires.
 *
 * Concepts are NOT tags (Bible XXI). The presence of a word does not
 * establish its meaning. Concepts are evidence; meaning emerges from
 * the relationship between concepts, signals, context, language, and
 * the story as a whole.
 *
 * Concepts are NOT public categories (Bible III, IV). A story can be
 * about money, parenting, aging, friendship, or migration without any
 * of those becoming a Room or a public menu item. Concepts feed the
 * background intelligence; the seven Rooms remain the public house.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

final class ConceptInference
{
    /**
     * Anything above this score counts as a semantic concept hit. Tuned
     * against the ensemble scorer in /classify (which penalises isolated
     * single-anchor hits) — 0.40 is conservative enough to avoid noise
     * but lets multi-anchor resonance through.
     */
    public const SEMANTIC_THRESHOLD = 0.40;

    public static function init(): void
    {
        // Pure functions.
    }

    /**
     * Deterministic phrase signatures (always available).
     *
     * @return array<string,list<string>>
     */
    public static function phraseSignatures(): array
    {
        return [
            'grief' => [
                'did not come home', 'never came back', 'died', 'burial', 'funeral',
                'last time i saw', 'still waiting', 'never called again',
                'kept dialling', 'kept dialing', 'called her number', 'called his number',
                'empty chair', 'his side of the bed', 'her side',
                'kufariki', 'kufa', 'mazishi', 'marehemu', 'aliacha dunia',
            ],
            'shame' => [
                'i lied', 'told him everything was', 'told her everything was',
                'smiled and said', 'could not tell', 'did not tell',
                'smiled and nodded', 'pretend', 'pretending', 'said nothing',
                'could not say', 'ashamed', 'niliacha kusema',
            ],
            'failure' => [
                'failed again', 'did not work out', 'failing again',
                'let him down', 'let her down', 'disappointed', 'not good enough',
                'did not make it', 'i have nothing', 'empty shop', 'closed the shop',
                'nilishindwa', 'sikuwaweza',
            ],
            'family' => [
                'my father', 'my mother', 'my parents', 'my son', 'my daughter',
                'firstborn', 'lastborn', 'our family', 'baba yangu', 'mama yangu',
                'ndugu yangu', 'kaka yangu', 'dada yangu',
            ],
            'money' => [
                'rent notice', 'no customers', 'no clients', 'loan', 'debt',
                'denied me', 'zero in my account', 'nothing in my', 'could not pay',
                'kulipa kodi', 'deni', 'mkopo', '400k', '200k', '100k', '50k',
                'evicted', 'rent', 'no money', 'broke',
            ],
            'loneliness' => [
                'empty house', 'talk to nobody', 'nobody knows', 'eat alone',
                'alone in the house', 'spent the night alone', 'cry at night',
                'night alone', 'sit in the dark', 'niko peke yangu',
            ],
            'hope' => [
                'tomorrow', 'one day', 'it will be well', 'still trying',
                'still believe', 'maybe one day', 'not giving up', 'kuna siku',
                'kila la heri',
            ],
            'healing' => [
                'felt lighter', 'forgave myself', 'forgave him', 'forgave her',
                'first night i slept', 'breathed', 'let it go', 'nilisamehe',
            ],
            'faith' => [
                'prayed', 'i prayed', 'church', 'mosque', 'pastor', 'imam',
                'sheikh', 'on my knees', 'niliomba', 'kanisa', 'msikiti',
                'bible', 'quran', 'qur\'an',
            ],
            'secrets' => [
                'never told anyone', 'i have never told', 'first time i say',
                'cannot tell anyone', 'only here', 'only this site',
                'i have kept', 'kept it from', 'sijawahi sema',
            ],
            'boundaries' => [
                'i said no', 'walked away', 'cut them off', 'blocked them',
                'enough is enough', 'protect my peace', 'distance myself',
                'niliacha', 'nlimwacha',
            ],
            'ambition' => [
                'build something', 'started a business', 'opened a shop',
                'my business', 'my company', 'i will build', 'biashara yangu',
            ],
            'relationships' => [
                'left me', 'he left', 'she left', 'after all these years',
                'found someone', 'married him', 'married her', 'wedding day',
                'our wedding', 'aliniwoa', 'alioa',
            ],
            'identity' => [
                'i do not know who i am', 'still becoming', 'finding myself',
                'who i really am', 'not the same person',
            ],
            'vulnerability' => [
                'i am scared', 'i am afraid', 'i cry', 'i am tired',
                'i am weak', 'i am broken', 'naogopa', 'nimechoka',
                'nimechoka kujifanya niko sawa',
            ],
            'memory' => [
                'i still remember', 'i remember the', 'the smell of',
                'that day', 'still hear his voice', 'still see her',
                'nakumbuka',
            ],
            'ritual' => [
                'every sunday', 'every morning', 'every night', 'every saturday',
                'same time', 'i used to', 'kila siku', 'kila jumapili',
            ],
            'absence' => [
                'silence where', 'the house was quiet', 'did not call',
                'hakupiga simu',
            ],
            'longing' => [
                'i miss him', 'i miss her', 'still miss', 'i wish i could',
                'if i could see', 'one more time', 'ninamkumbuka',
            ],
            'courage' => [
                'i finally said', 'i walked in', 'woke up and', 'made the call',
                'wrote this', 'i sent it',
            ],
            'gratitude' => [
                'thankful', 'grateful', 'i am grateful', 'thank god',
                'asante', 'nashukuru',
            ],
            'waiting' => [
                'still waiting', 'wait for', 'waiting for him', 'waiting for her',
                'nangoja',
            ],
            'jealousy' => [
                'i was jealous', 'i envied', 'i compared myself',
                'she had everything', 'he had everything',
            ],
            'betrayal' => [
                'he told everyone', 'she told everyone', 'shared my secret',
                'broke my trust', 'i trusted him', 'i trusted her', 'spread my',
                'aliniambia wengine',
            ],
            'home' => [
                'going home', 'back home', 'our house', 'childhood home',
                'where i grew up', 'home village', 'ushago', 'kijijini',
            ],
            'parenthood' => [
                'my child', 'my son', 'my daughter', 'i held him', 'i held her',
                'first time i held', 'became a father', 'became a mother',
                'mtoto wangu', 'watoto wangu',
            ],
            'father' => [
                'my father', 'my dad', 'baba yangu', 'baba', 'dad', 'daddy',
            ],
            'mother' => [
                'my mother', 'my mum', 'my mom', 'mama yangu', 'mama', 'mum',
                'mom',
            ],
            'forgiveness' => [
                'i forgave', 'let it go', 'i let go', 'held no anger', 'made peace',
                'nilisamehe',
            ],
            'justice' => [
                'reported', 'police statement', 'arrested', 'court',
                'lawyer said', 'taken to court', 'kituo cha polisi',
            ],
            'aging' => [
                'getting older', 'old age', 'gray hair', 'my knees', 'my eyes',
                'retire', 'retired', 'uzeeni',
            ],
            'work' => [
                'my boss', 'at the office', 'in the office', 'my job',
                'resigned', 'i resigned', 'fired', 'sacked', 'employed',
                'kazi yangu', 'bosi wangu',
            ],
            'friendship' => [
                'my friend', 'best friend', 'our friendship', 'friends since',
                'rafiki yangu',
            ],
            'joy' => [
                'i laughed', 'i smiled', 'for the first time', 'felt happy',
                'i was happy', 'nilifurahi',
            ],
            'separation' => [
                'moved out', 'packed my bags', 'left the house', 'separated',
                'divorce', 'divorced', 'parted ways', 'talaka',
            ],
            'illness' => [
                'hospital', 'sick', 'cancer', 'hiv', 'diagnosed', 'ward',
                'admitted', 'surgery', 'hospitali', 'mgonjwa', 'daktari',
                'matibabu',
            ],
            'violence' => [
                'beat me', 'beat her', 'beat him', 'hit me', 'hit her', 'hit him',
                'choked', 'slapped', 'kicked', 'blood', 'alinipiga', 'akapiga',
            ],
            'suicide' => [
                'end my life', 'kill myself', 'wanted to die', 'suicide',
                'no reason to live', 'take my life', 'kujiua',
            ],
            'abuse' => [
                'abused', 'abusive', 'touched me', 'molested', 'raped', 'rape',
                'forced himself on me', 'alininajisi', 'alinibaka',
            ],
            'addiction' => [
                'alcohol', 'drunk', 'drugs', 'cocaine', 'bhang', 'weed', 'heroin',
                'gambling', 'betting', 'pombe', 'bang',
            ],
            'sex' => [
                'slept with', 'sex', 'cheated', 'cheating', 'mistress',
                'mpango', 'side chick', 'mpango wa kando',
            ],
            'children' => [
                'my baby', 'my kid', 'watoto',
            ],
        ];
    }

    /**
     * Semantic anchors for each concept. Short prototypical phrases /
     * sentences that capture the *meaning* of the concept, for use with
     * the embedding service via /classify. A text is considered a match
     * if its similarity to ANY anchor exceeds SEMANTIC_THRESHOLD.
     *
     * The list is intentionally wider and more evocative than the
     * phrase signatures (which are exact-match). This is where the
     * house "reads between the lines."
     *
     * @return array<string,list<string>>
     */
    public static function semanticAnchors(): array
    {
        return [
            'grief' => [
                'I kept calling her phone even though I knew she would not answer.',
                'The house was too quiet after they left.',
                'I still set a plate for them at dinner out of habit.',
                'Every small thing reminds me they are gone.',
                'There is an empty space nothing else can fill.',
                'Niliendelea kumpigia simu ingawa alikuwa amekwisha fariki.',
            ],
            'shame' => [
                'I smiled and told everyone everything was fine.',
                'I could not bring myself to tell them the truth.',
                'I pretended not to care when I was dying inside.',
                'I lied because I was too ashamed to say what happened.',
            ],
            'failure' => [
                'I tried and I still could not provide for them.',
                'I let everyone down and I do not know how to face them.',
                'I keep failing at the one thing I am supposed to do.',
                'Biashara yangu ilikufa na sina chochote.',
            ],
            'family' => [
                'Family is everything even when they hurt you.',
                'My family does not know the real me.',
                'I carry their expectations everywhere I go.',
            ],
            'money' => [
                'I could not pay rent and I did not know who to turn to.',
                'The debt kept growing and I could not see a way out.',
                'I had nothing in my account and the children were hungry.',
                'Denis la kodi lilinifanya nilale nje.',
            ],
            'loneliness' => [
                'I eat alone most nights.',
                'I go through whole days without speaking to anyone.',
                'Even in a crowded room I feel completely alone.',
                'There is nobody I can tell these things to.',
            ],
            'hope' => [
                'I still believe tomorrow can be better.',
                'Even after everything I have not given up.',
                'One day this pain will mean something.',
                'Kuna siku nitapona.',
            ],
            'healing' => [
                'For the first time in years I slept through the night.',
                'I forgave them and felt something lift off my chest.',
                'I am slowly becoming myself again.',
                'Nilianza kupumzika tena.',
            ],
            'faith' => [
                'I got on my knees and prayed even though I had no words.',
                'The church was the only place I did not have to pretend.',
                'I held onto my faith when I had nothing else.',
            ],
            'secrets' => [
                'I have carried this for years and never told anyone.',
                'This is the first time I am saying it out loud.',
                'Nobody in my life knows this about me.',
            ],
            'boundaries' => [
                'I finally said no and walked away.',
                'I had to cut them off to protect my peace.',
                'I learned to put distance between myself and harm.',
            ],
            'ambition' => [
                'I started something small with almost no money.',
                'I am building something for myself and my children.',
                'I refuse to stay where I started.',
            ],
            'relationships' => [
                'After all these years they left without a word.',
                'I married them believing it would be forever.',
                'Our wedding day was the happiest and saddest day of my life.',
            ],
            'identity' => [
                'I am not sure who I am anymore.',
                'I am still becoming the person I want to be.',
                'I lost myself trying to please everyone.',
            ],
            'vulnerability' => [
                'I am tired of pretending I am okay.',
                'I cry when nobody is watching.',
                'I am afraid all the time even though I look strong.',
                'Nimechoka kujifanya niko sawa.',
            ],
            'memory' => [
                'I can still smell her cooking.',
                'There are days I remember everything as if it was yesterday.',
                'I hear their voice in certain songs.',
            ],
            'ritual' => [
                'Every Sunday I do the same thing we used to do together.',
                'I have small habits I cannot let go of since they left.',
            ],
            'absence' => [
                'Their side of the bed is still made the way they liked it.',
                'The silence after they left was louder than any fight.',
            ],
            'longing' => [
                'I wish I could hear their voice one more time.',
                'There are things I still want to tell them.',
                'I miss the person I thought they were.',
                'Ninamkumbuka sana.',
            ],
            'courage' => [
                'I woke up one morning and decided this was the last day.',
                'I walked in and said what I had rehearsed for years.',
                'Writing this is the hardest thing I have ever done.',
            ],
            'gratitude' => [
                'Even through this I am thankful.',
                'Small kindnesses kept me going.',
                'Asante kwa kunisikiliza.',
            ],
            'waiting' => [
                'I am still waiting for them to come back.',
                'I wait for a sign that I made the right choice.',
            ],
            'jealousy' => [
                'I saw them happy and it twisted something in me.',
                'I compared my life to hers and felt small.',
            ],
            'betrayal' => [
                'I told them in confidence and they told everyone.',
                'The person I trusted most turned against me.',
                'They shared my secret and I have not spoken since.',
            ],
            'home' => [
                'Going home feels like entering a different life.',
                'The village raised me and the city broke me.',
                'Ushago ndipo pazuri kuliko.',
            ],
            'parenthood' => [
                'I held my child and knew I had to be strong.',
                'I do not want my children to carry the same pain I did.',
                'Becoming a parent changed everything.',
            ],
            'father' => [
                'My father never said he was proud of me.',
                'I am turning into my father in ways I did not expect.',
                'I want my father to see me before it is too late.',
            ],
            'mother' => [
                'I wish I had told my mother everything before she died.',
                'My mother\'s hands were the only place I felt safe.',
                'Mama alinisamehe kwa kila kitu.',
            ],
            'forgiveness' => [
                'I forgave them not for them but for myself.',
                'Letting go did not mean forgetting.',
                'I made peace with what happened.',
            ],
            'justice' => [
                'I went to the police because nobody else would listen.',
                'I want them to face what they did.',
                'The court said one thing, my body says another.',
            ],
            'aging' => [
                'I am getting older and I still have not figured it out.',
                'My body reminds me every morning that I am not young.',
                'Uzeeni unakuja polepole.',
            ],
            'work' => [
                'My boss does not know I cry in the car before work.',
                'I resigned without another job because I could not breathe.',
                'I was sacked and I did not know how to tell my family.',
            ],
            'friendship' => [
                'My best friend was the only one who knew.',
                'Friends I thought would stay disappeared when things got hard.',
            ],
            'joy' => [
                'For a minute I forgot to be sad.',
                'I laughed without forcing it for the first time in months.',
            ],
            'separation' => [
                'I packed my bags in the middle of the night.',
                'The divorce papers arrived and I could not read them.',
                'We parted ways without ever really saying goodbye.',
            ],
            'illness' => [
                'The hospital waiting room became a second home.',
                'When they said the word I did not hear anything after.',
                'I got admitted and did not tell anyone.',
            ],
            'violence' => [
                'He hit me and then apologised like always.',
                'I wiped the blood and went back inside.',
                'Alinipiga na bado nikarudi nyumbani.',
            ],
            'suicide' => [
                'There were nights I did not want to wake up.',
                'I thought about ending it and then I thought of my mother.',
            ],
            'abuse' => [
                'He touched me when nobody was looking.',
                'Years later I still freeze when someone moves too fast.',
                'The words cut deeper than anything else.',
            ],
            'addiction' => [
                'The bottle was the only thing that listened.',
                'I placed another bet even though I had nothing left.',
            ],
            'sex' => [
                'I slept with him to feel less alone and felt worse after.',
                'I cheated and I cannot tell anyone why.',
                'The mpango gave me something my marriage could not.',
            ],
        ];
    }

    /**
     * Deterministic concept hits from phrase signatures only.
     *
     * @return list<string>
     */
    public static function conceptsFromText(string $text): array
    {
        $normal = AiKernel::normalise($text);
        $out    = [];
        foreach (self::phraseSignatures() as $slug => $phrases) {
            foreach ($phrases as $p) {
                if (str_contains($normal, $p)) {
                    $out[] = $slug;
                    break;
                }
            }
        }
        return array_values(array_unique($out));
    }

    /**
     * Semantic concept hits via embedding anchors. Returns
     * concept => score for any concept above threshold.
     *
     * @return array<string,float>
     */
    public static function semanticConcepts(string $text): array
    {
        $scores = Embeddings::classifyAgainstAnchors($text, self::semanticAnchors());
        $out = [];
        foreach ($scores as $slug => $s) {
            if ($s >= self::SEMANTIC_THRESHOLD) {
                $out[$slug] = round((float) $s, 3);
            }
        }
        arsort($out);
        return $out;
    }

    /**
     * Combined concepts: deterministic phrase hits + semantic anchor hits
     * (when service available) merged and deduplicated.
     *
     * @return list<string>
     */
    public static function conceptsFor(string $text): array
    {
        $phrase = self::conceptsFromText($text);
        $sem    = array_keys(self::semanticConcepts($text));
        return array_values(array_unique(array_merge($phrase, $sem)));
    }

    /*
     * Legacy door methods (conceptToDoor, doorsFor) removed in v1.7.3
     * (Corrections 7, 10 of the 1.7.2 memo). The eight retired Door
     * groupings (family, work, tradition, faith, love, loss, growth,
     * healing) are no longer produced by canonical inference. Their
     * useful meaning is carried directly by Concepts + Threads + Domains.
     *
     * No canonical Quiet Truths code calls these methods. If any third-
     * party snippet still references them, migrate the caller. The
     * ThemeInference.php shim remains only as a class alias.
     */
}
