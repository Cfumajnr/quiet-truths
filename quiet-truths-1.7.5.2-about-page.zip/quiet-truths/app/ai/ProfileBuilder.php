<?php
/**
 * Replaceable/testable entry point for profile calculation.
 *
 * Profile retains schema-normalisation compatibility helpers; all lifecycle
 * callers build through this service so the calculation engine can be
 * replaced without touching storage, forgetting, queues or admin rendering.
 */
namespace QuietTruths\Ai;

if (!defined('ABSPATH')) { exit; }

final class ProfileBuilder
{
    /** @return array<string,mixed> */
    public static function build(\WP_Post $post): array
    {
        if (!ProfileLifecycle::isEligible($post)) {
            return [];
        }
        return AiPolicy::enforce(Profile::build($post));
    }
}
