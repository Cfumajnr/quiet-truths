<?php
/**
 * Quiet Truths — Journal Relationships
 *
 * The discovery network of the deeper layer (Journal Bible §28–§29).
 *
 * A Journal relates to more than Journals: it connects to Stories,
 * Concepts, Threads, Domains, Context and other Journals. This class
 * builds that graph and — importantly — does NOT reduce every
 * relationship to "same category" (§29). Relationships carry a type:
 *
 *   - shares_subject          both address the same subject
 *   - explains               the Journal examines what the Story lived
 *   - illustrated_by         the Story gives the Journal lived grounding
 *   - shared_thread          a common recurring human current
 *   - shared_domain          a common broad area of life
 *   - opposite_perspectives  the two explore opposite readings
 *   - different_points       different parts of the same human experience
 *
 * This is machine-facing and never public (§48). The reader never sees
 * an AI taxonomy — only better discovery.
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

use QuietTruths\Core\Concepts;

final class JournalRelations
{
    /**
     * Build a typed relationship list for a given post against the whole
     * archive (Stories + Journals), ranked and bounded.
     *
     * @param int   $postId
     * @param int   $limit
     * @return list<array{id:int,type:string,label:string,score:float}>
     */
    public static function forPost(int $postId, int $limit = 6): array
    {
        $post = get_post($postId);
        if (!$post || 'publish' !== $post->post_status) {
            return [];
        }

        $profile = Profile::get($postId);
        $concepts = array_keys((array) ($profile['concepts'] ?? []));
        $threads  = self::activeThreads($profile);
        $domains  = array_keys((array) (($profile['domains']['scores'] ?? [])));

        $pool = self::allPublished(['qt_story', 'qt_journal'], $postId);
        $relations = [];

        foreach ($pool as $id) {
            $rel = self::classifyPair($postId, $post, $concepts, $threads, $domains, $id);

            if ($rel) {
                $relations[] = $rel;
            }
        }

        usort($relations, static fn ($a, $b) => $b['score'] <=> $a['score']);

        return array_slice($relations, 0, $limit);
    }

    /**
     * @return list<int>
     */
    private static function allPublished(array $types, int $exclude): array
    {
        $q = new \WP_Query([
            'post_type'      => $types,
            'post_status'    => 'publish',
            'posts_per_page' => 300,
            'post__not_in'   => [$exclude],
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ]);

        return array_map('intval', (array) ($q->posts ?: []));
    }

    /**
     * @param array<string,mixed> $profile
     * @return list<string>
     */
    private static function activeThreads(array $profile): array
    {
        $block = (array) ($profile['threads'] ?? []);
        $set   = (array) ($block['active'] ?? $block['scores'] ?? $block);

        return array_keys($set);
    }

    /**
     * Classify the relationship between the source post and a candidate,
     * returning a typed, scored relationship or null.
     *
     * @return array{id:int,type:string,label:string,score:float}|null
     */
    private static function classifyPair(int $srcId, \WP_Post $src, array $concepts, array $threads, array $domains, int $candId): ?array
    {
        $cand    = get_post($candId);
        if (!$cand) {
            return null;
        }

        $cProfile = Profile::get($candId);
        $cConcepts = array_keys((array) ($cProfile['concepts'] ?? []));
        $cThreads  = self::activeThreads($cProfile);
        $cDomains  = array_keys((array) (($cProfile['domains']['scores'] ?? [])));

        $sharedConcepts = count(array_intersect($concepts, $cConcepts));
        $sharedThreads  = count(array_intersect($threads, $cThreads));
        $sharedDomains  = count(array_intersect($domains, $cDomains));

        $isJournal = ('qt_journal' === $cand->post_type);
        $srcIsJournal = ('qt_journal' === $src->post_type);

        // Not enough shared ground to be meaningful.
        if (0 === $sharedConcepts && 0 === $sharedThreads) {
            return null;
        }

        $score = $sharedConcepts * 0.30 + $sharedThreads * 0.20 + $sharedDomains * 0.12;

        // Determine the relationship type (Journal Bible §29).
        if ($srcIsJournal && !$isJournal) {
            // Journal → Story: the Story illustrates the Journal's question.
            $type  = 'illustrated_by';
            $label = 'In lived experience';
            $score += 0.15; // a Story grounding a Journal is valuable
        } elseif (!$srcIsJournal && $isJournal) {
            // Story → Journal: the Journal explains the Story.
            $type  = 'explains';
            $label = 'A deeper reflection';
            $score += 0.15;
        } else {
            // Same form (Story↔Story or Journal↔Journal).
            if ($sharedThreads >= 2) {
                $type  = 'shared_thread';
                $label = 'Walks the same current';
            } else {
                $type  = 'shares_subject';
                $label = 'About the same subject';
            }
        }

        return [
            'id'    => $candId,
            'type'  => $type,
            'label' => $label,
            'score' => round(min(1.0, $score), 3),
        ];
    }
}
