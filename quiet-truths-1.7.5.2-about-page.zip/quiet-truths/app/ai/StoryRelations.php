<?php
/**
 * Quiet Truths — Story Relations (Layer 8: Relationships)
 *
 * Typed relationships between two stories, computed by reading both
 * stories' AI Profiles rather than recomputing signals from raw text.
 * This is critical: once every story has a profile, the "why" of a
 * connection comes from structured signals the house has already
 * decided on, not ad-hoc re-derivation.
 *
 * v1.7.3 / v1.7.4 (Corrections 12, 13, 18, 19, 29): the relation
 * engine uses ONLY the canonical relationship vocabulary. It does
 * NOT produce retired sameDoor / same_theme relations. Matching is
 * based on:
 *   - semantic vector similarity  (Layer 9 — BGE-M3 dense or token fallback)
 *   - concept overlap             (Layer 3 — weighted Jaccard over scored concepts)
 *   - thread overlap              (Layer 4 — recurring human currents crossing rooms)
 *   - domain overlap              (Layer 5 — broad areas of life, derived private layer)
 *   - room overlap                (Layer 2 — weak hint, not a boundary)
 *   - life-stage & emotional resonance (Layer 7 — context)
 *
 * The legacy keys same_theme / same_concept_other_room / sameDoor
 * appear ONLY in labelFor() as READ-only label translators for
 * cached pre-v1.7.2 relation records (Correction 18).
 *
 * @package QuietTruths\Ai
 */

namespace QuietTruths\Ai;

if (!defined('ABSPATH')) {
    exit;
}

final class StoryRelations
{
    public static function init(): void
    {
        add_filter('quiet_truths_relation_label', [self::class, 'labelFor'], 10, 2);
    }

    /**
     * Classify relation between two stories using their profiles.
     *
     * @return array{relations:list<string>,scores:array<string,float>,score:float,primary:string,why:list<string>}
     */
    public static function classify(int $a, int $b): array
    {
        $pa = get_post($a);
        $pb = get_post($b);
        if (!$pa || !$pb) {
            return ['relations' => [], 'scores' => [], 'score' => 0.0, 'primary' => '', 'why' => []];
        }

        $profA = Profile::get($a);
        $profB = Profile::get($b);

        // Vector similarity (read-only; uses stored vector or transient
        // token fallback — never makes HTTP calls on read path).
        $va = Embeddings::forPostRead($a);
        $vb = Embeddings::forPostRead($b);
        $sem = (!empty($va) && !empty($vb)) ? Embeddings::vectorSimilarity($va, $vb) : 0.0;

        // Signals from profiles (no re-parsing text).
        $aConcepts = (array) ($profA['concepts'] ?? []);
        $bConcepts = (array) ($profB['concepts'] ?? []);
        $aSlugs    = array_keys($aConcepts);
        $bSlugs    = array_keys($bConcepts);
        $overlap   = array_intersect($aSlugs, $bSlugs);
        $union     = array_unique(array_merge($aSlugs, $bSlugs));
        $iou       = empty($union) ? 0.0 : count($overlap) / count($union);

        // Weighted concept overlap (uses scores, not just presence).
        $conceptSim = 0.0;
        if (!empty($overlap)) {
            $num = 0.0; $den = 0.0;
            foreach ($overlap as $slug) {
                $num += min((float) ($aConcepts[$slug] ?? 0), (float) ($bConcepts[$slug] ?? 0));
                $den += max((float) ($aConcepts[$slug] ?? 0), (float) ($bConcepts[$slug] ?? 0));
            }
            $conceptSim = $den > 0 ? $num / $den : 0.0;
        }

        // Thread overlap (cross-cutting human-experience currents).
        $aThreads = (array) ($profA['threads']['active'] ?? []);
        $bThreads = (array) ($profB['threads']['active'] ?? []);
        $threadOverlap = array_intersect_key($aThreads, $bThreads);
        $threadSim = 0.0;
        if (!empty($threadOverlap)) {
            $tnum = 0.0; $tden = 0.0;
            foreach ($threadOverlap as $slug => $_) {
                $tnum += min((float) ($aThreads[$slug] ?? 0), (float) ($bThreads[$slug] ?? 0));
                $tden += max((float) ($aThreads[$slug] ?? 0), (float) ($bThreads[$slug] ?? 0));
            }
            $threadSim = $tden > 0 ? $tnum / $tden : 0.0;
        }

        // Domain overlap (private broad areas of life — Work &
        // Livelihood, Family & Care, etc.). These are derived, not
        // scored from raw evidence; overlap here is a softer signal
        // than concept or thread match.
        $aDomains = array_keys(array_filter((array) ($profA['domains']['scores'] ?? []), fn($v) => (float) $v >= 0.10));
        $bDomains = array_keys(array_filter((array) ($profB['domains']['scores'] ?? []), fn($v) => (float) $v >= 0.10));
        $domainOverlap = array_intersect($aDomains, $bDomains);
        $domainSim = !empty($aDomains) || !empty($bDomains)
            ? count($domainOverlap) / max(1, count(array_unique(array_merge($aDomains, $bDomains))))
            : 0.0;

        // Room overlap.
        $aRooms = self::roomSlugsFromProfile($profA);
        $bRooms = self::roomSlugsFromProfile($profB);
        $sameRoom = !empty(array_intersect($aRooms, $bRooms));

        // Emotional resonance (similar valence) — not matching Doors.
        $aVal = (float) ($profA['emotional']['valence'] ?? 0);
        $bVal = (float) ($profB['emotional']['valence'] ?? 0);
        $valenceGap = abs($aVal - $bVal);
        $emotionalKinship = 1.0 - min(1.0, $valenceGap / 1.2); // similar valence

        $aStages = (array) ($profA['life_context']['stages'] ?? []);
        $bStages = (array) ($profB['life_context']['stages'] ?? []);
        $sameStage = !empty(array_intersect($aStages, $bStages));

        // Circumstance overlap (context signals like poverty, illness).
        $aContext = (array) ($profA['signals']['context'] ?? []);
        $bContext = (array) ($profB['signals']['context'] ?? []);
        $contextOverlap = count(array_intersect_key(
            array_filter($aContext, fn($v) => (float) $v >= 0.45),
            array_filter($bContext, fn($v) => (float) $v >= 0.45)
        ));
        $contextSignal = $contextOverlap > 0 ? min(0.30, 0.10 * $contextOverlap) : 0.0;

        // ── per-relation scoring ──
        $scores = [];
        $scores['similar_experience'] =
            ($sameRoom ? 0.25 : 0.0) + $conceptSim * 0.30 + $threadSim * 0.20
            + $sem * 0.30 + $domainSim * 0.10;

        $scores['same_current'] =
            $threadSim * 0.55 + $conceptSim * 0.20 + $sem * 0.20
            + (count($threadOverlap) >= 1 ? 0.10 : 0.0);

        $scores['emotional_kin'] =
            $emotionalKinship * 0.30 + $sem * 0.30 + $threadSim * 0.20
            + (1.0 - $iou) * 0.05 + $contextSignal;

        $scores['same_life'] =
            $domainSim * 0.35 + $threadSim * 0.20 + $sem * 0.20
            + ($sameStage ? 0.20 : 0.0) + $contextSignal;

        $scores['contrasting'] =
            ($valenceGap >= 0.6 ? 0.40 : $valenceGap * 0.55) + $sem * 0.20
            + $threadSim * 0.10
            + ($sameRoom && $valenceGap >= 0.4 ? 0.15 : 0.0);

        $scores['continuation'] =
            ($conceptSim > 0.20 ? 0.20 : 0.0) + $sem * 0.25 + $threadSim * 0.20
            + $domainSim * 0.10
            + (self::hasArc($a, $b, $profA, $profB) ? 0.25 : 0.0);

        $scores['same_truth_other_room'] =
            (!$sameRoom && count($overlap) >= 1 ? 0.30 : 0.0)
            + $sem * 0.25 + $conceptSim * 0.20 + $threadSim * 0.20;

        $scores['related_different'] =
            $sem * 0.35 + $threadSim * 0.20 + $conceptSim * 0.10 + $domainSim * 0.10;

        foreach ($scores as $k => $v) {
            $scores[$k] = max(0.0, min(1.0, $v));
        }

        $floors = [
            'similar_experience'     => 0.55,
            'same_current'           => 0.40,
            'emotional_kin'          => 0.45,
            'same_life'              => 0.40,
            'contrasting'            => 0.55,
            'continuation'           => 0.45,
            'same_truth_other_room'  => 0.50,
            'related_different'      => 0.40,
        ];
        $relations = [];
        foreach ($scores as $k => $v) {
            if ($v >= ($floors[$k] ?? 0.5)) {
                $relations[] = $k;
            }
        }
        uasort($scores, fn($x, $y) => $y <=> $x);
        usort($relations, fn($x, $y) => ($scores[$y] ?? 0) <=> ($scores[$x] ?? 0));

        $primary = $relations[0] ?? '';
        $overall = $sem * 0.30 + $conceptSim * 0.20 + $threadSim * 0.20
                 + $domainSim * 0.10
                 + ($sameRoom ? 0.08 : 0.0)
                 + $emotionalKinship * 0.05
                 + ($sameStage ? 0.07 : 0.0);
        $overall = max(0.0, min(1.0, $overall));

        // Build a short "why" chain of the top 2 overlapping concepts
        // plus top thread (so readers see "grief · loss" etc rather than
        // only slugs).
        $why = [];
        foreach (array_slice(array_values($overlap), 0, 2) as $c) {
            $why[] = (string) $c;
        }
        if (count($why) < 3 && !empty($threadOverlap)) {
            $why[] = (string) (array_key_first($threadOverlap) ?? '');
        }
        $why = array_values(array_filter($why, fn($s) => '' !== $s));

        // Internal component provenance (Corrections 9 & 27): the
        // relationship score is derived from distinct evidence layers, so
        // we expose the breakdown for explainability/tuning. This is
        // internal and never rendered to the reader.
        $components = [
            'semantic'        => round((float) $sem, 3),
            'concept'         => round((float) $conceptSim, 3),
            'thread'          => round((float) $threadSim, 3),
            'domain'          => round((float) $domainSim, 3),
            'room_affinity'   => $sameRoom ? 1 : 0,
            'context'         => round((float) $contextSignal, 3),
            'life_stage'      => $sameStage ? 1 : 0,
            'emotional'       => round((float) $emotionalKinship, 3),
        ];

        return [
            'relations'  => $relations,
            'scores'     => $scores,
            'score'      => round($overall, 3),
            'primary'    => $primary,
            'why'        => array_slice($why, 0, 3),
            'components' => $components,
        ];
    }

    public static function labelFor(string $label, string $relation): string
    {
        if ('' !== $label) return $label;
        return match ($relation) {
            // ── Canonical v1.7.2+ relation keys (produced by classify()) ──
            'similar_experience'     => __('Another story like this', 'quiet-truths'),
            'same_current'           => __('Walks the same current', 'quiet-truths'),
            'emotional_kin'          => __('Walks similar ground', 'quiet-truths'),
            'same_life'              => __('From the same season of life', 'quiet-truths'),
            'contrasting'            => __('A different ending', 'quiet-truths'),
            'continuation'           => __('A later chapter', 'quiet-truths'),
            'related_different'      => __('You might also sit with', 'quiet-truths'),
            'same_truth_other_room'  => __('The same truth, another room', 'quiet-truths'),

            // ── Legacy relation keys (v1.6–v1.7.0 / Doors & Themes era) ──
            //
            // classify() has NOT produced these keys since v1.7.2. They
            // are listed here STRICTLY as a READ-path label translator so
            // that if any older cached relation record (in postmeta,
            // transients, or related-story caches) still carries a
            // retired key, the reader sees the closest human-readable
            // canonical label instead of a raw slug.
            //
            // This is explicitly permitted under v1.7.3 Clause 10 (legacy
            // fallbacks are acceptable during migration). It is NOT a
            // signal that sameDoor / same_theme scoring has returned —
            // that logic was removed in v1.7.2 and must not be restored
            // (v1.7.3 Clauses 12, 13).
            //
            // This is LEGACY COMPATIBILITY, isolated and read-only: it
            // only translates genuinely old cached labels and never
            // generates them. It may remain indefinitely (Correction 40).
            'same_theme'             => __('Walks the same current', 'quiet-truths'),
            'same_concept_other_room'=> __('The same truth, another room', 'quiet-truths'),
            'sameDoor'               => __('Walks the same current', 'quiet-truths'),

            default                  => '',
        };
    }

    /**
     * @return list<array{id:int,relations:list<string>,scores:array<string,float>,score:float,primary:string,label:string,why:list<string>}>
     */
    /**
     * Bound on retained related-story candidates during ranking
     * (Corrections 32 & 33). A candidate that is not competitive against
     * the best seen so far is discarded immediately, so discovery never
     * accumulates the whole archive in memory.
     *
     * This is a RANKING PARAMETER, configurable via the
     * `quiet_truths_related_keep` filter so it can change without a
     * redesign.
     */
    private const RELATED_KEEP = 60;

    /**
     * Resolve the configured related-story retention bound (Correction 6
     * applied to relationships). Ranking stays bounded and tunable.
     */
    private static function relatedKeep(): int
    {
        return max(1, (int) apply_filters('quiet_truths_related_keep', self::RELATED_KEEP));
    }

    public static function relatedTo(int $postId, int $limit = 4): array
    {
        $post = get_post($postId);
        if (!$post || 'publish' !== $post->post_status) return [];

        // Related-story discovery evaluates the FULL published archive
        // in streaming batches (Correction 29) instead of the newest 80
        // stories — the strongest related story may be anywhere. Ranking
        // is BOUNDED (Corrections 32 & 33): only the strongest candidates
        // are retained and sorted; weak candidates are discarded before
        // the final sort. Memory never grows with the archive.
        $best = [];
        self::forEachStory(function (int $cid) use ($postId, &$best): void {
            if ($cid === $postId) {
                return;
            }
            $rel = self::classify($postId, $cid);
            if ($rel['score'] < 0.15 || empty($rel['primary'])) {
                return;
            }
            self::retainRelated(
                $best,
                array_merge(
                    ['id' => $cid, 'label' => self::labelFor('', $rel['primary'])],
                    $rel
                )
            );
        });

        usort($best, fn($x,$y) => $y['score'] <=> $x['score']);
        return array_slice($best, 0, $limit);
    }

    /**
     * Retain a related-story candidate only if it is competitive against
     * the strongest candidates seen so far (Correction 33). Keeps at
     * most RELATED_KEEP entries; the weakest is evicted when a stronger
     * candidate arrives.
     *
     * @param array<int,array<string,mixed>> $best  list of retained candidates
     * @param array<string,mixed>            $cand
     */
    private static function retainRelated(array &$best, array $cand): void
    {
        $score = (float) $cand['score'];
        $id    = (int) $cand['id'];

        // Upgrade an already-retained id in place.
        foreach ($best as $i => $entry) {
            if ((int) $entry['id'] === $id) {
                if ($score > (float) $entry['score']) {
                    $best[$i] = $cand;
                }
                return;
            }
        }

        if (count($best) < self::relatedKeep()) {
            $best[] = $cand;
            return;
        }

        // Full: evict the weakest only if the new candidate beats it.
        $minIdx   = 0;
        $minScore = (float) $best[0]['score'];
        foreach ($best as $i => $entry) {
            $s = (float) $entry['score'];
            if ($s < $minScore) {
                $minScore = $s;
                $minIdx   = $i;
            }
        }
        if ($score > $minScore) {
            $best[$minIdx] = $cand;
        }
    }

    /**
     * Stream every published qt_story in stable batches, invoking $fn for
     * each ID (Correction 29). Avoids loading the whole archive into
     * memory so discovery can scale with the house.
     *
     * @param callable(int):void $fn
     */
    private static function forEachStory(callable $fn, int $per = 250): void
    {
        $page = 1;
        while (true) {
            $q = new \WP_Query([
                'post_type'      => 'qt_story',
                'post_status'    => 'publish',
                'posts_per_page' => $per,
                'paged'          => $page,
                'orderby'        => 'ID',
                'order'          => 'ASC',
                'fields'         => 'ids',
            ]);
            if (empty($q->posts)) {
                break;
            }
            foreach ($q->posts as $cid) {
                $fn((int) $cid);
            }
            $page++;
            if ($page > (int) $q->max_num_pages) {
                break;
            }
        }
    }

    /**
     * Heuristic for "continuation": one story narrates events later in
     * time than another, or uses forward-looking / later-time cues.
     * Uses the current Context layer's tense scores where available, plus
     * lexical time-cues — Context is an active part of the current
     * architecture (Correction 33), not a future one.
     */
    private static function hasArc(int $a, int $b, array $profA, array $profB): bool
    {
        // Use context.tense.future_hoped/past as soft arc hints where
        // available (v7+ profiles carry this).
        $aTense = (array) ($profA['context']['tense'] ?? []);
        $bTense = (array) ($profB['context']['tense'] ?? []);
        if ((($aTense['past'] ?? 0) > 0.4 && ($bTense['future_hoped'] ?? 0) > 0.3)
            || (($bTense['past'] ?? 0) > 0.4 && ($aTense['future_hoped'] ?? 0) > 0.3)) {
            return true;
        }

        foreach ([$a, $b] as $pid) {
            $post = get_post($pid);
            if (!$post) continue;
            $t = AiKernel::normalise((string) $post->post_title . ' ' . (string) $post->post_content);
            foreach (['years later','months later','afterwards','now i','today i','miaka baadaye','baadaye','sasa mimi','since then','looking back','later'] as $cue) {
                if (str_contains($t, $cue)) return true;
            }
        }
        return false;
    }

    /**
     * Extract all meaningful room slugs from a profile, understanding
     * both v5 (rooms.assigned + rooms.secondary) and older flat shapes.
     *
     * @return list<string>
     */
    private static function roomSlugsFromProfile(array $profile): array
    {
        $rooms = $profile['rooms'] ?? [];
        $out = [];
        if (is_array($rooms)) {
            if (!empty($rooms['assigned'])) $out[] = (string) $rooms['assigned'];
            if (!empty($rooms['primary']) && $rooms['primary'] !== ($rooms['assigned'] ?? null)) {
                $out[] = (string) $rooms['primary'];
            }
            foreach ((array) ($rooms['secondary'] ?? []) as $sec) {
                if (is_array($sec) && !empty($sec['slug'])) $out[] = (string) $sec['slug'];
            }
            // Flat list fallbacks (v4 and earlier, plus lexical fallback).
            foreach ($rooms as $k => $v) {
                if (is_string($k) && in_array($k, ['assigned','primary','secondary','affinity','primary_score'], true)) continue;
                if (is_string($v) && '' !== $v && !is_numeric($v)) $out[] = $v;
            }
        }
        return array_values(array_unique(array_filter($out)));
    }
}
