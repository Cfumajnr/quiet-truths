<?php
/**
 * Silence is golden.
 *
 * Prevents directory listing and direct web hits into the app tree
 * from returning a 403 or exposing the fact that the directory exists.
 *
 * @package QuietTruths
 */
