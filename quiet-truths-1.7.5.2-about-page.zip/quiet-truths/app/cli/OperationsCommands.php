<?php
/** Deterministic WP-CLI operations runner for production cron. */
namespace QuietTruths\Cli;

use QuietTruths\Ai\BackgroundWorker;
use QuietTruths\Ai\ProfileLifecycle;
use QuietTruths\Core\Health;
use QuietTruths\Core\Retention;
use QuietTruths\Core\Tombstones;
use WP_CLI;

if (!defined('ABSPATH') || !defined('WP_CLI') || !WP_CLI) { return; }

final class OperationsCommands
{
    /**
     * Run due Quiet Truths jobs and retention deterministically.
     *
     * ## EXAMPLES
     *     wp qt operations run --quiet
     */
    public function run(array $_, array $opts): void
    {
        Health::heartbeat('wp_cli');
        $reconciled = Tombstones::reconcile();
        $ran = $this->runDueQuietJobs();
        $last = get_option('qt_retention_last_run', []);
        $lastTs = is_array($last) && !empty($last['checked_at_gmt'])
            ? strtotime($last['checked_at_gmt'] . ' UTC') : 0;
        $retention = null;
        if ($lastTs < time() - 12 * HOUR_IN_SECONDS) {
            $retention = Retention::run(false);
        }
        if (empty($opts['quiet'])) {
            WP_CLI::success(sprintf(
                'Quiet Truths operations complete: %d due jobs; %d tombstones enforced%s.',
                $ran,
                (int) ($reconciled['enforced'] ?? 0),
                $retention ? ', retention executed' : ''
            ));
        }
    }

    public function status(): void
    {
        foreach (Health::checks() as $name => $check) {
            WP_CLI::line(sprintf('[%s] %-20s %s', $check['ok'] ? 'OK' : '!!', $name, $check['value']));
        }
    }

    /** wp qt operations forget <post-id> [--reason=<reason>] */
    public function forget(array $args, array $opts): void
    {
        $id = absint($args[0] ?? 0);
        if (!$id || !get_post($id)) WP_CLI::error('Valid Story/Journal ID required.');
        $removed = ProfileLifecycle::forget($id, sanitize_key($opts['reason'] ?? 'cli'));
        WP_CLI::success(sprintf('AI forget complete for #%d; %d derived rows removed.', $id, $removed));
    }

    private function runDueQuietJobs(): int
    {
        $allowed = [BackgroundWorker::HOOK_PROFILE, BackgroundWorker::HOOK_CONCEPT_BACKFILL];
        $cron = function_exists('_get_cron_array') ? _get_cron_array() : [];
        $now = time(); $ran = 0;
        foreach ((array) $cron as $timestamp => $hooks) {
            if ((int) $timestamp > $now) continue;
            foreach ($allowed as $hook) {
                foreach ((array) ($hooks[$hook] ?? []) as $event) {
                    $args = array_values((array) ($event['args'] ?? []));
                    wp_unschedule_event((int) $timestamp, $hook, $args, true);
                    do_action_ref_array($hook, $args);
                    $ran++;
                }
            }
        }
        return $ran;
    }
}

WP_CLI::add_command('qt operations', OperationsCommands::class);
