<?php
/**
 * Quiet Truths — WP-CLI migration-verification commands.
 *
 * Implements Clause 6 of the v1.7.3 ratified architecture:
 *
 *     Legacy data → Read → Interpret → Migrate → Verify → Rebuild → Retire
 *
 * These commands NEVER run on web requests, NEVER run automatically,
 * NEVER overwrite canonical data, and NEVER delete legacy data. They
 * exist so mwenye nyumba can:
 *
 *   1. See how much legacy data still lives on published stories.
 *   2. Populate canonical _qt_concepts for any story whose canonical
 *      meta is missing — by translating legacy _qt_themes / _qt_doors
 *      into their nearest current-concept equivalents (NOT by creating
 *      new Themes or Doors).
 *   3. Verify after migration that no story was left behind.
 *
 * Legacy → canonical concept mapping below is the distilled translation
 * table from app/config/themes.php's migration notes. The mapping is
 * intentionally CONSERVATIVE: it only maps to concepts that already
 * exist in config/concepts.php. If a legacy door group's meaning spans
 * multiple concepts, we write multiple canonical concepts (each at
 * score 0.75 — evidence that is real but second-hand, inherited from
 * the legacy ontology rather than freshly derived).
 *
 *   ⚠️  Nothing here revives Door/Theme inference. Nothing here writes
 *   _qt_themes or _qt_doors. Nothing here adds public categories.
 *
 * @package QuietTruths\Cli
 */

namespace QuietTruths\Cli;

if (!defined('ABSPATH')) {
    exit;
}

use QuietTruths\Core\Concepts;
use WP_CLI;

if (!defined('WP_CLI') || !WP_CLI) {
    return;
}

class MigrateCommands
{
    /**
     * Show available migration subcommands when run without a subcommand.
     */
    public function __invoke(): void
    {
        WP_CLI::line('Quiet Truths — migration verification (v1.7.4)');
        WP_CLI::line('');
        WP_CLI::line('Subcommands:');
        WP_CLI::line('  wp qt ai migrate:report     — archive-wide legacy data counts');
        WP_CLI::line('  wp qt ai migrate:verify     — list posts that need migration (dry-run)');
        WP_CLI::line('  wp qt ai migrate:apply      — write canonical _qt_concepts from legacy data');
        WP_CLI::line('');
        WP_CLI::line('Principles (Clause 6, v1.7.3 memo):');
        WP_CLI::line('  - Legacy data is READ, INTERPRETED, TRANSLATED.');
        WP_CLI::line('  - Canonical _qt_concepts is only written when it is ABSENT.');
        WP_CLI::line('  - Legacy _qt_themes / _qt_doors are NEVER modified or deleted.');
        WP_CLI::line('  - No command runs automatically; no web requests touch these paths.');
    }
    /**
     * Legacy door/theme slug → list of canonical concept slugs.
     *
     * Sourced directly from the migration notes in app/config/themes.php.
     * Each concept slug here MUST exist in app/config/concepts.php (the
     * canonical knowledge base). If a concept is not yet in the KB, it
     * is intentionally omitted — better to under-map than to invent
     * concepts at migration time.
     *
     * Score assigned to each migrated concept (0.75) is deliberately
     * below the threshold for "freshly inferred from content" (1.0)
     * because this is second-hand, inherited evidence — enough for
     * search to find the story, enough for profiles to be coherent,
     * but flagged so a future full warm() rebuild can replace it with
     * native concept scores without loss.
     *
     * @var array<string, list<string>>
     */
    private const LEGACY_DOOR_TO_CONCEPTS = [
        // Family  → family-care domain + family/parenthood concepts
        //           + love-intimacy / trust / belonging threads.
        // NOTE: only slugs that exist in app/config/concepts.php appear here.
        'family'    => ['relationships', 'family', 'parenthood', 'home'],
        // Work    → work-livelihood + money-material domains
        //           + work/ambition/justice concepts + responsibility thread.
        'work'      => ['work', 'money', 'ambition', 'justice'],
        // Tradition → culture-society domain + religion/ritual/origins/memory
        //             concepts + belonging / faith-belief threads.
        'tradition' => ['religion', 'origins', 'identity', 'memory'],
        // Faith   → faith-meaning domain + religion/gratitude/hope/forgiveness.
        'faith'     => ['religion', 'hope', 'forgiveness', 'peace'],
        // Love    → love-intimacy domain + love/relationships/friendship/joy.
        'love'      => ['relationships', 'love', 'friendship', 'joy', 'vulnerability', 'loneliness', 'forgiveness'],
        // Loss    → loss-change domain + grief/separation/longing/aging/memory.
        'loss'      => ['grief', 'separation', 'aging', 'memory', 'loneliness'],
        // Growth  → education-growth + identity-self domains
        //           + growth/identity/courage/hope/forgiveness concepts.
        'growth'    => ['growth', 'identity', 'courage', 'hope', 'forgiveness', 'education', 'ambition'],
        // Healing → healing-recovery domain + healing/forgiveness/hope/peace/
        //           boundaries concepts + mending / vulnerability threads.
        'healing'   => ['healing', 'forgiveness', 'hope', 'peace', 'boundaries', 'vulnerability'],
    ];

    /**
     * Score assigned to concepts migrated from legacy data.
     *
     * - Freshly inferred by ConceptInference::infer(): 1.0
     * - Inherited from legacy _qt_themes / _qt_doors:   0.75  (here)
     *
     * The gap tells the next warm() that these inherited concepts are
     * good enough to serve but SHOULD be re-derived from content when
     * time permits. This preserves the lifecycle principle: a
     * migrated profile is never made semantically WORSE than the old
     * one, but it is honestly marked as inherited.
     */
    private const MIGRATED_CONCEPT_SCORE = 0.75;

    /**
     * Report on legacy Theme/Door data across the archive.
     *
     * Counts how many published qt_stories carry _qt_themes or
     * _qt_doors, how many already have canonical _qt_concepts, and
     * breaks down legacy-door distribution. No writes.
     *
     * ## EXAMPLES
     *     wp qt ai migrate:report
     */
    public function report(): void
    {
        global $wpdb;

        $total = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s AND post_status = 'publish'",
            'qt_story'
        ));

        $withCanonical = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key = %s",
            \QuietTruths\Ai\Profile::CONCEPTS_META_KEY
        ));

        $withLegacyThemes = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key = %s",
            \QuietTruths\Ai\Profile::LEGACY_THEMES_META_KEY
        ));

        $withLegacyDoors = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key = %s",
            \QuietTruths\Ai\Profile::LEGACY_DOORS_META_KEY
        ));

        // Posts that have legacy data but NO canonical concepts yet.
        // These are the posts migrate:apply would address.
        $needMigration = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT p.ID)
               FROM {$wpdb->posts} p
              WHERE p.post_type = %s
                AND p.post_status = 'publish'
                AND EXISTS (
                    SELECT 1 FROM {$wpdb->postmeta} lm
                     WHERE lm.post_id = p.ID
                       AND lm.meta_key IN (%s, %s)
                )
                AND NOT EXISTS (
                    SELECT 1 FROM {$wpdb->postmeta} cm
                     WHERE cm.post_id = p.ID
                       AND cm.meta_key = %s
                )",
            'qt_story',
            \QuietTruths\Ai\Profile::LEGACY_THEMES_META_KEY,
            \QuietTruths\Ai\Profile::LEGACY_DOORS_META_KEY,
            \QuietTruths\Ai\Profile::CONCEPTS_META_KEY
        ));

        WP_CLI::line('Quiet Truths — Archive migration status');
        WP_CLI::line(str_repeat('─', 50));
        WP_CLI::line(sprintf('  Published stories        : %d', $total));
        WP_CLI::line(sprintf('  With canonical _qt_concepts : %d', $withCanonical));
        WP_CLI::line(sprintf('  With legacy _qt_themes   : %d  (read-only)', $withLegacyThemes));
        WP_CLI::line(sprintf('  With legacy _qt_doors    : %d  (read-only)', $withLegacyDoors));
        WP_CLI::line(sprintf('  Need migration*          : %d', $needMigration));
        WP_CLI::line('');
        WP_CLI::line('  * Stories with legacy data but NO canonical _qt_concepts yet.');
        WP_CLI::line('    These can be non-destructively migrated with:');
        WP_CLI::line('        wp qt ai migrate:apply          (writes canonical meta only)');
        WP_CLI::line('    Or fully re-profiled with:');
        WP_CLI::line('        wp qt ai backfill --force       (runs full AI rebuild)');

        // Per-door distribution (based on _qt_themes, which was a flat
        // list of broad theme slugs). We read it via direct SQL and
        // summarise in PHP so we don't load every post.
        WP_CLI::line('');
        WP_CLI::line('Legacy door distribution (from _qt_themes):');
        WP_CLI::line(str_repeat('─', 50));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s",
            \QuietTruths\Ai\Profile::LEGACY_THEMES_META_KEY
        ));
        $counts = [];
        foreach ($rows as $row) {
            $val = maybe_unserialize($row->meta_value);
            if (!is_array($val)) {
                continue;
            }
            foreach ($val as $slug) {
                $slug = (string) $slug;
                if ('' === $slug) {
                    continue;
                }
                $counts[$slug] = ($counts[$slug] ?? 0) + 1;
            }
        }
        arsort($counts);
        if (empty($counts)) {
            WP_CLI::line('  (none — archive is clean)');
        } else {
            foreach ($counts as $slug => $c) {
                $mapped = isset(self::LEGACY_DOOR_TO_CONCEPTS[$slug])
                    ? implode(', ', self::LEGACY_DOOR_TO_CONCEPTS[$slug])
                    : '— (no canonical mapping; will be skipped)';
                WP_CLI::line(sprintf('  %-12s %4d stories  → %s', $slug, $c, $mapped));
            }
        }
    }

    /**
     * Dry-run verification: list every published story that has legacy
     * data but no canonical _qt_concepts, showing what would be
     * migrated. No writes.
     *
     * ## OPTIONS
     * [--format=<fmt>]
     * : Output format: table (default), csv, json, count.
     *
     * ## EXAMPLES
     *     wp qt ai migrate:verify
     *     wp qt ai migrate:verify --format=csv
     */
    public function verify(array $_, array $opts): void
    {
        $format = (string) ($opts['format'] ?? 'table');
        $posts = $this->postsNeedingMigration();
        if ('count' === $format) {
            WP_CLI::line((string) count($posts));
            return;
        }
        if (empty($posts)) {
            WP_CLI::success('No stories need migration — every published story already has canonical _qt_concepts.');
            return;
        }

        $out = [];
        foreach ($posts as $p) {
            $legacyThemes = get_post_meta($p->ID, \QuietTruths\Ai\Profile::LEGACY_THEMES_META_KEY, true) ?: [];
            $legacyDoors  = get_post_meta($p->ID, \QuietTruths\Ai\Profile::LEGACY_DOORS_META_KEY, true) ?: [];
            $translated   = $this->translateLegacy((array) $legacyThemes, (array) $legacyDoors);
            $out[] = [
                'ID'             => $p->ID,
                'title'          => $p->post_title,
                'legacy_themes'  => implode(',', (array) $legacyThemes),
                'legacy_doors'   => is_array($legacyDoors) ? implode(',', $legacyDoors) : (string) $legacyDoors,
                'would_concepts' => implode(',', array_keys($translated)),
            ];
        }

        if ('json' === $format) {
            WP_CLI::line(wp_json_encode($out, JSON_PRETTY_PRINT));
        } elseif ('csv' === $format) {
            WP_CLI::line('ID,title,legacy_themes,legacy_doors,would_concepts');
            foreach ($out as $r) {
                WP_CLI::line(implode(',', [
                    $r['ID'],
                    '"' . str_replace('"', '""', $r['title']) . '"',
                    '"' . str_replace('"', '""', $r['legacy_themes']) . '"',
                    '"' . str_replace('"', '""', $r['legacy_doors']) . '"',
                    '"' . str_replace('"', '""', $r['would_concepts']) . '"',
                ]));
            }
        } else {
            WP_CLI::line(sprintf('Found %d stories that would receive canonical _qt_concepts from legacy data:', count($out)));
            WP_CLI::line('');
            $formatter = new \WP_CLI\Formatter($opts, ['ID', 'title', 'legacy_themes', 'would_concepts']);
            $formatter->display_items($out);
            WP_CLI::line('');
            WP_CLI::line('Run: wp qt ai migrate:apply    to perform the non-destructive migration.');
            WP_CLI::line('Run: wp qt ai backfill --force to fully rebuild AI profiles (deeper, slower).');
        }
    }

    /**
     * Apply non-destructive migration: for every published story that
     * has legacy _qt_themes or _qt_doors but NO canonical _qt_concepts,
     * write _qt_concepts by translating the legacy slugs to their
     * nearest current-concept equivalents.
     *
     * SAFETY PROPERTIES (Clause 6):
     *   - Never overwrites existing _qt_concepts (only writes where
     *     the canonical key is missing or empty).
     *   - Never writes to _qt_themes or _qt_doors (legacy remains
     *     read-only; we only READ it for translation).
     *   - Never deletes legacy data (archive preserved first).
     *   - Runs idempotently: running twice produces no second write.
     *
     * ## OPTIONS
     * [--dry-run]
     * : Show what would be written without writing.
     *
     * [--batch-size=<n>]
     * : Process n posts at a time. Default 50.
     *
     * ## EXAMPLES
     *     wp qt ai migrate:apply --dry-run
     *     wp qt ai migrate:apply
     */
    public function apply(array $_, array $opts): void
    {
        $dry   = !empty($opts['dry-run']);
        $batch = max(10, (int) ($opts['batch-size'] ?? 50));

        $posts = $this->postsNeedingMigration();
        $total = count($posts);

        if (0 === $total) {
            WP_CLI::success('No stories need migration. The canonical house is in order.');
            return;
        }

        WP_CLI::line(sprintf(
            '%s %d published %s with legacy data but no canonical _qt_concepts.',
            $dry ? 'Would migrate' : 'Migrating',
            $total,
            1 === $total ? 'story' : 'stories'
        ));
        WP_CLI::line('  · Legacy keys read   : _qt_themes, _qt_doors (read-only, NOT modified)');
        WP_CLI::line('  · Canonical key written: _qt_concepts');
        WP_CLI::line('  · Existing _qt_concepts: NEVER overwritten');
        WP_CLI::line('  · Legacy data        : NEVER deleted');
        WP_CLI::line('');

        $written = 0;
        $skipped = 0;
        $noMap   = 0;
        $progress = $total > 0 ? \WP_CLI\Utils\make_progress_bar($dry ? 'Scanning' : 'Migrating', $total) : null;

        foreach (array_chunk($posts, $batch) as $chunk) {
            foreach ($chunk as $p) {
                $legacyThemes = get_post_meta($p->ID, \QuietTruths\Ai\Profile::LEGACY_THEMES_META_KEY, true) ?: [];
                $legacyDoors  = get_post_meta($p->ID, \QuietTruths\Ai\Profile::LEGACY_DOORS_META_KEY, true) ?: [];

                // Defensive double-check: do NOT write if canonical
                // meta has appeared since our initial SELECT (another
                // process may have warmed this post concurrently).
                $existing = get_post_meta($p->ID, \QuietTruths\Ai\Profile::CONCEPTS_META_KEY, true);
                if (is_array($existing) && !empty($existing)) {
                    $skipped++;
                    if ($progress) $progress->tick();
                    continue;
                }

                $translated = $this->translateLegacy((array) $legacyThemes, (array) $legacyDoors);
                if (empty($translated)) {
                    $noMap++;
                    if ($progress) $progress->tick();
                    continue;
                }

                // Shape for _qt_concepts: list of {slug, score}.
                $conceptList = [];
                foreach ($translated as $slug => $score) {
                    $conceptList[] = ['slug' => $slug, 'score' => (float) $score];
                }

                if (!$dry) {
                    update_post_meta($p->ID, \QuietTruths\Ai\Profile::CONCEPTS_META_KEY, $conceptList);
                }
                $written++;

                if ($progress) $progress->tick();
            }
        }
        if ($progress) $progress->finish();

        WP_CLI::line('');
        $parts = [];
        $parts[] = sprintf('%s %d %s canonical concept records',
            $dry ? 'would write' : 'wrote',
            $written,
            1 === $written ? 'story' : 'stories'
        );
        if ($skipped > 0) {
            $parts[] = sprintf('%d skipped (canonical meta appeared concurrently)', $skipped);
        }
        if ($noMap > 0) {
            $parts[] = sprintf('%d with no translateable legacy mapping (run a full backfill for these)', $noMap);
        }
        WP_CLI::success(ucfirst(implode('; ', $parts)) . '.');

        if ($dry) {
            WP_CLI::line('');
            WP_CLI::line('Tip: after applying, run: wp qt ai migrate:verify --format=count');
            WP_CLI::line('     It should report 0 — confirming every legacy story is now on the canonical key.');
        }
    }

    /**
     * Translate legacy _qt_themes / _qt_doors slugs into canonical
     * concept slugs (with scores).
     *
     * Translation rules (conservative, by design):
     *   - Only slugs present in LEGACY_DOOR_TO_CONCEPTS are translated.
     *   - Unknown legacy slugs are silently dropped (better to miss a
     *     concept than to invent one).
     *   - Duplicates across themes/doors are merged (max score wins).
     *   - Only concepts that exist in the current knowledge base are
     *     kept (defensive: the map is curated, but we double-check
     *     against Concepts::concepts() to be safe).
     *
     * @param array<int,string> $legacyThemes
     * @param array<int,string> $legacyDoors
     * @return array<string,float> slug => score
     */
    private function translateLegacy(array $legacyThemes, array $legacyDoors): array
    {
        $kb = Concepts::concepts(); // slug => definition
        $out = [];

        foreach (array_merge($legacyThemes, $legacyDoors) as $slug) {
            $slug = (string) $slug;
            if ('' === $slug) {
                continue;
            }
            $targets = self::LEGACY_DOOR_TO_CONCEPTS[$slug] ?? [];
            foreach ($targets as $targetSlug) {
                if (!isset($kb[$targetSlug])) {
                    // Concept is not yet in the knowledge base; skip
                    // rather than write an orphaned slug.
                    continue;
                }
                if (!isset($out[$targetSlug]) || self::MIGRATED_CONCEPT_SCORE > $out[$targetSlug]) {
                    $out[$targetSlug] = self::MIGRATED_CONCEPT_SCORE;
                }
            }
        }

        return $out;
    }

    /**
     * Fetch all published qt_stories that have legacy _qt_themes or
     * _qt_doors but no canonical _qt_concepts. Uses ID-pagination
     * internally so we don't load everything into memory at once
     * (defensive — typical archive is small, but we should be kind).
     *
     * @return list<\WP_Post>
     */
    private function postsNeedingMigration(): array
    {
        global $wpdb;
        $out = [];
        $lastId = 0;
        $batch = 200;
        while (true) {
            // We select post IDs (fast) then get_post() each — keeps
            // the SQL tight and lets caches do their work.
            $ids = $wpdb->get_col($wpdb->prepare(
                "SELECT p.ID FROM {$wpdb->posts} p
                 WHERE p.post_type = %s
                   AND p.post_status = 'publish'
                   AND p.ID > %d
                   AND EXISTS (
                       SELECT 1 FROM {$wpdb->postmeta} lm
                        WHERE lm.post_id = p.ID
                          AND lm.meta_key IN (%s, %s)
                   )
                   AND NOT EXISTS (
                       SELECT 1 FROM {$wpdb->postmeta} cm
                        WHERE cm.post_id = p.ID
                          AND cm.meta_key = %s
                   )
                 ORDER BY p.ID ASC
                 LIMIT %d",
                'qt_story',
                $lastId,
                \QuietTruths\Ai\Profile::LEGACY_THEMES_META_KEY,
                \QuietTruths\Ai\Profile::LEGACY_DOORS_META_KEY,
                \QuietTruths\Ai\Profile::CONCEPTS_META_KEY,
                $batch
            ));
            if (empty($ids)) {
                break;
            }
            foreach ($ids as $id) {
                $id = (int) $id;
                $lastId = max($lastId, $id);
                $post = get_post($id);
                if ($post) {
                    $out[] = $post;
                }
            }
        }
        return $out;
    }
}

if (class_exists('WP_CLI')) {
    WP_CLI::add_command('qt ai migrate', __NAMESPACE__ . '\\MigrateCommands');
}
