<?php
/**
 * Quiet Truths — Background Intelligence Domains
 *
 * Domains are the twenty broad areas of human life that organise the
 * concept vocabulary underneath the seven Rooms. They are defined by
 * the Quiet Truths AI Bible (article XVIII) and answer the question:
 *
 *     "What area of life is involved?"
 *
 * This is a DIFFERENT question from what Threads answer ("what human
 * current runs through the experience?") and from what Rooms answer
 * ("where does this story live?"). The Non-Collapse Principle (Bible L)
 * keeps all three distinct:
 *
 *   - Room/Category  = public home.        Seven, frozen.
 *   - Thread         = recurring current.  Open-ended; scored.
 *   - Domain         = area of life.       Private organising layer;
 *                                          not individually scored
 *                                          (derived from concept weights).
 *
 * Domains are background intelligence structures. They do NOT become
 * WordPress categories, they do NOT appear in public navigation, they
 * are NOT shown as chips or labels on a story page. They exist so the
 * concept library has structure as it grows into hundreds/thousands
 * of entries, and so that SemanticSearch can fan a query out across
 * the right area of life (e.g. "lifestyle" → Work & Livelihood, Money,
 * Home & Belonging, Family & Care, Everyday Life, Identity & Self).
 *
 * The list below is the INITIAL twenty from the AI Bible. Domains are
 * expandable (Bible XXXVIII) but new domains are added deliberately
 * under editorial review — they are not auto-generated.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

// Each entry: slug => { name, description }
// Order is meaningful — presented here in the order the Bible names them.
return [
    'people-relationships' => [
        'name'        => 'People & Relationships',
        'description' => 'Who people are in relation to one another — mother, father, child, spouse, sibling, friend, neighbour, colleague, stranger, community.',
    ],
    'life-stages' => [
        'name'        => 'Life Stages & Transitions',
        'description' => 'Where a person is in life and what they are moving through — childhood, adolescence, adulthood, becoming a parent, marriage, separation, divorce, retirement, aging, leaving home, returning home, starting again, migration, loss, recovery.',
    ],
    'work-livelihood' => [
        'name'        => 'Work & Livelihood',
        'description' => 'How people make a living and how work shapes their lives — employment, unemployment, business, career, dismissal, promotion, workplace conflict, financial pressure, ambition, income, opportunity, failure, professional identity.',
    ],
    'home-belonging' => [
        'name'        => 'Home & Belonging',
        'description' => 'Where people come from and where they feel they belong — home, village, city, neighbourhood, family home, diaspora, migration, returning, displacement, belonging, roots, origins, community.',
    ],
    'love-intimacy' => [
        'name'        => 'Love & Intimacy',
        'description' => 'Intimate relationships and the experiences surrounding them — attraction, love, marriage, intimacy, desire, betrayal, separation, loneliness, trust, jealousy, commitment, rejection, reconciliation.',
    ],
    'family-care' => [
        'name'        => 'Family & Care',
        'description' => 'Family structures, responsibilities, and caregiving — parenting, motherhood, fatherhood, children, siblings, parents, caregiving, responsibility, school fees, family expectations, family conflict, aging parents, inheritance.',
    ],
    'emotional-experience' => [
        'name'        => 'Emotional Experience',
        'description' => 'Emotional states and emotional movement — grief, loneliness, shame, fear, anger, guilt, joy, relief, hope, regret, longing, jealousy, gratitude, vulnerability, uncertainty, peace. Several may coexist.',
    ],
    'conflict-decisions' => [
        'name'        => 'Conflict & Decisions',
        'description' => 'Moments of competing choice, pressure, and consequence — leaving, staying, deciding, refusing, accepting, confrontation, disagreement, justice, compromise, consequences, moral conflict, family pressure, social pressure.',
    ],
    'health-vulnerability' => [
        'name'        => 'Health & Vulnerability',
        'description' => 'Illness, disability, addiction, recovery, treatment, caregiving, mortality, pain, vulnerability, dependency, loss of independence. Handled with care and restraint.',
    ],
    'identity-self' => [
        'name'        => 'Identity & Self',
        'description' => 'How people see themselves and how that understanding changes — identity, self-worth, confidence, insecurity, belonging, shame, becoming, independence, expectations, personal change, authenticity, self-discovery.',
    ],
    'faith-meaning' => [
        'name'        => 'Faith & Meaning',
        'description' => 'Belief, doubt, spirituality, purpose, and questions of meaning — faith, belief, doubt, prayer, spirituality, religion, purpose, meaning, forgiveness, morality, hope, existential questions.',
    ],
    'memory-time' => [
        'name'        => 'Memory & Time',
        'description' => 'How stories relate to the past, present, and future — childhood, memory, nostalgia, regret, aging, looking back, waiting, anticipation, forgotten events, family history, things remembered or deliberately forgotten.',
    ],
    'loss-change' => [
        'name'        => 'Loss & Change',
        'description' => 'Endings, absence, separation, disruption, and transformation — death, separation, divorce, departure, displacement, job loss, friendship ending, changing identity, loss of home, loss of opportunity, transformation.',
    ],
    'healing-recovery' => [
        'name'        => 'Healing & Recovery',
        'description' => 'What happens after the hard thing, while the person is not yet done — recovery, forgiveness, therapy, rebuilding, boundaries, acceptance, sobriety, learning again, starting over, rebuilding trust, finding peace. Mending is unfinished.',
    ],
    'everyday-life' => [
        'name'        => 'Everyday Life',
        'description' => 'Ordinary experiences that become meaningful when viewed as part of a human life — meals, routines, neighbours, friendship, errands, workdays, family gatherings, school runs, ordinary conversations, small celebrations, small disappointments, quiet joys.',
    ],
    'culture-society' => [
        'name'        => 'Culture & Society',
        'description' => 'The social environment surrounding individual experiences — traditions, expectations, gender roles, community norms, social pressure, cultural expectations, reputation, class, customs, generational differences, social change.',
    ],
    'place-environment' => [
        'name'        => 'Place & Environment',
        'description' => 'The physical and geographic context of a story — Nairobi, villages, towns, cities, neighbourhoods, workplaces, schools, homes, travel, migration, rural life, urban life. Place can change the meaning of an otherwise similar experience.',
    ],
    'education-growth' => [
        'name'        => 'Education & Growth',
        'description' => 'Learning, opportunity, development, and ambition — school, university, education, exams, learning, opportunity, failure, achievement, ambition, career preparation, personal growth, mentorship.',
    ],
    'money-material' => [
        'name'        => 'Money & Material Life',
        'description' => 'The material conditions affecting people\'s lives — income, debt, rent, school fees, poverty, wealth, savings, business, housing, financial pressure, possessions, inheritance, economic opportunity.',
    ],
    'communication-expression' => [
        'name'        => 'Communication & Expression',
        'description' => 'How people express, withhold, or fail to express what they feel — letters, messages, apologies, confessions, silence, difficult conversations, things left unsaid, asking for forgiveness, telling the truth, writing to someone, speaking too late.',
    ],
];
