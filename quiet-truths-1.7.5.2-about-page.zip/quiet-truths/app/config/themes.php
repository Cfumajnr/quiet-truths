<?php
/**
 * Quiet Truths — Legacy URL redirect map (LEGACY URL COMPATIBILITY ONLY).
 *
 * ⚠️  NOT CANONICAL ONTOLOGY. NOT AN AI KNOWLEDGE BASE. ⚠️
 *
 * v1.7.4 (Corrections 20, 21): this file exists for ONE purpose only —
 * supporting the legacy ?qt_theme= URL redirect
 * (Core\Themes::redirectLegacyTheme()) so bookmarks from the v1.6–v1.7.0
 * era do not 404. It translates old slugs to human-readable names so
 * the redirect page can render a sane title; it does NOT drive AI
 * inference, search, categorization, discovery, public navigation, or
 * story processing.
 *
 * NO AI COMPONENT imports or queries this file. Legacy URL handling
 * belongs to routing compatibility, not intelligence. If any AI code
 * is found reading this file, that is a bug and should be removed.
 *
 * The eight groups it once described — family, work, tradition, faith,
 * love, loss, growth, healing — were the reader-facing "Doors" of
 * v1.6–v1.7.0. They are RETIRED:
 *
 *   - ConceptInference::conceptToDoor() removed (v1.7.3)
 *   - ConceptInference::doorsFor() removed (v1.7.3)
 *   - _qt_doors no longer written
 *   - _qt_themes no longer written (canonical storage is _qt_concepts)
 *   - StoryRelations no longer produces sameDoor / same_theme relations
 *   - doors.css retired, no .qt-door markup ships
 *   - No same-room door bound remains
 *
 * Each legacy group's useful meaning has been translated into the
 * canonical background ontology (Concepts + Threads + Domains). See
 * the migration map in wp qt ai migrate for the live translation.
 *
 * DO NOT add new entries to this file.
 * DO NOT build new features against this file.
 * DO NOT reference these slugs as a public taxonomy.
 * DO NOT require this file from AI, search, or discovery code.
 *
 * This is LEGACY URL COMPATIBILITY, isolated and read-only. It may
 * remain indefinitely for that purpose; it is not part of current
 * intelligence. Core\Themes and this file are never imported by AI,
 * search, or discovery code (Correction 40).
 *
 * @package QuietTruths
 * @deprecated 1.7.3 Legacy URL compatibility only. Canonical ontology
 *             is Concepts + Threads + Domains (private background).
 */

if (!defined('ABSPATH')) {
    exit;
}

return [
    'family'    => ['name' => 'Family'],
    'work'      => ['name' => 'Work'],
    'tradition' => ['name' => 'Tradition'],
    'faith'     => ['name' => 'Faith'],
    'love'      => ['name' => 'Love'],
    'loss'      => ['name' => 'Loss'],
    'growth'    => ['name' => 'Growth'],
    'healing'   => ['name' => 'Healing'],
];
