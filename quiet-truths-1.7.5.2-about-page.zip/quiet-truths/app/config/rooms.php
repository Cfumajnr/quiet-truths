<?php
/**
 * Quiet Truths — CANONICAL ROOM DEFINITIONS (single source of truth)
 *
 * EVERY part of the house reads the seven rooms from here.
 *
 *   - UI (constants.php / template archives / room headers) reads name,
 *     description, purpose for public-facing copy.
 *   - RoomAffinity (AI scoring engine) reads concepts, lexical, signals,
 *     bias, prototypes — it is a SCORER, not a second ontology.
 *   - Submission form reads name, description, concepts for the writer-
 *     facing room picker / live suggestions.
 *   - Reader archives read name + description for headers.
 *
 * No other file may re-define what a room means. Components may score,
 * display, or reason about rooms, but they do not own the definitions.
 * "A room has one canonical definition."
 *
 * The seven rooms are FROZEN. The lists of prototypes/lexical cues may
 * grow, but slugs, names, purposes, and conceptual territories do not
 * change without a deliberate house decision.
 *
 * Evidence hierarchy for AI scoring (preserved):
 *     prototype 0.35 → concept 0.18 → signal 0.10 → lexical 0.05
 *                              Heavy Hearts gravity 0.02
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

return [
    'beginnings' => [
        'slug'        => 'beginnings',
        'name'        => 'Beginnings',
        'description' => 'For when something starts — the first day, the first love, the city, the child, the morning after.',
        'purpose'     => 'Something has begun. Starting, arriving, leaving, first love, first job, first day, education, becoming a mother, courage, ambition, a new city, a new life.',
        // AI scoring cues (consumed by RoomAffinity) — slugs reference the
        // concept knowledge base and signal layer.
        'concepts'    => ['hope','courage','education','origins','ambition','identity','growth','parenthood'],
        'signals'     => ['emotional:hope','emotional:courage','context:work_hustle','time:young_adult','time:recent_past','communication:narrative'],
        'lexical'     => [
            'first day','first time','started','arrived','moved to','joined','began','beginning',
            'new chapter','starting over','fresh start','mwanzo mpya','kwanza','nilipofika',
            'first job','new school','new city','new life','admitted','accepted','opened the door',
            'stepped into','the day i left home','became a mother','first morning','i did not know anyone',
        ],
        'bias'        => 0.00,
        'prototypes'  => [
            'the first day of my new life in the city',
            'starting over after everything fell apart',
            'leaving home to find work for the first time',
            'the day i walked into campus and did not know anyone',
            'arriving in a new place with one small bag',
            'when i became a mother and everything was new',
            'getting that job that changed everything',
            'finally finding the courage to begin',
            'the first morning after i left him',
            'becoming a mother for the first time at twenty-two',
        ],
    ],

    'heavy-hearts' => [
        'slug'        => 'heavy-hearts',
        'name'        => 'Heavy Hearts',
        'description' => 'Grief, betrayal, loneliness, illness, the weight carried quietly. What is heavy.',
        'purpose'     => 'Something is heavy. Grief, betrayal, loneliness, illness, shame, fear, anger, secrets, the thing carried alone.',
        'concepts'    => ['grief','loneliness','betrayal','separation','secrets','fear','shame','anger','memory','health','silence'],
        'signals'     => ['emotional:grief','emotional:loss','emotional:shame','emotional:loneliness','emotional:betrayal','emotional:fear','emotional:guilt','emotional:shock','relationship:deceased','relationship:ex','relationship:absent','context:domestic_violence','context:illness','context:addiction'],
        'lexical'     => [
            'i cried','i could not stop','i sat alone','empty','heavy heart','heart heavy','numb',
            'could not breathe','broken','dark','my son died','my mother died','did not come home',
            'never came back','we buried','mazishi','machozi','alilia','huzuni','maumivu moyoni',
            'lost him','lost her','did not know how to go on','the weight','carried it alone',
            'could not tell anyone',
        ],
        // NOTE: Heavy Hearts bias = 0.02 is SEMANTIC GRAVITY, not a popularity
        // weight. It reflects the genuinely wider emotional range this room
        // holds. Never increase without calibration evidence.
        'bias'        => 0.02,
        'prototypes'  => [
            'the day they called to say he was gone',
            'sitting alone in the house after the funeral',
            'my husband left and i did not know how to tell the children',
            'carrying a secret i could not tell anyone',
            'when i realised the marriage was over',
            'the shame of what happened and not being able to speak',
            'crying in the matatu on the way to work',
            'the day the doctor said the word cancer',
            'i carried it alone for years',
            'the night i sat in the dark and did not move',
        ],
    ],

    'crossroads' => [
        'slug'        => 'crossroads',
        'name'        => 'Crossroads',
        'description' => 'The choices, the leavings, the price of going or staying.',
        'purpose'     => 'A choice is being asked of you. Money, work, school fees, court, leaving, staying, proposals, family decisions, justice, dreams deferred.',
        'concepts'    => ['work','money','justice','courage','boundaries','ambition','fear'],
        'signals'     => ['emotional:fear','emotional:hope','context:work_hustle','context:school_fees','context:poverty_hardship','context:success_escape','communication:narrative'],
        'lexical'     => [
            'i had to decide','choice','did not know whether','stay or leave','should i','what if',
            'took the job','resigned','quit','left him','left her','walked away','filed a case',
            'reported','borrowed','mkopo','chama','kodi','rent','school fees','karo','determined',
            'made the decision','crossroads','kuchagua','maamuzi','ilibidi nichague','when i said no',
            'should i stay','choosing between','two paths',
        ],
        'bias'        => 0.00,
        'prototypes'  => [
            'standing at the edge of a decision that would change everything',
            'should i leave him or stay for the children',
            'borrowing school fees from the chama again',
            'the day i walked into my boss\'s office and resigned',
            'choosing between rent and food for the week',
            'the moment i decided to report him to the police',
            'accepting the job in another country and not knowing when i would return',
            'when i said no for the first time',
            'two offers on the table and only forty-eight hours to choose',
            'leaving the marriage with nothing but a bag',
        ],
    ],

    'homecoming' => [
        'slug'        => 'homecoming',
        'name'        => 'Homecoming',
        'description' => 'Returning — to people, to places, to the self.',
        'purpose'     => 'Where you are from and where you return. Village, family, home, diaspora, parents aging, inheritance, in-laws, origins, memory, parenthood, forgiveness.',
        'concepts'    => ['home','family','forgiveness','origins','memory','aging','religion','parenthood'],
        'signals'     => ['relationship:mother','relationship:father','relationship:grandparent','relationship:sibling','relationship:child','relationship:spouse_partner','relationship:community','time:childhood','time:long_past','time:looking_back','context:inherited_faith'],
        'lexical'     => [
            'went home','returned home','back to the village','kijijini','nyumbani','shags',
            'my father\'s house','my mother\'s hands','grandmother','grandfather','grew up',
            'family gathering','chrismas','christmas','burial','mazishi','rural','home after',
            'back home','ancestors','ukoo','jamaa','babu','bibi','shamba','compound','homestead',
            'kwetu','kwao','niliporudi',
        ],
        'bias'        => 0.00,
        'prototypes'  => [
            'going back to the village after years in the city',
            'sitting on my grandmother\'s stool in the kitchen',
            'burying my father on the shamba he loved',
            'christmas at home with all the aunties and uncles',
            'forgiving my mother after all those years',
            'finding my way back to the faith i grew up in',
            'the smell of my mother\'s cooking when i walked in',
            'walking the paths i walked as a small child',
            'meeting my in-laws for the first time at their homestead',
            'when my own child called me mama for the first time in our house',
        ],
    ],

    'mending' => [
        'slug'        => 'mending',
        'name'        => 'Mending',
        'description' => 'Healing that is not finished — forgiveness, sobriety, learning to sleep again, putting yourself back together.',
        'purpose'     => 'What comes after the hard thing, while you are still becoming okay. Healing unfinished, therapy, forgiveness, recovery, sobriety, boundaries, learning to sleep again, starting over.',
        'concepts'    => ['healing','forgiveness','hope','boundaries','vulnerability','courage','peace'],
        'signals'     => ['emotional:relief','emotional:forgiveness','emotional:peace','emotional:hope','emotional:vulnerability','context:addiction','context:illness','time:looking_forward'],
        'lexical'     => [
            'healing','therapy','counselling','getting better','slowly','one day at a time',
            'started to','learning to','began to forgive','forgave him','forgave her','let go',
            'set a boundary','said no','recovering','sober','sobriety','slept again','could sleep',
            'first night i slept','felt lighter','mending','putting myself back','kupona',
            'kuanza upya','kujenga upya','kupona pole pole','step by step','hatua kwa hatua',
            'rebuild','the wound closing but leaving a scar','starting to feel like myself again',
        ],
        'bias'        => 0.00,
        'prototypes'  => [
            'the first night i slept through after he left',
            'going to therapy for the first time and crying the whole hour',
            'learning to forgive her slowly',
            'one year sober and still taking it a day at a time',
            'the day i looked in the mirror and recognised myself',
            'finally setting the boundary i had avoided for years',
            'the wound closing but leaving a scar',
            'starting to feel like myself again',
            'forgiving myself for what i did to survive',
            'one year later and still putting myself back together',
        ],
    ],

    'letters' => [
        'slug'        => 'letters',
        'name'        => 'Letters',
        'description' => 'Words written but never sent — to a father, a stranger, the self, the one who did not come home.',
        'purpose'     => 'Something written to someone who may never read it. This room is defined by FORM and INTENTION — direct address, unsent — not by topic. Grief letters belong here; love letters belong here; apology letters and letters to the self belong here. The communication detector (not keywords) is the primary signal.',
        'concepts'    => ['secrets','relationships','separation','grief','love','memory'],
        // Letters is the one room where SIGNALS (communication:*) outweigh
        // concept matches. The form is the point.
        'signals'     => ['communication:unsent_letter','communication:apology','communication:confession','communication:gratitude_letter','communication:address_to_younger_self','communication:address_to_deceased','relationship:deceased','relationship:absent','relationship:younger_self'],
        'lexical'     => [
            'dear','to my','i never told you','i wish you could','if you were here','i hope you know',
            'i want you to know','goodbye','i forgive you','thank you for','you never met','i miss you',
            'i still have','to the woman who','to the man who','to the girl who','to the boy who','younger self',
        ],
        'bias'        => 0.00,
        'prototypes'  => [
            'dear dad i do not know if you will ever read this',
            'to the woman who paid my school fees when we had nothing',
            'i still have your number saved in my phone three years later',
            'a letter to my younger self at seventeen',
            'goodbye my brother i never got to say it',
            'mum i hope you are proud of the woman i became',
            'to the stranger who sat with me that night i will never know your name',
            'if you were here i would tell you everything',
            'i wrote this and never sent it',
            'dear younger me it gets worse before it gets better',
        ],
    ],

    'small-mercies' => [
        'slug'        => 'small-mercies',
        'name'        => 'Small Mercies',
        'description' => 'Everyday kindness, the friend who showed up, the cup of tea, the day nothing went wrong.',
        'purpose'     => 'The ordinary good that makes life bearable. A friend showing up, chai, ugali from a neighbour, school fees paid, a child making you laugh, getting out of bed, nothing going wrong.',
        'concepts'    => ['joy','friendship','hope','gratitude','peace','success','waiting'],
        'signals'     => ['emotional:joy','emotional:gratitude','emotional:relief','emotional:peace','emotional:pride','relationship:friend','relationship:community','communication:gratitude_letter','context:success_escape'],
        'lexical'     => [
            'smiled','laughed','cup of tea','chai','neighbour brought','showed up','paid the fees',
            'the sun came out','children laughed','breathed','walked home','felt warm','grateful',
            'thankful','small thing','kind','kindness','ugali','mboga','a good day','quiet morning',
            'breathed easy','amani','furaha','asante','nashukuru','alinitendea wema','neighbour','rafiki alikuja',
            'a neighbour brought ugali','the friend who showed up',
        ],
        'bias'        => 0.00,
        'prototypes'  => [
            'a neighbour brought us ugali when we had nothing',
            'laughing with my sister until we cried about nothing',
            'the cup of chai my colleague left on my desk',
            'waking up to the sun and the sound of birds',
            'finally paying the last of the school fees',
            'the child who held my hand on the bus without saying a word',
            'a quiet sunday after a hard week',
            'the friend who showed up with nothing to say',
            'getting out of bed when it had been days',
            'the day nothing went wrong',
        ],
    ],
];
