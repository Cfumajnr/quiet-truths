<?php
/**
 * Quiet Truths — Threads (recurring human currents)
 *
 * Threads are recurring human currents — ideas, experiences or tensions
 * that can run through many stories, many Rooms, many Domains (AI
 * Bible XV, audit §V). They answer the question:
 *
 *     "What human current runs through this experience?"
 *
 * Threads are NOT categories, NOT Rooms, NOT Domains, NOT Concepts
 * (AI Bible XIX, audit L — the Non-Collapse Principle):
 *   - Room   = public home (7, frozen).
 *   - Domain = area of life (20, private, organising).
 *   - Thread = human current running through (open set, scored, private).
 *   - Concept = specific subject the story names (open set, scored).
 *
 * A thread qualifies as a thread if it captures a recurring human
 * current that can cross Rooms, Domains and specific subjects (audit
 * §V.2). Work, money, the body, place, time on the clock are Domains
 * (areas of life), not currents — they were retired from the early
 * ten-thread model in v1.7.0.
 *
 * Threads are grouped into nine internal FAMILIES (AI Bible XVII):
 *   connection, change, responsibility, loss, inner-life, agency,
 *   meaning, struggle, time. A tenth family-free thread captures
 *   silence/the unsaid. Families are organising labels only; they
 *   are never exposed publicly.
 *
 * Each thread carries:
 *   - name, description
 *   - family          organisational bucket
 *   - concepts[]      concepts that typically feed this current
 *   - words[]         lexical cues (supporting evidence, not the truth)
 *   - signals[]       signal references ("group:name") that imply it
 *   - prototypes[]    short prototypical phrases for BGE-M3 embedding
 *   - status          'established' | 'candidate' (governance per audit XV)
 *   - domains[]       Domains this thread typically runs through (for
 *                     search fan-out); purely for discovery, not scoring
 *   - aliases[]       deprecated slugs that previously named this
 *                     current (e.g. 'faith' -> 'faith-belief') so old
 *                     profile data remains readable without recompute.
 *
 * Scoring weights are unchanged: prototype 0.30 -> concepts 0.18 ->
 * signals 0.12 -> lexical capped at 0.40. Threads with status 'candidate'
 * still score (so we can see their distribution on the corpus) but
 * are held back from discovery surfaces until promoted.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

return [

    /* ═══ CONNECTION ═══ */

    'love-intimacy' => [
        'name'        => 'Love & Intimacy',
        'description' => 'Love, closeness, desire, intimacy, romantic and chosen closeness — and the heartbreak around them.',
        'family'      => 'connection',
        'status'      => 'active',
        'domains'     => ['love-intimacy'],
        'concepts'    => ['relationships','love','friendship','jealousy','vulnerability','betrayal','separation','forgiveness','longing'],
        'aliases'     => ['love'],
        'words'       => ['love','loved','loving','lover','beloved','romance','romantic','tenderness','affection','kissed','held me','her hand','his hand','fell in love','heartbreak','boyfriend','girlfriend','partner','fiancé','fiancée','spouse','intimacy','intimate','made love','fell for him','fell for her','mapenzi','kupendana','mpenzi','penzi','mchumba','uchumba','ndoa','talaka','kuachana'],
        'signals'     => ['emotional:love','emotional:longing','emotional:vulnerability','emotional:betrayal','relationship:spouse_partner','relationship:friend','relationship:ex','communication:unsent_letter'],
        'prototypes'  => [
            'the first time i realised i loved her',
            'learning to be held after being hurt before',
            'marriage through the years when love is not loud',
            'a friend who showed up when everyone else left',
            'the softness between two people who have been through it',
            'heartbreak that taught me what i needed',
            'loving someone from a distance because that is all you can do',
            'forgiving him but choosing myself anyway',
        ],
    ],

    'belonging' => [
        'name'        => 'Belonging',
        'description' => 'Feeling at home (or not), roots, acceptance by a place or people, where you fit.',
        'family'      => 'connection',
        'status'      => 'active',
        'domains'     => ['home-belonging','culture-society','place-environment'],
        'concepts'    => ['home','origins','identity','community','friendship','migration'],
        'aliases'     => ['place-belonging'],
        'words'       => ['belong','belonged','belonging','roots','home','accepted','welcome','fit in','fitting in','where i belong','community','my people','our people','clan','ancestral','homeland','diaspora','homesick','nostalgia','alien','outsider','stranger','nikona nyumbani','nimerudi','mtaani','pakwa','jirani','jamaa','ukoo'],
        'signals'     => ['relationship:community','time:childhood','time:looking_back','context:migration_diaspora','emotional:longing'],
        'prototypes'  => [
            'going back to the village after years in nairobi',
            'the smell of my grandmother\'s kitchen',
            'living abroad and missing home in the body',
            'the estate where i grew up now all changed',
            'finding people who felt like home in a new city',
            'being the outsider in my own family',
            'the matatu ride back to where i am from',
        ],
    ],

    'trust' => [
        'name'        => 'Trust',
        'description' => 'Trusting and being trusted, broken trust, choosing to trust again, reliability between people.',
        'family'      => 'connection',
        'status'      => 'candidate',
        'domains'     => ['love-intimacy','family-care','people-relationships'],
        'concepts'    => ['forgiveness','betrayal','vulnerability','relationships','boundaries'],
        'aliases'     => [],
        'words'       => ['trust','trusted','trusting','trust me','broke my trust','trust again','i trusted him','i trusted her','relied on','counted on','let me down','kuamini','nikiamini','kuniamini','uaminifu','sadikika'],
        'signals'     => ['emotional:betrayal','emotional:vulnerability','relationship:spouse_partner','relationship:friend'],
        'prototypes'  => [
            'i trusted them with the one thing i never told anyone',
            'learning to trust again after being betrayed',
            'someone who showed up exactly when they said they would',
            'the day i stopped trusting someone i loved',
        ],
    ],

    'friendship' => [
        'name'        => 'Friendship',
        'description' => 'Chosen closeness — friends, neighbours, the people we choose who walk with us.',
        'family'      => 'connection',
        'status'      => 'candidate',
        'domains'     => ['people-relationships','everyday-life'],
        'concepts'    => ['friendship','joy','gratitude','community'],
        'aliases'     => [],
        'words'       => ['friend','friends','best friend','my friend','neighbour','neighbor','rafiki','jirani','marafiki','showed up for me','was there for me','walked with me'],
        'signals'     => ['relationship:friend','emotional:gratitude'],
        'prototypes'  => [
            'my best friend was the only one who knew',
            'friends i thought would stay disappeared when things got hard',
            'a neighbour brought ugali when we had nothing',
            'the friend who sat with me in silence and did not need to fix it',
        ],
    ],

    'connection-isolation' => [
        'name'        => 'Connection & Isolation',
        'description' => 'The current of being with others, being unseen, loneliness in a crowd, being held.',
        'family'      => 'connection',
        'status'      => 'candidate',
        'domains'     => ['emotional-experience','people-relationships','everyday-life'],
        'concepts'    => ['loneliness','grief','friendship','community','vulnerability'],
        'aliases'     => [],
        'words'       => ['alone','lonely','no one','nobody','isolation','isolated','unseen','invisible','surrounded by people','cry at night','empty house','niko peke yangu','mwenyewe','upweke','kuna watu ila hakuna mtu','kula peke yangu'],
        'signals'     => ['emotional:loneliness','emotional:vulnerability'],
        'prototypes'  => [
            'i eat alone most nights',
            'even in a crowded room i feel completely alone',
            'there is nobody i can tell these things to',
            'spending whole days without speaking to anyone',
        ],
    ],

    /* ═══ CHANGE ═══ */

    'becoming' => [
        'name'        => 'Becoming',
        'description' => 'Personal growth, identity change, becoming someone new, the slow work of turning into yourself.',
        'family'      => 'change',
        'status'      => 'candidate',
        'domains'     => ['identity-self','education-growth','life-stages'],
        'concepts'    => ['identity','growth','courage','forgiveness','ambition','boundaries'],
        'aliases'     => [],
        'words'       => ['becoming','growing','changed','not the same person','finding myself','new version of me','still becoming','learning to','grown into','kibadilika','nimebadilika','sikuwa vile','nikawa mtu mwingine','kukua'],
        'signals'     => ['emotional:hope','emotional:vulnerability'],
        'prototypes'  => [
            'i am not sure who i am anymore but i am becoming someone truer',
            'i am slowly becoming myself again',
            'i lost myself trying to please everyone and now i am finding me',
            'the person i was five years ago would not recognise me',
        ],
    ],

    'separation' => [
        'name'        => 'Separation',
        'description' => 'Parting, distance, leaving, divorce, departure, being kept apart.',
        'family'      => 'change',
        'status'      => 'active',
        'domains'     => ['loss-change','love-intimacy','family-care','life-stages'],
        'concepts'    => ['separation','grief','betrayal','longing','migration'],
        'aliases'     => [],
        'words'       => ['separated','separation','left','moved out','parted ways','divorce','divorced','packed my bags','went away','distance','apart','miles away','talaka','kutengana','kuachana','kuondoka','aliacha','nimeachwa'],
        'signals'     => ['emotional:longing','emotional:grief','relationship:ex','context:migration_diaspora'],
        'prototypes'  => [
            'i packed my bags in the middle of the night',
            'the divorce papers arrived and i could not read them',
            'we parted ways without ever really saying goodbye',
            'living miles away from the people who raised me',
        ],
    ],

    'transition' => [
        'name'        => 'Transition',
        'description' => 'Movement between life stages, starting over, new beginnings, arrivals and departures.',
        'family'      => 'change',
        'status'      => 'candidate',
        'domains'     => ['life-stages','home-belonging','education-growth'],
        'concepts'    => ['courage','ambition','origins','identity','hope','migration'],
        'aliases'     => [],
        'words'       => ['starting over','new chapter','moved','arrived','first day','left home','new city','new school','new job','begin again','fresh start','kwanza','kuanza upya','siku ya kwanza','nimehamia','mji mpya'],
        'signals'     => ['emotional:hope','emotional:fear','context:migration_diaspora','time:anniversary'],
        'prototypes'  => [
            'the morning after deciding to change',
            'first day in a new city where i knew nobody',
            'starting over with almost nothing',
            'becoming a mother for the first time',
        ],
    ],

    'letting-go' => [
        'name'        => 'Letting Go',
        'description' => 'Release, acceptance, forgiving what cannot be changed, surrender, moving on.',
        'family'      => 'change',
        'status'      => 'candidate',
        'domains'     => ['healing-recovery','emotional-experience'],
        'concepts'    => ['forgiveness','healing','peace','hope','boundaries'],
        'aliases'     => [],
        'words'       => ['let go','letting go','let it be','accepted','moved on','surrender','released','i made peace','letting him go','letting her go','kusamehe','kuachilia','kukubali','amani'],
        'signals'     => ['emotional:peace','emotional:forgiveness'],
        'prototypes'  => [
            'i forgave them not for them but for myself',
            'letting go did not mean forgetting',
            'i made peace with what happened',
            'i finally stopped waiting for them to come back',
        ],
    ],

    /* ═══ RESPONSIBILITY ═══ */

    'responsibility' => [
        'name'        => 'Responsibility',
        'description' => 'Duty, provision, carrying others, showing up, what is owed to people who depend on you.',
        'family'      => 'responsibility',
        'status'      => 'active',
        'domains'     => ['family-care','work-livelihood','money-material'],
        'concepts'    => ['parenthood','family','work','money','education','courage','sacrifice'],
        'aliases'     => [],
        'words'       => ['responsibility','duty','duties','provide for','providing','i had to','depended on me','depended on me','carried the family','siblings school fees','pay rent','send money','support my family','looking after','taking care','wajibu','mzigo','kuhudumia','kulea','kusomesha','kutuma pesa nyumbani','black tax'],
        'signals'     => ['relationship:child','relationship:sibling','context:school_fees','context:poverty_hardship','context:unemployment','emotional:fear'],
        'prototypes'  => [
            'the responsibility of sending money home to the family',
            'i kept paying school fees even after i lost my job',
            'i was the firstborn and everyone looked to me',
            'my siblings ate because i did not',
            'the weight of being the one everyone depends on',
        ],
    ],

    'sacrifice' => [
        'name'        => 'Sacrifice',
        'description' => 'Giving something up for someone or something else, cost, what was laid down.',
        'family'      => 'responsibility',
        'status'      => 'candidate',
        'domains'     => ['family-care','work-livelihood','love-intimacy'],
        'concepts'    => ['love','family','courage','responsibility','forgiveness'],
        'aliases'     => [],
        'words'       => ['sacrifice','sacrificed','gave up','laid down','for their sake','for my children','paid the price','gave everything','for us','kutoa','kutoa sadaka','kujitoa','kupoteza kwaajili','nilijitoa'],
        'signals'     => ['relationship:child','context:poverty_hardship','emotional:love'],
        'prototypes'  => [
            'i gave up my dream so my sister could go to school',
            'i did not eat so my child could',
            'staying for the children when i wanted to leave',
            'i sacrificed my youth so my family could survive',
        ],
    ],

    'care' => [
        'name'        => 'Care',
        'description' => 'Active caregiving — looking after the sick, aging parents, children, the vulnerable; showing up physically.',
        'family'      => 'responsibility',
        'status'      => 'candidate',
        'domains'     => ['family-care','health-vulnerability','people-relationships'],
        'concepts'    => ['aging','health','parenthood','illness','love'],
        'aliases'     => [],
        'words'       => ['caring for','taking care of','looking after','caregiver','nursed','sat with her','bathed him','took him to hospital','watched over','kumhudumia','kumtunza','kuangalia','mgonjwa','mzazi mzee','kuuguza'],
        'signals'     => ['relationship:parent','relationship:child','context:illness','relationship:grandparent','emotional:vulnerability'],
        'prototypes'  => [
            'caring for my mother as her memory faded',
            'i slept on the hospital floor for three weeks',
            'looking after a parent who once looked after me',
            'giving medicine in the middle of the night when the fever would not break',
        ],
    ],

    'obligation' => [
        'name'        => 'Obligation',
        'description' => 'The weight of what is expected — family expectation, social pressure, duty felt as weight rather than love.',
        'family'      => 'responsibility',
        'status'      => 'candidate',
        'domains'     => ['family-care','culture-society','emotional-experience'],
        'concepts'    => ['family','culture','justice','shame','identity'],
        'aliases'     => [],
        'words'       => ['expected','obligation','expected of me','family expects','i was supposed to','had no choice','duty to','i owed','tradition','custom','expectations','in-laws','lazima','nilazimika','kutarajiwa','sharti','maadili','desturi'],
        'signals'     => ['relationship:in_laws','emotional:shame','context:family_pressure','context:cultural_pressure'],
        'prototypes'  => [
            'i was supposed to marry the man they chose',
            'the family expected me to send money even when i had none',
            'i did it because a daughter is supposed to',
            'the weight of being a good child',
        ],
    ],

    /* ═══ LOSS ═══ */

    'grief' => [
        'name'        => 'Grief',
        'description' => 'Mourning, absence, the weight of losing someone or something — death and other losses.',
        'family'      => 'loss',
        'status'      => 'active',
        'domains'     => ['loss-change','emotional-experience','memory-time'],
        'concepts'    => ['grief','loss','loneliness','memory','separation','love'],
        'aliases'     => [],
        'words'       => ['died','passed away','lost him','lost her','burial','funeral','mourning','grief','grieving','mourned','still miss','empty chair','wore black','mazishi','kufariki','kufa','marehemu','kifo','ombolezo','kumkosa','ameondoka'],
        'signals'     => ['emotional:grief','emotional:longing','relationship:deceased','time:anniversary','communication:unsent_letter'],
        'prototypes'  => [
            'I kept calling her phone even though I knew she would not answer',
            'I still set a plate for them at dinner out of habit',
            'there is an empty space nothing else can fill',
            'every small thing reminds me they are gone',
        ],
    ],

    'longing' => [
        'name'        => 'Longing',
        'description' => 'Wanting what is gone or far — missing, desire to return, unfinished reach for someone or something.',
        'family'      => 'loss',
        'status'      => 'candidate',
        'domains'     => ['emotional-experience','love-intimacy','memory-time'],
        'concepts'    => ['longing','grief','love','memory','home','separation','migration'],
        'aliases'     => [],
        'words'       => ['miss him','miss her','long for','wish i could','yearn','aching','one more time','if i could see','ninamkumbuka sana','natamani','kukosa','kumiss','roho inaniuma'],
        'signals'     => ['emotional:longing','context:migration_diaspora','time:looking_back','communication:unsent_letter'],
        'prototypes'  => [
            'i wish i could hear their voice one more time',
            'there are things i still want to tell them',
            'i miss the person i thought they were',
            'ninamkumbuka sana',
        ],
    ],

    'loss' => [
        'name'        => 'Loss',
        'description' => 'Endings beyond death — job loss, home loss, opportunity loss, friendship ending, identity loss.',
        'family'      => 'loss',
        'status'      => 'candidate',
        'domains'     => ['loss-change','work-livelihood','home-belonging'],
        'concepts'    => ['grief','separation','failure','betrayal','work','money'],
        'aliases'     => [],
        'words'       => ['lost my job','lost the house','lost the business','lost the chance','lost our friendship','evicted','closed the shop','fired','sacked','dismissed','friendship ended','ended our friendship','kufukuzwa','kufilisika','biashara kufa','kupoteza kazi'],
        'signals'     => ['context:unemployment','context:poverty_hardship','emotional:shock','emotional:grief'],
        'prototypes'  => [
            'i lost the job that was holding our family together',
            'the shop closed and with it a piece of who i was',
            'i was evicted in the middle of the night with the children',
            'a friendship of twenty years ended in silence',
        ],
    ],

    /* ═══ INNER LIFE ═══ */

    'shame' => [
        'name'        => 'Shame',
        'description' => 'The quiet feeling of being wrong, exposed, not enough, carrying what you cannot say.',
        'family'      => 'inner-life',
        'status'      => 'active',
        'domains'     => ['emotional-experience','identity-self'],
        'concepts'    => ['shame','secrets','silence','vulnerability','failure','guilt'],
        'aliases'     => [],
        'words'       => ['ashamed','shame','embarrassed','humiliated','disgrace','i lied','pretended','could not tell anyone','smiled and said nothing','said nothing','niliaibishwa','aibu','fedheha','sikutaka kusema','nimeficha','nimejifanya'],
        'signals'     => ['emotional:shame','communication:withheld','context:sexual_violence','context:failure_shame'],
        'prototypes'  => [
            'i smiled and told everyone everything was fine',
            'i could not bring myself to tell them the truth',
            'i lied because i was too ashamed to say what happened',
            'i pretended not to care when i was dying inside',
        ],
    ],

    'fear' => [
        'name'        => 'Fear',
        'description' => 'Dread, anxiety, what one is afraid of — feared futures, the thing that wakes you at 3 a.m.',
        'family'      => 'inner-life',
        'status'      => 'active',
        'domains'     => ['emotional-experience','health-vulnerability','conflict-decisions'],
        'concepts'    => ['fear','anxiety','worry','violence','health','survival'],
        'aliases'     => [],
        'words'       => ['afraid','fear','scared','frightened','terrified','dread','anxious','panic','woke up afraid','i was scared','naogopa','wasiwasi','hofu','kutishika','kuogopa','hofu ya'],
        'signals'     => ['emotional:fear','context:domestic_violence','context:illness','context:unemployment','tense:feared'],
        'prototypes'  => [
            'i am afraid all the time even though i look strong',
            'the fear that wakes me up at three in the morning',
            'i am afraid my mother will die before i make it home',
            'i pretended i was not scared but my hands were shaking',
        ],
    ],

    'guilt' => [
        'name'        => 'Guilt',
        'description' => 'Responsibility for harm done, regret for choices, what you carry as your fault.',
        'family'      => 'inner-life',
        'status'      => 'candidate',
        'domains'     => ['emotional-experience','family-care','faith-meaning'],
        'concepts'    => ['forgiveness','shame','grief','regret','responsibility'],
        'aliases'     => [],
        'words'       => ['guilty','guilt','it was my fault','i blame myself','i should have','i should not have','if i had','i did not','forgive me','cannot forgive myself','hatia','najilaumu','kulaumu','nilikosea','sikumfanyia','sikutenda'],
        'signals'     => ['emotional:regret','communication:apology','relationship:deceased'],
        'prototypes'  => [
            'i still blame myself for not being there',
            'if i had answered the call that night would they still be here',
            'i cannot forgive myself for what i did',
            'the guilt lives in my chest even after all these years',
        ],
    ],

    'hope' => [
        'name'        => 'Hope',
        'description' => 'Belief in something ahead, even small; the refusal to stop trying; the quiet expectation of good.',
        'family'      => 'inner-life',
        'status'      => 'active',
        'domains'     => ['faith-meaning','emotional-experience','healing-recovery'],
        'concepts'    => ['hope','courage','faith','forgiveness','ambition'],
        'aliases'     => [],
        'words'       => ['hope','hopeful','believe','tomorrow','one day','it will be well','still trying','still believe','maybe','kuna siku','kila la heri','kuna matumaini','natumai','bado natafuta','sijakata tamaa','matumaini','tumaini'],
        'signals'     => ['emotional:hope','tense:hoped_for'],
        'prototypes'  => [
            'i still believe tomorrow can be better',
            'even after everything i have not given up',
            'one day this pain will mean something',
            'kuna siku nitapona',
        ],
    ],

    'vulnerability' => [
        'name'        => 'Vulnerability',
        'description' => 'Openness, softness, exposure, letting yourself be seen — and the fear and release around it.',
        'family'      => 'inner-life',
        'status'      => 'candidate',
        'domains'     => ['emotional-experience','identity-self','love-intimacy','health-vulnerability'],
        'concepts'    => ['vulnerability','love','courage','forgiveness','shame','identity'],
        'aliases'     => ['body'],
        'words'       => ['vulnerable','soft','open','raw','weak','fragile','exposed','let him in','let her in','let my guard down','cry','naked','wazi','moyo wazi','nimejifungua','kuwa dhaifu'],
        'signals'     => ['emotional:vulnerability','emotional:love','context:illness'],
        'prototypes'  => [
            'i am tired of pretending i am okay',
            'i cry when nobody is watching',
            'i let him see the parts of me i usually hide',
            'saying it out loud made me feel both lighter and more afraid',
        ],
    ],

    'identity-self' => [
        'name'        => 'Identity & Self',
        'description' => 'Who one is, self-worth, becoming yourself, what is true about you under the roles you play.',
        'family'      => 'inner-life',
        'status'      => 'candidate',
        'domains'     => ['identity-self'],
        'concepts'    => ['identity','pride','dignity','shame','becoming','forgiveness','vulnerability'],
        'aliases'     => [],
        'words'       => ['who i am','myself','self-worth','i am the kind of person','not the person i was','the real me','i became','inauthentic','pretending to be','lost myself','found myself','nani mimi','nafsi yangu','mwenyewe','utambulisho','kujitambua'],
        'signals'     => ['emotional:vulnerability','emotional:shame'],
        'prototypes'  => [
            'i am not sure who i am anymore',
            'i lost myself trying to please everyone',
            'finding myself after years of being someone else\'s version of me',
            'i am finally becoming the person i want to be',
        ],
    ],

    /* ═══ AGENCY ═══ */

    'courage' => [
        'name'        => 'Courage',
        'description' => 'Acting despite fear, walking in, speaking up, leaving, beginning — the choice to move.',
        'family'      => 'agency',
        'status'      => 'active',
        'domains'     => ['conflict-decisions','identity-self'],
        'concepts'    => ['courage','boundaries','hope','justice','freedom'],
        'aliases'     => [],
        'words'       => ['courage','brave','bravery','dared','i walked in','i said no','spoke up','stood up','i decided','i finally','woke up and','made the call','wrote this','i sent it','ushujaa','jasiri','kuthubutu','nilithubutu','nikasema hapana','nikaamua'],
        'signals'     => ['emotional:courage','context:justice_court','communication:difficult_conversation'],
        'prototypes'  => [
            'i woke up one morning and decided this was the last day',
            'i walked in and said what i had rehearsed for years',
            'writing this is the hardest thing i have ever done',
            'i said no and walked away knowing it would cost me',
        ],
    ],

    'freedom-choice' => [
        'name'        => 'Freedom & Choice',
        'description' => 'Agency, deciding, refusing, choosing for yourself, independence; the moment of choice.',
        'family'      => 'agency',
        'status'      => 'candidate',
        'domains'     => ['conflict-decisions','identity-self'],
        'concepts'    => ['freedom','independence','courage','boundaries','ambition','choice'],
        'aliases'     => [],
        'words'       => ['i chose','i decided','my choice','free','freedom','on my own','independent','refused','i refused','walked away','i left','my decision','uhuru','kuchagua','niliamua','mimi mwenyewe','kukataa','kuondoka'],
        'signals'     => ['emotional:courage','tense:decided'],
        'prototypes'  => [
            'i finally chose myself',
            'i walked away from everything i had known',
            'saying no was the first time i felt free',
            'leaving was the hardest and most honest thing i did',
        ],
    ],

    'boundaries' => [
        'name'        => 'Boundaries',
        'description' => 'Saying no, protecting your peace, cutting harm off, distance as self-protection.',
        'family'      => 'agency',
        'status'      => 'candidate',
        'domains'     => ['identity-self','healing-recovery','conflict-decisions'],
        'concepts'    => ['boundaries','forgiveness','courage','healing','peace'],
        'aliases'     => [],
        'words'       => ['i said no','walked away','cut them off','blocked them','enough is enough','protect my peace','distance myself','drew a line','set a boundary','nilisema hapana','nikaacha','nikaondoka','nikakata uhusiano','amekataa','sivumili tena'],
        'signals'     => ['emotional:peace','emotional:courage','communication:withheld'],
        'prototypes'  => [
            'i finally said no and walked away',
            'i had to cut them off to protect my peace',
            'i learned to put distance between myself and harm',
            'enough was enough',
        ],
    ],

    'ambition-drive' => [
        'name'        => 'Ambition & Drive',
        'description' => 'Wanting more, building, striving, refusing to stay where you started; the hunger to build.',
        'family'      => 'agency',
        'status'      => 'candidate',
        'domains'     => ['work-livelihood','education-growth','identity-self'],
        'concepts'    => ['ambition','education','work','success','hope','courage'],
        'aliases'     => [],
        'words'       => ['ambition','dream','goals','build','started a business','opened a shop','i will build','refuse to stay','make something of myself','i want more','working hard','determined','biashara yangu','kujenga','kujituma','kusoma kwa bidii','maendeleo','malengo','ndoto zangu'],
        'signals'     => ['emotional:hope','emotional:courage','context:success_escape'],
        'prototypes'  => [
            'i started something small with almost no money',
            'i refuse to stay where i started',
            'building something for myself and my children',
            'i wake up at four because i refuse to be poor forever',
        ],
    ],

    'survival-resilience' => [
        'name'        => 'Survival & Resilience',
        'description' => 'Enduring, carrying on, getting through, the will to keep going through what should break you.',
        'family'      => 'agency',
        'status'      => 'active',
        'domains'     => ['conflict-decisions','health-vulnerability','work-livelihood'],
        'concepts'    => ['courage','hope','fear','survival','violence','resilience','healing'],
        'aliases'     => ['violence-survival'],
        'words'       => ['survived','survivor','carried on','kept going','got through','made it through','i am still here','did not break','endured','endure','nimeokoka','nimesurvive','sijakata tamaa','kuvumilia','kustahimili','kuishi','sikufa','niko hai'],
        'signals'     => ['emotional:courage','emotional:relief','context:domestic_violence','context:illness','context:poverty_hardship'],
        'prototypes'  => [
            'the night i decided to leave was the night i survived',
            'i have carried more than anyone should and i am still here',
            'surviving something i thought would kill me',
            'kuvumilia kila siku hadi mwisho',
        ],
    ],

    /* ═══ MEANING ═══ */

    'faith-belief' => [
        'name'        => 'Faith & Belief',
        'description' => 'Belief, doubt, prayer, spirituality, religion, what holds you when nothing else does.',
        'family'      => 'meaning',
        'status'      => 'active',
        'domains'     => ['faith-meaning'],
        'concepts'    => ['religion','hope','peace','silence','forgiveness','gratitude'],
        'aliases'     => ['faith'],
        'words'       => ['god','allah','jesus','church','mosque','prayer','prayed','praying','worship','faith','spiritual','belief','pastor','imam','priest','quran','bible','heaven','hell','blessing','miracle','soul','divine','mungu','maombi','sala','kusali','kanisa','msikiti','baraka','dua','imani','roho','dhambi','injili','dini','kwa sababu mungu','niliomba','aliniombea'],
        'signals'     => ['emotional:hope','emotional:peace','emotional:forgiveness','context:inherited_faith'],
        'prototypes'  => [
            'i knelt and prayed even when i did not know what to say',
            'my mother\'s faith carried our family through hard times',
            'doubt and belief living side by side in the same chest',
            'going back to church or to the mosque after years away',
        ],
    ],

    'forgiveness' => [
        'name'        => 'Forgiveness',
        'description' => 'Letting go of blame — of others, of yourself; forgiving, making peace.',
        'family'      => 'meaning',
        'status'      => 'candidate',
        'domains'     => ['faith-meaning','healing-recovery'],
        'concepts'    => ['forgiveness','peace','healing','hope','love','guilt'],
        'aliases'     => [],
        'words'       => ['forgave','forgive','forgiveness','let go of anger','made peace','pardoned','reconciled','nilisamehe','kusamehe','ame nisamehe','kusuluhisha','amani','sina hasira'],
        'signals'     => ['emotional:forgiveness','emotional:peace','communication:apology'],
        'prototypes'  => [
            'i forgave them not for them but for myself',
            'i made peace with what happened',
            'forgiving myself took longer than forgiving him',
            'the apology i waited years for never came so i let it go anyway',
        ],
    ],

    'meaning-purpose' => [
        'name'        => 'Meaning & Purpose',
        'description' => 'Questions of why, what it is all for, existential weight, what gives life meaning.',
        'family'      => 'meaning',
        'status'      => 'candidate',
        'domains'     => ['faith-meaning','identity-self'],
        'concepts'    => ['hope','faith','identity','memory','grief','purpose'],
        'aliases'     => [],
        'words'       => ['meaning','purpose','why','point of','what is it for','exist','i wondered if','why me','what is the point','empty inside','maana','madhumuni','kwa nini','sababu','maisha yana maana gani','najiuliza'],
        'signals'     => ['emotional:longing','emotional:vulnerability','emotional:grief'],
        'prototypes'  => [
            'i sat with the question of what any of this was for',
            'after everything i still did not know what my life meant',
            'looking for a reason to keep going',
            'the question of why this happened never really goes away',
        ],
    ],

    /* ═══ STRUGGLE ═══ */

    'injustice' => [
        'name'        => 'Injustice',
        'description' => 'Being wronged, unfairness, corruption, systems failing people, accountability denied.',
        'family'      => 'struggle',
        'status'      => 'active',
        'domains'     => ['conflict-decisions','culture-society'],
        'concepts'    => ['justice','anger','courage'],
        'aliases'     => [],
        'words'       => ['justice','injustice','unfair','court','courts','police','lawyer','evidence','vindicated','accountability','wronged','complaint','compensation','corruption','bribe','arrested','case','haki','dhuluma','kudhulumiwa','mahakama','polisi','mwanasheria','ushahidi','kesi','rushwa','mafisadi','kubughu','kutendewa isivyo haki','kupigania haki','kusema ukweli'],
        'signals'     => ['emotional:anger','relationship:police_authority','context:poverty_hardship'],
        'prototypes'  => [
            'the day the judge ruled against me',
            'fighting for what was right even when it cost me',
            'a bribe i would not pay',
            'speaking up when everyone else was quiet',
            'the police who did nothing when we reported',
        ],
    ],

    'betrayal' => [
        'name'        => 'Betrayal',
        'description' => 'Broken trust by someone close — a secret shared, trust turned against you, infidelity, confidence violated.',
        'family'      => 'struggle',
        'status'      => 'candidate',
        'domains'     => ['love-intimacy','friendship','conflict-decisions'],
        'concepts'    => ['betrayal','anger','shame','trust','secrets'],
        'aliases'     => [],
        'words'       => ['betrayed','betrayal','stabbed me in the back','broke my trust','cheated','cheating','affair','shared my secret','told everyone','spread my','i trusted him','i trusted her','alisaliti','kunisaliti','uhaini','amenidanganya','amefanya uhaini'],
        'signals'     => ['emotional:betrayal','emotional:anger','relationship:spouse_partner','relationship:friend'],
        'prototypes'  => [
            'the person i trusted most turned against me',
            'i told them in confidence and they told everyone',
            'finding out what they had been saying behind my back',
            'they shared my secret and i have not spoken since',
        ],
    ],

    'conflict' => [
        'name'        => 'Conflict',
        'description' => 'Tension, disagreement, difficult conversations, family pressure, confrontation, moral conflict.',
        'family'      => 'struggle',
        'status'      => 'candidate',
        'domains'     => ['conflict-decisions','family-care','culture-society'],
        'concepts'    => ['anger','courage','boundaries','justice','family'],
        'aliases'     => [],
        'words'       => ['fought','argued','quarrel','disagreement','confrontation','difficult conversation','raised voice','shouted','fight','conflict','clash','pressure','family pressure','tension','kugombana','mabishano','kupigana kelele','kukosana','mzozo','shinikizo','kushinikizwa'],
        'signals'     => ['emotional:anger','communication:difficult_conversation','context:family_pressure','context:cultural_pressure'],
        'prototypes'  => [
            'we sat across from each other and finally said the hard things',
            'a fight that changed everything between us',
            'the family pressured me until i had no breath',
            'disagreeing with the people i love most',
        ],
    ],

    'addiction-struggle' => [
        'name'        => 'Addiction & Struggle',
        'description' => 'The hold of substances or patterns — alcohol, gambling, substances, cycles one cannot escape on willpower alone.',
        'family'      => 'struggle',
        'status'      => 'candidate',
        'domains'     => ['health-vulnerability','emotional-experience'],
        'concepts'    => ['addiction','shame','healing','recovery','vulnerability'],
        'aliases'     => [],
        'words'       => ['alcohol','drunk','drugs','bhang','weed','cocaine','heroin','gambling','betting','sober','sobriety','drank','bottle','relapse','rehab','pombe','kulewa','mlevi','bang','kupoteza','kuzoea','kuacha pombe'],
        'signals'     => ['context:addiction','emotional:shame','emotional:vulnerability'],
        'prototypes'  => [
            'the bottle was the only thing that listened',
            'i placed another bet even though i had nothing left',
            'getting sober one day at a time',
            'i hid the drinking from everyone including myself',
        ],
    ],

    /* ═══ TIME ═══ */

    'memory' => [
        'name'        => 'Memory',
        'description' => 'The past in the present, echoes, what stays, what returns, what will not leave.',
        'family'      => 'time',
        'status'      => 'candidate',
        'domains'     => ['memory-time','home-belonging'],
        'concepts'    => ['memory','grief','nostalgia','aging','regret'],
        'aliases'     => ['time-memory'],
        'words'       => ['remember','remembered','memory','memories','recall','nostalgia','flashback','still hear','still see','i can still smell','the day','those days','back then','growing up','childhood','kumbukumbu','nakumbuka','zamani','utotoni','bado nakumbuka','sahau','kusahau'],
        'signals'     => ['time:childhood','time:adolescence','time:long_past','time:looking_back','time:anniversary','relationship:deceased'],
        'prototypes'  => [
            'i can still smell her cooking',
            'ten years later it still visits me',
            'a memory that comes back when it rains',
            'i hear their voice in certain songs',
        ],
    ],

    'waiting' => [
        'name'        => 'Waiting',
        'description' => 'Patience, deferred hope, anticipation, what has not arrived, what you are sitting with.',
        'family'      => 'time',
        'status'      => 'candidate',
        'domains'     => ['memory-time','faith-meaning','emotional-experience'],
        'concepts'    => ['waiting','hope','longing','patience','fear'],
        'aliases'     => [],
        'words'       => ['waiting','still waiting','wait for','waiting for him','waiting for her','waited','patience','patient','kungoja','kusubiri','nangoja','bado nasubiri','subiri','itafika siku','saa ingefika','nimekaa tu'],
        'signals'     => ['emotional:longing','emotional:hope','tense:hoped_for'],
        'prototypes'  => [
            'i am still waiting for them to come back',
            'waiting for a sign that i made the right choice',
            'i waited for years for an apology that never came',
            'sitting in the quiet of something not yet arrived',
        ],
    ],

    'regret' => [
        'name'        => 'Regret',
        'description' => 'Wishing things had been otherwise, roads not taken, words unsaid, the weight of the past.',
        'family'      => 'time',
        'status'      => 'candidate',
        'domains'     => ['memory-time','emotional-experience'],
        'concepts'    => ['regret','guilt','grief','memory','forgiveness','longing'],
        'aliases'     => [],
        'words'       => ['regret','regretted','i wish i had','if only','i should have','i should not have','did not say','never told them','i never got to','looking back i','majuto','ninajuta','laiti','kama ningefanya','sikumwambia'],
        'signals'     => ['time:looking_back','emotional:regret','relationship:deceased','communication:unsaid'],
        'prototypes'  => [
            'there are things i never got to say',
            'i still wish i had answered the phone that night',
            'looking back i wish i had been kinder to myself',
            'the road i did not take still visits me sometimes',
        ],
    ],

    'aging-legacy' => [
        'name'        => 'Aging & Legacy',
        'description' => 'Growing older, time\'s passing, what is left behind, parents aging, legacy and inheritance.',
        'family'      => 'time',
        'status'      => 'candidate',
        'domains'     => ['memory-time','family-care','life-stages','money-material'],
        'concepts'    => ['aging','memory','legacy','inheritance','family','grief'],
        'aliases'     => [],
        'words'       => ['growing old','older','ageing','retirement','retired','grey hair','wrinkles','old age','legacy','inheritance','heir','grandchildren','grandmother','grandfather','wrinkled','uzee','mzee','wazee','urithi','mirathi','kustaafu','mvi','umri','makunzi','babu','bibi'],
        'signals'     => ['relationship:grandparent','relationship:parent','time:long_past','context:inheritance_family'],
        'prototypes'  => [
            'watching my parents grow old',
            'my father\'s hands are not as steady as they used to be',
            'what will i leave behind when i am gone',
            'the family now asks me the questions they used to ask him',
        ],
    ],

    /* ═══ FAMILY-FREE THREAD: SILENCE ═══ */

    'silence-unsaid' => [
        'name'        => 'Silence & The Unsaid',
        'description' => 'Secrets, silence, what is withheld, what is carried without being named, the words that never came. Stands outside the other families because silence runs through them all.',
        'family'      => 'silence',
        'status'      => 'active',
        'domains'     => ['communication-expression','emotional-experience'],
        'concepts'    => ['secrets','silence'],
        'aliases'     => ['silence-secrets'],
        'words'       => ['secret','secrets','unspoken','unsaid','never told','tell no one','kept it to myself','hidden','buried','carried it','heavy secret','nobody knew','no one knew','pretended','silent','silence','did not say','never said','could not tell anyone','locked away','siri','kimya','kunyamaza','kuficha','sijamwambia','sikuambia','kubeba mzigo','siri ya moyo','msalaba wangu','nimekaa kimya','sikuwaambia'],
        'signals'     => ['communication:confession','communication:withheld','emotional:shame','emotional:loneliness','context:success_escape'],
        'prototypes'  => [
            'i carried it for twenty years without saying a word',
            'the thing i have never told anyone',
            'smiling at the funeral while falling apart inside',
            'pretending everything was fine',
            'a family secret everyone knew but nobody spoke',
            'letters i wrote but never sent',
        ],
    ],
];
