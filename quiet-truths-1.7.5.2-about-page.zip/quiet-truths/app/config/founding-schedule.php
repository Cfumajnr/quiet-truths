<?php
/**
 * Quiet Truths — founding collection release schedule.
 *
 * The 32 entries below were already live before the current AI-native
 * Quiet Truths build. They are a migrated founding collection, not native
 * form submissions. This schedule gives that collection a deliberate
 * weekly journey through the Rooms from 1 January to 6 August 2026. The
 * first native Quiet Truths Story, "The Woman Who Went Back", follows on
 * 9 August 2026 and is intentionally not assigned a legacy date here.
 *
 * Nothing applies automatically. The operator previews and explicitly
 * applies/restores the schedule under Quiet Stories → Founding Schedule.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

return [
    'version'     => '2026-weekly-v1',
    'timezone'    => 'Africa/Nairobi',
    'native_slug' => 'the-woman-who-went-back',
    'entries'     => [
        ['date' => '2026-01-01 09:00:00', 'room' => 'beginnings',    'slug' => 'every-small-step-changed-the-direction-of-her-life'],
        ['date' => '2026-01-08 09:00:00', 'room' => 'heavy-hearts',  'slug' => 'after-everyone-left'],
        ['date' => '2026-01-15 09:00:00', 'room' => 'crossroads',    'slug' => 'she-remembered-every-promise-except-the-one-she-made-to-herself'],
        ['date' => '2026-01-22 09:00:00', 'room' => 'homecoming',    'slug' => 'the-boy-i-came-back-for'],
        ['date' => '2026-01-29 09:00:00', 'room' => 'mending',       'slug' => 'she-stopped-writing-after-that-one-reply'],
        ['date' => '2026-02-05 09:00:00', 'room' => 'letters',       'slug' => 'his-father-asked-for-one-last-favour'],
        ['date' => '2026-02-12 09:00:00', 'room' => 'small-mercies', 'slug' => 'holding-the-door'],

        ['date' => '2026-02-19 09:00:00', 'room' => 'beginnings',    'slug' => 'the-future-arrived-quietly'],
        ['date' => '2026-02-26 09:00:00', 'room' => 'heavy-hearts',  'slug' => 'the-woman-they-said-was-a-blessing-i-call-a-curse'],
        ['date' => '2026-03-05 09:00:00', 'room' => 'crossroads',    'slug' => 'the-man-i-am-after-six-pm'],
        ['date' => '2026-03-12 09:00:00', 'room' => 'homecoming',    'slug' => 'what-the-lake-keeps'],
        ['date' => '2026-03-19 09:00:00', 'room' => 'mending',       'slug' => 'the-car-that-took-my-family-away'],
        ['date' => '2026-03-26 09:00:00', 'room' => 'letters',       'slug' => 'a-letter-ill-never-send'],
        ['date' => '2026-04-02 09:00:00', 'room' => 'small-mercies', 'slug' => 'the-whisper-that-knew-my-name'],

        ['date' => '2026-04-09 09:00:00', 'room' => 'beginnings',    'slug' => 'they-built-a-house-they-hadnt-moved-into-yet'],
        ['date' => '2026-04-16 09:00:00', 'room' => 'heavy-hearts',  'slug' => 'i-slept-with-another-man-to-save-my-husband-two-years-later-he-left-me-for-a-second-wife'],
        ['date' => '2026-04-23 09:00:00', 'room' => 'crossroads',    'slug' => 'she-could-report-the-truth-or-protect-her-brother'],
        ['date' => '2026-04-30 09:00:00', 'room' => 'homecoming',    'slug' => 'the-man-who-ran-out-of-charm'],
        ['date' => '2026-05-07 09:00:00', 'room' => 'mending',       'slug' => 'i-sat-in-the-last-row-of-her-wedding'],
        ['date' => '2026-05-14 09:00:00', 'room' => 'letters',       'slug' => 'voice-notes-i-never-sent'],
        ['date' => '2026-05-21 09:00:00', 'room' => 'small-mercies', 'slug' => 'he-deletes-chats-every-night-not-because-hes-cheating-because-he-says-privacy-is-important'],

        ['date' => '2026-05-28 09:00:00', 'room' => 'beginnings',    'slug' => 'i-attended-my-exs-wedding-i-shouldnt-have'],
        ['date' => '2026-06-04 09:00:00', 'room' => 'heavy-hearts',  'slug' => 'twelve-years-later-she-called-only-to-hand-me-my-dead-son'],
        ['date' => '2026-06-11 09:00:00', 'room' => 'crossroads',    'slug' => 'my-mother-never-wanted-me-23-years-later-i-still-dont-know-how-to-love-her-back'],
        ['date' => '2026-06-18 09:00:00', 'room' => 'homecoming',    'slug' => 'i-raised-another-mans-child-for-12-years-without-knowing'],
        ['date' => '2026-06-25 09:00:00', 'room' => 'letters',       'slug' => 'she-started-locking-the-bedroom-door-after-10pm'],
        ['date' => '2026-07-02 09:00:00', 'room' => 'small-mercies', 'slug' => 'i-lied-to-my-wife-about-my-salary-for-six-years-because-i-feared-shed-leave-if-she-knew-how-little-i-earned'],

        ['date' => '2026-07-09 09:00:00', 'room' => 'beginnings',    'slug' => 'every-birthday-reminded-her-of-one-unanswered-prayer'],
        ['date' => '2026-07-16 09:00:00', 'room' => 'heavy-hearts',  'slug' => 'i-dont-know-how-to-tell-my-father-i-am-failing-again'],
        ['date' => '2026-07-23 09:00:00', 'room' => 'crossroads',    'slug' => 'my-husband-confessed-after-18-years-that-he-has-another-daughter-who-is-now-joining-university'],
        ['date' => '2026-07-30 09:00:00', 'room' => 'letters',       'slug' => 'we-never-made-it-past-four-months'],
        ['date' => '2026-08-06 09:00:00', 'room' => 'beginnings',    'slug' => 'nobody-warns-you-about-becoming'],
    ],
];
