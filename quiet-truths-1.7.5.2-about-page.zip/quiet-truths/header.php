<?php
/**
 * Quiet Truths — Header
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

// Component helpers must exist before any qt_* call below.
$qt_loader = get_stylesheet_directory() . '/app/presentation/components/loader.php';
if (!file_exists($qt_loader)) {
    error_log('Quiet Truths: component loader missing at ' . $qt_loader);
} else {
    require_once $qt_loader;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="qt-header">
    <div class="qt-header__inner">
        <div class="qt-header__brand">
            <a class="qt-header__logo" href="<?php echo esc_url(home_url('/')); ?>">
                <?php echo esc_html__('Quiet', 'quiet-truths'); ?> <span><?php echo esc_html__('Truths', 'quiet-truths'); ?></span>
            </a>
            <p class="qt-header__tagline"><?php echo esc_html__('Where Truth Finds Peace.', 'quiet-truths'); ?></p>
        </div>

        <?php
        if (function_exists('qt_header_nav')) {
            qt_header_nav();
        }
        ?>

        <button class="qt-header__menu-toggle" type="button" aria-expanded="false" aria-controls="qt-mobile-nav">
            <span class="sr-only"><?php echo esc_html__('Menu', 'quiet-truths'); ?></span>
            <span aria-hidden="true">☰</span>
        </button>
    </div>
</header>

<?php
if (function_exists('qt_mobile_nav')) {
    qt_mobile_nav();
}
if (function_exists('qt_search_overlay')) {
    qt_search_overlay();
}
?>
