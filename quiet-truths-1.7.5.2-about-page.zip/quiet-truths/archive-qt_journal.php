<?php
/**
 * Quiet Truths — Journal archive (post type: qt_journal)
 *
 * The Journal door leads here — a dedicated, calm, editorial space for
 * considered writing (Journal Bible §1, §3, §28). Primarily a reading
 * experience, with a quiet path to submit a Journal for editorial
 * review. No categories, no reaction counts, no popularity scores.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main id="qt-main">
    <header class="room-header">
        <?php echo qt_room_symbol('letters'); ?>
        <h1 class="room-header__name"><?php echo esc_html__('The Journals', 'quiet-truths'); ?></h1>
        <p class="room-header__description">
            <?php echo esc_html__('Deeper writing about the things we live, question, witness and try to understand.', 'quiet-truths'); ?>
        </p>
    </header>

    <div class="library-search u-mt-lg">
        <p class="library-search__line">
            <?php echo esc_html__('Read, wander, or follow a question into the deeper layer of the house.', 'quiet-truths'); ?>
        </p>
        <?php qt_search_bar(''); ?>
        <div class="qt-live-suggest" id="qt-live-suggest-library" hidden></div>
    </div>

    <section class="story-feed" style="padding-top:var(--space-xl)">
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <?php qt_journal_card(get_the_ID()); ?>
            <?php endwhile; ?>
        <?php else : ?>
            <?php qt_gentle_notice('reflection', __('The Journals are still finding their first voices. Deeper writing will gather here.', 'quiet-truths')); ?>
        <?php endif; ?>
    </section>

    <div class="u-text-center u-mt-2xl">
        <?php
        the_posts_pagination([
            'mid_size'  => 1,
            'prev_text' => '←',
            'next_text' => '→',
            'type'      => 'list',
        ]);
        ?>
    </div>

    <?php if (shortcode_exists('qt_journal_submission')) : ?>
        <section class="journal-submit-invite">
            <p class="rooms-section__label"><?php echo esc_html__('Have something worth exploring?', 'quiet-truths'); ?></p>
            <p class="story-more__note">
                <?php echo esc_html__('A Journal is considered writing — examined, not just experienced. Submissions enter editorial review.', 'quiet-truths'); ?>
            </p>
            <p class="u-mt-lg">
                <a class="qt-button qt-button--quiet" href="<?php echo esc_url(home_url('/submit-a-journal/')); ?>">
                    <?php echo esc_html__('Submit a Journal for Editorial Review', 'quiet-truths'); ?>
                </a>
            </p>
        </section>
    <?php endif; ?>
</main>

<?php get_footer(); ?>
