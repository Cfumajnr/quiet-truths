<?php
/**
 * Quiet Truths Genesis — Child Theme of Blocksy
 *
 * Enqueues the parent theme, then boots the platform.
 * No CSS paths. No enqueues. No business logic.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Safety net: str_starts_with / str_ends_with / str_contains arrived in
 * PHP 8.0. The theme requires PHP 8.0 (see style.css), so these are
 * only loaded if someone runs the theme on a lower version by accident.
 */
if (!function_exists('str_starts_with')) {
    function str_starts_with($haystack, $needle) {
        return (string) $needle !== '' && strncmp($haystack, $needle, strlen($needle)) === 0;
    }
}

if (!function_exists('str_ends_with')) {
    function str_ends_with($haystack, $needle) {
        if ('' === $needle || $needle === $haystack) return true;
        if ('' === $haystack) return false;
        return substr($haystack, -strlen($needle)) === $needle;
    }
}

if (!function_exists('str_contains')) {
    function str_contains($haystack, $needle) {
        return $needle !== '' && strpos($haystack, $needle) !== false;
    }
}

// ── Mandatory production requirements (fail closed, keep Admin reachable) ──
$qt_requirements = get_stylesheet_directory() . '/app/core/Requirements.php';
if (!is_file($qt_requirements)) {
    error_log('Quiet Truths: Requirements.php is missing.');
    return;
}
require_once $qt_requirements;
if (!\QuietTruths\Core\Requirements::enforce()) {
    return;
}

// ── Child theme: load parent stylesheet ──
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style(
        'blocksy-parent',
        get_template_directory_uri() . '/style.css',
        [],
        wp_get_theme()->get('Version')
    );
}, 1);

// ── Locale: default the house to Kenyan English so <html lang> and ──
// og:locale are "en-KE". Honours a non-empty WPLANG setting in WP Admin.
if ('' === (string) get_option('WPLANG')) {
    add_filter('locale', static function (): string {
        return 'en_KE';
    });
}

// ── Boot the platform (with error guard) ──
$qt_bootstrap = get_stylesheet_directory() . '/app/core/Application.php';

add_action('after_setup_theme', function () use ($qt_bootstrap) {
    if (!file_exists($qt_bootstrap)) {
        error_log('Quiet Truths: Application.php not found at ' . $qt_bootstrap);
        return;
    }

    try {
        require_once $qt_bootstrap;
        \QuietTruths\Core\Application::boot();
    } catch (\Throwable $e) {
        error_log('Quiet Truths bootstrap error: ' . $e->getMessage());
        if (defined('WP_DEBUG') && WP_DEBUG) {
            wp_die('Quiet Truths could not start: ' . esc_html($e->getMessage()));
        }
    }
});
