# Quiet Truths production verification

Run `tests/production.sh https://quiettruths.co.ke` after deployment. A non-zero exit blocks release.

The automated probe verifies canonical HTTPS redirects, About/Room/search/sitemap availability, reviewed About copy, security headers, cache isolation on interactive pages, `security.txt`, direct internal-source denial, debug-log denial and absence of unresolved governance tokens.

Manual authenticated checks remain required for administrator-only controls:

- only the sole operator account can view pending Stories and AI/privacy evidence;
- decline, withdrawal, restore and deletion create minimum audit events;
- withdrawal immediately removes public access and leaves no derived meta;
- `wp qt operations run` heartbeat and retention state are green;
- encrypted backup restoration is reconciled against post-backup withdrawal/deletion records;
- administrator MFA is enforced by Wordfence;
- debug display is disabled and logs are not web-accessible;
- cPanel/server cron runs `wp qt operations run --quiet` at least every five minutes;
- accessibility is checked by keyboard, screen reader, reduced-motion mode and mobile forms;
- Lighthouse/WebPageTest is run for Home, Story, Room, Search and submission pages under an uncached mobile profile;
- SQLi, stored/reflected XSS, CSRF, capability and cache-leak checks are performed against staging with the production server stack.

No test may use real pending Story text. Use synthetic fixtures only.
