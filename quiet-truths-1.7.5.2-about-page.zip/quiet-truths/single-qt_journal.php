<?php
/**
 * Quiet Truths — Single journal (reading view, bylined)
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main id="qt-main" class="reading-container reading-container--story" style="padding-top:var(--space-3xl);padding-bottom:var(--space-4xl)">
    <?php while (have_posts()) : the_post(); ?>

        <?php $qt_byline = qt_journal_byline(get_the_ID()); ?>

        <article class="journal-single">
            <div class="journal-single__byline">
                <span class="journal-single__byline-name"><?php echo esc_html($qt_byline['name'] ?: __('A writer', 'quiet-truths')); ?></span>
                <?php if ('' !== $qt_byline['role']) : ?>
                    <span class="journal-single__byline-role"><?php echo esc_html($qt_byline['role']); ?></span>
                <?php endif; ?>
            </div>

            <h1 class="story-single__title"><?php the_title(); ?></h1>

            <p class="story-single__meta">
                <span><?php echo esc_html(get_the_date('j M Y')); ?></span>
                <?php if ('' !== qt_reading_time(get_the_ID())) : ?>
                    <span aria-hidden="true">·</span>
                    <span><?php echo esc_html(qt_reading_time(get_the_ID())); ?></span>
                <?php endif; ?>
            </p>

            <div class="story-single__body">
                <?php the_content(); ?>
            </div>

            <?php if ('' !== $qt_byline['bio']) : ?>
                <div class="journal-single__bio">
                    <span class="journal-single__bio-name"><?php echo esc_html($qt_byline['name'] ?: ''); ?></span>
                    <p><?php echo esc_html($qt_byline['bio']); ?></p>
                </div>
            <?php endif; ?>
        </article>

        <?php
        // The conversation beneath the Journal — comments only, no
        // reactions, no counts (Journal Bible §19–§25).
        if (function_exists('qt_journal_conversation')) {
            qt_journal_conversation(get_the_ID());
        }
        ?>

        <?php
        // The discovery network — the full typed relationship graph
        // (Journal Bible §28–§29): Stories that illustrate this Journal,
        // and Journals that share its current. Reader never sees the AI
        // taxonomy — only gentle, editorial labels (§48).
        if (class_exists(\QuietTruths\Ai\JournalRelations::class)) {
            $qt_rels = \QuietTruths\Ai\JournalRelations::forPost(get_the_ID(), 8);

            $qt_story_rels = array_values(array_filter($qt_rels, static fn ($r) => 'qt_story' === get_post_type((int) $r['id'])));
            $qt_journal_rels = array_values(array_filter($qt_rels, static fn ($r) => 'qt_journal' === get_post_type((int) $r['id'])));

            if (!empty($qt_story_rels)) :
        ?>
            <section class="story-more">
                <p class="rooms-section__label"><?php echo esc_html__('In lived experience', 'quiet-truths'); ?></p>
                <p class="story-more__note">
                    <?php echo esc_html__('The house saw these stories near this journal — people who have lived close to what it examines.', 'quiet-truths'); ?>
                </p>
                <?php foreach (array_slice($qt_story_rels, 0, 3) as $qt_rel) : ?>
                    <?php
                    $qt_s    = get_post((int) $qt_rel['id']);
                    if (!$qt_s) continue;
                    $qt_s_room = qt_story_room($qt_s->ID);
                    $qt_s_time = qt_reading_time($qt_s);
                    ?>
                    <a class="qt-story-row" href="<?php echo esc_url(get_permalink($qt_s)); ?>">
                        <h3 class="qt-story-row__title"><?php echo esc_html((string) $qt_s->post_title); ?></h3>
                        <p class="qt-story-row__excerpt"><?php echo esc_html(qt_story_excerpt($qt_s, 200)); ?></p>
                        <div class="qt-story-row__meta">
                            <?php if ($qt_s_room) : ?>
                                <span><?php echo esc_html(sprintf(__('From the %s room', 'quiet-truths'), $qt_s_room->name)); ?></span>
                            <?php endif; ?>
                            <?php if ('' !== $qt_s_time) : ?>
                                <span aria-hidden="true">·</span><span><?php echo esc_html($qt_s_time); ?></span>
                            <?php endif; ?>
                        </div>
                    </a>
                <?php endforeach; ?>
            </section>
        <?php
            endif;

            if (!empty($qt_journal_rels)) :
        ?>
            <section class="story-more">
                <p class="rooms-section__label"><?php echo esc_html__('More from the journals', 'quiet-truths'); ?></p>
                <?php foreach (array_slice($qt_journal_rels, 0, 3) as $qt_rel) : ?>
                    <?php
                    $qt_j = get_post((int) $qt_rel['id']);
                    if ($qt_j) qt_journal_card($qt_j);
                    ?>
                <?php endforeach; ?>
            </section>
        <?php
            endif;
        }
        ?>

    <?php endwhile; ?>
</main>

<?php get_footer(); ?>
