/**
 * Quiet Truths — live-search.js
 * As the visitor types in ANY search field (the Begin search on the
 * homepage, the search overlay, the results page), the invisible layer
 * offers suggestions: concepts whose name — or whose words — begin with
 * what has been typed so far. Runs entirely in the browser.
 */
(function () {
    'use strict';

    var CFG = window.QTLiveSearch || { concepts: [] };

    function ready(fn) {
        if (document.readyState !== 'loading') {
            fn();
        } else {
            document.addEventListener('DOMContentLoaded', fn);
        }
    }

    ready(function () {
        var inputs = document.querySelectorAll('input[data-qt-live]');

        inputs.forEach(function (input) {
            var form = input.closest('form');

            if (!form) {
                return;
            }

            // The suggestion box: either the form's next sibling, or the
            // first qt-live-suggest that follows the form within the
            // same container.
            var next = form.nextElementSibling;

            if (!next || !next.classList.contains('qt-live-suggest')) {
                var container = form.parentElement;

                if (container) {
                    var after = [];

                    Array.prototype.forEach.call(container.children, function (child) {
                        if (after.length || child === form) {
                            after.push(child);
                        }
                    });

                    for (var i = 0; i < after.length; i++) {
                        if (after[i].classList && after[i].classList.contains('qt-live-suggest')) {
                            next = after[i];
                            break;
                        }
                    }
                }
            }

            if (!next || !next.classList.contains('qt-live-suggest')) {
                return;
            }

            input.addEventListener('input', function () {
                var q = input.value.trim().toLowerCase();

                if (q.length < 1) {
                    next.hidden = true;
                    next.innerHTML = '';
                    return;
                }

                var hits = [];

                CFG.concepts.forEach(function (c) {
                    if (hits.length >= 6) {
                        return;
                    }

                    var name = (c.name || '').toLowerCase();
                    var words = c.words || [];
                    var match = name.indexOf(q) === 0;

                    if (!match) {
                        for (var i = 0; i < words.length; i++) {
                            if (words[i].indexOf(q) === 0) {
                                match = true;
                                break;
                            }
                        }
                    }

                    if (match) {
                        hits.push(c);
                    }
                });

                if (!hits.length) {
                    next.hidden = true;
                    next.innerHTML = '';
                    return;
                }

                next.hidden = false;
                next.innerHTML = '';

                // Discover the home URL from the form's action so the JS
                // does not hard-code "/" (works on subfolder installs).
                var homeUrl = form.getAttribute('action') || '/';
                var sep = homeUrl.indexOf('?') === -1 ? '?' : '&';

                hits.forEach(function (c) {
                    var a = document.createElement('a');
                    a.className = 'qt-live-suggest__item';
                    a.href = homeUrl + sep + 's=' + encodeURIComponent(c.name) + '&qt_concept=' + encodeURIComponent(c.slug);
                    a.textContent = c.name;
                    next.appendChild(a);
                });
            });
        });
    });
})();
