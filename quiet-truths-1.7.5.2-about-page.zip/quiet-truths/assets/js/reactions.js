/**
 * Quiet Truths — Silent reader reactions
 *
 * A quiet interaction: the reader sees only the words. On click, the
 * hidden emoji gently emerges from behind the phrase and the reaction
 * is recorded via AJAX. The emoji is a MOMENT, not a status: it stays
 * visible for ~30 seconds, then falls back to words-only while the
 * reaction remains recorded and the buttons stay disabled.
 *
 * Three states:
 *   A) Available   — words only, emoji hidden, clickable
 *   B) Revealed    — emoji visible (temporary, after successful reaction)
 *   C) Acknowledged— words only + Dawn underline, buttons disabled
 *
 * The form still works without JavaScript (a plain POST that reloads),
 * so this enhancement degrades gracefully.
 */
(function () {
    'use strict';

    var REVEAL_MS = 30000; // ~30 seconds

    function ready(fn) {
        if (document.readyState !== 'loading') {
            fn();
        } else {
            document.addEventListener('DOMContentLoaded', fn);
        }
    }

    ready(function () {
        var section = document.querySelector('.qt-reactions');
        if (!section) {
            return;
        }

        var form = section.querySelector('.qt-reactions__form');
        var buttons = section.querySelectorAll('.qt-reactions__button');

        if (!form || !buttons.length) {
            return;
        }

        var storyId = form.getAttribute('data-story-id') || '';

        // If the page was already rendered in the acknowledged state
        // (returning visitor, server already knows), keep it quiet.
        Array.prototype.forEach.call(buttons, function (b) {
            if (b.classList.contains('is-selected')) {
                b.disabled = true;
                b.setAttribute('aria-disabled', 'true');
                b.setAttribute('aria-pressed', 'true');
                b.classList.remove('is-revealed');
            }
        });

        Array.prototype.forEach.call(buttons, function (button) {
            button.addEventListener('click', function (event) {
                if (button.disabled || button.getAttribute('aria-disabled') === 'true') {
                    event.preventDefault();
                    return;
                }

                // Prevent the default full-page POST so the reveal is smooth.
                event.preventDefault();

                var slug = button.getAttribute('value');

                var body = new URLSearchParams();
                body.set('action', 'qt_react');
                body.set('story_id', storyId);
                body.set('qt_react', slug);
                body.set('qt_react_action', 'react');
                body.set('_wpnonce', (window.QTReactions && window.QTReactions.nonce) || '');

                fetch(window.QTReactions.ajaxUrl, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: body.toString()
                })
                    .then(function (res) {
                        return res.json();
                    })
                    .then(function (data) {
                        if (data && data.success) {
                            // Confirmed. Reveal the emoji NOW (this button),
                            // permanently record the reaction, disable the set,
                            // then begin the per-button 30s visual timer.
                            button.classList.add('is-revealed');

                            Array.prototype.forEach.call(buttons, function (b) {
                                b.disabled = true;
                                b.setAttribute('aria-disabled', 'true');
                                if (b !== button) {
                                    b.classList.remove('is-revealed');
                                }
                            });
                            button.classList.add('is-selected');
                            button.setAttribute('aria-pressed', 'true');

                            if (!section.querySelector('.qt-reactions__note')) {
                                var note = document.createElement('p');
                                note.className = 'qt-reactions__note';
                                note.textContent = window.QTReactions && window.QTReactions.thanks
                                    ? window.QTReactions.thanks
                                    : 'The house has heard you. Thank you for being here.';
                                section.appendChild(note);
                            }

                            // 30-second timer: remove ONLY is-revealed. The
                            // reaction stays recorded, selected, disabled.
                            window.setTimeout(function () {
                                button.classList.remove('is-revealed');
                            }, REVEAL_MS);
                        } else {
                            // Not confirmed — restore the normal interactive
                            // state and let the fallback submit mechanism run.
                            button.classList.remove('is-revealed');
                            form.submit();
                        }
                    })
                    .catch(function () {
                        button.classList.remove('is-revealed');
                        form.submit();
                    });
            });
        });
    });
})();
