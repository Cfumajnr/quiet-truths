/**
 * Quiet Truths — writer.js
 * A gentle writing assistant for the story form. Runs entirely in the
 * browser (no external AI calls): live word count, repeated-word
 * reminders and optional moderation-language nudges.
 * The server is always the final judge.
 */
(function () {
    'use strict';

    var CFG = window.QTWriter || { minWords: 20, maxChars: 4000, badWords: [], badPhrases: [], concepts: [], rooms: {}, roomAffinity: {}, warnMap: {}, privacyRules: {} };

    var LEET = {
        '0': 'o', '1': 'i', '3': 'e', '4': 'a', '5': 's', '7': 't', '8': 'b',
        '@': 'a', '$': 's', '!': 'i', '+': 't'
    };

    var STOP = new Set((
        'the a an and or but so if then than that this these those with for on at by ' +
        'from to of in is are was were be been being have has had do does did not no yes ' +
        'i me my we our us you your they them their he him his she her it its there here ' +
        'when where why how what which who whom about into over after before between during ' +
        'because while even every each few both all any some more most other such only own ' +
        'same too very just like also once upon off out up down again one two first last'
    ).split(' '));

    function normalize(s) {
        s = s.toLowerCase();
        for (var k in LEET) {
            s = s.split(k).join(LEET[k]);
        }
        return s.replace(/(.)\1{2,}/g, '$1$1');
    }

    function wordsOf(s) {
        return (s.toLowerCase().match(/[a-z']+/g) || []);
    }

    function analyze(text) {
        var words = wordsOf(text);
        var freq = {};
        var repeats = [];

        for (var i = 0; i < words.length; i++) {
            var w = words[i];
            if (w.length >= 3 && !STOP.has(w)) {
                freq[w] = (freq[w] || 0) + 1;
            }
        }

        var keys = Object.keys(freq).sort(function (a, b) {
            return (freq[b] - freq[a]) || (a < b ? -1 : 1);
        });

        for (var j = 0; j < keys.length && repeats.length < 4; j++) {
            if (freq[keys[j]] >= 3) {
                repeats.push({ w: keys[j], n: freq[keys[j]] });
            }
        }

        var norm = normalize(text);
        var tight = norm.replace(/[^a-z0-9]+/g, '');
        var bad = null;

        function esc(re) {
            return re.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        }

        for (var b = 0; b < CFG.badWords.length; b++) {
            var bw = CFG.badWords[b];
            if (new RegExp('\\b' + esc(bw) + '\\b').test(norm) || tight.indexOf(bw) > -1) {
                bad = bw;
                break;
            }
        }

        if (!bad) {
            for (var p = 0; p < CFG.badPhrases.length; p++) {
                var bp = CFG.badPhrases[p];
                if (norm.indexOf(bp) > -1 || tight.indexOf(bp.replace(/\s+/g, '')) > -1) {
                    bad = bp;
                    break;
                }
            }
        }

        return { total: words.length, chars: text.length, repeats: repeats, bad: bad };
    }

    /* ── The invisible layer: which concepts is this story about? ── */

    var CONCEPT_MAP = {};
    CFG.concepts.forEach(function (c) {
        c.words.forEach(function (w) {
            (CONCEPT_MAP[w] = CONCEPT_MAP[w] || []).push(c.slug);
        });
    });

    function detectConcepts(text) {
        var tokens = wordsOf(normalize(text));
        var seen = {};
        var scores = {};

        tokens.forEach(function (t) {
            if (t.length < 3 || seen[t]) {
                return;
            }
            seen[t] = true;
            (CONCEPT_MAP[t] || []).forEach(function (slug) {
                scores[slug] = (scores[slug] || 0) + 1;
            });
        });

        return Object.keys(scores)
            .filter(function (slug) { return scores[slug] >= 2; })
            .sort(function (a, b) { return scores[b] - scores[a]; });
    }

    /* ── Gentle content-warning suggestions ──
     * The house suggests themes writers may want to warn readers about.
     * These fill the warnings input — the writer can edit freely. */
    var WARN_PHRASES = {
        grief:    ['died','death','burial','funeral','passed away','killed','lost him','lost her','coffin','buried'],
        illness:  ['hospital','sick','cancer','hiv','diagnosed','ward','admitted','surgery','fell ill'],
        violence: ['beat','beaten','hit me','hit her','hit him','raped','assaulted','blood','choked'],
        suicide:  ['end my life','kill myself','wanted to die','suicide','no reason to live'],
        abuse:    ['abused','abusive','touched me','molested'],
        money:    ['debt','evicted','rent notice','no money','broke','no customers','empty shop'],
        loss:     ['divorce','separated','never came back','left me for','did not come home'],
        faith:    ['prayed','pastor','church','mosque','imam','sheikh'],
        sex:      ['slept with','cheated','mistress','mpango','side chick','brothel'],
        family:   ['my father','my mother','my son','my daughter','firstborn']
    };

    function detectWarnings(text) {
        var norm = normalize(text);
        var found = [];
        Object.keys(WARN_PHRASES).forEach(function (tag) {
            if (WARN_PHRASES[tag].some(function (p) { return norm.indexOf(p) > -1; })) {
                found.push(tag);
            }
        });
        return found;
    }

    /* ── Gentle privacy nudges ──
     * The house quietly notices phones, emails, IDs, M-Pesa references,
     * social links, and clusters of identifying details. These are
     * nudges, never blocks — the writer decides. */

    function detectPrivacyNudges(text) {
        var rules = CFG.privacyRules || {};
        var patterns = rules.patterns || {};
        var msgs = rules.nudgeMessages || {};
        var found = [];
        var seen = {};

        function add(kind, message) {
            if (seen[kind]) return;
            seen[kind] = true;
            found.push({ kind: kind, message: message });
        }

        Object.keys(patterns).forEach(function (kind) {
            try {
                var re = new RegExp(patterns[kind], 'i');
                if (re.test(text)) {
                    add(kind, msgs[kind] || (kind + ' detected'));
                }
            } catch (e) { /* bad regex — ignore */ }
        });

        // Constellation detection: age + gender + job + city (+ workplace/named_child).
        var constellation = rules.constellation || {};
        var cHits = 0;
        var cStrongHits = 0;
        Object.keys(constellation).forEach(function (k) {
            try {
                if (new RegExp(constellation[k], 'i').test(text)) {
                    cHits++;
                    if (['named_child', 'workplace'].indexOf(k) !== -1) cStrongHits++;
                }
            } catch (e) {}
        });
        var threshold = rules.constellationThreshold || 3;
        var uThreshold = rules.uniquenessThreshold || 3;
        if (cStrongHits >= 1 && cHits >= 2) {
            add('uniqueness', msgs.uniqueness || 'a named detail plus demographics could identify you — consider softening one');
        } else if (cHits >= threshold) {
            add('cluster', msgs.cluster || 'several details together could identify you — consider softening one');
        }

        return found;
    }

    function renderRoomSuggestions(text) {
        var block = document.getElementById('qt-suggest');
        var chips = document.getElementById('qt-suggest-chips');
        var select = document.getElementById('qt_room');

        if (!block || !chips) {
            return;
        }

        var detected = detectConcepts(text);

        if (!detected.length) {
            block.hidden = true;
            chips.innerHTML = '';
            return;
        }

        var roomScores = {};
        Object.keys(CFG.roomAffinity || {}).forEach(function (roomSlug) {
            CFG.roomAffinity[roomSlug].forEach(function (conceptSlug) {
                if (detected.indexOf(conceptSlug) > -1) {
                    roomScores[roomSlug] = (roomScores[roomSlug] || 0) + 1;
                }
            });
        });

        var top = Object.keys(roomScores)
            .sort(function (a, b) { return roomScores[b] - roomScores[a]; })
            .slice(0, 3);

        if (!top.length) {
            block.hidden = true;
            chips.innerHTML = '';
            return;
        }

        block.hidden = false;
        chips.innerHTML = '';

        top.forEach(function (roomSlug) {
            var chip = document.createElement('button');
            chip.type = 'button';
            chip.className = 'qt-suggest__chip';
            chip.textContent = CFG.rooms[roomSlug] || roomSlug;

            chip.addEventListener('click', function () {
                if (select) {
                    select.value = roomSlug;
                }
                chips.querySelectorAll('.qt-suggest__chip').forEach(function (c) {
                    c.classList.remove('is-chosen');
                });
                chip.classList.add('is-chosen');
            });

            chips.appendChild(chip);
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        var textarea = document.querySelector('[data-qt-writer]');

        if (!textarea) {
            return;
        }

        var counter = document.getElementById('qt-writer-count');
        var chips = document.getElementById('qt-writer-repeats');
        var warn = document.getElementById('qt-writer-warn');
        var warnField = document.getElementById('qt_warnings');
        var warnWrap = document.getElementById('qt-warn-suggest');
        if (!warnWrap) {
            // Inject a small chip holder under the warnings field.
            var wf = warnField || document.querySelector('.qt-writer');
            if (wf && wf.parentElement) {
                warnWrap = document.createElement('div');
                warnWrap.id = 'qt-warn-suggest';
                warnWrap.className = 'qt-writer__chips';
                wf.parentElement.insertBefore(warnWrap, wf.nextSibling);
            }
        }

        function run() {
            var a = analyze(textarea.value);

            if (counter) {
                var need = Math.max(0, CFG.minWords - a.total);
                var text = a.total + ' word' + (a.total === 1 ? '' : 's') + ' · ' + a.chars + ' characters';

                if (need > 0) {
                    text += ' · ' + need + ' more word' + (need === 1 ? '' : 's') + ' to be held';
                }

                counter.textContent = text;
            }

            if (chips) {
                chips.innerHTML = '';

                a.repeats.forEach(function (r) {
                    var chip = document.createElement('span');
                    chip.className = 'qt-writer__chip' + (r.n >= 10 ? ' qt-writer__chip--many' : '');
                    chip.textContent = r.w + ' ×' + r.n;

                    if (r.n >= 10) {
                        chip.title = 'You have used this word ' + r.n + ' times.';
                    }

                    chips.appendChild(chip);
                });
            }

            if (warn) {
                if (a.bad) {
                    warn.classList.add('is-visible');
                    warn.textContent = 'This wording may need extra human review. Context matters, and your submission will still be read.';
                } else {
                    warn.classList.remove('is-visible');
                }
            }

            renderRoomSuggestions(textarea.value);

            // Suggest content-warning chips (non-blocking, writer can ignore).
            if (warnWrap && CFG.warnMap) {
                var wtags = detectWarnings(textarea.value);
                warnWrap.innerHTML = '';
                if (wtags.length) {
                    var label = document.createElement('span');
                    label.className = 'qt-writer__warn-label';
                    label.textContent = 'Content warnings you might add: ';
                    label.style.fontSize = '12px';
                    label.style.color = 'var(--c-subtle, #888)';
                    warnWrap.appendChild(label);
                }
                wtags.forEach(function (tag) {
                    var chip = document.createElement('button');
                    chip.type = 'button';
                    chip.className = 'qt-writer__chip qt-writer__chip--warn';
                    chip.textContent = CFG.warnMap[tag] || tag;
                    chip.title = 'Click to add this warning';
                    chip.addEventListener('click', function () {
                        if (!warnField) return;
                        var cur = warnField.value.trim();
                        var pieces = cur ? cur.split(/\s*,\s*/).filter(Boolean) : [];
                        if (pieces.indexOf((CFG.warnMap[tag] || tag)) === -1) {
                            pieces.push(CFG.warnMap[tag] || tag);
                            warnField.value = pieces.join(', ');
                        }
                    });
                    warnWrap.appendChild(chip);
                });
            }

            // Privacy nudge chips (non-clickable — they're reminders).
            var privacyWrap = document.getElementById('qt-privacy-suggest');
            if (!privacyWrap) {
                var after = warnWrap || (warnField && warnField.parentElement);
                if (after) {
                    privacyWrap = document.createElement('div');
                    privacyWrap.id = 'qt-privacy-suggest';
                    privacyWrap.className = 'qt-writer__chips qt-writer__chips--privacy';
                    after.parentNode.insertBefore(privacyWrap, after.nextSibling);
                }
            }
            if (privacyWrap) {
                var nudges = detectPrivacyNudges(textarea.value);
                privacyWrap.innerHTML = '';
                nudges.forEach(function (n) {
                    var chip = document.createElement('span');
                    chip.className = 'qt-writer__chip qt-writer__chip--privacy';
                    chip.textContent = n.message;
                    chip.title = 'Just a quiet reminder — the writer decides.';
                    privacyWrap.appendChild(chip);
                });
            }
        }

        textarea.addEventListener('input', run);
        run();
    });
})();
