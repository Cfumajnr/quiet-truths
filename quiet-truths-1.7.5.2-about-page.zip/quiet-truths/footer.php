<?php
/**
 * Quiet Truths — Footer
 *
 * The closing line changes by page. It is not a slogan repeated
 * everywhere; each surface has its own quiet sentence that meets
 * the reader where they are.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

$qt_loader = get_stylesheet_directory() . '/app/presentation/components/loader.php';
if (file_exists($qt_loader)) {
    require_once $qt_loader;
}

/**
 * Return the footer closing line for the current page.
 *
 * Each surface has its own sentence — the core Quiet Truths line only
 * appears at the foot of the Home page, exactly as intended.
 */
function qt_footer_closing_line(): string
{
    // Home page — core line, only here.
    if (is_front_page() || is_home()) {
        return __('The website whispers, so stories can be heard.', 'quiet-truths');
    }

    // Individual story page.
    if (is_singular('qt_story')) {
        return __('For a little while, this is someone else\'s truth. Stay long enough to hear it.', 'quiet-truths');
    }

    // Identify the current page by path so any slug-named page gets the
    // right line — robust to /about/, /about-us/, /leave-a-story/,
    // /leave-your-story/, /writer/, /writer-to-quiet-truths/, etc.
    $path = '';
    if (is_page() || is_singular('page')) {
        $post = get_queried_object();
        if ($post instanceof \WP_Post && 'page' === $post->post_type) {
            $path = (string) $post->post_name;
        }
    }

    $contains = static function (string $haystack, array $needles): bool {
        foreach ($needles as $n) {
            if ('' !== $n && false !== strpos($haystack, $n)) {
                return true;
            }
        }
        return false;
    };

    // Leave a story page.
    if ($contains($path, ['leave', 'submit', 'contribute', 'share', 'your-story'])) {
        return __('There are stories we carry quietly until we find somewhere to leave them.', 'quiet-truths');
    }

    // Writer → Quiet Truths page.
    if ($contains($path, ['writer', 'writing', 'author'])) {
        return __('Sometimes, writing it down is the first way a truth can be heard.', 'quiet-truths');
    }

    // About page.
    if ($contains($path, ['about', 'house', 'why', 'mission'])) {
        return __('Quiet Truths exists for the things people carry, but do not always know how to say.', 'quiet-truths');
    }

    // Journals archive / single journal — extend the writer line softly.
    if (is_post_type_archive('qt_journal') || is_singular('qt_journal')) {
        return __('Some truths are carried further by people willing to sign their names.', 'quiet-truths');
    }

    // Rooms, story archive, search, 404, others: a neutral closing,
    // not the home slogan.
    return __('Every truth held here is read slowly, and held with care.', 'quiet-truths');
}
?>
<footer class="qt-footer">
    <p class="qt-footer__closing">
        <?php echo esc_html(qt_footer_closing_line()); ?>
    </p>

    <div class="qt-footer__mark" aria-hidden="true"></div>

    <nav class="qt-footer__nav" aria-label="<?php echo esc_attr__('Footer', 'quiet-truths'); ?>">
        <?php
        if (function_exists('qt_footer_nav')) {
            qt_footer_nav();
        }
        ?>
    </nav>

    <p class="u-text-center u-text-subtle u-mt-xl" style="font-family:var(--font-interface);font-size:var(--text-xs)">
        &copy; <?php echo esc_html(date_i18n('Y')); ?> <?php echo esc_html__('Quiet Truths', 'quiet-truths'); ?> —
        <?php echo esc_html__('stories kept with dignity', 'quiet-truths'); ?>
    </p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
