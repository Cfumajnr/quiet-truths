<?php
/**
 * Quiet Truths — Room archive (taxonomy: qt_room)
 *
 * Uses the main WordPress query (set to 12 posts per page by
 * Application::roomArchivePagination). No duplicate WP_Query.
 *
 * @package QuietTruths
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header();

$qt_term = get_queried_object();
$qt_slug = ($qt_term instanceof WP_Term) ? $qt_term->slug : '';

$qt_room_meta = defined('QT_ROOMS') ? QT_ROOMS : [];
$qt_data      = $qt_room_meta[$qt_slug] ?? [
    'name'        => ($qt_term instanceof WP_Term) ? $qt_term->name : __('A room', 'quiet-truths'),
    'description' => ($qt_term instanceof WP_Term) ? (string) term_description($qt_term) : '',
];
?>

<main id="qt-main">
    <?php qt_room_header($qt_slug, $qt_data['name'], $qt_data['description']); ?>

    <?php
    // The feel of the room — computed from its own stories.
    if (class_exists(\QuietTruths\Core\Rooms::class)) {
        $qt_atmo = \QuietTruths\Core\Rooms::atmosphere($qt_slug);
        qt_room_atmosphere($qt_atmo);
    }
    ?>

    <section class="story-feed" style="padding-top:0">
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <?php qt_story_panel(get_the_ID()); ?>
            <?php endwhile; ?>
        <?php else : ?>
            <?php qt_gentle_notice('reflection', __('This room is still being furnished. Stories left here will appear when they are given a place.', 'quiet-truths')); ?>
        <?php endif; ?>
    </section>

    <?php if ($wp_query->max_num_pages > 1) : ?>
        <?php qt_pagination(); ?>
    <?php endif; ?>

    <?php
    // The house leading you onward, across the invisible layer.
    if (class_exists(\QuietTruths\Core\Rooms::class)) {
        $qt_cross = \QuietTruths\Core\Rooms::suggestedFrom($qt_slug, 3);
        qt_cross_room_suggest($qt_cross, $qt_data['name']);
    }
    ?>

    <section class="starting-point">
        <p class="starting-point__label"><?php echo esc_html__('Back to the collection', 'quiet-truths'); ?></p>
        <?php qt_button(home_url('/stories/'), __('All stories', 'quiet-truths'), 'quiet'); ?>
    </section>
</main>

<?php get_footer(); ?>
